<? 
 $dbhost = "rsukemayoran.jakarta.go.id";
 $dbuser="c134rsukemayoran";
 $dbpass="serdang123";
 $dbname="c1341234";
 $koneksi = mysql_connect($dbhost,$dbuser,$dbpass) or die ("Gagal Koneksi");
 mysql_select_db($dbname,$koneksi);
?>