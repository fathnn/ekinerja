<?php
include"config/koneksi.php";

$src = addslashes($_POST['src']);
$query = mysql_query('select * from skp where skp like "%'.$src.'%" ');
while($data=mysql_fetch_array($query)){
	echo '<span class="pilihan" data-waktu="'.$data['waktu'].'"  onclick="pilih_kota(\''.$data['skp'].'\');hideStuff(\'suggest\');">'.$data['skp'].'</span>';
}
?>