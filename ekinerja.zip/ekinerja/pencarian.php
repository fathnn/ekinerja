<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="shortcut icon" href="favicon.ico">
<link href="css/print.css" rel="stylesheet">
</head>
	<style>
body {
	font-family: "Arial", serif;
	line-height: 1.25;
	padding: 40px 20px;
}
.header{
	text-align: center;
	border-bottom: 1px solid #ddd;
}
table {
	border: 1px solid green;
	border-collapse: collapse;
	margin: 0;
	padding: 0;
	width: 100%;
}
table caption {
	font-size: 1.5em;
	margin: .25em 0 .75em;
}
table tr {
	background: ;
	border: 1px solid green;
	padding: .35em;
}
table th,
table td {
	padding: .625em;
	text-align: center;
}
table th {
	font-size: .85em;
	letter-spacing: .1em;
	text-transform: uppercase;

}
table td img {
	text-align: center;
}
@media screen and (max-width: 600px) {
	table {
		border: 0;
	}
	table caption {
		font-size: 1.3em;
	}
	table thead {
		display: none;
	}
	table tr {
		border-bottom: 3px solid ;
		display: block;
		margin-bottom: .725em;
	}
	table td {
		border-bottom: 1px solid ;
		display: block;
		font-size: .8em;
		text-align: right;
	}
	table td:before {
		content: attr(data-label);
		float: left;
		font-weight: bold;
		text-transform: uppercase;
	}
	table td:last-child {
		border-bottom: 0;
	}
}
	</style>
<body >

<?  
	include"config/koneksi.php";
	$tm="$_POST[tahun]-$_POST[bulan]-28";
	$tgl=$tm;
	$periode=$_POST['bulan']-$_POST['tahun'];
	$day = date('F Y', strtotime($periode));
	$ukpd=$_POST['ukpd'];
	$per=explode('-',$tgl);
	$bln=$per[1];
	$thn=$per[0];
	$waktu= date ('H:i:s');
	$tampil=mysql_query("select * from pencapaian where 
						 Month(pencapaian.tanggal)='$bln' 
						 and Year(pencapaian.tanggal)='$thn' and id_ukpd LIKE '%$ukpd%' 
						 order by id_pencapaian ASC  ");
	echo "
	<div class='header'>
	<h2 class='head' >LAPORAN PENGGAJIAN   </h2><p>
	</div>
	Periode : $tgl
	<table class='tabel'>
	<thead>
  <tr> 
    <td rowspan='2'>No</td>
    <td rowspan='2'>NIP</td>
    <td  rowspan='2'>Nama </td>
    <!--<td  rowspan='2'>Npwp</td>-->
    <!--<td rowspan='2'>Norek</td>-->
    <td  rowspan='2'>Masa Kerja</td>
    <td rowspan='2'>Gaji Pokok</td>
    <td rowspan='2'>Bruto</td>
    <td rowspan='2'>Tunjangan</td>
    <td colspan='5'>Kehadiran</td>
    <td colspan='5'>Potongan</td>
    <td rowspan='2'>BPJS Kesehatan</td>
    <td colspan='3'>BPJS Ketenaga Kerjaan</td>
    <td rowspan='2'>BHU</td>
    <td rowspan='2'>Tunj. Validasi</td>
    <td rowspan='2'>Tot. Pot Absensi &amp; BPJS</td>
    <td  rowspan='2'>Tunj Bersih</td>
    <td rowspan='2'>Hasil</td>
  </tr>
  <tr> 
    <td >Alpha</td>
    <td >Sakit 1 s/d 2 Hr</td>
    <td >Sakit &gt; 2 Hr</td>
    <td >Izin</td>
    <td >Telat</td>
    <td>Alpha</td>
    <td>Sakit 1 s/d 2 Hr</td>
    <td>Sakit &gt; 2 Hr</td>
    <td>Izin</td>
    <td >Tlat</td>
    <td >JKK &amp; JKM</td>
    <td >IJHT</td>
    <td >JP</td>
  </tr>
  </thead>
  <tbody>";
  $no=1;
  while($dt=mysql_fetch_array($tampil)){;
  
  	$bag=mysql_query("select * from bagian where id_bag='$dt[id_bag]'");
	$bagian=mysql_fetch_array($bag);
		
	$peg=mysql_query("select * from pegawai where nip='$dt[nip]'");
	$pgw=mysql_fetch_array($peg);
	$bpjsks=$pgw['bpjsks'];
	$bpjsjkk=$pgw['bpjsjkk'];
	$bpjsijht=$pgw['bpjsijht'];
	$bpjsjp=$pgw['bpjsjp'];
	
	$jab=mysql_query("select * from jabatan where id_jab='$dt[id_jab]'");
	$jabatan=mysql_fetch_array($jab);
	
	
	$waktu_k=mysql_query("select * from waktu_k where 
						 Month(waktu_k.tanggal)='$bln' 
						 and Year(waktu_k.tanggal)='$thn' and nip='$dt[nip]'
						 order by id_waktu_k ASC ");
	
	$penyerapan=mysql_query("select * from penyerapan where 
						 Month(penyerapan.tanggal)='$bln' 
						 and Year(penyerapan.tanggal)='$thn' and id_ukpd LIKE '%$ukpd%'");
	while($pny=mysql_fetch_array($penyerapan)){
	$n_penyerapan=$pny['nilai'];
	}
						 
        $wk=mysql_fetch_array($waktu_k);
		$sakit1=$wk['sakit1'];
		$sakit2=$wk['sakit2'];
		$izin=$wk['izin'];
		$alpha=$wk['alpha'];
		$telat=$wk['telat'];
		$anggaran=$n_penyerapan*0.2;
		$nilai=$dt['nskp']+$dt['nprilaku']+$anggaran;
		$tun_val=$dt['tunjangan']*$nilai/100;
		$tun_val1=number_format($tun_val,0);
		$hsakit1=($wk['sakit1']*0.01)*$tun_val;
		$hsakit1t=number_format($hsakit1,0);
		$hsakit2=($wk['sakit2']*0.02)*$tun_val;
		$hsakit2t=number_format($hsakit2,0);
		$htelat=(($wk['telat']/450)*0.025)*$tun_val;
		$htelat_t=number_format($htelat,0);
		$hizin=($wk['izin']*0.025)*$tun_val;
		$hizint=number_format($hizin,0);
		$halpha=($wk['alpha']*0.05)*$tun_val;
		$halphat=number_format($halpha,0);
		$potongan_tun=$htelat+$hsakit1+$hsakit2+$hizin+$halpha;
		$potongan=number_format($potongan_tun,0);
		$bpjskesehatan=$dt['gapok']*$bpjsks;
		$bpjskes=number_format($bpjskesehatan,0);
		$bpjsk1=$dt['gapok']*$bpjsjkk;
		$bpjsk2=$dt['gapok']*$bpjsijht;
		$bpjsk3=$dt['gapok']*$bpjsjp;
		$bpjstenagakerja=$bpjsjkk+$bpjsijht+$bpjsjp;
		$potongan_tun=$htelat+$hsakit1+$hsakit2+$hizin+$halpha+$bpjskesehatan+$bpjsk1+$bpjsk2+$bpjsk3;
		$potongan=number_format($potongan_tun,0);
		$bpjstenag=number_format($bpjstenagakerja,0);
		$tunjangan_bersih=$tun_val-$potongan_tun;
		$tun_pendapatan=number_format($tunjangan_bersih,0);
		$tunjangan=number_format($dt['tunjangan'],0);
		$gapok=number_format($dt['gapok'],0);
		$bruto=number_format($dt['bruto'],0);
		$bpjsjkkt=number_format($bpjsk1,0);
		$bpjsijhtt=number_format($bpjsk2,0);
		$bpjsjpt=number_format($bpjsk3,0);
		$total=$dt['gapok']+$tunjangan_bersih;
		$subtotal=number_format($total,0);
		$idst=$dt['id_status'];
	$st=mysql_query("select * from status where id_status='$idst'");
	$b=mysql_fetch_array($st);
	$status=$b['nilai'];
	$nama=$dt['nama'];
	$nip=$dt['nip'];
	//$npwp=$pgw['npwp'];
	//$norek=$pgw['norek'];
	$masakerja=$dt['masa_kerja'];	
  echo "<tr valign='middle' align='center'>
  <td scope='row' data-label='No'>$no</td>
  <td data-label='Nip'>'$nip</td>
    <td data-label='Nama'>$nama</td>
	<!--<td data-label='NPWP'>$npwp</td>-->
	<!--<td data-label='Norek'>$norek</td>-->
	 <td data-label='Masa Kerja'>$dt[masa_kerja]</td>
	 <td data-label='Gaji Pokok'>Rp.$gapok</td>
	 <td data-label='Gaji Pokok'>Rp.$bruto</td>
	<td data-label='Tunjangan'>Rp.$tunjangan</td>
	<td data-label='Alpha'>$alpha.Hari</td>
	<td data-label='Sakit 1-2 Hari'>$sakit1.Hari</td>
	<td data-label='Sakit > 2'>$sakit2.Hari</td>
	<td data-label='Izin'>$izin.Hari</td>
	<td data-label='Telat'>$telat.Menit</td>
	<td data-label='Potongan Alpha'>Rp.$halphat</td>
	<td data-label='Potongan Sakit 1-2 Hari'>Rp.$hsakit1t</td>
	<td data-label='Potongan Sakit > 2 Hari'>Rp.$hsakit2t</td>
	<td data-label='Potongan Izin'>Rp.$hizint</td>
	<td data-label='Potongan Telat'>Rp.$htelat_t</td>
	<td data-label='BPJS Kesehatan'>Rp.$bpjskes</td>
	<td data-label='BPJS JKK & JKM'>Rp.$bpjsjkkt</td>
	<td data-label='BPJS IJHT'>Rp.$bpjsijhtt</td>
	<td data-label='BPJS JP'>Rp.$bpjsjpt</td>
	<td data-label='Nilai Validasi'>$nilai%</td>
	<td data-label='Tunjangan Validasi'>Rp.$tun_val1</td>
	<td data-label='Total Potongan'>Rp.$potongan</td>
	<td data-label='Tunjangan Pendapatan'>Rp.$tun_pendapatan</td>
	<td data-label='Gapok + Tun.Bersih'>Rp.$subtotal</td>
  </tr>
  ";
  $no++;
  }
echo"</tbody><table>";
?>
<div style="text-align:center;padding:20px;">
	<input class="noPrint" type="button" value="Cetak Halaman" onclick="window.print()">
	 <form action='cetak.php' method='post' enctype='multipart/form-data' >
	 <input type="hidden" name="tanggal" value="<? echo"$tgl"; ?>" ><input type=submit value="export excel"> </form>
	</div>
</div>
</body>
</html>
