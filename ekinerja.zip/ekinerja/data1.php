<?php
	// require connection.php
	require('config/koneksi.php');

	$q = strtolower($_GET['term']);
	$query = "select * from skp where skp like '%$q%' order by kd_skp asc";
	$query = mysql_query($query);
	$num = mysql_num_rows($query);
   	if($num > 0){
		while ($row = mysql_fetch_array($query)){
			$row_set[] = htmlentities(stripslashes($row[1]));
		}
		echo json_encode($row_set);
	}
?>