<?php 
session_start();
error_reporting(0);
include "timeout.php";
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SISTEM INFORMASI KEPEGAWAIAN</title>
    <!-- Core CSS - Include with every page -->
    <link href="assets/plugins/bootstrap/bootstrap.css" rel="stylesheet" />
    <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link href="assets/plugins/pace/pace-theme-big-counter.css" rel="stylesheet" />
    <link href="assets/css/style.css" rel="stylesheet" />
	<link href="assets/css/style.css" rel="stylesheet" />
    <link href="assets/css/main-style.css" rel="stylesheet" />
	    <!-- Page-Level CSS -->
    <link href="assets/plugins/morris/morris-0.4.3.min.css" rel="stylesheet" />
	<script src="js/jquery-1.4.js" type="text/javascript"></script>
<script src="js/superfish.js" type="text/javascript"></script>
<script src="js/hoverIntent.js" type="text/javascript"></script>

	<script type="text/javascript">
      $(document).ready(function(){
			   $('ul.nav').superfish();
		  });
  </script>
   </head>
<body>
    <!--  wrapper -->
    <div id="wrapper">
        <!-- navbar top -->
        <nav class="navbar navbar-default navbar-fixed-top" role="navigation" id="navbar">
            

        </nav>
        <!-- end navbar top -->

        <!-- navbar side -->
        <nav class="navbar-default navbar-static-side" role="navigation">
            <!-- sidebar-collapse -->
            <div class="sidebar-collapse">
                <!-- side-menu -->
                <ul class="nav" id="side-menu">
                    
      <li> 
        <!-- user image section-->
        <div class="user-section"> 
          <div class="user-section-inner"> </div>
          <div class="user-info"> 
            <div> <strong><? echo"Selamat Datang $_SESSION[namauser] "; ?> </strong></div>
            <div class="user-text-online"> <span class="user-circle-online btn btn-success btn-circle "></span>&nbsp;Online 
            </div>
          </div>
        </div>
        <!--end user image section-->
      </li>
                    
      <li class="sidebar-search"> 
        <!-- search section-->
        <div class="input-group custom-search-form"> 
          <input type="text" class="form-control" placeholder="Search...">
          <span class="input-group-btn"> 
          <button class="btn btn-default" type="button"> <i class="fa fa-search"></i> 
          </button>
          </span> </div>
        <!--end search section-->
      </li>
                    
      <li class="selected"> <a href=""><i class="fa fa-dashboard fa-fw"></i>Dashboard</a> 
      </li>

          <?php if ($_SESSION['leveluser']=='3'){ ?>
	<li><a class="border link linkback" href="?module=absensi">Home</a></li>
	<li>
	<a class="border link linkback" href="?module=pegawai&act=detail&id=<?php echo $_SESSION['namauser'];?>">Data Pegawai</a>
	</li>
	<li><a class="border link linkback" href="?module=skptahunan&act=detail&nip=<?php echo $_SESSION['namauser'];?>">E Kinerja</a>
		<ul>
          <li><a href="?module=skptahunan&act=detail&nip=<?php echo $_SESSION['namauser'];?>" class="li">Input 
            SKP Tahunan</a></li>
          <li><a href="?module=kinerja&act=detail&nip=<?php echo $_SESSION['namauser'];?>" class="li">Input 
            Aktifitas Utama</a></li>
          <li><a href="?module=aktifitas&act=detail&nip=<?php echo $_SESSION['namauser'];?>" class="li">Aktifitas 
            Tambahan</a></li>
          <li><a href="?module=kreatifitas&act=detail&nip=<?php echo $_SESSION['namauser'];?>" class="li">Kreatifitas</a></li>
        </ul>
		</li>
		<li><a class="border link linkback" href="logout.php">Logout</a></li>
		  
		          
     <?php 
	}
	if ($_SESSION['leveluser']=='1'){
	?>
    	<li><a class="border link linkback" href="?module=pegawai">Data Pegawai</a>
        	
        <ul>
          <li><a href="?module=bagian" class="li">Data Bagian</a></li>
          <li><a href="?module=jabatan" class="li">Data Jabatan</a></li>
        </ul>
        </li>
        <li><a class="border link linkback" href="?module=pelatihan">Data Pelatihan</a></li>
        <li><a class="border link linkback" href="?module=kjb">Data Kenaikan Jabatan</a></li>
		<li><a class="border link linkback" href="?module=skp">E Kinerja</a>
		<ul>
          <li><a href="?module=skptahunan&act=detail&nip=<?php echo $_SESSION['namauser'];?>" class="li">SKP 
            Tahunan</a></li>
          <li><a href="?module=kinerja&act=detail&nip=<?php echo $_SESSION['namauser'];?>" class="li">Aktivitas 
            Utama</a></li>
          <li><a href="?module=aktifitas&act=detail&nip=<?php echo $_SESSION['namauser'];?>" class="li">Aktifitas 
            Tambahan</a></li>
          <li><a href="?module=kreatifitas&act=detail&nip=<?php echo $_SESSION['namauser'];?>" class="li">Kreatifitas</a></li>
          <li><a href="?module=unit&act=detail&id_bag=<?php echo $_SESSION['id_bag']; ?>" class="li">Kinerja 
            Bawahan</a></li>
        </ul>
		</li>
		
		<?php } 
	if($_SESSION['leveluser']=='1' or $_SESSION['leveluser']=='2'){
	?>
		<li><a class="border link linkback" href="#">Laporan</a>
        	
        <ul>
          <li><a href="laporan_pegawai.php" class="li" target="_blank">Laporan 
            Data Pegawai</a></li>
          <li><a href="?module=lap_absensi" class="li">Laporan Data Absensi</a></li>
          <li><a href="laporan_pelatihan.php" target="_blank" class="li">Laporan 
            Data pelatihan</a></li>
          <li><a href="laporan_kjp.php" target="_blank" class="li">Laporan Kenaikan 
            Jabatan</a></li>
        </ul>
        </li>
		<li><a class="border link linkback" href="logout.php">Logout</a></li>
	<?php } ?>
        
      <li class="clear"></li>
    </ul>
        <!-- second-level-items -->
      </li>
                </ul>
                <!-- end side-menu -->
            </div>
            <!-- end sidebar-collapse -->
        </nav>
        <!-- end navbar side -->
        <!--  page-wrapper -->
        <div id="page-wrapper">

            <div class="row">
                <!-- Page Header -->
                
      <div class="col-lg-12"> </div>
                <!--End Page Header -->
            </div>

            <div class="row">
                <!-- Welcome -->
                 <div id="wrapper">
        <!-- navbar top -->
        <nav class="navbar navbar-default navbar-fixed-top" role="navigation" id="navbar">
            

        </nav> </div><img src="images/banner1.png" width="1000" height="200">
     <?php include "data.php"; ?>
                <!--end  Welcome -->
            </div>

      </div>
            </div>


         


        </div>
        <!-- end page-wrapper -->

    </div>
    <!-- end wrapper -->

    <!-- Core Scripts - Include with every page -->
    <script src="assets/plugins/jquery-1.10.2.js"></script>
    <script src="assets/plugins/bootstrap/bootstrap.min.js"></script>
    <script src="assets/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="assets/plugins/pace/pace.js"></script>
    <script src="assets/scripts/siminta.js"></script>
    <!-- Page-Level Plugin Scripts-->
    <script src="assets/plugins/morris/raphael-2.1.0.min.js"></script>
    <script src="assets/plugins/morris/morris.js"></script>
    <script src="assets/scripts/dashboard-demo.js"></script>

</body>

</html>
