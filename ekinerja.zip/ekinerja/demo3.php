<?php  
// Koneksi
mysql_connect("localhost","root","");  
mysql_select_db("kpi");  
$result = mysql_query("select * from skp");
$jsArray = "var prdName = new Array();\n";
echo 'Kode Produk : <select name="prdId" onchange="document.getElementById(\'prd_name\').value = prdName[this.value]">';
echo '<option>-------</option>';
while ($row = mysql_fetch_array($result)) {
    echo '<option value="' . $row['kd_skp'] . '">' . $row['kd_skp'] . '</option>';
    $jsArray .= "prdName['" . $row['kd_skp'] . "'] = '" . addslashes($row['skp']) . "';\n";
}
echo '</select>';
?>
<br />
Nama Produk : <input type="text" name="prod_name" id="prd_name"/>
<script type="text/javascript">
<? echo $jsArray; ?>
</script>
