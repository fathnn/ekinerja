﻿<?php 
session_start();
error_reporting(0);
include "timeout.php";
$bagian=$_SESSION['id_bag'];
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>SISTEM INFORMASI KEPEGAWAIAN</title>
<link rel="stylesheet" href="css/style3.css" type="text/css"  />
<script src="js/jquery-1.4.js" type="text/javascript"></script>
<script src="js/superfish.js" type="text/javascript"></script>
<script src="js/hoverIntent.js" type="text/javascript"></script>

	<script type="text/javascript">
      $(document).ready(function(){
			   $('ul.nav').superfish();
		  });
  </script>
</head>

<body>
<div id="container">
<div id="header">
<span class="judul">E - KINERJA PEGAWAI NON PNS RSUD KEMAYORAN</span><br />
<span class="judul2"></span></br>
</div>
<div class="judul2"><? 
echo"Selamat Datang $_SESSION[namauser] "; ?></div>
<div id="menu">
	<ul class="nav">
	<?php if ($_SESSION['leveluser']=='3'){ ?>
	<li><a class="border link linkback" href="?module=absensi">Home</a></li>
	<li>
	<a class="border link linkback" href="?module=pegawai&act=detail&id=<?php echo $_SESSION['namauser'];?>">Data Pegawai</a>
	</li>
	<li><a class="border link linkback" href="?module=skptahunan&act=detail&nip=<?php echo $_SESSION['namauser'];?>">E Kinerja</a>
		<ul>
          <li><a href="?module=skptahunan&act=detail&nip=<?php echo $_SESSION['namauser'];?>" class="li">Input 
            SKP Tahunan</a></li>
          <li><a href="?module=kinerja&act=detail&nip=<?php echo $_SESSION['namauser'];?>" class="li">Input 
            Aktifitas Utama</a></li>
          <li><a href="?module=aktifitas&act=detail&nip=<?php echo $_SESSION['namauser'];?>" class="li">Aktifitas 
            Tambahan</a></li>
          <li><a href="?module=kreatifitas&act=detail&nip=<?php echo $_SESSION['namauser'];?>" class="li">Kreatifitas</a></li>

        </ul>
		</li>
		<li><a class="border link linkback" href="logout.php">Logout</a></li>
	<?php 
	}
	if ($_SESSION['leveluser']=='1'){
	?>
    	<li><a class="border link linkback" href="?module=pegawai">Data Pegawai</a>
        	
        <ul>
          <li><a href="?module=bagian" class="li">Data Bagian</a></li>
          <li><a href="?module=jabatan" class="li">Data Jabatan</a></li>
        </ul>
        </li>
        <li><a class="border link linkback" href="?module=pelatihan">Data Pelatihan</a></li>
        <li><a class="border link linkback" href="?module=kjb">Data Kenaikan Jabatan</a></li>
		<li><a class="border link linkback" href="?module=skp">E Kinerja</a>
		<ul>
          <li><a href="?module=skptahunan&act=detail&nip=<?php echo $_SESSION['namauser'];?>" class="li">SKP 
            Tahunan</a></li>
          <li><a href="?module=kinerja&act=detail&nip=<?php echo $_SESSION['namauser'];?>" class="li">Aktivitas 
            Utama</a></li>
          <li><a href="?module=aktifitas&act=detail&nip=<?php echo $_SESSION['namauser'];?>" class="li">Aktifitas 
            Tambahan</a></li>
          <li><a href="?module=kreatifitas&act=detail&nip=<?php echo $_SESSION['namauser'];?>" class="li">Kreatifitas</a></li>
          <li><a href="?module=unit&act=detail&id_bag=<?php echo $_SESSION['id_bag']; ?>" class="li">Kinerja 
            Bawahan</a></li>
        </ul>
		</li>
		
	<?php } 
	if($_SESSION['leveluser']=='1' or $_SESSION['leveluser']=='2'){
	?>
		<li><a class="border link linkback" href="#">Laporan</a>
        	
        <ul>
          <li><a href="laporan_pegawai.php" class="li" target="_blank">Laporan 
            Data Pegawai</a></li>
          <li><a href="?module=lap_absensi" class="li">Laporan Data Absensi</a></li>
          <li><a href="laporan_pelatihan.php" target="_blank" class="li">Laporan 
            Data pelatihan</a></li>
          <li><a href="laporan_kjp.php" target="_blank" class="li">Laporan Kenaikan 
            Jabatan</a></li>
        </ul>
        </li>
		<li><a class="border link linkback" href="logout.php">Logout</a></li>
	<?php } ?>
        <li class="clear"></li>
    </ul>
</div>
<div id="content">
<div class="form">
	<?php include "data.php"; ?>
</div>
</div>
<div id="footer">Copyright &copy; 2012 by Fauzan Ozan(achmadfauzan.ozan@gmail.com).|| Share by <a href="http://rsukemayoran.jakarta.go.id/" target="_blank">website RSU Kemayoran</a></div>
</div>
</body>
</html>
