-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 01, 2019 at 04:28 AM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ekinerja`
--

-- --------------------------------------------------------

--
-- Table structure for table `absensi`
--

CREATE TABLE `absensi` (
  `id_absensi` int(10) NOT NULL,
  `nip` varchar(30) NOT NULL,
  `tanggal_absen` date NOT NULL,
  `jam_masuk` time NOT NULL,
  `jam_keluar` time NOT NULL,
  `status_masuk` enum('Y','N') NOT NULL DEFAULT 'N',
  `status_keluar` enum('Y','N') NOT NULL DEFAULT 'N',
  `ket` char(2) NOT NULL DEFAULT 'NA',
  `terlambat` enum('Y','N') NOT NULL DEFAULT 'N'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `bagian`
--

CREATE TABLE `bagian` (
  `id_bag` varchar(4) NOT NULL,
  `n_bag` varchar(25) NOT NULL,
  `id_skpd` varchar(10) NOT NULL,
  `id_ukpd` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bagian`
--

INSERT INTO `bagian` (`id_bag`, `n_bag`, `id_skpd`, `id_ukpd`) VALUES
('B01', 'UKP', '1.02', '1.02.058'),
('B02', 'UKM', '1.02', '1.02.058'),
('B03', 'Tata Usaha', '1.02', '1.02.058'),
('B04', 'Kec Duren Sawit', '1.02', '1.02.058'),
('B05', 'Kel Duren Sawit', '1.02', '1.02.058'),
('B06', 'Kel Pondok Kopi 1', '1.02', '1.02.058'),
('B07', 'Kel Pondok Kopi 2', '1.02', '1.02.058'),
('B08', 'Kel Pondok Bambu1', '1.02', '1.02.058'),
('B09', 'Kel Pondok Bambu 2', '1.02', '1.02.058'),
('B10', 'Kel Klender 1', '1.02', '1.02.058'),
('B11', 'Kel Klender 2', '1.02', '1.02.058'),
('B12', 'Kel Klender 3', '1.02', '1.02.058'),
('B13', 'Kel Malaka Jaya', '1.02', '1.02.058'),
('B14', 'Kel Malaka Sari', '1.02', '1.02.058'),
('B15', 'Kel Pondok Kelapa', '1.02', '1.02.058');

-- --------------------------------------------------------

--
-- Table structure for table `disiplin`
--

CREATE TABLE `disiplin` (
  `id_disiplin` varchar(8) NOT NULL,
  `nip` varchar(30) NOT NULL,
  `tanggal` date NOT NULL,
  `k_diri` int(8) NOT NULL,
  `k_penampilan` int(8) NOT NULL,
  `k_seragam` int(8) NOT NULL,
  `k_alat` int(8) NOT NULL,
  `k_ruangan` int(8) NOT NULL,
  `k_sarana` int(8) NOT NULL,
  `point` int(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `h_jabatan`
--

CREATE TABLE `h_jabatan` (
  `idh` int(11) NOT NULL,
  `idkjb` varchar(4) NOT NULL,
  `jab_old` varchar(20) NOT NULL,
  `tgl_ajb` date NOT NULL,
  `jabatan_baru` varchar(20) NOT NULL,
  `tgl_kjb` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jabatan`
--

CREATE TABLE `jabatan` (
  `id_jab` varchar(4) NOT NULL,
  `id_skpd` varchar(10) NOT NULL,
  `id_ukpd` varchar(10) NOT NULL,
  `n_jab` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jabatan`
--

INSERT INTO `jabatan` (`id_jab`, `id_skpd`, `id_ukpd`, `n_jab`) VALUES
('J01', '', '', 'ADMINISTRASI UMUM'),
('J02', '1.02', '1.02.058', 'ADM BPJS'),
('J03', '1.02', '1.02.058', 'ADM KASIR'),
('J04', '1.02', '1.02.058', 'ADM LOKET'),
('J05', '1.02', '1.02.058', 'ADM PENGADAAN'),
('J06', '1.02', '1.02.058', 'ADM SURAT & UMUM'),
('J07', '1.02', '1.02.058', 'ADM YANMED'),
('J08', '1.02', '1.02.058', 'ADM. JANGMED'),
('J09', '1.02', '1.02.058', 'ADM. KEPERAWATAN'),
('J10', '1.02', '1.02.058', 'AKUNTING'),
('J11', '1.02', '1.02.058', 'ANALIS LAB'),
('J12', '1.02', '1.02.058', 'APOTEKER'),
('J13', '1.02', '1.02.058', 'ASS APOTEKER'),
('J14', '1.02', '1.02.058', 'BIDAN'),
('J15', '1.02', '1.02.058', 'BIDAN RANAP'),
('J16', '1.02', '1.02.058', 'BIDAN VK'),
('J17', '1.02', '1.02.058', 'DIKLAT & PENGEMBANGA'),
('J18', '1.02', '1.02.058', 'DOKTER'),
('J19', '1.02', '1.02.058', 'DOKTER GIGI'),
('J20', '1.02', '1.02.058', 'FISIOTERAPI'),
('J21', '1.02', '1.02.058', 'HUMAS & PEMASARAN'),
('J22', '1.02', '1.02.058', 'IPSRS'),
('J23', '1.02', '1.02.058', 'IT'),
('J24', '1.02', '1.02.058', 'K3'),
('J25', '1.02', '1.02.058', 'KA. SATPEL'),
('J26', '1.02', '1.02.058', 'KEPEGAWAIAN'),
('J27', '1.02', '1.02.058', 'NUTRISIONIS'),
('J28', '1.02', '1.02.058', 'P. JAWAB/KARU'),
('J29', '1.02', '1.02.058', 'P. PIUTANG'),
('J30', '1.02', '1.02.058', 'PENGEMUDI'),
('J31', '1.02', '1.02.058', 'PERAWAT'),
('J32', '1.02', '1.02.058', 'PERAWAT GIGI'),
('J33', '1.02', '1.02.058', 'PERAWAT HCU'),
('J34', '1.02', '1.02.058', 'PERAWAT IGD'),
('J35', '1.02', '1.02.058', 'PERAWAT OK'),
('J36', '1.02', '1.02.058', 'PERAWAT POLI SPES'),
('J37', '1.02', '1.02.058', 'PERAWAT RANAP ANAK'),
('J38', '1.02', '1.02.058', 'PERAWAT RANAP DEWASA'),
('J39', '1.02', '1.02.058', 'PEREKAM MEDIS'),
('J40', '1.02', '1.02.058', 'PERENCANAAN'),
('J41', '1.02', '1.02.058', 'RADIOGRAFER'),
('J42', '1.02', '1.02.058', 'REFRAKSIONIS'),
('J43', '1.02', '1.02.058', 'SANITARIAN'),
('J44', '1.02', '1.02.058', 'EPIDEMIOLOGI'),
('J45', '1.02', '1.02.058', 'VERIFIKATOR');

-- --------------------------------------------------------

--
-- Table structure for table `kinerja`
--

CREATE TABLE `kinerja` (
  `id_kinerja` varchar(8) NOT NULL,
  `nip` varchar(30) NOT NULL,
  `kd_skp` varchar(160) NOT NULL,
  `uraian` text NOT NULL,
  `jam_mulai` time NOT NULL,
  `jam_akhir` time NOT NULL,
  `jumlah` int(8) NOT NULL,
  `waktu_e` int(8) NOT NULL,
  `tanggal` date NOT NULL,
  `keterangan` varchar(25) NOT NULL,
  `point` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `kompetensi`
--

CREATE TABLE `kompetensi` (
  `id_kompetensi` varchar(8) NOT NULL,
  `nip` varchar(30) NOT NULL,
  `tanggal` date NOT NULL,
  `menganalisa1` int(8) NOT NULL,
  `menganalisa2` int(8) NOT NULL,
  `komunikasi1` int(8) NOT NULL,
  `komunikasi2` int(8) NOT NULL,
  `kerjasama1` int(8) NOT NULL,
  `kerjasama2` int(8) NOT NULL,
  `kecerdasan1` int(8) NOT NULL,
  `kecerdasan2` int(8) NOT NULL,
  `kecerdasan3` int(8) NOT NULL,
  `fokus1` int(8) NOT NULL,
  `fokus2` int(8) NOT NULL,
  `fokus3` int(8) NOT NULL,
  `tanggung1` int(8) NOT NULL,
  `tanggung2` int(8) NOT NULL,
  `tanggung3` int(8) NOT NULL,
  `tanggung4` int(8) NOT NULL,
  `orientasi_k1` int(8) NOT NULL,
  `orientasi_k2` int(8) NOT NULL,
  `inisiatif1` int(8) NOT NULL,
  `inisiatif2` int(8) NOT NULL,
  `disiplin1` int(8) NOT NULL,
  `disiplin2` int(8) NOT NULL,
  `disiplin3` int(8) NOT NULL,
  `orientasi_p1` int(8) NOT NULL,
  `orientasi_p2` int(8) NOT NULL,
  `orientasi_p3` int(8) NOT NULL,
  `point` varchar(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `kreatifitas`
--

CREATE TABLE `kreatifitas` (
  `id_kreatifitas` varchar(8) NOT NULL,
  `nip` varchar(30) NOT NULL,
  `tanggal` date NOT NULL,
  `wm_k` time NOT NULL,
  `wa_k` time NOT NULL,
  `jumlah` int(8) NOT NULL,
  `kreatifitas` varchar(60) NOT NULL,
  `uraian` varchar(150) NOT NULL,
  `keterangan` varchar(25) NOT NULL,
  `point` int(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `k_jabatan`
--

CREATE TABLE `k_jabatan` (
  `idkjb` varchar(4) NOT NULL,
  `nip` varchar(20) NOT NULL,
  `masa_kerja` int(10) NOT NULL,
  `keterangan` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `pegawai`
--

CREATE TABLE `pegawai` (
  `nip` varchar(30) NOT NULL,
  `nama` varchar(40) NOT NULL,
  `tmpt_lahir` varchar(200) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `jenis_kelamin` enum('L','P') NOT NULL,
  `npwp` varchar(25) NOT NULL,
  `norek` varchar(25) NOT NULL,
  `id_status` varchar(15) NOT NULL,
  `status` varchar(8) NOT NULL,
  `id_pendidikan` varchar(8) NOT NULL,
  `alamat` varchar(200) NOT NULL,
  `tgl_masuk` date NOT NULL,
  `id_rumpun` varchar(8) NOT NULL,
  `id_bag` varchar(4) NOT NULL,
  `id_jab` varchar(4) NOT NULL,
  `id_skpd` varchar(10) NOT NULL,
  `id_ukpd` varchar(10) NOT NULL,
  `bpjsks` varchar(8) NOT NULL,
  `bpjsjkk` varchar(8) NOT NULL,
  `bpjsijht` varchar(8) NOT NULL,
  `bpjsjp` varchar(8) NOT NULL,
  `kasatpel` varchar(30) NOT NULL,
  `kasie` varchar(20) NOT NULL,
  `foto` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pegawai`
--

INSERT INTO `pegawai` (`nip`, `nama`, `tmpt_lahir`, `tgl_lahir`, `jenis_kelamin`, `npwp`, `norek`, `id_status`, `status`, `id_pendidikan`, `alamat`, `tgl_masuk`, `id_rumpun`, `id_bag`, `id_jab`, `id_skpd`, `id_ukpd`, `bpjsks`, `bpjsjkk`, `bpjsijht`, `bpjsjp`, `kasatpel`, `kasie`, `foto`) VALUES
('197201261992032003', 'Saulas Donater Rosdiana N', 'Sukabumi', '1972-01-26', 'P', '', '', '', 'PNS', 'PND2', '', '2019-03-01', '', '', '', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', '168365', 'kepalaTU', ''),
('10205519940203201904253', 'Fahmilla Chatra Marvel', 'Yogyakarta', '1994-02-03', 'L', '80.935.149.7-412.000', '15320051767', 'TK-0', 'NON PNS', 'PND4', 'Kp Sugutamu RT/RW 007/022 Kel. Mekarjaya Kec. Sukmajaya, Depok, Jawa Barat', '2019-04-01', 'Rum08', 'B04', 'J23', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519910624201704134', 'dr. Muhammad Adhitya Wicaksono', 'Banjarmasin', '1991-06-24', 'L', '72.848.494.0-015.000', '53520011584', 'K-1', 'NON PNS', 'PND2', 'Jl. Subur Raya no. 11 RT 001/08 Kodepos 12960 Jakarta Selatan Kel. Menteng Atas Kec. Setiabudi ', '2017-04-03', 'Rum04', 'B01', 'J18', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519850228201602145', 'Ahmad Hasan', 'Depok', '1985-02-28', 'L', '70.929.589.3-412.000', '12223137387', 'K-2', 'NON PNS', 'PND2', 'Perumahan Griya Bukit Mas Blok. F2 Rt 03/14 Pancoran Mas, Depok', '2016-02-01', 'Rum04', 'B04', 'J18', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519810908201501047', 'Andina Maryati', 'Padang ', '1981-09-08', 'P', '69.649.461.6-211.006', '50023184550', 'K-0', 'NON PNS', 'PND3', 'Jl. Madrasah II No. 46 RT 08/RW 10 Kel. Duren Sawit Kec. Duren Sawit', '2015-01-01', 'Rum09', 'B04', 'J05', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('1020551983042120190554', 'Andri Harwantono', 'Jakarta', '1983-04-21', 'L', '70.403.873.6-040.7000', '51220135420', 'TK-0', 'NON PNS', 'PND4', 'Jl. Kusuma Selatan A. Blok E7/9 Perumahan Wisma Jaya Aren Jaya Bekasi Timur 17111', '2019-05-02', 'Rum08', 'B04', 'J23', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519820121200306042', 'Vevi Indriana', 'Semarang', '1982-01-21', 'P', '73.590.452.6-008.000', '52423004281', 'K-2', 'NON PNS', 'PND5', 'JL SMP 135 NO 11 A RT 12 RW 07 PONDOK BAMBU - JAKARTA TIMUR ', '2003-06-01', 'Rum08', 'B04', 'J01', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519950109201902249', 'Jamilah', 'Jakarta', '1995-01-09', 'P', '46.081.666.3-003.000', '15323197975', 'TK-0', 'NON PNS', 'PND4', 'JL CIPINANG KEBEMBEM NO 9 RT 02 RW 12 PISANGAN TIMUR - JAKARTA TIMUR', '2019-02-18', 'Rum06', 'B04', 'J13', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519790711200501041', 'Handi', 'Kuningan', '1979-07-11', 'L', '73.552.029.8-008.000', '52423004231', 'K-1', 'NON PNS', 'PND5', 'JL KELURAHAN V RT 11 RW 01 DUREN SAWIT - JAKARTA TIMUR ', '2005-01-01', 'Rum08', 'B04', 'J04', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519841121200405045', 'Tri Indah', 'Klaten ', '1984-11-21', 'P', '55.821.260.1-085.000', '52423004222', 'K-0', 'NON PNS', 'PND5', 'Jl H.Dogol RT 16 RW 07 PONDOK BAMBU-JAKARTA TIMUR', '2004-05-31', 'Rum08', 'B04', 'J04', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519911128201706135', 'Iwan Sunarya Purba ', 'Jagapayung', '1991-02-25', 'L', '72.642.369.2-063.000', '53523073041', 'K-1', 'NON PNS', 'PND4', 'JL HAJI NUAR RT 8 RW 6 KAMPUNG BOJONG INDAH - PONDOK KELAPA- JAKARTA TIMUR ', '2017-07-11', 'Rum06', 'B04', 'J34', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519950712201902246', 'Sri Intan Yulianingsih', 'Tasikmalaya', '1995-07-12', 'P', '82.186.927.8-429.000', '51220134296', 'TK-0', 'NON PNS', 'PND4', 'KP TANGSI RT 003 RW 006 DESA SUKADANAU KECAMATAN CIKARANG BARAT KABUPATEN BEKASI', '2019-02-18', 'Rum06', 'B04', 'J39', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('11020551975082320401044', 'Sri Haryati', 'Jakarta', '1975-08-23', 'P', '47.664.773.0-008.000', '52423004630', 'K-2', 'NON PNS', 'PND5', 'JL NUSA INDAH 5 GG.7 NO 212 RT 12 RW 04 PERUMNAS KLENDER MALAKA JAYA', '2004-01-01', 'Rum08', 'B04', 'J01', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519910212201405164', 'Shinta Febriyanti', 'Jakarta', '1991-02-12', 'P', '46.980.357.1-407.000', '52423003927', 'K-1', 'NON PNS', 'PND4', 'JL H. ILYAS GG. H. MIDIH RT 03 RW 12 NO 32 CIKUNIR JAKA MULYA - BEKASI SELATAN ', '2014-05-02', 'Rum06', 'B04', 'J13', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519750404201301048', 'Abdul Basiyit Ritonga ', 'Sibangkua', '1975-04-04', 'L', '73.593.977.9-008.000', '52423004273', 'K-1', 'NON PNS', 'PND5', 'JL KAMPUNG SUMUR RT 07 RW 17 KLENDER - DUREN SAWIT - JAKARTA TIMUR', '2013-01-01', 'Rum08', 'B04', 'J01', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519900701201901237', 'Ade Sugianto', 'Ciamis', '1990-07-01', 'L', '69.984.558.2-006.000', '50020212552', 'K-0', 'NON PNS', 'PND5', 'JL UJUNG KRAWANG RT 04 RW 05 PULO GEBANG - CAKUNG - JAKARTA TIMUR', '2019-01-07', 'Rum08', 'B04', 'J04', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519691204200301057', 'Sutardi', 'Karang Anyar', '1969-12-04', 'L', '73.658.571.2-403.000', '52423004176', 'K-1', 'NON PNS', 'PND5', 'JL VILA NUSA INDAH 3 RT 02 RW 37 BOJONG KULUR - GUNUNG PUTRI - BOGOR', '2003-01-30', 'Rum08', 'B04', 'J01', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519931212201902247', 'Alex Wijarnoko', 'Karanganyar', '1993-12-21', 'L', '90.694.056.4-528.000', '51220134521', 'TK-0', 'NON PNS', 'PND4', 'jl. laut maluku B2/13, kav tni AL, rt 11 rw 17, duren sawit, jakarta timur', '2019-03-01', 'Rum10', 'B04', 'J39', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519731009201603056', 'Maryani', 'Jasinga', '1973-10-09', 'P', '75.410.929.6-008.000', '50020213681 ', 'TK-0', 'NON PNS', 'PND5', 'Kp.Sumur Rt 010 RW 10 No.69 Kel.Klender kec.Duren Sawit jakarta Timur', '2016-03-01', 'Rum10', 'B04', 'J04', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519850601201603053', 'Vita yunita', 'Jakarta', '1985-06-01', 'P', '58.521.061.0-008.000', '500.20.21385.1', 'K-1', 'NON PNS', 'PND5', 'Jl. Buluh Perindu 1 No 6A Rt 016 Rw 006 pondok bambu, duren sawit, jakarta timur', '2016-03-01', 'Rum10', 'B04', 'J04', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519950520201603054', 'Dimas Pandhanu Kusrianto', 'Kebumen', '1995-05-20', 'L', '75.453.485.7-523.000', '53520007391', 'TK-0', 'NON PNS', 'PND5', 'Jl. Amal Rt. 010 Rw. 001', '2016-03-01', 'Rum10', 'B04', 'J04', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519961128201603055', 'Eka wulandari', 'Sukoharjo', '1996-11-28', 'P', '75.323.624.9-532.000', '500.20.21422.9', 'TK-0', 'NON PNS', 'PND5', 'Jl. Masjid Al Ikhlas Rt. 01 Rw.  01', '2016-03-01', 'Rum10', 'B04', 'J04', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('0551994062820161123153', 'Ahmad Mausul', 'Jakarta', '1994-06-28', 'L', '75.043.613.1-002.000', '51223212263', 'TK-0', 'NON PNS', 'PND4', 'Jalan Panca Warga 2 rt 007/02 nomor 22 ,kelurahan Cipinang Besar Selatan kecamatan Jatinegara ,Jakarta Timur', '2016-11-23', 'Rum12', 'B04', 'J31', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519900917201602018', 'Rudi Awal Saputra', 'Tegal', '1990-09-17', 'L', '98.518.657.6-501.000', '12520028379', 'K-0', 'NON PNS', 'PND4', 'jl Haji mahbub no 97,rt 004 rw 014 kelurahan bahagia kecamtan babelan bekasi utara', '2016-02-01', 'Rum12', 'B04', 'J31', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('0551990062620170703192', 'Primus hadi wijaya', 'Tebing Tinggi', '1990-06-26', 'L', '81.732.691.1-705.000', '53523073068', 'K-0', 'NON PNS', 'PND4', 'Jalan Lembah Aren 4 Blok K.8 No.22 RT.010 / RW.009 Kelurahan Pondok Kelapa. Kecamatan Duren Sawit. Jakarta Timur. 13450', '2017-03-03', 'Rum12', 'B04', 'J31', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519890601201602015', 'Andi Kumar', 'Aceh Tengah', '1989-06-01', 'L', '74.073.399.3-044.01', '504.20.06779.2', 'K-0', 'NON PNS', 'PND4', 'Kp. Jembatan RT 007 RW 014 Kelurahan Penggilingan, Kecamatan Cakung, Kota Administrasi Jakarta Timur', '2016-02-01', 'Rum12', 'B04', 'J31', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('055199301210160201110', 'Anggi Putra', 'Ogan Lima', '1990-01-20', 'L', '75.228.571.8-326.000', '51823042979', 'K-0', 'NON PNS', 'PND4', 'jln bina karya RT10 rw 03 kelurahan pondok kopi kecamatan duren sawit kab jakarta timur no 183B', '2016-02-01', 'Rum12', 'B04', 'J31', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519770921201602005', 'dr. Neny Rohaeny', 'Jakarta', '1977-09-21', 'P', '79.968.956.7-017.000', '50320910491', 'K-2', 'NON PNS', 'PND3', 'Jln. M. Kahfi II 04/05 No. 04 Srengseng Sawah.Jagakarsa.Jakarta Selatan', '2016-02-01', 'Rum04', 'B04', 'J18', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519870102201602007', 'dr. Dian Fridayani', 'Jakarta', '1987-01-02', 'P', '75.226.827.6-008.000', '503 23125272', 'TK-0', 'NON PNS', 'PND3', 'Jl. Pondok Kopi VII Blok G 6 No. 11 RT 006/ RW 008', '2016-02-01', 'Rum04', 'B04', 'J18', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519840304201602008', 'dr. Rizky Dwi Mulyanti', 'Jakarta', '1984-03-04', 'L', '70.221.267.1-008.000', '53423054154', 'K-1', 'NON PNS', 'PND3', 'Jl. Mawar Merah V no.158 RT 003 RW 007 Perumnas Klender Kelurahan Malaka Jaya Kec.Duren Sawit', '2016-02-01', 'Rum04', 'B04', 'J18', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('0551990061920160201091', 'dr. Ladoni Amiro', 'Jakarta', '1990-06-19', 'L', '70.984.038.3-432.000', '512 201200 23', 'K-0', 'NON PNS', 'PND3', 'JL. BOROBUDUR NO 10 RT.001 RW.006 PENGASINAN RAWA LUMBU', '2015-05-01', 'Rum04', 'B04', 'J18', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519901122201611009', 'dr. Dhimas Hartanto', 'Jakarta', '1990-11-22', 'L', '70.663.071.2-407.000', '50323206078', 'K-0', 'NON PNS', 'PND3', 'Pondok Kopi Blok Y9 No. 7 RT 010 RW 006', '2016-11-23', 'Rum04', 'B04', 'J18', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('055183040420160301113', 'Chandra Ariestadi', 'Jakarta', '1983-04-04', 'L', '49.051.907.1-416.000', '50320918531', 'K-2', 'NON PNS', 'PND4', 'kp.pulo jahert 007/010kel jatinegarakec cakungjakarta timur', '2016-03-01', 'Rum05', 'B04', 'J13', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519670715201603033', 'Eko Mulyadi', 'Jakarta', '1967-07-15', 'L', '25.209.394.3-005.000', '51220116859', 'K-0', 'NON PNS', 'PND4', 'JLN CILILITAN BESAR GG SILUMAN RT04 RW03 NO 18', '2016-03-01', 'Rum05', 'B04', 'J13', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519940215201603032', 'I Gusti Ayu Agung Ardhi Maharani', 'Jakarta', '1994-02-15', 'P', '44.957.071.2-003.000', '50123081163', 'TK-0', 'NON PNS', 'PND4', 'Jl.  Bekasi Timur Raya Km 18 Gang Remaja 3 Rt. 07 Rw.  07', '2016-03-01', 'Rum05', 'B04', 'J13', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519951024201712029', 'Mila Hanifah', 'Bekasi', '1995-10-24', 'P', '83.463.744.9-432.000', '600.23.02427.3', 'TK-0', 'NON PNS', 'PND4', 'BEKASI TIMUR REGENSI BLOK H9/39 JL. MURAI 4 RT 003/015 KELURAHAN CIMUNING KECAMATAN MUSTIKA JAYA', '2017-12-04', 'Rum05', 'B04', 'J13', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519951202201712028', 'Dalila Rima Azizah', 'Jakarta', '1995-12-20', 'P', '76.384.722.5-009.000', '53523074722', 'TK-0', 'NON PNS', 'PND4', 'jalan basuki rt.004 rw.02 no.20 cilangkap jakarta timur', '2017-12-04', 'Rum05', 'B04', 'J13', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519960626201902248', 'Chamelia Pertiwi', 'Bekasi', '1996-06-26', 'P', '83.390.700.9-427.000', '568.20.00061.9', 'TK-0', 'NON PNS', 'PND4', 'jl bintara 14 no.16 RT 01/09 .kelurahan bintara kecamatan bekasi barat . kota bekasi', '2019-03-01', 'Rum05', 'B04', 'J13', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519950320201805231', 'Ariyani', 'Sukabumi', '1995-03-20', 'P', '80.322.038.3-405.000', '20320039627', 'K-1', 'NON PNS', 'PND4', 'Eastpark apartment AA 15 03, RT 009 RW 009, kel. Jatinegara, kec.Cakung jakarta timur', '2018-05-07', 'Rum08', 'B04', 'J31', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519940717201804219', 'Barliana Restu Saraswqti', 'Ponorogo', '1994-07-17', 'P', '82.112.286.8-432.000', '51420074702', 'TK-0', 'NON PNS', 'PND4', 'Jalan Pulo Sirih Timur 6 Blok CB No. 157 Taman Galaxy Indah', '2018-04-02', 'Rum08', 'B04', 'J14', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519911228201804220', 'Ayu Wulandari', 'Bekasi', '1991-12-28', 'P', '66.186.822.4-432.000', '51223235310', 'K-1', 'NON PNS', 'PND4', 'Jl. Manunggal XVII RT/RW 008/011 Kel. Lubang Buaya Kec. Cipayung. Jakarta Timur', '2018-04-02', 'Rum08', 'B04', 'J14', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('0551990030420170602179', 'Margaretha', 'Jakarta', '1990-03-04', 'P', '68.309.739.8-008.000', '51223218067', 'K-1', 'NON PNS', 'PND2', 'Jl.Pratama no.46 RT/RW 002/008 curug, pondok kelapa', '2017-06-02', 'Rum04', 'B04', 'J18', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('1020551987120320170602183', 'Desty Dwianti', 'Jakarta', '1987-12-03', 'P', '547079004-008.000', '51223218075', 'TK-0', 'NON PNS', 'PND2', 'Jalan Rawa Jaya Rt 02/04 No. 32 Pondok Kopi, Duren Sawit, Jakarta Timur', '2017-06-02', 'Rum04', 'B04', 'J18', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519940223201707050', 'Dinar Febriani', 'Jakarta', '1994-02-23', 'P', '76.825.370.0-009.000', '53523073220', 'TK-0', 'NON PNS', 'PND4', 'Jl Tanah Merdeka No 71 RT/RW 008/005 Kel Susukan kec Ciracas, Jakarta Timur', '2017-07-19', 'Rum09', 'B04', 'J40', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519970426201902245', 'Dewi Apriyanti', 'Banjarnegara', '1997-04-26', 'P', '90.492.856.1-005.000', '51220134482', 'TK-0', 'NON PNS', 'PND4', 'PETUGURAN RT 04 RW 01 PUNGGELAN BANJARNEGARA', '2019-03-01', 'Rum06', 'B04', 'J31', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519900925201404084', 'EKA SEPTI WAHYUNI', 'AMBARAWA', '1990-09-25', 'P', '73.547.498.3-008.000', '52423003901', 'K-0', 'NON PNS', 'PND4', 'Jl. Amal II No.19 RT 010 RW 001 Kel. Pondok Bambu, Kec. Duren Sawit, Jakarta Timur, DKI Jakarta', '2014-04-01', 'Rum08', 'B05', 'J14', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519950619201804209', 'LISA PUJI ASTUTI', 'BEKASI ', '1995-06-19', 'P', '80.778.602.5-427.000', '53523083381', 'TK-0', 'NON PNS', 'PND4', 'Jl. Sultan Agung RT 003 RW 04 No.57 kel./kec. Medan Satia, Bekasi, Jawa Barat', '2018-04-01', 'Rum08', 'B05', 'J43', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519870604201304193', 'SUSIYAWATI', 'LOSARI', '1987-06-04', 'P', '57.211.733.1-003.000', '52423004681', 'K-2', 'NON PNS', 'PND4', 'Jl. Rawamangun Muka IV /19 RT 14 / RW 12 Kel. Rawamangun  Kec. Pulo gadung Jakarta Timur', '2013-04-01', 'Rum08', 'B05', 'J31', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519780914200601198', 'IDIL FITRI', 'padang bindu', '1978-09-14', 'L', '73.644.336.7-008.000', '52423004494', 'K-2', 'NON PNS', 'PND5', 'pondk kelapa No4 rt 016/rw02 kel pondok kelapa kec duren sawit jakata-timur', '2003-06-01', 'Rum10', 'B05', 'J04', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519930115201604192', 'NURISKA ASDIANTI', 'JAKARTA', '1993-01-15', 'P', '75.880.910.7-006.000', '51223206573', 'K-1', 'NON PNS', 'PND4', 'RGTC blok puspa indah no. 316 RT 06/10 kel.Cakung Barat kec Cakung Jakarta timur', '2016-04-01', 'Rum08', 'B05', 'J31', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519940524201602173', 'Nindy Audyna', 'Bekasi', '1994-05-24', 'P', '75.152.113.9-435.000', '50023264146', 'TK-0', 'NON PNS', 'PND4', 'Jl. Rawadas RT/RW 003/003, Pondok Kopi, Duren Sawit. Jakarta Timur', '2016-02-01', 'Rum06', 'B04', 'J31', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519900210201608169', 'Febri Mutiarani Putri', 'Semarang', '1990-02-10', 'P', '66.326.911.6-412.000', '53423075399', 'TK-0', 'NON PNS', 'PND2', 'Jl. Taman sari I no.12 RT 03/016 Perumahan Jatinegara baru, penggilingan, cakung, jaktim', '2016-08-01', 'Rum04', 'B04', 'J18', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('102055119920521201707190', 'Mei Anjellyna', 'Jakarta', '1992-05-21', 'P', '66.845.056.2-008.000', '53523073092', 'TK-0', 'NON PNS', 'PND4', 'Jl. Pertanian Utara RT 002/001 No.15 Klender, Durensawit,Jakarta Timur', '2017-07-07', 'Rum06', 'B04', 'J31', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519920108201804218', 'Lenni Sri Paramitha Brutu', 'Tebing tinggi', '1992-01-08', 'P', '84.626.009.9-086.000', '53523083373', 'TK-0', 'NON PNS', 'PND4', 'Jl. Cempaka IV No.4, Cakung, Kayu Tinggi', '2018-04-02', 'Rum06', 'B04', 'J14', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('102055198910093011707127', 'Anelia Prasticha Sari', 'Demak', '1989-10-09', 'P', '36.112.286.8-515.000', '53523073033', 'K-0', 'NON PNS', 'PND4', 'Jl. Sawah Barat II Rt 001/006 Pondok Bambu, Durensawit, JAKARTA Timur', '2017-07-07', 'Rum06', 'B04', 'J31', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519850702201711051', 'Haryanto', 'Kebumen', '1985-07-02', 'L', '75.499.170.1-015.000', '500-20-23242.1', 'K-1', 'NON PNS', 'PND5', 'Jl. Kebon Pala II Rt 04/04 Kampung Melayu,Jatinegara,Jakarta Timur', '2017-11-02', 'Rum10', 'B04', 'J01', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('1020551990041820161123154', 'Rahma Apriana Ulva', 'Jakarta', '1190-04-18', 'P', '97.117.793.6-002.000', '51123314653', 'TK-0', 'NON PNS', 'PND2', 'jl. Otista 82 Gg. Tanjung lengkong Rt/Rw 016/007 No. 11A, Kel : Bidaracina, Kec : Jatinegara, jakarta Timur, DKI Jakarta', '2016-08-01', 'Rum05', 'B04', 'J12', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519910416201608034', 'Indri Saditri', 'Cianjur', '1991-04-16', 'P', '66.786.585.1-407.000', '53523048608', 'TK-0', 'NON PNS', 'PND4', 'BJI Kp. Cerwet Jl. Melur 2 blok F5 no 11 RT/RW 03/14, Duren Jaya, Bekasi Timur, Jawa Barat', '2016-08-01', 'Rum06', 'B04', 'J27', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('0551990082320160201086', 'dr. Amira', 'B.Lampung', '1990-08-23', 'P', '71.147.893.3-005.000', '12223137395', 'K-1', 'NON PNS', 'PND2', 'JL. AL Mabruk 2 no.34 RT/RW 03/03 Kel. Balekambang, Kecamatan Kramatjati. Jakarta Timur', '2016-02-01', 'Rum04', 'B01', 'J18', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('1020551992091620160418130', 'Annisa Siskha Septiana', 'Jakarta', '1992-09-16', 'P', '75.898.655.8-004.000', '15323083431', 'K-0', 'NON PNS', 'PND4', 'kp rawa badung Rt 008/07 No 47 Kel. Jatinegara Kec. Cakung', '2016-04-18', 'Rum07', 'B01', 'J14', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('1020551992092920170403163', 'Anna Selviana', 'Jakarta', '1992-09-29', 'P', '55.885.864.3-008.000', '53520011576', 'TK-0', 'NON PNS', 'PND4', 'Komplek Abadi Jl. Pendawa Raya Blok K No. 3 Rt. 011 Rw. 006 Kel/Kec. Duren Sawit Kode Pos 13440', '2017-04-03', 'Rum07', 'B04', 'J31', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('102055199104022016021147', 'Andini Suci Aprilia', 'Jakarta', '1991-04-02', 'P', '59.634.990.2-009.000', '50020234874', 'K-0', 'NON PNS', 'PND4', 'Condet Batu Ampar Rt. 002 Rw. 005 N0. 20 Kel. Batu Ampar Kec. Kramat Jati Kode Pos.', '2016-02-11', 'Rum07', 'B01', 'J31', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('102055199101312016021106', 'Heni Prasetyaningsih', 'Jakarta', '1991-01-31', 'P', '74.985.518.5-008.000', '50020234891', 'K-0', 'NON PNS', 'PND4', 'Kp.Kapitan Rt 010 Rw 004 No.37 Kel Klender Kec Duren Sawit', '2016-02-11', 'Rum07', 'B01', 'J14', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519920409201602099', 'Nurseti Handayani', 'Jakarta', '1992-04-09', 'P', '75.145.658.3-008.000', '50023264138', 'K-0', 'NON PNS', 'PND4', 'KAV DKI Blok L 8 No. 5 Rt. 004 Rw. 009 Kel. Pondok Kelapa Kec. Duren Sawit', '2016-02-11', 'Rum07', 'B01', 'J14', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519970405201905254', 'Krisna Kurniawan Shihab', 'Cilacap', '1997-04-05', 'L', '85.759.973.2-522.000', '51220135471', 'TK-0', 'NON PNS', 'PND4', 'Jl. Hidup Baru 1, Gg. Guru Limin, No.38, RT/RW 10/03, Kel. Gandaria Utara, Kec. Kebayoran Baru, Jakarta Selatan', '2019-05-02', 'Rum07', 'B04', 'J43', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519900602201804211', 'Maulvi Nazir', 'Bekasi', '1990-06-02', 'L', '45.000.596.2-435.000', '53723117941', 'K-0', 'NON PNS', 'PND2', 'Kp. Ujung Harapan RT 001/014 Desa Bahagia Kecamatan Babelan. Bekasi', '2018-04-02', 'Rum04', 'B04', 'J18', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519910515201608036', 'Muhamad Yusuf', 'Jakarta', '1991-05-15', 'L', '71.622.021.5-048.000', '20123120917', 'K-0', 'NON PNS', 'PND4', 'Jln. Jati III No. 23 RT 4 RW 5 Kelurahan Sungai Bambu Kecamatan Tanjung Priok Jakarta Utara 14330', '2016-08-01', 'Rum07', 'B02', 'J43', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519851109201305039', 'Nova Dyah Wanditasari', 'Jakarta', '1985-09-09', 'P', '35.598.366.9-407.000', '52423004192', 'K-1', 'NON PNS', 'PND4', 'Jl Pisang No 17 RT/RW 004/005 Kel Harapan Jaya Kec Bekasi Utara Bekasi', '2013-05-01', 'Rum09', 'B04', 'J26', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519940927201604013', 'Septi Kusuma Dewi', 'Jakarta', '1994-09-27', 'P', '74.068.459.2-008.000', '60123078452', 'TK-0', 'NON PNS', 'PND4', 'Jalan SMPN 135 RT 007/007 No. 33 kel. Pondok Bambu Kec. Duren Sawit Jakarta Timur 13430', '2016-05-09', 'Rum06', 'B04', 'J31', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519780301199601043', 'Masanih', 'Jakarta', '1978-03-01', 'P', '44.429.112.4-008.000', '52423004184', 'K-2', 'NON PNS', 'PND5', 'Jalan Kesehatan RT 02 RW 05 No.48 Kel. Podok Bambu Kec. Duren Sawit Jakarta Timur 13430', '1996-01-05', 'Rum10', 'B04', 'J01', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519850101201510010', 'Nuraini Hasanah', 'jakarta', '1985-01-01', 'P', '67.911.062.7-005.000', '50023198984', 'K-2', 'NON PNS', 'PND4', 'Rusun Cipinang Muara 2 Blok Pengajaran/B No. 505 Rt 18/Rw02 Kel. Pondok Bambu Kec. Duren Sawit Jakarta Timur 13430', '2015-10-01', 'Rum06', 'B04', 'J31', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519921008201604011', 'Efi Nofitasari', 'Paliyan Lor', '1992-08-10', 'P', '71.239.103.6-008.000', '60123078428', 'K-1', 'NON PNS', 'PND4', 'Jl. Yodium No.71 Rt01 /RW 011 Kel. Duren Sawit Kec. Duren Sawit Jakarta Timur 13440', '2016-04-16', 'Rum06', 'B04', 'J31', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519880707201802065', 'Widya Ariaty', 'Palembang', '1988-07-07', 'P', '35.820.788.4-527.000', '53523080927', 'K-1', 'NON PNS', 'PND2', 'Griya Metropolitan 2 Blok E5 No.3 Pekayon Bekasi Selatan Kota Bekasi 17148', '2018-02-01', 'Rum04', 'B04', 'J18', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519891021201608012', 'Yesi Suherlani', 'klaten', '1989-10-21', 'P', '71.143.613.9-004.000', '53523048616', 'K-1', 'NON PNS', 'PND4', 'Kp. Pengarengan no.16 rt 02/12 jatinegara cakung jaktim', '2016-08-12', 'Rum06', 'B04', 'J31', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519960816201902244', 'Nabila Sri Ayu A Abdullah', 'Poso', '1996-08-16', 'P', '83.507.519.3-447.000', '51220134288', 'TK-0', 'NON PNS', 'PND4', 'KP sawah No 37 RT 005/ RW 002 Kel. Jatimelati Kec Pondok Melati Bekasi Jawa Barat', '2019-02-18', 'Rum06', 'B04', 'J31', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519970313201902243', 'Farikha Fadlika', 'Magelang', '1997-03-13', 'P', '82.126.360.5-524.000', '51220134491', 'TK-0', 'NON PNS', 'PND4', 'jl.H. Dogol no.34, Pondok Bambu, Duren Sawit, Jakarta Timur', '2019-02-18', 'Rum06', 'B04', 'J31', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519970824201902242', 'Mega Nur Arif', 'Jakarta', '1997-08-24', 'P', '90.151.190.7-002.000', '56820000597', 'TK-0', 'NON PNS', 'PND4', 'Jl Basuki Rahmat RT/RW 011/010 Cipinang Besar Selatan, Jatinegara,  Jakarta Timur', '2019-02-18', 'Rum06', 'B04', 'J31', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519890227201706189', 'Sidgi', 'Cirebon', '1989-02-27', 'L', '71.173.095.2-008.000', '51223218091', 'K-1', 'NON PNS', 'PND2', 'KP Sumur RT/RW 012/010, Klender, Duren Sawit. Jakarta Timur', '2017-06-02', 'Rum04', 'B04', 'J18', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519900103201804213', 'Katarina Maria', 'Bandung', '1990-01-03', 'P', '71,089,735,6-009,000', '53723117886', 'K-0', 'NON PNS', 'PND2', 'JL. Manunggal II no 17 A, Ceger, Cipayung, Jakarta Timur', '2018-04-02', 'Rum04', 'B04', 'J18', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519840608201704116', 'Euis Sri Rahayu', 'Jakarta', '1984-06-18', 'P', '67,912,886,8-009,000', '52123055876', 'K-2', 'NON PNS', 'PND4', 'JL SLTP 258 N0.80 RT12/10 CIBUBUR Ciracas jakarta timur', '2017-04-03', 'Rum06', 'B04', 'J31', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519940409201804216', 'Sandi Permana', 'Tasikmalaya', '1994-04-09', 'L', '80.567.184.9-425.000', '51223235336', 'TK-0', 'NON PNS', 'PND4', 'Jl. Malaka 2, RT 006/RW 009, Kel. Malaka sari. Kec. Durensawit, jakarta timur', '2018-04-02', 'Rum06', 'B04', 'J31', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519891129201706171', 'Mirshad Adiresya Putra', 'Bukittinggi', '1989-11-29', 'L', '70.835.874.2-202.000', '51223218105', 'K-1', 'NON PNS', 'PND2', 'Jl. Lenteng Agung Baru No. 57a 05/02, Kelurahan Lenteng Agung, Kecamatan Jagakarsa, Jakarta Selatan', '2017-06-02', 'Rum04', 'B04', 'J18', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519920921201707174', 'Bayu Saputra', 'Lombok', '1992-09-21', 'L', '64.169.112.6-008.000', '53723086671', 'TK-0', 'NON PNS', 'PND4', 'Jl delima I no 17 RT 005 Rw 008, kelurahan pondok kelapa kecamatan duren sawit JAKTIM', '2017-07-07', 'Rum06', 'B04', 'J31', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519900721201704196', 'Marda Ardi Arini', 'sleman', '1990-07-21', 'P', '16.999.814.3-432.000', '51220122867', 'K-1', 'NON PNS', 'PND4', 'bojong menteng Rt 004/003 Rawalumbu Bekasi', '2017-04-03', 'Rum06', 'B04', 'J14', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519901018201608066', 'Oktafiani Purba', 'medan', '1990-10-18', 'P', '76,63,206,5,9447,000', '53723055201', 'K-0', 'NON PNS', 'PND4', 'JL.PELANGI NO.86 RT.02/ RW.05 JATI BENING-BEKASI', '2016-08-01', 'Rum06', 'B04', 'J31', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519930909201704195', 'Fitri Yanti', 'Jakarta', '1993-09-09', 'P', '81.231.277.5-435.000', '53523071855', 'K-0', 'NON PNS', 'PND4', 'Senopati Estate blok C2 No 1 RT 004 RW 011 Kel. Sumur Batu, Kec. Bantar Gebang, Kota Bekasi', '2017-04-03', 'Rum06', 'B04', 'J14', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519890903201707191', 'Diah Septiani', 'Jakarta', '1989-09-03', 'P', '88.170.473.8-008,000', '53523073025', 'K-1', 'NON PNS', 'PND4', 'JL Kelurahan I No.33 RT 08 RW 04 Kel.Duren Sawit Kec.Duren Sawit Jakarta Timur', '2017-07-07', 'Rum06', 'B04', 'J31', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519910805201805227', 'Rikza Anaupal Dahri', 'Sukabumi', '1991-08-05', 'L', '75.041.375.9-008.000', '53420013325', 'TK-0', 'NON PNS', 'PND2', 'JL. Delima 3 Blok 1 No. 14 RT 12 RW 3, Kel. Malaka Sari, Kec. Duren Sawit, Jakarta Timur', '2018-05-07', 'Rum04', 'B04', 'J18', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519900912201605188', 'Lucinda Corry Fitria', 'Bekasi', '1990-09-12', 'P', '70.725.973.5-407.000', '53523043088', 'K-1', 'NON PNS', 'PND2', 'Jl. Marinir Timur 1, Blok AB 8 No. 26, RT.008/013, Kel. Pondok Kelapa, Kec. Duren Sawit, Jakarta Timur, 13450.', '2016-05-18', 'Rum04', 'B04', 'J18', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519890509201804210', 'Nelson Reynaldo Harahap', 'Tanjung Pinang', '1989-05-09', 'L', '982670481-219.000', '53523083357', 'TK-0', 'NON PNS', 'PND2', 'Jl. Stadion No. 85 Kec. Mandau Riau', '2018-04-02', 'Rum04', 'B04', 'J18', '1.02', '1.02.058', '', '', '', '', '', '', ''),
('10205519920203201711052', 'Nika Hendra Priyatna', 'Kuningan', '1992-02-03', 'L', '', '', 'K-0', 'NON PNS', 'PND5', 'Jl. Selat Sunda Raya Kavling AL Block E11 No. 12', '2017-11-02', 'Rum10', 'B04', 'J01', '1.02', '1.02.058', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `pelatihan`
--

CREATE TABLE `pelatihan` (
  `id_pelatihan` int(4) NOT NULL,
  `nip` varchar(30) NOT NULL,
  `tgl_pelatihan` date NOT NULL,
  `topik_pelatihan` varchar(100) NOT NULL,
  `penyelenggara` text NOT NULL,
  `hasil_pelatihan` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `pencapaian`
--

CREATE TABLE `pencapaian` (
  `id_pencapaian` varchar(8) NOT NULL,
  `nip` varchar(30) NOT NULL,
  `id_bag` varchar(8) NOT NULL,
  `id_jab` varchar(8) NOT NULL,
  `id_status` varchar(8) NOT NULL,
  `id_skpd` varchar(10) NOT NULL,
  `id_ukpd` varchar(10) NOT NULL,
  `id_penyerapan` varchar(20) NOT NULL,
  `nama` varchar(35) NOT NULL,
  `tanggal` date NOT NULL,
  `penilai` varchar(30) NOT NULL,
  `nskp` int(5) NOT NULL,
  `nprilaku` decimal(5,2) NOT NULL,
  `masa_kerja` varchar(25) NOT NULL,
  `rumpun` varchar(45) NOT NULL,
  `bruto` int(25) NOT NULL,
  `tunjangan` int(25) NOT NULL,
  `gapok` int(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `pendidikan`
--

CREATE TABLE `pendidikan` (
  `idp` int(4) NOT NULL,
  `nip` varchar(30) NOT NULL,
  `t_pdk` varchar(20) NOT NULL,
  `d_pdk` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `pendidikan_t`
--

CREATE TABLE `pendidikan_t` (
  `id_pendidikan` varchar(8) NOT NULL,
  `id_skpd` varchar(10) NOT NULL,
  `id_ukpd` varchar(10) NOT NULL,
  `n_pendidikan` varchar(45) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pendidikan_t`
--

INSERT INTO `pendidikan_t` (`id_pendidikan`, `id_skpd`, `id_ukpd`, `n_pendidikan`) VALUES
('PND5', '1.02', '1.02.058', 'SLTA'),
('PND4', '1.02', '1.02.058', 'D III / D IV'),
('PND3', '1.02', '1.02.058', 'S1'),
('PND2', '1.02', '1.02.058', 'S2 / dr./ drg./ Apoteker/ Ners'),
('PND1', '1.02', '1.02.058', 'S3 / dr. Spesialis');

-- --------------------------------------------------------

--
-- Table structure for table `pengalaman_kerja`
--

CREATE TABLE `pengalaman_kerja` (
  `id_peker` int(4) NOT NULL,
  `nip` varchar(30) NOT NULL,
  `nm_pekerjaan` varchar(50) NOT NULL,
  `d_pekerjaan` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `pengukuran`
--

CREATE TABLE `pengukuran` (
  `id_pengukuran` varchar(8) NOT NULL,
  `nip` varchar(30) NOT NULL,
  `tanggal` date NOT NULL,
  `nilai_utama` int(8) NOT NULL,
  `nilai_tambahan` int(8) NOT NULL,
  `nilai_kreatifitas` int(8) NOT NULL,
  `jumlah` int(8) NOT NULL,
  `hari` int(8) NOT NULL,
  `max_waktu` int(8) NOT NULL,
  `point` varchar(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `penyerapan`
--

CREATE TABLE `penyerapan` (
  `id_penyerapan` varchar(8) NOT NULL,
  `id_skpd` varchar(10) NOT NULL,
  `id_ukpd` varchar(10) NOT NULL,
  `tanggal` date NOT NULL,
  `nilai` int(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `penyerapan`
--

INSERT INTO `penyerapan` (`id_penyerapan`, `id_skpd`, `id_ukpd`, `tanggal`, `nilai`) VALUES
('PNY00002', '1.02', '1.02.058', '2018-01-28', 100);

-- --------------------------------------------------------

--
-- Table structure for table `rumpun`
--

CREATE TABLE `rumpun` (
  `id_rumpun` varchar(8) NOT NULL,
  `n_rumpun` varchar(35) NOT NULL,
  `nilai` varchar(8) NOT NULL,
  `id_skpd` varchar(10) NOT NULL,
  `id_ukpd` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rumpun`
--

INSERT INTO `rumpun` (`id_rumpun`, `n_rumpun`, `nilai`, `id_skpd`, `id_ukpd`) VALUES
('Rum01', 'Dokter Spesialis Bedah', '4', '1.02', '1.02.058'),
('Rum02', 'Dokter Spesialis Non Bedah', '2.5', '1.02', '1.02.058'),
('Rum03', 'Dokter Spesialis Penunjang', '1.8', '1.02', '1.02.058'),
('Rum04', 'Dokter Umum / Dokter Gigi', '1.6', '1.02', '1.02.058'),
('Rum05', 'Apoteker / Ners', '1.5', '1.02', '1.02.058'),
('Rum06', 'Radiologi/Analis/DIV/DIII Kes', '0.8', '1.02', '1.02.058'),
('Rum07', 'Teknis Tingkat Ahli', '1.5', '1.02', '1.02.058'),
('Rum08', 'Teknis Tingkat Terampil', '1', '1.02', '1.02.058'),
('Rum09', 'Administrasi Tingkat Ahli', '0.7', '1.02', '1.02.058'),
('Rum10', 'Administrasi Tingkat Terampil', '0.6', '1.02', '1.02.058'),
('Rum11', 'Operasional Tingkat Ahli', '0.5', '1.02', '1.02.058'),
('Rum12', 'Operasional Tingkat Terampil', '0.4', '1.02', '1.02.058');

-- --------------------------------------------------------

--
-- Table structure for table `setting`
--

CREATE TABLE `setting` (
  `id_setting` varchar(4) NOT NULL,
  `pj` int(1) NOT NULL,
  `management` int(1) NOT NULL,
  `kinerja` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `setting`
--

INSERT INTO `setting` (`id_setting`, `pj`, `management`, `kinerja`) VALUES
('ST01', 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `set_user`
--

CREATE TABLE `set_user` (
  `id` int(50) NOT NULL,
  `ket` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Table structure for table `skp`
--

CREATE TABLE `skp` (
  `kd_skp` varchar(8) NOT NULL,
  `skp` varchar(160) NOT NULL,
  `waktu` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `skp`
--

INSERT INTO `skp` (`kd_skp`, `skp`, `waktu`) VALUES
('SKP00001', 'Alih Media Indeksing dan Editing Arsip - 30.0 menit', '30'),
('SKP00002', 'Alih Media Indeksing dan Editing Arsip - 15.0 menit', '15'),
('SKP00003', 'Bertugas menjadi Panitera Pengganti - 60.0 menit', '60'),
('SKP00004', 'Bertugas menjadi Panitera Pengganti - 30.0 menit', '30'),
('SKP00005', 'Bertugas menjadi Panitera Pengganti - 120.0 menit', '120'),
('SKP00006', 'Evaluasi Dokumen Kualifikasi Pengadaan Barang / Jasa (termasuk lelang ulang) - 60.0 menit', '60'),
('SKP00007', 'Evaluasi Dokumen Kualifikasi Pengadaan Barang / Jasa (termasuk lelang ulang) - 120.0 menit', '120'),
('SKP00008', 'Evaluasi Dokumen Kualifikasi Pengadaan Barang / Jasa (termasuk lelang ulang) - 90.0 menit', '90'),
('SKP00009', 'Input Keterangan Absensi Pegawai Melalui Media Elektronik (Per Hari) - 30.0 menit', '30'),
('SKP00010', 'Input Keterangan Absensi Pegawai Melalui Media Elektronik (Per Hari) - 15.0 menit', '15'),
('SKP00011', 'Input PKG Jenjang SD, SMP, SMA, SMK - 60.0 menit', '60'),
('SKP00012', 'Input PKG Jenjang SD, SMP, SMA, SMK - 120.0 menit', '120'),
('SKP00013', 'Inventarisasi permasalahan - 60.0 menit', '60'),
('SKP00014', 'Inventarisasi permasalahan - 30.0 menit', '30'),
('SKP00015', 'Inventarisasi permasalahan - 120.0 menit', '120'),
('SKP00016', 'Klarifikasi dan Negosiasi Penawaran Penyedia Barang / Jasa - 30.0 menit', '30'),
('SKP00017', 'Klarifikasi dan Negosiasi Penawaran Penyedia Barang / Jasa - 60.0 menit', '60'),
('SKP00018', 'Legalisir dokumen (per 5 lembar) - 5.0 menit', '5'),
('SKP00019', 'Melaksakan tugas sebagai pembaca doa (1x acara / event) - 15.0 menit', '15'),
('SKP00020', 'Melaksanakan arahan pimpinan - 15.0 menit', '15'),
('SKP00021', 'Melaksanakan arahan pimpinan - 60.0 menit', '60'),
('SKP00022', 'Melaksanakan arahan pimpinan - 30.0 menit', '30'),
('SKP00023', 'Melaksanakan cap bakar / tanda selar kapal-kapal di bawah 7 GT pada pelabuhan - 30.0 menit', '30'),
('SKP00024', 'Melaksanakan deteksi dini (per lokasi) - 60.0 menit', '60'),
('SKP00025', 'Melaksanakan duplikasi database - 30.0 menit', '30'),
('SKP00026', 'Melaksanakan duplikasi database - 15.0 menit', '15'),
('SKP00027', 'Melaksanakan duplikasi database - 60.0 menit', '60'),
('SKP00028', 'Melaksanakan Grouping ID Radio Trunking - 60.0 menit', '60'),
('SKP00029', 'Melaksanakan Grouping ID Radio Trunking - 120.0 menit', '120'),
('SKP00030', 'Melaksanakan Identifikasi dan asesmen Warga Binaan Sosial - 60.0 menit', '60'),
('SKP00031', 'Melaksanakan imunisasi, vaksinasi, feed additive - 30.0 menit', '30'),
('SKP00032', 'Melaksanakan imunisasi, vaksinasi, feed additive - 180.0 menit', '180'),
('SKP00033', 'Melaksanakan imunisasi, vaksinasi, feed additive - 120.0 menit', '120'),
('SKP00034', 'Melaksanakan Inventaris Alat Ukur Telekomunikasi - 30.0 menit', '30'),
('SKP00035', 'Melaksanakan Kegiatan Pembinaan - 180.0 menit', '180'),
('SKP00036', 'Melaksanakan Kegiatan Pembinaan - 90.0 menit', '90'),
('SKP00037', 'Melaksanakan Kegiatan Pembinaan - 120.0 menit', '120'),
('SKP00038', 'Melaksanakan konfirmasi / rekonsiliasi dengan pusat / provinsi / SKPD / UKPD - 120.0 menit', '120'),
('SKP00039', 'Melaksanakan konfirmasi / rekonsiliasi dengan pusat / provinsi / SKPD / UKPD - 180.0 menit', '180'),
('SKP00040', 'Melaksanakan konfirmasi / rekonsiliasi dengan pusat / provinsi / SKPD / UKPD - 30.0 menit', '30'),
('SKP00041', 'Melaksanakan konfirmasi / rekonsiliasi dengan pusat / provinsi / SKPD / UKPD - 60.0 menit', '60'),
('SKP00042', 'Melaksanakan latihan musik (pada Dinas Damkar) - 30.0 menit', '30'),
('SKP00043', 'Melaksanakan latihan musik (pada Dinas Damkar) - 120.0 menit', '120'),
('SKP00044', 'Melaksanakan latihan musik (pada Dinas Damkar) - 60.0 menit', '60'),
('SKP00045', 'Melaksanakan Layanan Perpustakaan Mobil Keliling - 120.0 menit', '120'),
('SKP00046', 'Melaksanakan Layanan Perpustakaan Mobil Keliling - 180.0 menit', '180'),
('SKP00047', 'Melaksanakan Layanan Perpustakaan Siswa - 30.0 menit', '30'),
('SKP00048', 'Melaksanakan / melakukan Survei / tinjauan lapangan (per lokasi) - 30.0 menit', '30'),
('SKP00049', 'Melaksanakan / melakukan Survei / tinjauan lapangan (per lokasi) - 60.0 menit', '60'),
('SKP00050', 'Melaksanakan / melakukan Survei / tinjauan lapangan (per lokasi) - 120.0 menit', '120'),
('SKP00051', 'Melaksanakan / Melayani Konsultasi Individu / kelompok - 10.0 menit', '10'),
('SKP00052', 'Melaksanakan / Melayani Konsultasi SKPD / UKPD - 30.0 menit', '30'),
('SKP00053', 'Melaksanakan / Melayani Konsultasi SKPD / UKPD - 15.0 menit', '15'),
('SKP00054', 'Melaksanakan / Melayani Konsultasi SKPD / UKPD - 60.0 menit', '60'),
('SKP00055', 'Melaksanakan / mengikuti sosialisasi tingkat kota / provinsi / nasional - 120.0 menit', '120'),
('SKP00056', 'Melaksanakan / mengikuti sosialisasi tingkat kota / provinsi / nasional - 300.0 menit', '300'),
('SKP00057', 'Melaksanakan / mengikuti sosialisasi tingkat kota / provinsi / nasional - 180.0 menit', '180'),
('SKP00058', 'Melaksanakan / mengikuti sosialisasi tingkat kota / provinsi / nasional - 240.0 menit', '240'),
('SKP00059', 'Melaksanakan panen tanaman (per lokasi) - 30.0 menit', '30'),
('SKP00060', 'Melaksanakan panen tanaman (per lokasi) - 60.0 menit', '60'),
('SKP00061', 'Melaksanakan pelatihan per kegiatan - 180.0 menit', '180'),
('SKP00062', 'Melaksanakan pelatihan per kegiatan - 120.0 menit', '120'),
('SKP00063', 'Melaksanakan pelatihan per kegiatan - 60.0 menit', '60'),
('SKP00064', 'Melaksanakan pelayanan kesehatan sesuai dengan objek kerja - 30.0 menit', '30'),
('SKP00065', 'Melaksanakan pelayanan klinis umum, spesialis, gizi kerja dan produktivitas kerja - 30.0 menit', '30'),
('SKP00066', 'Melaksanakan pelayanan klinis umum, spesialis, gizi kerja dan produktivitas kerja - 15.0 menit', '15'),
('SKP00067', 'Melaksanakan pelayanan penanganan satwa liar - 180.0 menit', '180'),
('SKP00068', 'Melaksanakan pelayanan penanganan satwa liar - 120.0 menit', '120'),
('SKP00069', 'Melaksanakan Pemberantasan Sarang Nyamuk (PSN) - 60.0 menit', '60'),
('SKP00070', 'Melaksanakan Pemberantasan Sarang Nyamuk (PSN) - 120.0 menit', '120'),
('SKP00071', 'Melaksanakan Pemberian Peringatan Terhadap Pelanggaran Perizinan dan Non Perizinan - 30.0 menit', '30'),
('SKP00072', 'Melaksanakan pembibitan tanaman (per lokasi) - 30.0 menit', '30'),
('SKP00073', 'Melaksanakan pembibitan tanaman (per lokasi) - 60.0 menit', '60'),
('SKP00074', 'Melaksanakan pembinaan fisik, pembinaan olahraga dan kegiatan pelatihan - 120.0 menit', '120'),
('SKP00075', 'Melaksanakan pembinaan fisik, pembinaan olahraga dan kegiatan pelatihan - 60.0 menit', '60'),
('SKP00076', 'Melaksanakan pemeliharaan dan perbaikan instalasi listrik dan air - 30.0 menit', '30'),
('SKP00077', 'Melaksanakan pemeliharaan dan perbaikan instalasi listrik dan air - 60.0 menit', '60'),
('SKP00078', 'Melaksanakan pemeliharaan / perawatan / pembersihan prasarana dan sarana - 30.0 menit', '30'),
('SKP00079', 'Melaksanakan pemeliharaan / perawatan / pembersihan prasarana dan sarana - 60.0 menit', '60'),
('SKP00080', 'Melaksanakan pemeliharaan / perawatan / pembersihan prasarana dan sarana - 120.0 menit', '120'),
('SKP00081', 'Melaksanakan pemeliharaan / perawatan / pembersihan prasarana dan sarana - 15.0 menit', '15'),
('SKP00082', 'Melaksanakan pemeliharaan tanaman (per lokasi) - 60.0 menit', '60'),
('SKP00083', 'Melaksanakan pemeliharaan tanaman (per lokasi) - 30.0 menit', '30'),
('SKP00084', 'Melaksanakan pemeriksaan ante mortem dan post mortem (per pasien) - 120.0 menit', '120'),
('SKP00085', 'Melaksanakan pemeriksaan ante mortem dan post mortem (per pasien) - 60.0 menit', '60'),
('SKP00086', 'Melaksanakan Pemeriksaan penunjang pelayanan kesehatan olahraga dan kebugaran medical check up pegawai - 90.0 menit', '90'),
('SKP00087', 'Melaksanakan Pemrograman HT / RIG Trunking - 15.0 menit', '15'),
('SKP00088', 'Melaksanakan pemusnahan dokumen / barang (per dokumen / barang) - 15.0 menit', '15'),
('SKP00089', 'Melaksanakan pemusnahan dokumen / barang (per dokumen / barang) - 60.0 menit', '60'),
('SKP00090', 'Melaksanakan pemusnahan dokumen / barang (per dokumen / barang) - 30.0 menit', '30'),
('SKP00091', 'Melaksanakan penagihan pada penyewa - 15.0 menit', '15'),
('SKP00092', 'Melaksanakan Penanganan Gangguan pada BTS Radio Trunking - 120.0 menit', '120'),
('SKP00093', 'Melaksanakan Penanganan Gangguan pada HT / RIG Pengguna - 30.0 menit', '30'),
('SKP00094', 'Melaksanakan penanganan keadaan darurat - 180.0 menit', '180'),
('SKP00095', 'Melaksanakan penanganan keadaan darurat - 120.0 menit', '120'),
('SKP00096', 'Melaksanakan penanganan keadaan darurat - 60.0 menit', '60'),
('SKP00097', 'Melaksanakan penanganan keadaan darurat - 30.0 menit', '30'),
('SKP00098', 'Melaksanakan Pendataan CCTV - 30.0 menit', '30'),
('SKP00099', 'Melaksanakan Pendataan Fisik Menara Telekomunikasi - 30.0 menit', '30'),
('SKP00100', 'Melaksanakan Pendataan HT / RIG Trunking - 30.0 menit', '30'),
('SKP00101', 'Melaksanakan Pendistribusian Logistik dan Penanganan Kedaruratan - 60.0 menit', '60'),
('SKP00102', 'Melaksanakan Penentuan Titik Lokasi CCTV - 30.0 menit', '30'),
('SKP00103', 'Melaksanakan Penerapan rancangan konfigurasi sistem jaringan komputer - 120.0 menit', '120'),
('SKP00104', 'Melaksanakan Penerapan rancangan konfigurasi sistem jaringan komputer - 60.0 menit', '60'),
('SKP00105', 'Melaksanakan Penertiban (per titik / per objek) - 60.0 menit', '60'),
('SKP00106', 'Melaksanakan Penertiban (per titik / per objek) - 120.0 menit', '120'),
('SKP00107', 'Melaksanakan Penertiban (per titik / per objek) - 180.0 menit', '180'),
('SKP00108', 'Melaksanakan Pengambilan Gambar dengan Kamera - 5.0 menit', '5'),
('SKP00109', 'Melaksanakan Pengambilan Gambar dengan Kamera - 15.0 menit', '15'),
('SKP00110', 'Melaksanakan Pengambilan Gambar dengan Kamera - 2.0 menit', '2'),
('SKP00111', 'Melaksanakan pengaturan lalu lintas - 120.0 menit', '120'),
('SKP00112', 'Melaksanakan pengaturan lalu lintas - 30.0 menit', '30'),
('SKP00113', 'Melaksanakan pengaturan lalu lintas - 60.0 menit', '60'),
('SKP00114', 'Melaksanakan penginformasian kepada pengguna jalan dengan Variable Message Sign (VMS) Mobile - 120.0 menit', '120'),
('SKP00115', 'Melaksanakan penginformasian kepada pengguna jalan dengan Variable Message Sign (VMS) Mobile - 60.0 menit', '60'),
('SKP00116', 'Melaksanakan Pengukuran Koordinat - 10.0 menit', '10'),
('SKP00117', 'Melaksanakan Pengukuran Pengukuran Gelombang Elektromagnetik (Radiasi) - 15.0 menit', '15'),
('SKP00118', 'Melaksanakan Pengukuran Pengukuran Gelombang Elektromagnetik (Radiasi) - 30.0 menit', '30'),
('SKP00119', 'Melaksanakan Pengukuran Spektrum Radio Frekuensi - 30.0 menit', '30'),
('SKP00120', 'Melaksanakan Pengukuran Spektrum Radio Frekuensi - 15.0 menit', '15'),
('SKP00121', 'Melaksanakan pengukuran tanah >1000 m2 (per lokasi) - 90.0 menit', '90'),
('SKP00122', 'Melaksanakan pengukuran tanah 500 - 1000 m2 (per lokasi) - 60.0 menit', '60'),
('SKP00123', 'Melaksanakan pengukuran tanah < 500 m2 (per lokasi) - 30.0 menit', '30'),
('SKP00124', 'Melaksanakan Pengukuran Tinggi Menara Telekomunikasi - 10.0 menit', '10'),
('SKP00125', 'Melaksanakan pengumpulan data, validasi data, analisis data dan penyajian (publikasi data) sesuai dengan objek kerja - 60.0 menit', '60'),
('SKP00126', 'Melaksanakan pengumpulan data, validasi data, analisis data dan penyajian (publikasi data) sesuai dengan objek kerja - 120.0 menit', '120'),
('SKP00127', 'Melaksanakan Penilaian Kinerja Guru - 60.0 menit', '60'),
('SKP00128', 'Melaksanakan Penilaian Kinerja Guru - 120.0 menit', '120'),
('SKP00129', 'Melaksanakan Penilaian Kinerja Kepala Sekolah / Pengawas Sekolah - 60.0 menit', '60'),
('SKP00130', 'Melaksanakan Penilaian Kinerja Kepala Sekolah / Pengawas Sekolah - 120.0 menit', '120'),
('SKP00131', 'Melaksanakan penjurian (per hari per kegiatan) - 120.0 menit', '120'),
('SKP00132', 'Melaksanakan penyidikan (per hari per kasus) - 60.0 menit', '60'),
('SKP00133', 'Melaksanakan penyidikan (per hari per kasus) - 120.0 menit', '120'),
('SKP00134', 'Melaksanakan Perakitan dan Instalasi Pemasangan RIG Trunking - 60.0 menit', '60'),
('SKP00135', 'Melaksanakan Perakitan dan Instalasi Pemasangan RIG Trunking - 120.0 menit', '120'),
('SKP00136', 'Melaksanakan perbaikan objek kerja setelah koreksi pimpinan - 30.0 menit', '30'),
('SKP00137', 'Melaksanakan perbaikan objek kerja setelah koreksi pimpinan - 15.0 menit', '15'),
('SKP00138', 'Melaksanakan Registrasi HT / RIG Trunking Ke Sistem - 5.0 menit', '5'),
('SKP00139', 'Melaksanakan sanitasi kandang (perkandang) - 30.0 menit', '30'),
('SKP00140', 'Melaksanakan sensus barang - 120.0 menit', '120'),
('SKP00141', 'Melaksanakan sensus barang - 30.0 menit', '30'),
('SKP00142', 'Melaksanakan sensus barang - 60.0 menit', '60'),
('SKP00143', 'Melaksanakan tera ulang terhadap alat ukur (per alat ukur) - 30.0 menit', '30'),
('SKP00144', 'Melaksanakan tera ulang terhadap alat ukur (per alat ukur) - 15.0 menit', '15'),
('SKP00145', 'Melaksanakan tindakan medis terhadap satwa (per hewan) - 120.0 menit', '120'),
('SKP00146', 'Melaksanakan tindakan medis terhadap satwa (per hewan) - 60.0 menit', '60'),
('SKP00147', 'Melaksanakan tindakan medis terhadap satwa (per hewan) - 30.0 menit', '30'),
('SKP00148', 'Melaksanakan tindakan rawat jalan - 60.0 menit', '60'),
('SKP00149', 'Melaksanakan tindakan rawat jalan - 30.0 menit', '30'),
('SKP00150', 'Melaksanakan tindakan rawat jalan - 10.0 menit', '10'),
('SKP00151', 'Melaksanakan Transaksi Pembayaran ke Pihak Ketiga - 30.0 menit', '30'),
('SKP00152', 'Melaksanakan tugas piket diluar jam kerja - 30.0 menit', '30'),
('SKP00153', 'Melaksanakan tugas piket diluar jam kerja - 120.0 menit', '120'),
('SKP00154', 'Melaksanakan tugas piket diluar jam kerja - 60.0 menit', '60'),
('SKP00155', 'Melaksanakan tugas sebagai asisten pelayanan kesehatan - 10.0 menit', '10'),
('SKP00156', 'Melaksanakan tugas sebagai asisten pelayanan kesehatan - 5.0 menit', '5'),
('SKP00157', 'Melaksanakan tugas sebagai asistensi Pelayanan Kesehatan - 10.0 menit', '10'),
('SKP00158', 'Melaksanakan tugas-tugas pengawasan dengan kompleksitas rendah dalam kegiatan pemantauan - 240.0 menit', '240'),
('SKP00159', 'Melaksanakan tugas-tugas pengawasan dengan kompleksitas rendah dalam kegiatan pemantauan - 120.0 menit', '120'),
('SKP00160', 'Melaksanakan tugas-tugas pengawasan dengan kompleksitas sedang dalam kegiatan pemantauan - 240.0 menit', '240'),
('SKP00161', 'Melaksanakan tugas-tugas pengawasan dengan kompleksitas sedang dalam kegiatan pemantauan - 120.0 menit', '120'),
('SKP00162', 'Melaksanakan tugas untuk kelancaran dan ketertiban di area pelabuhan - 30.0 menit', '30'),
('SKP00163', 'Melaksanakan upaya pencegahan - 30.0 menit', '30'),
('SKP00164', 'Melaksanakan upaya pencegahan - 60.0 menit', '60'),
('SKP00165', 'Melaksanakan Verifikasi (per berkas) - 5.0 menit', '5'),
('SKP00166', 'Melaksanakan Verifikasi (per berkas) - 15.0 menit', '15'),
('SKP00167', 'Melaksanakan Verifikasi (per berkas) - 60.0 menit', '60'),
('SKP00168', 'Melaksanakan Verifikasi (per berkas) - 30.0 menit', '30'),
('SKP00169', 'Melaksanakan Wawancara dengan Pelapor / Saksi - 30.0 menit', '30'),
('SKP00170', 'Melaksanakan Wawancara dengan Pelapor / Saksi - 60.0 menit', '60'),
('SKP00171', 'Melakukan analisa dalam proses pengadaan Barang / Jasa - 60.0 menit', '60'),
('SKP00172', 'Melakukan analisa dalam proses pengadaan Barang / Jasa - 120.0 menit', '120'),
('SKP00173', 'Melakukan analisa / kajian / telaahan - 180.0 menit', '180'),
('SKP00174', 'Melakukan analisa / kajian / telaahan - 30.0 menit', '30'),
('SKP00175', 'Melakukan analisa / kajian / telaahan - 60.0 menit', '60'),
('SKP00176', 'Melakukan analisa / kajian / telaahan - 120.0 menit', '120'),
('SKP00177', 'Melakukan analisa usulan anggaran dan perubahan anggaran SKPD / UKPD - 90.0 menit', '90'),
('SKP00178', 'Melakukan Audit Rutin Sistem - 30.0 menit', '30'),
('SKP00179', 'Melakukan Audit Rutin Sistem - 60.0 menit', '60'),
('SKP00180', 'Melakukan Back Up Aplikasi / Sistem - 60.0 menit', '60'),
('SKP00181', 'Melakukan Back Up Aplikasi / Sistem - 120.0 menit', '120'),
('SKP00182', 'Melakukan Back Up Data - 120.0 menit', '120'),
('SKP00183', 'Melakukan Back Up Data - 60.0 menit', '60'),
('SKP00184', 'Melakukan coding program database - 60.0 menit', '60'),
('SKP00185', 'Melakukan coding program database - 90.0 menit', '90'),
('SKP00186', 'Melakukan deteksi - 60.0 menit', '60'),
('SKP00187', 'Melakukan deteksi - 120.0 menit', '120'),
('SKP00188', 'Melakukan Digitalisasi Arsip (per file) - 30.0 menit', '30'),
('SKP00189', 'Melakukan Digitalisasi Arsip (per file) - 15.0 menit', '15'),
('SKP00190', 'Melakukan dokumentasi kegiatan seperti pengambilan gambar dan cetak gambar - 10.0 menit', '10'),
('SKP00191', 'Melakukan edukasi pasien - 15.0 menit', '15'),
('SKP00192', 'Melakukan evakuasi kegiatan emergency / kecelakaan terhadap sarana dan prasarana lampu lalu lintas - 60.0 menit', '60'),
('SKP00193', 'Melakukan evakuasi penyelamatan - 60.0 menit', '60'),
('SKP00194', 'Melakukan evakuasi penyelamatan - 120.0 menit', '120'),
('SKP00195', 'Melakukan evaluasi - 60.0 menit', '60'),
('SKP00196', 'Melakukan evaluasi - 120.0 menit', '120'),
('SKP00197', 'Melakukan evaluasi - 30.0 menit', '30'),
('SKP00198', 'Melakukan Evaluasi Sistem Akuntabilitas Kinerja Instansi Pemerintah per 1 SKPD - 30.0 menit', '30'),
('SKP00199', 'Melakukan Evaluasi Sistem Akuntabilitas Kinerja Instansi Pemerintah per 1 SKPD - 60.0 menit', '60'),
('SKP00200', 'Melakukan identifikasi - 90.0 menit', '90'),
('SKP00201', 'Melakukan identifikasi - 60.0 menit', '60'),
('SKP00202', 'Melakukan identifikasi - 30.0 menit', '30'),
('SKP00203', 'Melakukan identifikasi - 15.0 menit', '15'),
('SKP00204', 'Melakukan Identifikasi dan Verfikasi Perangkat Keras - 60.0 menit', '60'),
('SKP00205', 'Melakukan Identifikasi dan Verfikasi Perangkat Keras - 30.0 menit', '30'),
('SKP00206', 'Melakukan Inservice Jaringan Online Mainframe - 15.0 menit', '15'),
('SKP00207', 'Melakukan Inservice Printer Online - 15.0 menit', '15'),
('SKP00208', 'Melakukan inspeksi - 60.0 menit', '60'),
('SKP00209', 'Melakukan inspeksi - 120.0 menit', '120'),
('SKP00210', 'Melakukan inspeksi - 30.0 menit', '30'),
('SKP00211', 'Melakukan instalasi perangkat lunak / keras - 15.0 menit', '15'),
('SKP00212', 'Melakukan instalasi perangkat lunak / keras - 30.0 menit', '30'),
('SKP00213', 'Melakukan inventarisasi - 10.0 menit', '10'),
('SKP00214', 'Melakukan inventarisasi - 60.0 menit', '60'),
('SKP00215', 'Melakukan inventarisasi - 30.0 menit', '30'),
('SKP00216', 'Melakukan kalibrasi - 15.0 menit', '15'),
('SKP00217', 'Melakukan kalibrasi - 60.0 menit', '60'),
('SKP00218', 'Melakukan kalibrasi - 30.0 menit', '30'),
('SKP00219', 'Melakukan kegiatan administrasi (Menerima surat, fax, telepon dan mengirim surat, fax) - 10.0 menit', '10'),
('SKP00220', 'Melakukan kegiatan administrasi (Menerima surat, fax, telepon dan mengirim surat, fax) - 5.0 menit', '5'),
('SKP00221', 'Melakukan kegiatan administrasi (Menerima surat, fax, telepon dan mengirim surat, fax) - 15.0 menit', '15'),
('SKP00222', 'Melakukan kegiatan pelayanan (Menerima, memverifikasi dan mencatat berkas / surat / dokumen dan / atau memberi penjelasan) - 15.0 menit', '15'),
('SKP00223', 'Melakukan kegiatan pelayanan (Menerima, memverifikasi, dan mencatat berkas / surat / dokumen dan / atau memberi penjelasan) - 3.0 menit', '3'),
('SKP00224', 'Melakukan kegiatan pelayanan (Menerima, memverifikasi, dan mencatat berkas / surat / dokumen dan / atau memberi penjelasan) - 5.0 menit', '5'),
('SKP00225', 'Melakukan kegiatan promosi kesehatan perorangan - 15.0 menit', '15'),
('SKP00226', 'Melakukan kegiatan Promosi / Pameran / Bazar Investasi Dalam Negeri - 180.0 menit', '180'),
('SKP00227', 'Melakukan kegiatan Promosi / Pameran / Bazar Investasi Dalam Negeri - 120.0 menit', '120'),
('SKP00228', 'Melakukan kegiatan surat menyurat - 15.0 menit', '15'),
('SKP00229', 'Melakukan kegiatan surveilance kasus atau penyakit yang berpotensi menjadi KLB per lokasi - 120.0 menit', '120'),
('SKP00230', 'Melakukan kegiatan surveilance kasus atau penyakit yang berpotensi menjadi KLB per lokasi - 60.0 menit', '60'),
('SKP00231', 'Melakukan kegiatan surveilance kasus atau penyakit yang berpotensi menjadi KLB per lokasi - 180.0 menit', '180'),
('SKP00232', 'Melakukan klaim asuransi - 30.0 menit', '30'),
('SKP00233', 'Melakukan klaim asuransi - 60.0 menit', '60'),
('SKP00234', 'Melakukan konfirmasi gaji dan tunjangan lainnya sebagai data bahan belanja pegawai SKPD - 60.0 menit', '60'),
('SKP00235', 'Melakukan konfirmasi gaji dan tunjangan lainnya sebagai data bahan belanja pegawai SKPD - 30.0 menit', '30'),
('SKP00236', 'Melakukan konversi sistem database - 60.0 menit', '60'),
('SKP00237', 'Melakukan konversi sistem database - 30.0 menit', '30'),
('SKP00238', 'Melakukan koordinasi dengan pusat / provinsi - 60.0 menit', '60'),
('SKP00239', 'Melakukan koordinasi dengan pusat / provinsi - 120.0 menit', '120'),
('SKP00240', 'Melakukan koordinasi dengan SKPD - 30.0 menit', '30'),
('SKP00241', 'Melakukan koordinasi dengan SKPD - 45.0 menit', '45'),
('SKP00242', 'Melakukan koordinasi dengan SKPD - 60.0 menit', '60'),
('SKP00243', 'Melakukan koordinasi dengan subbidang / subbagian dalam satu SKPD - 15.0 menit', '15'),
('SKP00244', 'Melakukan koordinasi dengan subbidang / subbagian dalam satu SKPD - 30.0 menit', '30'),
('SKP00245', 'Melakukan koordinasi melalui media elektronik - 15.0 menit', '15'),
('SKP00246', 'Melakukan kunjungan kerja - 60.0 menit', '60'),
('SKP00247', 'Melakukan kunjungan kerja - 120.0 menit', '120'),
('SKP00248', 'Melakukan kunjungan kerja - 180.0 menit', '180'),
('SKP00249', 'Melakukan kunjungan kerja - 300.0 menit', '300'),
('SKP00250', 'Melakukan Laminasi Arsip - 10.0 menit', '10'),
('SKP00251', 'Melakukan / melaksanakan pemeriksaan / penelitian / uji pada laboratorium - 15.0 menit', '15'),
('SKP00252', 'Melakukan / melaksanakan pemeriksaan / penelitian / uji pada laboratorium - 30.0 menit', '30'),
('SKP00253', 'Melakukan / melaksanakan pemeriksaan / penelitian / uji pada laboratorium - 5.0 menit', '5'),
('SKP00254', 'Melakukan / membuat sistem manajemen mutu - 120.0 menit', '120'),
('SKP00255', 'Melakukan / membuat sistem manajemen mutu - 60.0 menit', '60'),
('SKP00256', 'Melakukan negosiasi dan penyelesaian masalah (per kejadian) - 60.0 menit', '60'),
('SKP00257', 'Melakukan otorisasi / pengesahan objek kerja - 15.0 menit', '15'),
('SKP00258', 'Melakukan otorisasi / pengesahan objek kerja - 5.0 menit', '5'),
('SKP00259', 'Melakukan patroli - 15.0 menit', '15'),
('SKP00260', 'Melakukan patroli - 30.0 menit', '30'),
('SKP00261', 'Melakukan pekerjaan gas medis - 30.0 menit', '30'),
('SKP00262', 'Melakukan pekerjaan linen Rumah Sakit - 30.0 menit', '30'),
('SKP00263', 'Melakukan pekerjaan linen Rumah Sakit - 15.0 menit', '15'),
('SKP00264', 'Melakukan pekerjaan linen Rumah Sakit - 45.0 menit', '45'),
('SKP00265', 'Melakukan pekerjaan rekam medis - 10.0 menit', '10'),
('SKP00266', 'Melakukan pekerjaan rekam medis - 20.0 menit', '20'),
('SKP00267', 'Melakukan pekerjaan rekam medis - 30.0 menit', '30'),
('SKP00268', 'Melakukan pekerjaan rekam medis - 60.0 menit', '60'),
('SKP00269', 'Melakukan Pelayanan Kesehatan Wanita - 20.0 menit', '20'),
('SKP00270', 'Melakukan pelayanan Pap Smear - 20.0 menit', '20'),
('SKP00271', 'Melakukan pelayaran sebagai ABK sesuai dengan prosedur pelayaran - 120.0 menit', '120'),
('SKP00272', 'Melakukan pelayaran sebagai ABK sesuai dengan prosedur pelayaran - 60.0 menit', '60'),
('SKP00273', 'Melakukan pembinaan / penilaian pegawai - 15.0 menit', '15'),
('SKP00274', 'Melakukan pemeliharaan kandang (per lokasi) - 30.0 menit', '30'),
('SKP00275', 'Melakukan pemeliharaan kandang (per lokasi) - 60.0 menit', '60'),
('SKP00276', 'Melakukan pemeliharaan kandang (per lokasi) - 120.0 menit', '120'),
('SKP00277', 'Melakukan pemeliharaan objek kerja - 30.0 menit', '30'),
('SKP00278', 'Melakukan pemeliharaan objek kerja - 60.0 menit', '60'),
('SKP00279', 'Melakukan pemeliharaan objek kerja - 45.0 menit', '45'),
('SKP00280', 'Melakukan pemeliharaan objek kerja - 15.0 menit', '15'),
('SKP00281', 'Melakukan Pemeliharaan Perangkat Keras / Lunak - 30.0 menit', '30'),
('SKP00282', 'Melakukan Pemeliharaan Perangkat Keras / Lunak - 60.0 menit', '60'),
('SKP00283', 'Melakukan pemerikasaan dan pengawasan - 120.0 menit', '120'),
('SKP00284', 'Melakukan pemerikasaan dan pengawasan - 60.0 menit', '60'),
('SKP00285', 'Melakukan pemeriksaan barang / dokumen / berkas - 3.0 menit', '3'),
('SKP00286', 'Melakukan pemeriksaan barang / dokumen / berkas - 5.0 menit', '5'),
('SKP00287', 'Melakukan pemeriksaan berdasarkan temuan, aduan, tangkap tangan - 120.0 menit', '120'),
('SKP00288', 'Melakukan pemeriksaan berdasarkan temuan, aduan, tangkap tangan - 60.0 menit', '60'),
('SKP00289', 'Melakukan pemeriksaan objek pasca bencana (banjir, kebakaran, gempa, dll) - 120.0 menit', '120'),
('SKP00290', 'Melakukan pemeriksaan objek pasca bencana (banjir, kebakaran, gempa, dll) - 180.0 menit', '180'),
('SKP00291', 'Melakukan pemeriksaan okupasi terapi (Formal kasus berat) - 15.0 menit', '15'),
('SKP00292', 'Melakukan pemeriksaan okupasi terapi ( Informal ) - 20.0 menit', '20'),
('SKP00293', 'Melakukan pemeriksaan terhadap alat-alat bukti - 10.0 menit', '10'),
('SKP00294', 'Melakukan pemeriksaan tes kekuatan otot - 15.0 menit', '15'),
('SKP00295', 'Melakukan Pemungutan / Penyetoran Pajak - 60.0 menit', '60'),
('SKP00296', 'Melakukan Pemungutan / Penyetoran Pajak - 30.0 menit', '30'),
('SKP00297', 'Melakukan Penanganan Masalah (Troubleshooting) pada Aplikasi / Sistem - 30.0 menit', '30'),
('SKP00298', 'Melakukan Penanganan Masalah (Troubleshooting) pada Aplikasi / Sistem - 60.0 menit', '60'),
('SKP00299', 'Melakukan penanggulangan KLB dan wabah - 30.0 menit', '30'),
('SKP00300', 'Melakukan penanggulangan KLB dan wabah - 15.0 menit', '15'),
('SKP00301', 'Melakukan penanggulangan KLB dan wabah - 60.0 menit', '60'),
('SKP00302', 'Melakukan pencairan SP2D - 30.0 menit', '30'),
('SKP00303', 'Melakukan Pencatatan dan pelayanan laboratorium - 60.0 menit', '60'),
('SKP00304', 'Melakukan pendampingan kegiatan - 60.0 menit', '60'),
('SKP00305', 'Melakukan pendampingan kegiatan - 180.0 menit', '180'),
('SKP00306', 'Melakukan pendampingan kegiatan - 30.0 menit', '30'),
('SKP00307', 'Melakukan pendampingan kegiatan - 120.0 menit', '120'),
('SKP00308', 'Melakukan pendampingan penyusunan Analisa jabatan, Analisa Beban Kerja dan Evaluasi Jabatan - 120.0 menit', '120'),
('SKP00309', 'Melakukan pendampingan penyusunan Analisa jabatan, Analisa Beban Kerja dan Evaluasi Jabatan - 60.0 menit', '60'),
('SKP00310', 'Melakukan pendampingan sidak (per lokasi sidak) - 120.0 menit', '120'),
('SKP00311', 'Melakukan pendampingan sidak (per lokasi sidak) - 60.0 menit', '60'),
('SKP00312', 'Melakukan pendataan - 60.0 menit', '60'),
('SKP00313', 'Melakukan pendataan - 30.0 menit', '30'),
('SKP00314', 'Melakukan pendataan - 120.0 menit', '120'),
('SKP00315', 'Melakukan pendataan - 90.0 menit', '90'),
('SKP00316', 'Melakukan pendistribusian barang - 60.0 menit', '60'),
('SKP00317', 'Melakukan pendistribusian barang - 30.0 menit', '30'),
('SKP00318', 'Melakukan pendistribusian barang - 15.0 menit', '15'),
('SKP00319', 'Melakukan pendistribusian barang - 120.0 menit', '120'),
('SKP00320', 'Melakukan penelitian - 30.0 menit', '30'),
('SKP00321', 'Melakukan penelitian - 15.0 menit', '15'),
('SKP00322', 'Melakukan penelitian - 60.0 menit', '60'),
('SKP00323', 'Melakukan Pengamanan / Pemantauan Data / Sistem - 120.0 menit', '120'),
('SKP00324', 'Melakukan Pengamanan / Pemantauan Data / Sistem - 60.0 menit', '60'),
('SKP00325', 'Melakukan Pengamatan dan Penggambaran terhadap target operasi - 60.0 menit', '60'),
('SKP00326', 'Melakukan Pengamatan dan Penggambaran terhadap target operasi - 30.0 menit', '30'),
('SKP00327', 'Melakukan pengambilan darah / sampling ke pasien - 5.0 menit', '5'),
('SKP00328', 'Melakukan pengaturan pada objek kerja - 15.0 menit', '15'),
('SKP00329', 'Melakukan pengaturan pada objek kerja - 60.0 menit', '60'),
('SKP00330', 'Melakukan pengaturan pada objek kerja - 30.0 menit', '30'),
('SKP00331', 'Melakukan pengaturan / pengelolaan objek kerja - 15.0 menit', '15'),
('SKP00332', 'Melakukan pengaturan / pengelolaan objek kerja - 30.0 menit', '30'),
('SKP00333', 'Melakukan pengaturan / setting router multiplayer / radio wireless / kamera / cctv (per objek) - 15.0 menit', '15'),
('SKP00334', 'Melakukan pengawasan - 60.0 menit', '60'),
('SKP00335', 'Melakukan pengawasan - 120.0 menit', '120'),
('SKP00336', 'Melakukan pengawasan - 30.0 menit', '30'),
('SKP00337', 'Melakukan pengawasan - 15.0 menit', '15'),
('SKP00338', 'Melakukan Pengawasan dan Audit - 60.0 menit', '60'),
('SKP00339', 'Melakukan Pengawasan dan Audit - 180.0 menit', '180'),
('SKP00340', 'Melakukan Pengawasan dan Audit - 120.0 menit', '120'),
('SKP00341', 'Melakukan pengecekan kelengkapan kapal sesuai prosedur dan arahan pimpinan - 60.0 menit', '60'),
('SKP00342', 'Melakukan pengecekan mutasi aset - 60.0 menit', '60'),
('SKP00343', 'Melakukan pengecekan mutasi aset - 120.0 menit', '120'),
('SKP00344', 'Melakukan pengecekan mutasi aset - 180.0 menit', '180'),
('SKP00345', 'Melakukan pengelolaan / pemeliharaan sistem aplikasi - 60.0 menit', '60'),
('SKP00346', 'Melakukan pengelolaan / pemeliharaan sistem aplikasi - 30.0 menit', '30'),
('SKP00347', 'Melakukan penghitungan terhadap objek kerja - 15.0 menit', '15'),
('SKP00348', 'Melakukan penghitungan terhadap objek kerja - 60.0 menit', '60'),
('SKP00349', 'Melakukan penghitungan terhadap objek kerja - 30.0 menit', '30'),
('SKP00350', 'Melakukan Pengkodean, Pendokumentasian dan Penyimpanan Hasil Uji - 20.0 menit', '20'),
('SKP00351', 'Melakukan Pengujian Atas Analisa Data pada Benda Cagar Budaya / Benda Seni (Per Benda) - 60.0 menit', '60'),
('SKP00352', 'Melakukan Pengujian Atas Analisa Data pada Benda Cagar Budaya / Benda Seni (Per Benda) - 30.0 menit', '30'),
('SKP00353', 'Melakukan pengukuran kapal nelayan untuk penetapan di bawah 7 GT (per kapal) - 60.0 menit', '60'),
('SKP00354', 'Melakukan Pengukuran Objek - 30.0 menit', '30'),
('SKP00355', 'Melakukan Pengukuran Objek - 60.0 menit', '60'),
('SKP00356', 'Melakukan Pengukuran Teknis Postel - 30.0 menit', '30'),
('SKP00357', 'Melakukan Pengukuran Teknis Postel - 120.0 menit', '120'),
('SKP00358', 'Melakukan Pengukuran Teknis Telekomunikasi dan Multimedia - 60.0 menit', '60'),
('SKP00359', 'Melakukan Pengukuran Teknis Telekomunikasi dan Multimedia - 30.0 menit', '30'),
('SKP00360', 'Melakukan penilaian - 60.0 menit', '60'),
('SKP00361', 'Melakukan penilaian - 30.0 menit', '30'),
('SKP00362', 'Melakukan penilaian - 120.0 menit', '120'),
('SKP00363', 'Melakukan penilaian - 10.0 menit', '10'),
('SKP00364', 'Melakukan penilaian angka kredit terhadap JFT - 60.0 menit', '60'),
('SKP00365', 'Melakukan penilaian dalam proses pengadaan barang / jasa - 60.0 menit', '60'),
('SKP00366', 'Melakukan penjilidan dan pendistribusian laporan keuangan - 60.0 menit', '60'),
('SKP00367', 'Melakukan penyegelan terhadap bangunan - 60.0 menit', '60'),
('SKP00368', 'Melakukan penyuluhan - 30.0 menit', '30'),
('SKP00369', 'Melakukan Perawatan Benda Cagar Budaya / Benda Seni - 60.0 menit', '60'),
('SKP00370', 'Melakukan Perawatan Benda Cagar Budaya / Benda Seni - 30.0 menit', '30'),
('SKP00371', 'Melakukan perbaikan objek kerja - 90.0 menit', '90'),
('SKP00372', 'Melakukan perbaikan objek kerja - 15.0 menit', '15'),
('SKP00373', 'Melakukan perbaikan objek kerja - 30.0 menit', '30'),
('SKP00374', 'Melakukan perbaikan objek kerja - 45.0 menit', '45'),
('SKP00375', 'Melakukan perbaikan objek kerja - 60.0 menit', '60'),
('SKP00376', 'Melakukan perbaikan objek kerja - 120.0 menit', '120'),
('SKP00377', 'Melakukan pointing arah antena sentral (per lokasi) - 30.0 menit', '30'),
('SKP00378', 'Melakukan Print Out Borderel, SKP dan TNKB - 60.0 menit', '60'),
('SKP00379', 'Melakukan Print Out Borderel, SKP dan TNKB - 30.0 menit', '30'),
('SKP00380', 'Melakukan proses kegiatan akreditasi - 30.0 menit', '30'),
('SKP00381', 'Melakukan QC, kalibrasi, persiapan reagen masing-masing alat kimia, hematologi, urinalisa, imunologi - 10.0 menit', '10'),
('SKP00382', 'Melakukan Rapat Rekonsiliasi dengan para bendahara pengeluaran - 120.0 menit', '120'),
('SKP00383', 'Melakukan Rapat Rekonsiliasi dengan para PPTK yang memiliki tagihan utang pada pihak ketiga - 120.0 menit', '120'),
('SKP00384', 'Melakukan Rapat Rekonsiliasi dengan pengurus barang dan penyimpan barang - 120.0 menit', '120'),
('SKP00385', 'Melakukan Recovery Data / Aplikasi / Sistem - 120.0 menit', '120'),
('SKP00386', 'Melakukan Recovery Data / Aplikasi / Sistem - 60.0 menit', '60'),
('SKP00387', 'Melakukan rekonsiliasi - 60.0 menit', '60'),
('SKP00388', 'Melakukan rekonsiliasi - 15.0 menit', '15'),
('SKP00389', 'Melakukan rekonsiliasi - 30.0 menit', '30'),
('SKP00390', 'Melakukan rekonsiliasi aset - 60.0 menit', '60'),
('SKP00391', 'Melakukan rekonsiliasi aset - 120.0 menit', '120'),
('SKP00392', 'Melakukan rekonsiliasi data / keuangan / aset - 180.0 menit', '180'),
('SKP00393', 'Melakukan rekonsiliasi data / keuangan / aset - 120.0 menit', '120'),
('SKP00394', 'Melakukan rekonsiliasi data / keuangan / aset - 60.0 menit', '60'),
('SKP00395', 'Melakukan rekonsiliasi data / keuangan / aset - 30.0 menit', '30'),
('SKP00396', 'Melakukan Rekonsiliasi Data per kegiatan - 30.0 menit', '30'),
('SKP00397', 'Melakukan rekonsiliasi Laporan Keuangan - 60.0 menit', '60'),
('SKP00398', 'Melakukan rekonsiliasi Laporan Keuangan - 30.0 menit', '30'),
('SKP00399', 'Melakukan rekonsiliasi Laporan Keuangan - 120.0 menit', '120'),
('SKP00400', 'Melakukan rekrutmen calon tenaga kerja untuk penempatan (per orang) - 60.0 menit', '60'),
('SKP00401', 'Melakukan rekrutmen calon tenaga kerja untuk penempatan (per orang) - 120.0 menit', '120'),
('SKP00402', 'Melakukan rekrutmen calon tenaga kerja untuk penempatan (per orang) - 30.0 menit', '30'),
('SKP00403', 'Melakukan reviu - 120.0 menit', '120'),
('SKP00404', 'Melakukan reviu - 60.0 menit', '30'),
('SKP00405', 'Melakukan reviu - 30.0 menit', '30'),
('SKP00406', 'Melakukan reviu - 180.0 menit', '180'),
('SKP00407', 'Melakukan rujukan - 60.0 menit', '60'),
('SKP00408', 'Melakukan screening palliative - 15.0 menit', '15'),
('SKP00409', 'Melakukan Seleksi Bahan Pustaka - 90.0 menit', '90'),
('SKP00410', 'Melakukan Seleksi Bahan Pustaka - 60.0 menit', '60'),
('SKP00411', 'Melakukan Start Up Aplikasi Online pada Mesin Mainframe - 30.0 menit', '30'),
('SKP00412', 'Melakukan Start Up Aplikasi Online pada Mesin Mainframe - 10.0 menit', '10'),
('SKP00413', 'Melakukan Stock Opname - 60.0 menit', '60'),
('SKP00414', 'Melakukan Stock Opname - 30.0 menit', '30'),
('SKP00415', 'Melakukan Stock Opname - 15.0 menit', '15'),
('SKP00416', 'Melakukan Stop Aplikasi Online pada Mesin Mainframe - 10.0 menit', '10'),
('SKP00417', 'Melakukan Stop Aplikasi Online pada Mesin Mainframe - 30.0 menit', '30'),
('SKP00418', 'Melakukan terapi pada kasus gangguan jiwa / psikososial tingkat sedang kelompok relaksasi / interaksi sosial - 60.0 menit', '60'),
('SKP00419', 'Melakukan terapi pada kasus gangguan jiwa / psikososial tingkat sedang kelompok relaksasi / interaksi sosial - 30.0 menit', '30'),
('SKP00420', 'Melakukan tindakan darurat medik gigi dan mulut kompleks tingkat I - 60.0 menit', '60'),
('SKP00421', 'Melakukan tindakan komplek medis - 120.0 menit', '120'),
('SKP00422', 'Melakukan tindakan komplek medis - 180.0 menit', '180'),
('SKP00423', 'Melakukan tindakan operasi medis - 120.0 menit', '120'),
('SKP00424', 'Melakukan tindakan operasi medis - 90.0 menit', '90'),
('SKP00425', 'Melakukan tindakan processing film - 15.0 menit', '15'),
('SKP00426', 'Melakukan tindakan proteksi radiasi / kalibrasi - 60.0 menit', '60'),
('SKP00427', 'Melakukan tindakan proteksi radiasi / kalibrasi - 15.0 menit', '15'),
('SKP00428', 'Melakukan tindakan proteksi radiasi / kalibrasi - 30.0 menit', '30'),
('SKP00429', 'Melakukan tindakan proteksi radiasi / kalibrasi - 180.0 menit', '180'),
('SKP00430', 'Melakukan tindakan radiologi - 30.0 menit', '30'),
('SKP00431', 'Melakukan tindakan radiologi - 15.0 menit', '15'),
('SKP00432', 'Melakukan tindakan teknik pemeriksaan radiologi USG - 15.0 menit', '15'),
('SKP00433', 'Melakukan tindakan teknik pemeriksaan radiologi USG - 30.0 menit', '30'),
('SKP00434', 'Melakukan tindakan terapi pada problem gerak dan fungsi pada tumbuh kembang anak kasus sedang - 30.0 menit', '30'),
('SKP00435', 'Melakukan tindakan / terapi pengobatan - 15.0 menit', '15'),
('SKP00436', 'Melakukan tindakan / terapi pengobatan - 60.0 menit', '60'),
('SKP00437', 'Melakukan tindakan / terapi pengobatan - 30.0 menit', '30'),
('SKP00438', 'Melakukan transfer pasien antara unit - 5.0 menit', '5'),
('SKP00439', 'Melakukan transfer pasien antara unit - 30.0 menit', '30'),
('SKP00440', 'Melakukan transfer pasien antara unit - 15.0 menit', '15'),
('SKP00441', 'Melakukan uji coba - 120.0 menit', '120'),
('SKP00442', 'Melakukan uji coba - 30.0 menit', '30'),
('SKP00443', 'Melakukan uji coba - 60.0 menit', '60'),
('SKP00444', 'Melakukan Update Berita pada Website - 10.0 menit', '10'),
('SKP00445', 'Melakukan Up Date Data - 15.0 menit', '15'),
('SKP00446', 'Melakukan Up Date Data - 60.0 menit', '60'),
('SKP00447', 'Melakukan Up Date Data - 30.0 menit', '30'),
('SKP00448', 'Melakukan usulan komponen per kode rekening kegiatan - 20.0 menit', '20'),
('SKP00449', 'Melakukan validasi Anggaran per kode rekening kegiatan - 20.0 menit', '20'),
('SKP00450', 'Melakukan validasi Anggaran per kode rekening kegiatan - 30.0 menit', '30'),
('SKP00451', 'Melakukan validasi Anggaran per kode rekening kegiatan - 10.0 menit', '10'),
('SKP00452', 'Melakukan validasi data - 5.0 menit', '5'),
('SKP00453', 'Melakukan validasi data - 15.0 menit', '15'),
('SKP00454', 'Melakukan validasi / verifikasi Analisa Jabatan / Analisa Beban Kerja / Evaluasi Jabatan SKPD / UKPD - 60.0 menit', '60'),
('SKP00455', 'Melakukan validasi / verifikasi Analisa Jabatan / Analisa Beban Kerja / Evaluasi Jabatan SKPD / UKPD - 90.0 menit', '90'),
('SKP00456', 'Melakukan validasi / verifikasi Kelas Jabatan / Nama Jabatan / Formasi Jabatan - 60.0 menit', '60'),
('SKP00457', 'Melakukan validasi / verifikasi Kelas Jabatan / Nama Jabatan / Formasi Jabatan - 30.0 menit', '30'),
('SKP00458', 'Melakukan validasi / verifikasi nama jabatan SKPD / UKPD - 90.0 menit', '90'),
('SKP00459', 'Melakukan validasi / verifikasi nama jabatan SKPD / UKPD - 60.0 menit', '60'),
('SKP00460', 'Melakukan verifikasi dan validasi - 60.0 menit', '60'),
('SKP00461', 'Melakukan verifikasi dan validasi - 15.0 menit', '15'),
('SKP00462', 'Melakukan verifikasi dan validasi - 30.0 menit', '30'),
('SKP00463', 'Melakukan verifikasi gambar perencanaan - 60.0 menit', '60'),
('SKP00464', 'Melakukan verifikasi gambar perencanaan - 30.0 menit', '30'),
('SKP00465', 'Melakukan visum et repertum - 60.0 menit', '60'),
('SKP00466', 'Melakukan visum et repertum - 120.0 menit', '120'),
('SKP00467', 'Melaporkan dan mempertanggungjawabkan pengeluaran Anggaran APBD / APBN ke BPKD, Inspektorat dan Kementerian Keuangan - 30.0 menit', '30'),
('SKP00468', 'Melaporkan hasil kegiatan kepada pimpinan - 15.0 menit', '15'),
('SKP00469', 'Melaporkan hasil kegiatan kepada pimpinan - 10.0 menit', '10'),
('SKP00470', 'Melatih satwa - 30.0 menit', '30'),
('SKP00471', 'Meliput acara - 60.0 menit', '60'),
('SKP00472', 'Memandikan Warga Binaan Sosial (WBS) - 30.0 menit', '30'),
('SKP00473', 'Memandu atraksi satwa - 30.0 menit', '30'),
('SKP00474', 'Memantau pasien - 5.0 menit', '5'),
('SKP00475', 'Memaraf Perbal - 5.0 menit', '5'),
('SKP00476', 'Memaraf Perbal - 2.0 menit', '2'),
('SKP00477', 'Memasang alat kontrasepsi - 20.0 menit', '20'),
('SKP00478', 'Memasang tanda legalitas mendirikan bangunan - 60.0 menit', '60'),
('SKP00479', 'Membawakan acara / MC (Per kegiatan) - 60.0 menit', '60'),
('SKP00480', 'Memberi arahan - 60.0 menit', '60'),
('SKP00481', 'Memberi arahan - 30.0 menit', '30'),
('SKP00482', 'Memberikan asistensi kepada pasien dalam terapi kelompok musculoskeletal (per 1 pasien) - 45.0 menit', '45'),
('SKP00483', 'Memberikan disposisi kepada bawahan - 3.0 menit', '3'),
('SKP00484', 'Memberikan disposisi kepada bawahan - 5.0 menit', '5'),
('SKP00485', 'Memberikan Informasi Layanan Publik - 5.0 menit', '5'),
('SKP00486', 'Memberikan Informasi Layanan Publik - 10.0 menit', '10'),
('SKP00487', 'Memberikan informasi status proses berkas perizinan dan non perizinan - 5.0 menit', '5'),
('SKP00488', 'Memberikan informasi terkait hasil verifikasi berkas perizinan dan non perizinan - 5.0 menit', '5'),
('SKP00489', 'Memberikan Informasi User ID dari Aplikasi SPSE - 20.0 menit', '20'),
('SKP00490', 'Memberikan keterangan mewakili pemerintah provinsi DKI Jakarta kepada pihak berwajib - 180.0 menit', '180'),
('SKP00491', 'Memberikan keterangan mewakili pemerintah provinsi DKI Jakarta kepada pihak berwajib - 60.0 menit', '60'),
('SKP00492', 'Memberikan keterangan mewakili pemerintah provinsi DKI Jakarta kepada pihak berwajib - 120.0 menit', '120'),
('SKP00493', 'Memberikan resep obat / pasien - 1.0 menit', '1'),
('SKP00494', 'Membimbing mahasiswa / peserta Diklat - 30.0 menit', '30'),
('SKP00495', 'Membimbing pelaksanaan Pelayanan kesehatan olahraga dan kebugaran - 15.0 menit', '15'),
('SKP00496', 'Membimbing pelaksanaan Pelayanan kesehatan olahraga dan kebugaran - 30.0 menit', '30'),
('SKP00497', 'Membuat algoritma pemrograman per modul - 60.0 menit', '60'),
('SKP00498', 'Membuat algoritma pemrograman per modul - 30.0 menit', '30'),
('SKP00499', 'Membuat algoritma pemrograman per modul - 60.0 menit', '60'),
('SKP00500', 'Membuat atau memperbaiki pengkayaan kandang (enrichment) - 60.0 menit', '60'),
('SKP00501', 'Membuat Berita Acara - 60.0 menit', '60'),
('SKP00502', 'Membuat Berita Acara - 120.0 menit', '120'),
('SKP00503', 'Membuat Berita Acara - 30.0 menit', '30'),
('SKP00504', 'Membuat bestek - 60.0 menit', '60'),
('SKP00505', 'Membuat bestek - 120.0 menit', '120'),
('SKP00506', 'Membuat buku induk inventaris (BII) - 30.0 menit', '30'),
('SKP00507', 'Membuat buku inventaris (BI) - 30.0 menit', '30'),
('SKP00508', 'Membuat catatan medik gigi dan mulut pasien rawat inap / jalan - 5.0 menit', '5'),
('SKP00509', 'Membuat catatan medik gigi dan mulut pasien rawat inap / jalan - 15.0 menit', '15'),
('SKP00510', 'Membuat catatan medik (per pasien) - 5.0 menit', '5'),
('SKP00511', 'Membuat daftar gaji / tunjangan / penghasilan lainnya - 120.0 menit', '120'),
('SKP00512', 'Membuat daftar gaji / tunjangan / penghasilan lainnya - 30.0 menit', '30'),
('SKP00513', 'Membuat daftar gaji / tunjangan / penghasilan lainnya - 60.0 menit', '60'),
('SKP00514', 'Membuat daftar menu - 60.0 menit', '60'),
('SKP00515', 'Membuat daftar menu - 15.0 menit', '15'),
('SKP00516', 'Membuat daftar menu - 30.0 menit', '30'),
('SKP00517', 'Membuat Daftar Usulan Penilaian Angka Kredit (DUPAK) - 30.0 menit', '30'),
('SKP00518', 'Membuat dan melaporkan SPT kepada Kantor Pelayanan Pajak - 30.0 menit', '30'),
('SKP00519', 'Membuat dan melaporkan SPT kepada Kantor Pelayanan Pajak - 60.0 menit', '60'),
('SKP00520', 'Membuat dan memasang Nomor Ujian (per objek) - 5.0 menit', '5'),
('SKP00521', 'Membuat dan menempel barcode aset tetap SKPD / UKPD - 5.0 menit', '5'),
('SKP00522', 'Membuat data kunjungan mancanegara - 30.0 menit', '30'),
('SKP00523', 'Membuat Detail Engineering Drawing (DED) konstruksi fisik - 180.0 menit', '180'),
('SKP00524', 'Membuat Detail Engineering Drawing (DED) konstruksi fisik - 120.0 menit', '120'),
('SKP00525', 'Membuat Detail Engineering Drawing (DED) konstruksi fisik - 90.0 menit', '90'),
('SKP00526', 'Membuat File PDF Perda / Pergub - 5.0 menit', '5'),
('SKP00527', 'Membuat gambar perencanaan - 120.0 menit', '120'),
('SKP00528', 'Membuat gambar perencanaan - 60.0 menit', '60'),
('SKP00529', 'Membuat gugatan / jawaban / replik / duplik / akta bukti / kesimpulan untuk persidangan di pengadilan - 60.0 menit', '60'),
('SKP00530', 'Membuat gugatan / jawaban / replik / duplik / akta bukti / kesimpulan untuk persidangan di pengadilan - 180.0 menit', '180'),
('SKP00531', 'Membuat gugatan / jawaban / replik / duplik / akta bukti / kesimpulan untuk persidangan di pengadilan - 120.0 menit', '120'),
('SKP00532', 'Membuat Instruksi Gubernur - 60.0 menit', '60'),
('SKP00533', 'Membuat Instruksi Gubernur - 30.0 menit', '30'),
('SKP00534', 'Membuat Instruksi Gubernur - 90.0 menit', '90'),
('SKP00535', 'Membuat instruksi Kepala SKPD / UKPD - 60.0 menit', '60'),
('SKP00536', 'Membuat instruksi Kepala SKPD / UKPD - 30.0 menit', '30'),
('SKP00537', 'Membuat instruksi Sekertaris Daerah - 30.0 menit', '30'),
('SKP00538', 'Membuat instruksi Sekertaris Daerah - 60.0 menit', '60'),
('SKP00539', 'Membuat instruksi Sekertaris Daerah - 90.0 menit', '90'),
('SKP00540', 'Membuat inventaris barang ( KIB) - 30.0 menit', '30'),
('SKP00541', 'Membuat jadwal kegiatan - 15.0 menit', '15'),
('SKP00542', 'Membuat jadwal kegiatan - 30.0 menit', '30'),
('SKP00543', 'Membuat jawaban - 120.0 menit', '120'),
('SKP00544', 'Membuat jawaban - 30.0 menit', '30'),
('SKP00545', 'Membuat jawaban - 60.0 menit', '60'),
('SKP00546', 'Membuat jurnal / catatan kondisi kapal secara berkala sesuai prosedur dan arahan pimpinan agar dapat mengetahui kondisi kapal - 45.0 menit', '45'),
('SKP00547', 'Membuat Karya Ilmiah / Makalah - 120.0 menit', '120'),
('SKP00548', 'Membuat karya tulis / karya ilmiah hasil pengkajian di bidang pengawasan yang dipublikasikan dalam bentuk buku yang diterbitkan dan diedarkan secara nasional / ', '120'),
('SKP00549', 'Membuat Kliping Berita - 30.0 menit', '30'),
('SKP00550', 'Membuat Kliping Berita - 15.0 menit', '15'),
('SKP00551', 'Membuat konsep expose - 60.0 menit', '60'),
('SKP00552', 'Membuat konsep expose - 30.0 menit', '30'),
('SKP00553', 'Membuat konsep keputusan gubernur kenaikan gaji berkala / pangkat / pensiun / PNS / CPNS / Mutasi - 30.0 menit', '30'),
('SKP00554', 'Membuat konsep keputusan gubernur kenaikan gaji berkala / pangkat / pensiun / PNS / CPNS / Mutasi - 60.0 menit', '60'),
('SKP00555', 'Membuat konsep Lakip Kota (asumsi bahan lengkap) - 180.0 menit', '180'),
('SKP00556', 'Membuat konsep Lakip Kota (asumsi bahan lengkap) - 120.0 menit', '120'),
('SKP00557', 'Membuat konsep Lakip Kota (asumsi bahan lengkap) - 60.0 menit', '60'),
('SKP00558', 'Membuat konsep MOU / perjanjian / kontrak - 120.0 menit', '120'),
('SKP00559', 'Membuat konsep MOU / perjanjian / kontrak - 30.0 menit', '30'),
('SKP00560', 'Membuat MOU / perjanjian / kontrak - 60.0 menit', '60'),
('SKP00561', 'Membuat Konsep Perhitungan Masa Kerja dan Jumlah Besaran Hak Pensiun atas Permintaan Sendiri - 5.0 menit', '5'),
('SKP00562', 'Membuat konsep Surat Dinas / Nota Dinas - 15.0 menit', '15'),
('SKP00563', 'Membuat konsep Surat Dinas / Nota Dinas - 30.0 menit', '30'),
('SKP00564', 'Membuat konsep Surat Dinas / Nota Dinas - 60.0 menit', '60'),
('SKP00565', 'Membuat konsep Surat Dinas / Nota Dinas - 45.0 menit', '45'),
('SKP00566', 'Membuat konsep Surat Edaran Gubernur - 60.0 menit', '60'),
('SKP00567', 'Membuat konsep Surat Edaran Sekretaris Daerah - 120.0 menit', '120'),
('SKP00568', 'Membuat konsep Surat Edaran Sekretaris Daerah - 90.0 menit', '90'),
('SKP00569', 'Membuat konsep Surat Edaran Sekretaris Daerah - 60.0 menit', '60'),
('SKP00570', 'Membuat konsep Surat Keputusan / Penetapan - 60.0 menit', '60'),
('SKP00571', 'Membuat konsep Surat Keputusan / Penetapan - 30.0 menit', '30'),
('SKP00572', 'Membuat konsep TOR atau KAK - 120.0 menit', '120'),
('SKP00573', 'Membuat konsep TOR atau KAK - 60.0 menit', '60'),
('SKP00574', 'Membuat laporan - 180.0 menit', '180'),
('SKP00575', 'Membuat laporan - 120.0 menit', '120'),
('SKP00576', 'Membuat laporan - 15.0 menit', '15'),
('SKP00577', 'Membuat laporan - 30.0 menit', '30'),
('SKP00578', 'Membuat laporan - 60.0 menit', '60'),
('SKP00579', 'Membuat Laporan Penggunaan Barang Pakai Habis (ATK, Obat, Alkes) - 30.0 menit', '30'),
('SKP00580', 'Membuat laporan Realisasi Keuangan - 120.0 menit', '120'),
('SKP00581', 'Membuat Media Pembelajaran / pelatihan dan bimbingan Pendidikan - 120.0 menit', '120'),
('SKP00582', 'Membuat Media Pembelajaran / pelatihan dan bimbingan Pendidikan - 90.0 menit', '90'),
('SKP00583', 'Membuat / melaksanakan administrasi - 15.0 menit', '15'),
('SKP00584', 'Membuat / melaksanakan administrasi - 30.0 menit', '30'),
('SKP00585', 'Membuat / melaksanakan administrasi - 60.0 menit', '60'),
('SKP00586', 'Membuat / menyiapkan bahan paparan - 60.0 menit', '60'),
('SKP00587', 'Membuat / menyiapkan bahan paparan - 30.0 menit', '30'),
('SKP00588', 'Membuat / menyiapkan bahan paparan - 120.0 menit', '120'),
('SKP00589', 'Membuat / menyusun Standar Operasional Prosedur (SOP) - 180.0 menit', '180'),
('SKP00590', 'Membuat / menyusun Standar Operasional Prosedur (SOP) - 60.0 menit', '60'),
('SKP00591', 'Membuat / menyusun Standar Operasional Prosedur (SOP) - 30.0 menit', '30'),
('SKP00592', 'Membuat notulen rapat - 20.0 menit', '20'),
('SKP00593', 'Membuat notulen rapat - 30.0 menit', '30'),
('SKP00594', 'Membuat notulen rapat - 45.0 menit', '45'),
('SKP00595', 'Membuat notulen rapat - 60.0 menit', '60'),
('SKP00596', 'Membuat otorisasi akses database - 15.0 menit', '15'),
('SKP00597', 'Membuat otorisasi akses database - 60.0 menit', '60'),
('SKP00598', 'Membuat otorisasi akses database - 30.0 menit', '30'),
('SKP00599', 'Membuat Pakta Integritas - 15.0 menit', '15'),
('SKP00600', 'Membuat Pakta Integritas - 5.0 menit', '5'),
('SKP00601', 'Membuat Penatausahaan Keuangan oleh bendahara dan PPK SKPD - 15.0 menit', '15'),
('SKP00602', 'Membuat Penetapan / penunjukan Penyedia barang / Jasa - 30.0 menit', '30'),
('SKP00603', 'Membuat Penetapan / penunjukan Penyedia barang / Jasa - 15.0 menit', '15'),
('SKP00604', 'Membuat penetapan terhadap pemutusan pelaksanaan Pengadaan Barang / Jasa - 60.0 menit', '60'),
('SKP00605', 'Membuat penetapan terhadap pemutusan pelaksanaan Pengadaan Barang / Jasa - 30.0 menit', '30'),
('SKP00606', 'Membuat pengumuman dan upload dokumen rencana umum pengadaan Barang / Jasa (per kegiatan) - 15.0 menit', '15'),
('SKP00607', 'Membuat perbaikan / koreksi Peraturan Perundang-undangan - 60.0 menit', '60'),
('SKP00608', 'Membuat perbaikan / koreksi Peraturan Perundang-undangan - 30.0 menit', '30'),
('SKP00609', 'Membuat perbaikan / koreksi Peraturan Perundang-undangan - 120.0 menit', '120'),
('SKP00610', 'Membuat perbaikan / koreksi / revisi objek kerja - 15.0 menit', '15'),
('SKP00611', 'Membuat perbaikan / koreksi / revisi objek kerja - 30.0 menit', '30'),
('SKP00612', 'Membuat perbaikan / koreksi / revisi objek kerja - 60.0 menit', '60'),
('SKP00613', 'Membuat perbaikan Surat Keputusan - 30.0 menit', '30'),
('SKP00614', 'Membuat perbaikan Surat Keputusan - 15.0 menit', '15'),
('SKP00615', 'Membuat perbaikan Surat Keputusan - 60.0 menit', '60'),
('SKP00616', 'Membuat perbal naskah dinas - 10.0 menit', '10'),
('SKP00617', 'Membuat perbal Peraturan Gubernur - 15.0 menit', '15'),
('SKP00618', 'Membuat perencanaan kebutuhan, penempatan, mutasi, pengembangan kompetensi pegawai - 30.0 menit', '30');
INSERT INTO `skp` (`kd_skp`, `skp`, `waktu`) VALUES
('SKP00619', 'Membuat peta - 60.0 menit', '60'),
('SKP00620', 'Membuat peta - 30.0 menit', '30'),
('SKP00621', 'Membuat pointers / agenda rapat - 30.0 menit', '30'),
('SKP00622', 'Membuat pointers / agenda rapat - 15.0 menit', '15'),
('SKP00623', 'Membuat press release - 60.0 menit', '60'),
('SKP00624', 'Membuat press release - 30.0 menit', '30'),
('SKP00625', 'Membuat program fisioterapi - 15.0 menit', '15'),
('SKP00626', 'Membuat program fisioterapi - 60.0 menit', '60'),
('SKP00627', 'Membuat program fisioterapi - 30.0 menit', '30'),
('SKP00628', 'Membuat rancangan aplikasi / sistem informasi lainnya - 60.0 menit', '60'),
('SKP00629', 'Membuat rancangan aplikasi / sistem informasi lainnya - 90.0 menit', '90'),
('SKP00630', 'Membuat Rancangan Keputusan Gubernur - 30.0 menit', '30'),
('SKP00631', 'Membuat Rancangan Keputusan Gubernur - 120.0 menit', '120'),
('SKP00632', 'Membuat Rancangan Keputusan Gubernur - 60.0 menit', '60'),
('SKP00633', 'Membuat rancangan Peraturan Daerah - 120.0 menit', '120'),
('SKP00634', 'Membuat rancangan Peraturan Daerah - 180.0 menit', '180'),
('SKP00635', 'Membuat rancangan Peraturan Daerah - 240.0 menit', '240'),
('SKP00636', 'Membuat rancangan Peraturan Gubernur - 60.0 menit', '60'),
('SKP00637', 'Membuat rancangan Peraturan Gubernur - 180.0 menit', '180'),
('SKP00638', 'Membuat rancangan Peraturan Gubernur - 120.0 menit', '120'),
('SKP00639', 'Membuat rekapitulasi data - 60.0 menit', '60'),
('SKP00640', 'Membuat rekapitulasi data - 120.0 menit', '120'),
('SKP00641', 'Membuat rekapitulasi data - 30.0 menit', '30'),
('SKP00642', 'Membuat Rencana Kerja Bidang Pendidikan - 60.0 menit', '60'),
('SKP00643', 'Membuat Rencana Kerja Bidang Pendidikan - 120.0 menit', '120'),
('SKP00644', 'Membuat RENJA - 180.0 menit', '180'),
('SKP00645', 'Membuat RENJA - 60.0 menit', '60'),
('SKP00646', 'Membuat RENJA - 120.0 menit', '120'),
('SKP00647', 'Membuat RENSTRA - 120.0 menit', '120'),
('SKP00648', 'Membuat RENSTRA - 60.0 menit', '60'),
('SKP00649', 'Membuat RENSTRA - 180.0 menit', '180'),
('SKP00650', 'Membuat resep - 1.0 menit', '1'),
('SKP00651', 'Membuat sambutan / pidato pejabat - 30.0 menit', '30'),
('SKP00652', 'Membuat sambutan / pidato pejabat - 15.0 menit', '15'),
('SKP00653', 'Membuat Sasaran Kerja Pegawai - 30.0 menit', '30'),
('SKP00654', 'Membuat sistem / aplikasi IT - 60.0 menit', '60'),
('SKP00655', 'Membuat sistem / aplikasi IT - 120.0 menit', '120'),
('SKP00656', 'Membuat SK Petikan (per 1 SK) - 3.0 menit', '3'),
('SKP00657', 'Membuat soal ujian - 60.0 menit', '60'),
('SKP00658', 'Membuat soal ujian - 120.0 menit', '120'),
('SKP00659', 'Membuat SPM - 15.0 menit', '15'),
('SKP00660', 'Membuat SPT Pajak Tahunan Pegawai - 10.0 menit', '10'),
('SKP00661', 'Membuat Surat Edaran - 30.0 menit', '30'),
('SKP00662', 'Membuat Surat Edaran - 60.0 menit', '60'),
('SKP00663', 'Membuat Surat Gugatan / Memori atau Kontra Memori - 300.0 menit', '300'),
('SKP00664', 'Membuat surat jawaban atas pengaduan masyarakat - 60.0 menit', '60'),
('SKP00665', 'Membuat Surat Pengantar Rekomendasi Teknis ke instansi terkait sesuai dengan bidang perizinan - 30.0 menit', '30'),
('SKP00666', 'Membuat Surat Penyediaan Dana (SPD) - 30.0 menit', '30'),
('SKP00667', 'Membuat Surat Perintah Pencairan (SPP) - 30.0 menit', '30'),
('SKP00668', 'Membuat Surat Pernyataan Pelantikan - 5.0 menit', '5'),
('SKP00669', 'Membuat Surat Setoran Pajak (SSP) - 10.0 menit', '10'),
('SKP00670', 'Membuat Surat Tanda Setoran (STS) - 10.0 menit', '10'),
('SKP00671', 'Membuat Surat Teguran - 30.0 menit', '30'),
('SKP00672', 'Membuat terjemahan / menyadur buku dan bahan lainnya - 30.0 menit', '30'),
('SKP00673', 'Membuat transkrip nilai peserta pelatihan per kegiatan - 30.0 menit', '30'),
('SKP00674', 'Membuat transkrip nilai peserta pelatihan per kegiatan - 60.0 menit', '60'),
('SKP00675', 'Membuat uji kelayakan terhadap objek kerja - 30.0 menit', '30'),
('SKP00676', 'Membuat uji kelayakan terhadap objek kerja - 60.0 menit', '60'),
('SKP00677', 'Membuat user ID baru pada aplikasi - 15.0 menit', '15'),
('SKP00678', 'Membuka / menutup rincian kegiatan SKPD / UKPD dalam sistem informasi - 5.0 menit', '5'),
('SKP00679', 'Memelihara peralatan operasional truk / bis / kendaraan lain - 60.0 menit', '60'),
('SKP00680', 'Memeriksa dan mencocokan nomor kendaraan yang meninggalkan areal parkir - 2.0 menit', '2'),
('SKP00681', 'Memeriksa dan mengklasifikasikan bahan dan data objek kerja - 10.0 menit', '10'),
('SKP00682', 'Memeriksa dokumen kapal nelayan / bakgan / kapal tradisonal (per kapal) - 30.0 menit', '30'),
('SKP00683', 'Memeriksa keadaan muatan sesuai prosedur yg berlaku untuk kelancaran pelaksanan pelayaran - 30.0 menit', '30'),
('SKP00684', 'Memeriksa kelengkapan surat / dokumen - 15.0 menit', '15'),
('SKP00685', 'Memeriksa kelengkapan surat / dokumen - 30.0 menit', '30'),
('SKP00686', 'Memeriksa kelengkapan surat / dokumen - 10.0 menit', '10'),
('SKP00687', 'Memeriksa kelengkapan surat / dokumen - 5.0 menit', '5'),
('SKP00688', 'Memeriksa kelengkapan surat kendaraan bermotor (Per 1 dokumen) - 15.0 menit', '15'),
('SKP00689', 'Memeriksa / meneliti hasil kegiatan / kerja - 15.0 menit', '15'),
('SKP00690', 'Memeriksa / meneliti hasil kegiatan / kerja - 30.0 menit', '30'),
('SKP00691', 'Memfasilitasi Permintaan Dari PA / KPA / PPK / ULP / Pejabat Pengadaan Berkaitan Dengan Blacklist Terhadap Penyedia Barang / Jasa - 30.0 menit', '30'),
('SKP00692', 'Memimpin rapat - 30.0 menit', '30'),
('SKP00693', 'Memimpin rapat - 120.0 menit', '120'),
('SKP00694', 'Memimpin rapat - 180.0 menit', '180'),
('SKP00695', 'Memimpin rapat - 60.0 menit', '60'),
('SKP00696', 'Mempelajari / membuat resume peraturan - 60.0 menit', '60'),
('SKP00697', 'Memperbaiki / memeriksa objek kerja - 30.0 menit', '30'),
('SKP00698', 'Memperbaiki / memeriksa objek kerja - 5.0 menit', '5'),
('SKP00699', 'Memperbaiki / memeriksa objek kerja - 15.0 menit', '15'),
('SKP00700', 'Memperbaiki / memeriksa objek kerja - 60.0 menit', '60'),
('SKP00701', 'Mempersiapkan acara / kegiatan - 120.0 menit', '120'),
('SKP00702', 'Mempersiapkan acara / kegiatan - 60.0 menit', '60'),
('SKP00703', 'Mempersiapkan acara / kegiatan - 30.0 menit', '30'),
('SKP00704', 'Mempersiapkan acara / kegiatan - 90.0 menit', '90'),
('SKP00705', 'Mempersiapkan alat kerja - 5.0 menit', '5'),
('SKP00706', 'Mempersiapkan alat kerja - 15.0 menit', '15'),
('SKP00707', 'Mempersiapkan alat kerja - 30.0 menit', '30'),
('SKP00708', 'Mempersiapkan operasional pertunjukan - 30.0 menit', '30'),
('SKP00709', 'Mempersiapkan peralatan dan bahan penunjang untuk pengambilan spesimen / sample Laboratorium - 5.0 menit', '5'),
('SKP00710', 'Mempersiapkan ruangan dan peralatan dalam kondisi siap pakai (Kasus berat okupasi terapi) - 5.0 menit', '5'),
('SKP00711', 'Memposting data usulan komponen / kode rekening SKPD / UKPD (per 10 item) - 15.0 menit', '15'),
('SKP00712', 'Memungut dan menyetorkan Pajak yang ditarik dari Pihak Ketiga ke Kantor Pajak - 60.0 menit', '60'),
('SKP00713', 'Memvalidasi dokumen Surat Permintaan Pembayaran (SPP) dan Laporan Keuangan - 180.0 menit', '180'),
('SKP00714', 'Memvalidasi dokumen Surat Permintaan Pembayaran (SPP) dan Laporan Keuangan - 60.0 menit', '60'),
('SKP00715', 'Memvalidasi dokumen Surat Permintaan Pembayaran (SPP) dan Laporan Keuangan - 120.0 menit', '120'),
('SKP00716', 'Memverifikasi / meneliti / memvalidasi / memaraf dokumen terkait penerbitan Surat Penyediaan Dana (SPD) - 15.0 menit', '15'),
('SKP00717', 'Memverifikasi / meneliti / memvalidasi / memaraf dokumen terkait penerbitan Surat Penyediaan Dana (SPD) - 5.0 menit', '5'),
('SKP00718', 'Memverifikasi / meneliti / memvalidasi / memaraf dokumen terkait penerbitan Surat Penyediaan Dana (SPD) - 10.0 menit', '10'),
('SKP00719', 'Memverifikasi penatausahaan keuangan oleh bendahara dan PPK SKPD - 20.0 menit', '20'),
('SKP00720', 'Memverifikasi Penetapan Angka Kredit (PAK) Jabatan Fungsional Tertentu - 60.0 menit', '60'),
('SKP00721', 'Memverifikasi Penetapan Angka Kredit (PAK) Jabatan Fungsional Tertentu - 15.0 menit', '15'),
('SKP00722', 'Memverifikasi Penetapan Angka Kredit (PAK) Jabatan Fungsional Tertentu - 30.0 menit', '30'),
('SKP00723', 'Memverifikasi usulan masyarakat hasil Musrenbang Kecamatan melalui website e-Musrenbang DKI - 30.0 menit', '30'),
('SKP00724', 'Memverifikasi usulan Standar Satuan Harga (SSH) / Analisis Standar Biaya (ASB) (per 2 SSH) - 10.0 menit', '10'),
('SKP00725', 'Menaklik Tiknet Perbal Naskah Dinas - 60.0 menit', '60'),
('SKP00726', 'Menaklik Tiknet Perbal Naskah Dinas - 30.0 menit', '30'),
('SKP00727', 'Menanam pohon / tumbuhan / bibit (per lokasi) - 120.0 menit', '120'),
('SKP00728', 'Menanam pohon / tumbuhan / bibit (per lokasi) - 60.0 menit', '60'),
('SKP00729', 'Menanam pohon / tumbuhan / bibit (per lokasi) - 30.0 menit', '30'),
('SKP00730', 'Menandatangani / memaraf Surat Kedinasan / dokumen / petikan - 10.0 menit', '10'),
('SKP00731', 'Menandatangani / memaraf Surat Kedinasan / dokumen / petikan - 5.0 menit', '5'),
('SKP00732', 'Menata Koleksi Bahan Pustaka - 30.0 menit', '30'),
('SKP00733', 'Menata / Menyusun Arsip - 5.0 menit', '5'),
('SKP00734', 'Menata / Menyusun Arsip - 60.0 menit', '30'),
('SKP00735', 'Menata / Menyusun Arsip - 15.0 menit', '15'),
('SKP00736', 'Mencatat BKU (per transaksi) - 2.0 menit', '2'),
('SKP00737', 'Mencatat dan Membukukan Buku Kas Umum (BKU) dan Buku Pembantu Lainnya - 5.0 menit', '5'),
('SKP00738', 'Mencatat dan menghitung waktu tunggu pasien rawat inap - 15.0 menit', '15'),
('SKP00739', 'Mencatat dan menghitung waktu tunggu pasien rawat inap - 10.0 menit', '10'),
('SKP00740', 'Mencatat dan menghitung waktu tunggu pasien rawat inap - 5.0 menit', '5'),
('SKP00741', 'Mencatat transaksi pembayaran via Bendahara Pengeluaran Pembantu - 30.0 menit', '30'),
('SKP00742', 'Mencetak - 0.1 menit', '1'),
('SKP00743', 'Mencetak - 0.2 menit', '2'),
('SKP00744', 'Mencetak hasil input Renja melalui sistem informasi - 5.0 menit', '5'),
('SKP00745', 'Mencetak Perda sebagai bahan APBD / APBD Perubahan - 10.0 menit', '10'),
('SKP00746', 'Mencetak Pergub sebagai bahan APBD / APBD Perubahan - 10.0 menit', '10'),
('SKP00747', 'Mendampingi kegiatan pelatihan keterampilan - 120.0 menit', '120'),
('SKP00748', 'Mendampingi kegiatan pelatihan keterampilan - 60.0 menit', '60'),
('SKP00749', 'Mendesain sertifikat, spanduk dan piagam - 30.0 menit', '30'),
('SKP00750', 'Mendistribusikan hasil audit BPK (temuan sementara dan jurnal) - 60.0 menit', '60'),
('SKP00751', 'Mendokumentasikan dokumen penting - 15.0 menit', '15'),
('SKP00752', 'Mendokumentasikan dokumen penting - 5.0 menit', '5'),
('SKP00753', 'Mendokumentasikan kegiatan (per kegiatan) - 15.0 menit', '15'),
('SKP00754', 'Mendokumentasikan kegiatan (per kegiatan) - 30.0 menit', '30'),
('SKP00755', 'Meneliti Berita Acara Serah Terima (BAST) - 15.0 menit', '15'),
('SKP00756', 'Meneliti Berita Acara Serah Terima (BAST) - 30.0 menit', '30'),
('SKP00757', 'Meneliti dan memverifikasi Analisis Standar Biaya (ASB) / Harga Satuan Pokok Kegiatan (HSPK) - 30.0 menit', '30'),
('SKP00758', 'Meneliti dan memverifikasi Analisis Standar Biaya (ASB) / Harga Satuan Pokok Kegiatan (HSPK) - 60.0 menit', '60'),
('SKP00759', 'Meneliti dan memverifikasi Analisis Standar Biaya (ASB) / Harga Satuan Pokok Kegiatan (HSPK) - 90.0 menit', '90'),
('SKP00760', 'Meneliti dan memverifikasi RKA / DPA - 90.0 menit', '90'),
('SKP00761', 'Meneliti dan memverifikasi RKA / DPA - 60.0 menit', '60'),
('SKP00762', 'Meneliti dan memverifikasi RKA / DPA - 30.0 menit', '30'),
('SKP00763', 'Meneliti dan memverifikasi Standar Satuan Harga (SSH) / kode rekening - 20.0 menit', '20'),
('SKP00764', 'Meneliti dan memverifikasi Standar Satuan Harga (SSH) / kode rekening - 30.0 menit', '30'),
('SKP00765', 'Meneliti dan memverifikasi Standar Satuan Harga (SSH) / kode rekening - 10.0 menit', '10'),
('SKP00766', 'Meneliti dan memverifikasi Standar Satuan Harga (SSH) / kode rekening - 5.0 menit', '5'),
('SKP00767', 'Meneliti dan mencocokan bukti-bukti pengeluaran dan penerimaan dengan laporan realisasi keuangan dan Buku Kas - 15.0 menit', '15'),
('SKP00768', 'Meneliti data - 15.0 menit', '15'),
('SKP00769', 'Meneliti data - 60.0 menit', '60'),
('SKP00770', 'Meneliti data - 30.0 menit', '30'),
('SKP00771', 'Meneliti data - 5.0 menit', '5'),
('SKP00772', 'Meneliti data - 10.0 menit', '10'),
('SKP00773', 'Meneliti data entry gaji dan tunjangan lainnya sebagai bahan konfirmasi belanja pegawai dengan SKPD - 30.0 menit', '30'),
('SKP00774', 'Meneliti laporan - 5.0 menit', '5'),
('SKP00775', 'Meneliti laporan - 30.0 menit', '30'),
('SKP00776', 'Meneliti laporan - 10.0 menit', '10'),
('SKP00777', 'Meneliti Laporan Keuangan - 120.0 menit', '120'),
('SKP00778', 'Meneliti Laporan Keuangan - 180.0 menit', '180'),
('SKP00779', 'Meneliti Laporan Keuangan - 60.0 menit', '60'),
('SKP00780', 'Meneliti, memeriksa, memvalidasi konsep Surat Keputusan - 30.0 menit', '30'),
('SKP00781', 'Meneliti, memeriksa, memvalidasi konsep Surat Keputusan - 15.0 menit', '15'),
('SKP00782', 'Meneliti, memeriksa, memvalidasi Surat Keputusan - 15.0 menit', '15'),
('SKP00783', 'Meneliti surat usulan penyampaian data belanja pegawai SKPD dalam rangka penyusunan APBD / APBD-P - 30.0 menit', '30'),
('SKP00784', 'Menempatkan Benda Cagar Budaya / Benda Seni (Per Benda) - 30.0 menit', '30'),
('SKP00785', 'Menempatkan Benda Cagar Budaya / Benda Seni (Per Benda) - 60.0 menit', '60'),
('SKP00786', 'Menerbitkan Surat Rekomendasi / Surat Izin - 30.0 menit', '30'),
('SKP00787', 'Menerima dan menyampaikan berita lewat Rig / HT - 3.0 menit', '3'),
('SKP00788', 'Menerima dan menyampaikan berita lewat Rig / HT - 5.0 menit', '5'),
('SKP00789', 'Menerima dan menyetor retribusi - 20.0 menit', '20'),
('SKP00790', 'Menerima dan menyortir bukti-bukti pengeluaran dan penerimaan serta Buku Kas - 15.0 menit', '15'),
('SKP00791', 'Menerima Konsul dari dokter spesialis lain - 20.0 menit', '20'),
('SKP00792', 'Menerima kunjungan kerja (1x kunjungan) - 180.0 menit', '180'),
('SKP00793', 'Menerima kunjungan kerja (1x kunjungan) - 60.0 menit', '60'),
('SKP00794', 'Menerima kunjungan kerja (1x kunjungan) - 120.0 menit', '120'),
('SKP00795', 'Menerima / memeriksa jumlah dan jenis barang / hasil pekerjaan - 60.0 menit', '60'),
('SKP00796', 'Menerima / memeriksa jumlah dan jenis barang / hasil pekerjaan - 90.0 menit', '90'),
('SKP00797', 'Menerima, mencatat bahan / objek kerja - 15.0 menit', '15'),
('SKP00798', 'Menerima, mencatat bahan / objek kerja - 10.0 menit', '10'),
('SKP00799', 'Menerima, mencatat bahan / objek kerja - 1.0 menit', '1'),
('SKP00800', 'Menerima, mencatat, memberi lembar disposisi - 5.0 menit', '5'),
('SKP00801', 'Menerima, mencatat, memberi lembar disposisi - 3.0 menit', '3'),
('SKP00802', 'Menerima pendaftaran - 5.0 menit', '5'),
('SKP00803', 'Menerima pendaftaran - 15.0 menit', '15'),
('SKP00804', 'Menerima pendaftaran pasien (per pasien) - 3.0 menit', '3'),
('SKP00805', 'Menerima Pengaduan Masyarakat (per aduan) - 15.0 menit', '15'),
('SKP00806', 'Menerima permohonan Penyelesaian Sengketa Informasi (PSI) - 5.0 menit', '5'),
('SKP00807', 'Menerima satwa yang baru datang / sakit - 30.0 menit', '30'),
('SKP00808', 'Menerima tamu dan mencatat keperluannya - 5.0 menit', '5'),
('SKP00809', 'Menerjemahkan Bahasa (1x kunjungan) - 60.0 menit', '60'),
('SKP00810', 'Mengadministrasikan surat - 5.0 menit', '5'),
('SKP00811', 'Mengajarkan Senam - 60.0 menit', '30'),
('SKP00812', 'Mengajarkan Senam - 90.0 menit', '90'),
('SKP00813', 'Mengajarkan senam lansia - 60.0 menit', '60'),
('SKP00814', 'Mengajar / melatih - 120.0 menit', '120'),
('SKP00815', 'Mengajar / melatih - 60.0 menit', '60'),
('SKP00816', 'Mengajar / Melatih Diklat di Bidang Pengadaan Barang / Jasa - 90.0 menit', '90'),
('SKP00817', 'Mengajukan gugatan / banding / kasasi / peninjauan kembali / memori / kontra memori ke pengadilan - 60.0 menit', '60'),
('SKP00818', 'Mengambil / mengantar dokumen / surat / berkas - 60.0 menit', '60'),
('SKP00819', 'Mengambil / mengantar dokumen / surat / berkas - 30.0 menit', '30'),
('SKP00820', 'Mengambil / mengantar dokumen / surat / berkas - 15.0 menit', '15'),
('SKP00821', 'Mengambil / mengantar dokumen / surat / berkas - 120.0 menit', '120'),
('SKP00822', 'Mengambil / mengantar dokumen / surat / berkas - 5.0 menit', '5'),
('SKP00823', 'Menganalisa formasi Izin Belajar / Tugas Belajar - 30.0 menit', '30'),
('SKP00824', 'Menganalisa formasi Izin Belajar / Tugas Belajar - 15.0 menit', '15'),
('SKP00825', 'Menganalisa hasil uji - 30.0 menit', '30'),
('SKP00826', 'Menganalisa hasil uji - 60.0 menit', '60'),
('SKP00827', 'Menganalisis aktivitas (Kasus ringan okupasi terapi) - 20.0 menit', '20'),
('SKP00828', 'Menganalisis / Validasi Perbal Naskah Dinas - 120.0 menit', '120'),
('SKP00829', 'Menganalisis / Validasi Perbal Naskah Dinas - 60.0 menit', '60'),
('SKP00830', 'Menganalisis / Validasi Perbal Naskah Dinas - 30.0 menit', '30'),
('SKP00831', 'Mengantar / Menjemput / Mengemudi Kendaraan Operasional - 60.0 menit', '60'),
('SKP00832', 'Mengantar / Menjemput / Mengemudi Kendaraan Operasional - 120.0 menit', '120'),
('SKP00833', 'Mengantar / Menjemput / Mengemudi Kendaraan Operasional - 30.0 menit', '30'),
('SKP00834', 'Mengawasi pelaksanaan karantina satwa - 60.0 menit', '60'),
('SKP00835', 'Mengawasi pengolahan sampah - 30.0 menit', '30'),
('SKP00836', 'Mengawasi pengolahan sampah - 60.0 menit', '60'),
('SKP00837', 'Mengecek kondisi kapal sesuai prosedur yg berlaku untuk kelancaran pelaksanaan pelayaran - 60.0 menit', '60'),
('SKP00838', 'Mengelola alokasi area database - 60.0 menit', '60'),
('SKP00839', 'Mengelola alokasi area database - 30.0 menit', '30'),
('SKP00840', 'Mengelola alokasi area database - 15.0 menit', '15'),
('SKP00841', 'Mengelola surat - 5.0 menit', '5'),
('SKP00842', 'Mengembangkan dan atau meremajakan rancangan rinci sistem informasi - 120.0 menit', '120'),
('SKP00843', 'Mengembangkan dan atau meremajakan rancangan rinci sistem informasi - 60.0 menit', '60'),
('SKP00844', 'Mengembangkan / meremajakan aplikasi / sistem informasi - 30.0 menit', '30'),
('SKP00845', 'Mengembangkan / meremajakan aplikasi / sistem informasi - 60.0 menit', '60'),
('SKP00846', 'Mengendalikan kapal sebagai nahkoda sesuai dengan prosedur pelayaran - 120.0 menit', '120'),
('SKP00847', 'Mengendalikan kapal sebagai nahkoda sesuai dengan prosedur pelayaran - 60.0 menit', '60'),
('SKP00848', 'Mengestimasi Pendapatan (per tagihan) - 15.0 menit', '15'),
('SKP00849', 'Mengestimasi Pendapatan (per tagihan) - 15.0 menit', '15'),
('SKP00850', 'Mengetik Surat - 15.0 menit', '15'),
('SKP00851', 'Mengevaluasi / meneliti hasil konfirmasi gaji dan tunjangan lainnya dengan SKPD - 30.0 menit', '30'),
('SKP00852', 'Menggandakan dan Memberikan cap stempel naskah dinas - 0.2 menit', '0.2'),
('SKP00853', 'Menghadiri acara seremonial - 60.0 menit', '60'),
('SKP00854', 'Menghadiri acara seremonial - 90.0 menit', '90'),
('SKP00855', 'Menghadiri acara seremonial - 30.0 menit', '30'),
('SKP00856', 'Menghadiri kegiatan pemberdayaan dan kesejahteraan keluarga (PKK ) bagi pegawai kelurahan - 120.0 menit', '120'),
('SKP00857', 'Menghadiri / mendampingi persidangan - 60.0 menit', '60'),
('SKP00858', 'Menghadiri / mendampingi persidangan - 120.0 menit', '120'),
('SKP00859', 'Menghadiri / mendampingi persidangan - 180.0 menit', '180'),
('SKP00860', 'Menghadiri sidang di pengadilan - 120.0 menit', '120'),
('SKP00861', 'Menghadiri sidang di pengadilan - 180.0 menit', '180'),
('SKP00862', 'Menghadiri sidang di pengadilan - 60.0 menit', '60'),
('SKP00863', 'Menghidupkan mesin - 5.0 menit', '5'),
('SKP00864', 'Menghidupkan mesin kapal - 15.0 menit', '15'),
('SKP00865', 'Menghimpun, mencocokan dan meneliti tagihan penyediaan jasa TALI dan IPAL - 30.0 menit', '30'),
('SKP00866', 'Menghimpun usulan Rencana Kerja dan Anggaran - 60.0 menit', '60'),
('SKP00867', 'Menghitung Besaran Retribusi Pemakaian Alat Ukur - 10.0 menit', '10'),
('SKP00868', 'Menghitung Besaran Retribusi Pemakaian Alat Ukur - 30.0 menit', '30'),
('SKP00869', 'Menghitung pemakaian barang habis pakai - 60.0 menit', '60'),
('SKP00870', 'Menghitung pemakaian barang habis pakai - 30.0 menit', '30'),
('SKP00871', 'Menghubungi keluarga anak asuh dalam rangka konsultasi dan monitoring perkembangan anak asuh - 10.0 menit', '10'),
('SKP00872', 'Mengidentifikasi dan memverifikasi data - 30.0 menit', '30'),
('SKP00873', 'Mengidentifikasi dan memverifikasi data - 5.0 menit', '5'),
('SKP00874', 'Mengidentifikasi dan memverifikasi data - 15.0 menit', '15'),
('SKP00875', 'Mengikuti kegiatan kerja bakti - 60.0 menit', '60'),
('SKP00876', 'Mengikuti kegiatan kerja bakti - 90.0 menit', '90'),
('SKP00877', 'Mengikuti kegiatan kerja bakti - 45.0 menit', '45'),
('SKP00878', 'Mengikuti kegiatan Rapat Kerja Nasional / Rembug Nasional - 360.0 menit', '360'),
('SKP00879', 'Mengikuti kegiatan Rapat Kerja Nasional / Rembug Nasional - 180.0 menit', '180'),
('SKP00880', 'Mengikuti kegiatan Rapat Kerja Nasional / Rembug Nasional - 300.0 menit', '300'),
('SKP00881', 'Mengikuti pelatihan input / supervisi e-Musrenbang - 120.0 menit', '120'),
('SKP00882', 'Mengikuti pelatihan / sosialisasi / pendidikan - 60.0 menit', '60'),
('SKP00883', 'Mengikuti pelatihan / sosialisasi / pendidikan - 300.0 menit', '300'),
('SKP00884', 'Mengikuti pelatihan / sosialisasi / pendidikan - 240.0 menit', '240'),
('SKP00885', 'Mengikuti pelatihan / sosialisasi / pendidikan - 180.0 menit', '180'),
('SKP00886', 'Mengikuti pelatihan / sosialisasi / pendidikan - 120.0 menit', '120'),
('SKP00887', 'Mengikuti pembahasan dalam sidang Musrenbang - 180.0 menit', '180'),
('SKP00888', 'Mengikuti pembahasan dalam sidang Musrenbang - 120.0 menit', '120'),
('SKP00889', 'Mengikuti pembahasan dalam sidang Musrenbang tingkat provinsi / kota / kabupaten / kecamatan / kelurahan - 120.0 menit', '120'),
('SKP00890', 'Mengikuti pembahasan dalam sidang Musrenbang tingkat provinsi / kota / kabupaten / kecamatan / kelurahan - 180.0 menit', '180'),
('SKP00891', 'Mengikuti Proses Ujian Sekolah (per mata pelajaran) - 120.0 menit', '120'),
('SKP00892', 'Mengikuti rapat teknis - 120.0 menit', '120'),
('SKP00893', 'Mengikuti rapat teknis - 60.0 menit', '60'),
('SKP00894', 'Mengikuti rapat teknis - 45.0 menit', '45'),
('SKP00895', 'Mengikuti rapat teknis - 90.0 menit', '90'),
('SKP00896', 'Mengikuti rapat teknis - 180.0 menit', '180'),
('SKP00897', 'Mengikuti RAPIM Gubernur - 60.0 menit', '60'),
('SKP00898', 'Mengikuti RAPIM Gubernur - 120.0 menit', '120'),
('SKP00899', 'Mengikuti RAPIM Gubernur - 180.0 menit', '180'),
('SKP00900', 'Mengikuti RAPIM Wakil Gubernur - 180.0 menit', '180'),
('SKP00901', 'Mengikuti RAPIM Wakil Gubernur - 60.0 menit', '60'),
('SKP00902', 'Mengikuti RAPIM Wakil Gubernur - 120.0 menit', '120'),
('SKP00903', 'Mengikuti ronde keperawatan - 60.0 menit', '60'),
('SKP00904', 'Mengikuti ronde keperawatan - 120.0 menit', '120'),
('SKP00905', 'Mengikuti ronde keperawatan - 30.0 menit', '30'),
('SKP00906', 'Mengikuti seminar / lokakarya / konferensi - 120.0 menit', '120'),
('SKP00907', 'Mengikuti seminar / lokakarya / konferensi - 60.0 menit', '60'),
('SKP00908', 'Mengikuti Senam - 90.0 menit', '90'),
('SKP00909', 'Mengikuti Senam - 60.0 menit', '60'),
('SKP00910', 'Mengikuti tes kompetensi - 120.0 menit', '120'),
('SKP00911', 'Mengikuti tes kompetensi - 180.0 menit', '180'),
('SKP00912', 'Mengikuti visit dokter - 30.0 menit', '30'),
('SKP00913', 'Mengikuti visit dokter - 60.0 menit', '60'),
('SKP00914', 'Mengikuti visit dokter - 10.0 menit', '10'),
('SKP00915', 'Mengikuti visit dokter (per 1 pasien) - 5.0 menit', '5'),
('SKP00916', 'Menginput Data / informasi (Per Kegiatan / Paket) - 15.0 menit', '15'),
('SKP00917', 'Menginput Data / informasi (Per Kegiatan / Paket) - 30.0 menit', '30'),
('SKP00918', 'Menginput Data / informasi (Per Kegiatan / Paket) - 5.0 menit', '5'),
('SKP00919', 'Menginput Data / informasi (Per Kegiatan / Paket) - 10.0 menit', '10'),
('SKP00920', 'Menginput data ke dalam sistem - 5.0 menit', '5'),
('SKP00921', 'Menginput data ke dalam sistem - 15.0 menit', '15'),
('SKP00922', 'Menginput data ke dalam sistem - 30.0 menit', '30'),
('SKP00923', 'Menginput jurnal SP2D ke aplikasi LPJ SIPKD BPKD Provinsi DKI Jakarta - 180.0 menit', '180'),
('SKP00924', 'Menginput jurnal SP2D ke aplikasi LPJ SIPKD BPKD Provinsi DKI Jakarta - 120.0 menit', '120'),
('SKP00925', 'Menginput jurnal SPJ ke aplikasi LPJ SIPKD BPKD Provinsi DKI Jakarta - 60.0 menit', '60'),
('SKP00926', 'Menginput jurnal SPJ / SP2D ke aplikasi LPJ SIPKD BPKD Provinsi DKI Jakarta - 60.0 menit', '60'),
('SKP00927', 'Menginput jurnal SPJ / SP2D ke aplikasi LPJ SIPKD BPKD Provinsi DKI Jakarta - 120.0 menit', '120'),
('SKP00928', 'Menginput jurnal SPJ / SP2D ke aplikasi LPJ SIPKD BPKD Provinsi DKI Jakarta - 15.0 menit', '15'),
('SKP00929', 'Menginput jurnal SPJ / SP2D ke aplikasi LPJ SIPKD BPKD Provinsi DKI Jakarta - 30.0 menit', '30'),
('SKP00930', 'Menginput Usulan Pensiun BUP ke dalam Sistem Aplikasi Pelayanan Kepegawaian (SAPK) BKN - 5.0 menit', '5'),
('SKP00931', 'Menginventarisasi surat usulan anggaran - 5.0 menit', '5'),
('SKP00932', 'Menginventarisir daftar pajak terutang - 60.0 menit', '60'),
('SKP00933', 'Menginventarisir daftar pajak terutang - 30.0 menit', '30'),
('SKP00934', 'Menginventarisir pendapatan jasa giro - 30.0 menit', '30'),
('SKP00935', 'Mengisi Buku Induk Siswa - 15.0 menit', '15'),
('SKP00936', 'Mengisi resume medis - 10.0 menit', '10'),
('SKP00937', 'Mengolah data - 60.0 menit', '60'),
('SKP00938', 'Mengolah data - 5.0 menit', '5'),
('SKP00939', 'Mengolah data - 15.0 menit', '15'),
('SKP00940', 'Mengolah data - 30.0 menit', '30'),
('SKP00941', 'Mengolah data - 10.0 menit', '10'),
('SKP00942', 'Mengolah data perencanaan dan anggaran - 90.0 menit', '90'),
('SKP00943', 'Mengolah / menyiapkan / menyajikan data - 30.0 menit', '30'),
('SKP00944', 'Mengolah / menyiapkan / menyajikan data - 15.0 menit', '15'),
('SKP00945', 'Mengontrol keamanan gedung dan lingkungan kantor pada siang / malam hari - 90.0 menit', '90'),
('SKP00946', 'Mengontrol keamanan gedung dan lingkungan kantor pada siang / malam hari - 30.0 menit', '30'),
('SKP00947', 'Mengontrol keamanan gedung dan lingkungan kantor pada siang / malam hari - 60.0 menit', '60'),
('SKP00948', 'Mengoperasikan pertunjukan (teater) - 60.0 menit', '60'),
('SKP00949', 'Mengoperasikan sarana dan prasarana penanggulangan kedaruratan - 60.0 menit', '60'),
('SKP00950', 'Mengoreksi hasil tes peserta pelatihan - 30.0 menit', '30'),
('SKP00951', 'Mengoreksi hasil tes peserta pelatihan - 60.0 menit', '60'),
('SKP00952', 'Menguji calon Pegawai baru -15.0 menit', '15'),
('SKP00953', 'Menguji pegawai / Mahasiswa / siswa - 30.0 menit', '30'),
('SKP00954', 'Menguji pegawai / Mahasiswa / siswa - 60.0 menit', '60'),
('SKP00955', 'Mengumpulkan bahan kerja - 15.0 menit', '15'),
('SKP00956', 'Mengumpulkan bahan kerja - 30.0 menit', '30'),
('SKP00957', 'Mengumpulkan Berkas / Dokumen - 15.0 menit', '15'),
('SKP00958', 'Mengumpulkan Berkas / Dokumen - 30.0 menit', '30'),
('SKP00959', 'Mengumpulkan dan mengedit artikel / media foto / video / audio untuk publikasi - 30.0 menit', '30'),
('SKP00960', 'Mengumpulkan dan mengedit artikel untuk publikasi - 60.0 menit', '60'),
('SKP00961', 'Mengumpulkan data / berkas / dokumen - 10.0 menit', '10'),
('SKP00962', 'Mengumpulkan data / berkas / dokumen - 15.0 menit', '15'),
('SKP00963', 'Mengumpulkan data / berkas / dokumen - 5.0 menit', '5'),
('SKP00964', 'Mengumpulkan data / berkas / dokumen - 30.0 menit', '30'),
('SKP00965', 'Mengumpulkan jawaban ujian - 15.0 menit', '15'),
('SKP00966', 'Mengumpulkan laporan keuangan - 30.0 menit', '30'),
('SKP00967', 'Mengupload Data / Artikel Kedalam Sistem Informasi - 15.0 menit', '15'),
('SKP00968', 'Mengupload Data / Artikel Kedalam Sistem Informasi - 30.0 menit', '30'),
('SKP00969', 'Mengurus kelengkapan kendaraan bermotor - 30.0 menit', '30'),
('SKP00970', 'Mengurus perizinan keluar masuk satwa - 90.0 menit', '90'),
('SKP00971', 'Menilai Usulan Pengembangan atau Pembangunan Sistem Informasi Baru dan Mengidetifikasi Dampak - 60.0 menit', '60'),
('SKP00972', 'Menilai Usulan Pengembangan atau Pembangunan Sistem Informasi Baru dan Mengidetifikasi Dampak - 30.0 menit', '30'),
('SKP00973', 'Menindaklanjuti pertanyaan masyarakat melalui QLUE / CROPS / sistem aplikasi lainnya - 30.0 menit', '30'),
('SKP00974', 'Menindaklanjuti pertanyaan masyarakat melalui QLUE / CROPS / sistem aplikasi lainnya - 15.0 menit', '15'),
('SKP00975', 'Menindaklanjuti pertanyaan masyarakat melalui QLUE / CROPS / sistem aplikasi lainnya - 5.0 menit', '5'),
('SKP00976', 'Meningkatkan kinerja perangkat lunak pada komputer mainframe / server - 15.0 menit', '15'),
('SKP00977', 'Meningkatkan kinerja perangkat lunak pada komputer mainframe / server - 30.0 menit', '30'),
('SKP00978', 'Menjadi instruktur senam kesehatan - 60.0 menit', '60'),
('SKP00979', 'Menjadi moderator - 120.0 menit', '120'),
('SKP00980', 'Menjadi moderator - 60.0 menit', '60'),
('SKP00981', 'Menjadi narasumber - 60.0 menit', '60'),
('SKP00982', 'Menjadi narasumber - 120.0 menit', '120'),
('SKP00983', 'Menjadi petugas upacara / apel - 30.0 menit', '30'),
('SKP00984', 'Menjadi petugas upacara / apel - 60.0 menit', '60'),
('SKP00985', 'Menjustir alat ukur - 30.0 menit', '30'),
('SKP00986', 'Menjustir alat ukur - 60.0 menit', '60'),
('SKP00987', 'Menyandarkan kapal setelah pelaksanan pelayaran sesuai prosedur yang berlaku agar kapal terjaga keamananya - 30.0 menit', '30'),
('SKP00988', 'Menyediakan data untuk Rapim Gubernur - 30.0 menit', '30'),
('SKP00989', 'Menyediakan data untuk Rapim Gubernur - 60.0 menit', '60'),
('SKP00990', 'Menyelenggarakan event kegiatan - 30.0 menit', '30'),
('SKP00991', 'Menyelenggarakan event kegiatan - 120.0 menit', '120'),
('SKP00992', 'Menyelenggarakan event kegiatan - 60.0 menit', '60'),
('SKP00993', 'Menyelenggarakan pelayanan pemulasaraan jenazah - 30.0 menit', '30'),
('SKP00994', 'Menyelenggarakan senam lansia - 60.0 menit', '60'),
('SKP00995', 'Menyetorkan Surat Tanda Setoran Langsung / Uang Persediaan / Ganti Uang / Tambah Uang (STS- LS / UP / GU / TU) - 60.0 menit', '60'),
('SKP00996', 'Menyiapkan bahan - 30.0 menit', '30'),
('SKP00997', 'Menyiapkan bahan - 60.0 menit', '60'),
('SKP00998', 'Menyiapkan bahan - 5.0 menit', '5'),
('SKP00999', 'Menyiapkan bahan - 10.0 menit', '10'),
('SKP01000', 'Menyiapkan Bahan laporan - 30.0 menit', '30'),
('SKP01001', 'Menyiapkan Bahan laporan - 60.0 menit', '60'),
('SKP01002', 'Menyiapkan bahan yang dibutuhkan oleh Lembaga Pemeriksa - 120.0 menit', '120'),
('SKP01003', 'Menyiapkan bahan yang dibutuhkan oleh Lembaga Pemeriksa - 60.0 menit', '60'),
('SKP01004', 'Menyiapkan Laporan Barang Pengguna Barang Semesteran (LBPS) dan Laporan Barang Pengguna Tahunan (LBPT) serta laporan inventarisasi 5 (lima) tahunan yang berada ', '60'),
('SKP01005', 'Menyiapkan, menganalisis, menyajikan dokumen untuk kebutuhan sertifikasi ISO - 120.0 menit', '120'),
('SKP01006', 'Menyiapkan, menganalisis, menyajikan dokumen untuk kebutuhan sertifikasi ISO - 60.0 menit', '60'),
('SKP01007', 'Menyiapkan / meracik obat berdasarkan resep dokter - 15.0 menit', '15'),
('SKP01008', 'Menyiapkan / meracik obat berdasarkan resep dokter - 5.0 menit', '5'),
('SKP01009', 'Menyiapkan naskah soal ujian perkegiatan - 15.0 menit', '15'),
('SKP01010', 'Menyiapkan rapat / diklat (Snack, daftar hadir) (Per 1 kegiatan) - 15.0 menit', '15'),
('SKP01011', 'Menyiapkan rapat / diklat (Snack, daftar hadir) (Per 1 kegiatan) - 30.0 menit', '30'),
('SKP01012', 'Menyusun Analisa Beban Kerja - 60.0 menit', '60'),
('SKP01013', 'Menyusun Analisa Beban Kerja - 30.0 menit', '30'),
('SKP01014', 'Menyusun angka konsolidasi aset - 120.0 menit', '120'),
('SKP01015', 'Menyusun angka konsolidasi aset - 60.0 menit', '60'),
('SKP01016', 'Menyusun angka konsolidasi selain aset - 60.0 menit', '60'),
('SKP01017', 'Menyusun angka konsolidasi selain aset - 120.0 menit', '120'),
('SKP01018', 'Menyusun angka konsolidasi selain aset - 30.0 menit', '30'),
('SKP01019', 'Menyusun bahan pembahasan rancangan Kebijakan - 60.0 menit', '60'),
('SKP01020', 'Menyusun bahan pembahasan rancangan Kebijakan - 120.0 menit', '120'),
('SKP01021', 'Menyusun daftar pajak terutang beserta fotokopi SSP - 60.0 menit', '60'),
('SKP01022', 'Menyusun dan mengerjakan SPJ Langsung (LS) per paket - 60.0 menit', '60'),
('SKP01023', 'Menyusun dan mengerjakan SPJ Langsung (LS) per paket - 30.0 menit', '30'),
('SKP01024', 'Menyusun dan menyiapkan bahan evaluasi - 120.0 menit', '120'),
('SKP01025', 'Menyusun dan menyiapkan bahan evaluasi - 60.0 menit', '60'),
('SKP01026', 'Menyusun data jabatan SKPD / UKPD - 90.0 menit', '90'),
('SKP01027', 'Menyusun data laporan jurnal SPJ - 30.0 menit', '30'),
('SKP01028', 'Menyusun data rekonsiliasi belanja - 180.0 menit', '180'),
('SKP01029', 'Menyusun data rekonsiliasi belanja - 120.0 menit', '120'),
('SKP01030', 'Menyusun data rekonsiliasi belanja - 60.0 menit', '60'),
('SKP01031', 'Menyusun data setoran SP2D Langsung (LS) - 300.0 menit', '300'),
('SKP01032', 'Menyusun data setoran SP2D Langsung (LS) - 60.0 menit', '60'),
('SKP01033', 'Menyusun data setoran SP2D Langsung (LS) - 120.0 menit', '120'),
('SKP01034', 'Menyusun data setoran SP2D Uang Persediaan (UP) - 120.0 menit', '120'),
('SKP01035', 'Menyusun data setoran SP2D Uang Persediaan (UP) - 300.0 menit', '300'),
('SKP01036', 'Menyusun data setoran SP2D Uang Persediaan (UP) - 60.0 menit', '60'),
('SKP01037', 'Menyusun Dokumen - 15.0 menit', '15'),
('SKP01038', 'Menyusun Dokumen - 10.0 menit', '10'),
('SKP01039', 'Menyusun Dokumen - 5.0 menit', '5'),
('SKP01040', 'Menyusun Dokumen RPJPD / RPJMD / RKPD - 120.0 menit', '120'),
('SKP01041', 'Menyusun Dokumen RPJPD / RPJMD / RKPD - 60.0 menit', '60'),
('SKP01042', 'Menyusun Dokumen RPJPD / RPJMD / RKPD - 180.0 menit', '180'),
('SKP01043', 'Menyusun draft Catatan atas Laporan Keuangan (CaLK) - 60.0 menit', '60'),
('SKP01044', 'Menyusun draft Catatan atas Laporan Keuangan (CaLK) - 120.0 menit', '120'),
('SKP01045', 'Menyusun draft Laporan Realisasi Anggaran (LRA) - 120.0 menit', '120'),
('SKP01046', 'Menyusun draft Laporan Realisasi Anggaran (LRA) - 60.0 menit', '60'),
('SKP01047', 'Menyusun draft Neraca - 120.0 menit', '120'),
('SKP01048', 'Menyusun draft Neraca - 60.0 menit', '60'),
('SKP01049', 'Menyusun Evaluasi Jabatan / Kelas Jabatan - 30.0 menit', '30'),
('SKP01050', 'Menyusun Evaluasi Jabatan / Kelas Jabatan - 60.0 menit', '60'),
('SKP01051', 'Menyusun Formasi Jabatan Pelaksana / Fungsional - 30.0 menit', '30'),
('SKP01052', 'Menyusun Formasi Jabatan Pelaksana / Fungsional - 60.0 menit', '60'),
('SKP01053', 'Menyusun formasi pegawai non PNS - 120.0 menit', '120'),
('SKP01054', 'Menyusun formasi pegawai non PNS - 60.0 menit', '60'),
('SKP01055', 'Menyusun indikator perjanjian kinerja SKPD / UKPD - 120.0 menit', '120'),
('SKP01056', 'Menyusun indikator perjanjian kinerja SKPD / UKPD - 180.0 menit', '180'),
('SKP01057', 'Menyusun Jadwal Anggaran Per Kegiatan Dalam Aplikasi Sistem informasi - 30.0 menit', '30'),
('SKP01058', 'Menyusun Jadwal Anggaran Per Kegiatan Dalam Aplikasi Sistem informasi - 60.0 menit', '60'),
('SKP01059', 'Menyusun kamus jabatan - 60.0 menit', '60'),
('SKP01060', 'Menyusun kamus jabatan - 120.0 menit', '120'),
('SKP01061', 'Menyusun Kebutuhan Formasi PNS - 30.0 menit', '30'),
('SKP01062', 'Menyusun Kebutuhan Formasi PNS - 120.0 menit', '120'),
('SKP01063', 'Menyusun Kebutuhan Formasi PNS - 60.0 menit', '60'),
('SKP01064', 'Menyusun konsep rincian anggaran - 30.0 menit', '30'),
('SKP01065', 'Menyusun konsep rincian anggaran - 60.0 menit', '60'),
('SKP01066', 'Menyusun Kurikulum / Buku / Diktat / Modul - 120.0 menit', '120'),
('SKP01067', 'Menyusun Kurikulum / Buku / Diktat / Modul - 60.0 menit', '60'),
('SKP01068', 'Menyusun Kurikulum / Buku / Diktat / Modul - 180.0 menit', '180'),
('SKP01069', 'Menyusun LAKIP - 60.0 menit', '60'),
('SKP01070', 'Menyusun LAKIP - 180.0 menit', '180'),
('SKP01071', 'Menyusun LAKIP - 120.0 menit', '120'),
('SKP01072', 'Menyusun laporan jurnal SP2D - 60.0 menit', '60'),
('SKP01073', 'Menyusun laporan jurnal SP2D - 30.0 menit', '30'),
('SKP01074', 'Menyusun laporan keuangan SKPD - 60.0 menit', '60'),
('SKP01075', 'Menyusun laporan keuangan SKPD - 180.0 menit', '180'),
('SKP01076', 'Menyusun laporan keuangan SKPD - 120.0 menit', '120'),
('SKP01077', 'Menyusun laporan pendapatan jasa giro - 30.0 menit', '30'),
('SKP01078', 'Menyusun Laporan Pertanggungjawaban Keuangan (bendahara pengeluaran) - 30.0 menit', '30'),
('SKP01079', 'Menyusun laporan tutup buku - 180.0 menit', '180'),
('SKP01080', 'Menyusun laporan tutup buku - 120.0 menit', '120'),
('SKP01081', 'Menyusun LKPJ (Laporan Kinerja Pertanggungjawaban) gubernur - 180.0 menit', '180'),
('SKP01082', 'Menyusun matriks - 120.0 menit', '120'),
('SKP01083', 'Menyusun matriks - 30.0 menit', '30'),
('SKP01084', 'Menyusun matriks - 60.0 menit', '60'),
('SKP01085', 'Menyusun / Membuat Sasaran Kerja Pegawai (SKP) - 60.0 menit', '60'),
('SKP01086', 'Menyusun Naskah Akademis - 60.0 menit', '60'),
('SKP01087', 'Menyusun Naskah Akademis - 120.0 menit', '120'),
('SKP01088', 'Menyusun Nota Keuangan - 180.0 menit', '180'),
('SKP01089', 'Menyusun Nota Keuangan - 120.0 menit', '120'),
('SKP01090', 'Menyusun pedoman / petunjuk teknis / petunjuk pelaksanaan - 90.0 menit', '90'),
('SKP01091', 'Menyusun pedoman / petunjuk teknis / petunjuk pelaksanaan - 120.0 menit', '120'),
('SKP01092', 'Menyusun pedoman / petunjuk teknis / petunjuk pelaksanaan - 60.0 menit', '60'),
('SKP01093', 'Menyusun Rancangan APBD / APBD-P - 120.0 menit', '120'),
('SKP01094', 'Menyusun Rancangan APBD / APBD-P - 60.0 menit', '60'),
('SKP01095', 'Menyusun Rancangan APBD / APBD-P - 180.0 menit', '180'),
('SKP01096', 'Menyusun rencana induk sistem informasi keseluruhan (Master Plan) - 60.0 menit', '60'),
('SKP01097', 'Menyusun rencana induk sistem informasi keseluruhan (Master Plan) - 120.0 menit', '120'),
('SKP01098', 'Menyusun rencana kebutuhan - 30.0 menit', '30'),
('SKP01099', 'Menyusun rencana kebutuhan - 15.0 menit', '15'),
('SKP01100', 'Menyusun Rencana Kegiatan / Anggaran - 120.0 menit', '120'),
('SKP01101', 'Menyusun Rencana Kegiatan / Anggaran - 30.0 menit', '30'),
('SKP01102', 'Menyusun Rencana Kegiatan / Anggaran - 60.0 menit', '60'),
('SKP01103', 'Menyusun rencana pemeriksaan okupasi terapi (Kasus ringan) - 10.0 menit', '10'),
('SKP01104', 'Menyusun rincian usulan Formasi kebutuhan pegawai - 120.0 menit', '120'),
('SKP01105', 'Menyusun rincian usulan Formasi kebutuhan pegawai - 180.0 menit', '180'),
('SKP01106', 'Menyusun ringkasan surat masuk Gubernur (Membuat resume) - 10.0 menit', '10'),
('SKP01107', 'Menyusun ringkasan surat masuk Gubernur (Membuat resume) - 15.0 menit', '15'),
('SKP01108', 'Menyusun RKA dan DPA - 120.0 menit', '120'),
('SKP01109', 'Menyusun RKA dan DPA - 60.0 menit', '60'),
('SKP01110', 'Menyusun studi kelayakan sistem - 60.0 menit', '60'),
('SKP01111', 'Menyusun studi kelayakan sistem - 30.0 menit', '30'),
('SKP01112', 'Menyusun studi kelayakan sistem - 120.0 menit', '120'),
('SKP01113', 'Menyusun tabel manual anggaran per kegiatan tahun anggaran - 60.0 menit', '60'),
('SKP01114', 'Menyusun Tindak Lanjut Temuan BPK - 30.0 menit', '30'),
('SKP01115', 'Menyusun Tindak Lanjut Temuan BPK - 60.0 menit', '60'),
('SKP01116', 'Meracik pakan satwa - 45.0 menit', '45'),
('SKP01117', 'Merawat satwa (per hewan) - 60.0 menit', '60'),
('SKP01118', 'Merawat satwa (per hewan) - 30.0 menit', '30'),
('SKP01119', 'Merevisi Rencana Kerja dan Anggaran per kegiatan - 30.0 menit', '30'),
('SKP01120', 'Mewarnai sediaan / Objek Kerja - 5.0 menit', '5'),
('SKP01121', 'Migrasi database - 60.0 menit', '30'),
('SKP01122', 'Migrasi database - 15.0 menit', '15'),
('SKP01123', 'Migrasi database - 30.0 menit', '30'),
('SKP01124', 'Monitoring CCTV lalu lintas melalui ruang pusat kendali lalu lintas ITS - 30.0 menit', '30'),
('SKP01125', 'Monitoring kegiatan - 120.0 menit', '120'),
('SKP01126', 'Monitoring kegiatan - 15.0 menit', '15'),
('SKP01127', 'Monitoring kegiatan - 30.0 menit', '30'),
('SKP01128', 'Monitoring kegiatan - 90.0 menit', '90'),
('SKP01129', 'Monitoring kegiatan - 60.0 menit', '60'),
('SKP01130', 'Narator pertunjukan teater bintang - 60.0 menit', '60'),
('SKP01131', 'Nomerator Bahan Perpustakaan (Per 5 Buku) - 5.0 menit', '5'),
('SKP01132', 'Observasi jasa pos - 30.0 menit', '30'),
('SKP01133', 'Observasi jasa pos - 60.0 menit', '60'),
('SKP01134', 'Observasi Jasa Telekomunikasi - 60.0 menit', '60'),
('SKP01135', 'Observasi Jasa Telekomunikasi - 30.0 menit', '30'),
('SKP01136', 'Observasi Multimedia - 60.0 menit', '60'),
('SKP01137', 'Observasi Multimedia - 30.0 menit', '30'),
('SKP01138', 'Panitia pada pelaksanaan kegiatan di SKPD / UKPD - 60.0 menit', '60'),
('SKP01139', 'Panitia pada pelaksanaan kegiatan di SKPD / UKPD - 120.0 menit', '120'),
('SKP01140', 'Panitia pada pelaksanaan kegiatan di SKPD / UKPD - 180.0 menit', '180'),
('SKP01141', 'Pelaksanaan gugus kendali mutu - 120.0 menit', '120'),
('SKP01142', 'Pelaksanaan gugus kendali mutu - 60.0 menit', '60'),
('SKP01143', 'Pelaksanaan rembuk RW - 180.0 menit', '180'),
('SKP01144', 'Pelaksanaan rembuk RW - 120.0 menit', '120'),
('SKP01145', 'Pelaporan dan pertanggungjawaban pelaksanaan tugas dan fungsi Inspektorat Pembantu - 120.0 menit', '120'),
('SKP01146', 'Pelaporan dan pertanggungjawaban pelaksanaan tugas dan fungsi Inspektorat Pembantu - 240.0 menit', '240'),
('SKP01147', 'Pelaporan dan pertanggungjawaban pelaksanaan tugas dan fungsi Inspektorat Pembantu - 180.0 menit', '180'),
('SKP01148', 'Pelayanan Makan Warga Binaan Sosial (WBS) perpasien - 15.0 menit', '15'),
('SKP01149', 'Pelayanan Surat PM1 / pernyataan / keterangan - 10.0 menit', '10'),
('SKP01150', 'Pemantauan kegiatan posyandu - 60.0 menit', '60'),
('SKP01151', 'Pemantauan kegiatan posyandu - 120.0 menit', '120'),
('SKP01152', 'Pemantauan Unjuk Rasa - 120.0 menit', '120'),
('SKP01153', 'Pemantauan Unjuk Rasa - 60.0 menit', '60'),
('SKP01154', 'Pembahasan KUA-PPAS Bersama DPRD - 120.0 menit', '120'),
('SKP01155', 'Pembahasan KUA-PPAS Bersama DPRD - 180.0 menit', '180'),
('SKP01156', 'Pembahasan RAPBD / RAPBD-P dengan DPRD - 120.0 menit', '120'),
('SKP01157', 'Pembahasan RAPBD / RAPBD-P dengan DPRD - 180.0 menit', '180'),
('SKP01158', 'Pembahasan RAPBD / RAPBD-P dengan Pemerintah Pusat - 180.0 menit', '180'),
('SKP01159', 'Pemberian keterangan ahli / saksi / sebagai pendamping di persidangan - 120.0 menit', '120'),
('SKP01160', 'Pemberian keterangan ahli / saksi / sebagai pendamping di persidangan - 180.0 menit', '180'),
('SKP01161', 'Pembuatan Album Foto Peserta Ujian Nasional - 60.0 menit', '60'),
('SKP01162', 'Pembuatan karya tulis / karya ilmiah - 60.0 menit', '60'),
('SKP01163', 'Pembuatan karya tulis / karya ilmiah - 120.0 menit', '120'),
('SKP01164', 'Pembuatan Tanda Nomor Pemeriksaan Uji pada Fisik Kendaraan - 5.0 menit', '5'),
('SKP01165', 'Pemeriksaan dan Pengujian Khusus Objek Kesehatan Keselamatan Kerja (K3 ) - 60.0 menit', '60'),
('SKP01166', 'Pemeriksaan gambar pelaksanaan bangunan / shop drawing / as built drawing (Per Gambar) - 30.0 menit', '30'),
('SKP01167', 'Pemeriksaan gambar pelaksanaan bangunan / shop drawing / as built drawing (Per Gambar) - 60.0 menit', '60'),
('SKP01168', 'Pemeriksaan Lab. Kesehatan - 10.0 menit', '10'),
('SKP01169', 'Pemeriksaan Lab. Kesehatan - 20.0 menit', '20'),
('SKP01170', 'Pemeriksaan Lab. Kesehatan - 15.0 menit', '15'),
('SKP01171', 'Pemeriksaan Operasi K3 Konstruksi - 120.0 menit', '120'),
('SKP01172', 'Pemeriksaan Operasi K3 Konstruksi - 60.0 menit', '60'),
('SKP01173', 'Pemeriksaan / pengawasan terhadap konstruksi / bangunan - 120.0 menit', '120'),
('SKP01174', 'Pemeriksaan / pengawasan terhadap konstruksi / bangunan - 180.0 menit', '180'),
('SKP01175', 'Pemeriksaan Specimen - 5.0 menit', '5'),
('SKP01176', 'Pemutakhiran data aset - 120.0 menit', '120'),
('SKP01177', 'Pemutakhiran data aset - 60.0 menit', '60'),
('SKP01178', 'Penandatanganan Berkas Perizinan dan Non Perizinan - 5.0 menit', '5'),
('SKP01179', 'Penanganan kegawatdaruratan - 30.0 menit', '30'),
('SKP01180', 'Penanganan kegawatdaruratan - 60.0 menit', '60'),
('SKP01181', 'Penataan arsip kantor - 30.0 menit', '30'),
('SKP01182', 'Penataan arsip kantor - 15.0 menit', '15'),
('SKP01183', 'Penataan arsip kantor - 45.0 menit', '45'),
('SKP01184', 'Pencairan SPM ke kantor kas daerah - 60.0 menit', '60'),
('SKP01185', 'Pendampingan Terhadap Penggunaan SPSE dan Aplikasi e-Procurement Lainnya - 30.0 menit', '30'),
('SKP01186', 'Penelitian berkas permohonan perizinan (per aplikasi pengajuan) - 60.0 menit', '60'),
('SKP01187', 'Penelitian berkas permohonan perizinan (per aplikasi pengajuan) - 30.0 menit', '30'),
('SKP01188', 'Penelitian berkas permohonan perizinan (per aplikasi pengajuan) - 15.0 menit', '15'),
('SKP01189', 'Penelitian berkas permohonan perizinan (per aplikasi pengajuan) - 5.0 menit', '5'),
('SKP01190', 'Penelitian berkas permohonan perizinan (teknis) - 10.0 menit', '10'),
('SKP01191', 'Penelitian berkas permohonan perizinan (teknis) - 5.0 menit', '5'),
('SKP01192', 'Penelitian berkas permohonan perizinan (teknis) - 15.0 menit', '15'),
('SKP01193', 'Penerimaan Hasil Pengadaan Barang / Jasa - 60.0 menit', '60'),
('SKP01194', 'Penerimaan Hasil Pengadaan Barang / Jasa - 30.0 menit', '30'),
('SKP01195', 'Pengawasan / Pelaksanaan Kegiatan Perencanaan dan Evaluasi Pengawasan / Melaksanakan kegiatan perencanaan pengawasan - 180.0 menit', '180'),
('SKP01196', 'Pengawasan / Pelaksanaan Kegiatan Perencanaan dan Evaluasi Pengawasan / Melaksanakan kegiatan perencanaan pengawasan - 60.0 menit', '60'),
('SKP01197', 'Pengawasan / Pelaksanaan Kegiatan Perencanaan dan Evaluasi Pengawasan / Melaksanakan kegiatan perencanaan pengawasan - 120.0 menit', '120'),
('SKP01198', 'Pengecapan Identitas Bahan Perpustakaan (Per 5 Buku) - 5.0 menit', '5'),
('SKP01199', 'Pengendalian organisme pengganggu tanaman (OPT) - 60.0 menit', '60'),
('SKP01200', 'Pengesahan gambar pelaksanaan bangunan / shop drawing / as built drawing untuk SLF (Per Gambar) - 15.0 menit', '15'),
('SKP01201', 'Pengesahan gambar pelaksanaan bangunan / shop drawing / as built drawing untuk SLF (Per Gambar) - 30.0 menit', '30'),
('SKP01202', 'Pengetikan Call Number Bahan Perpustakaan (Per 5 Buku) - 5.0 menit', '5'),
('SKP01203', 'Penggandaan berkas / dokumen - 0.1 menit', '0.1'),
('SKP01204', 'Penggandaan berkas / dokumen - 0.2 menit', '0.2'),
('SKP01205', 'Penginputan sisa mati anggaran - 30.0 menit', '30'),
('SKP01206', 'Pengurusan administrasi kepegawaian - 60.0 menit', '60'),
('SKP01207', 'Pengurusan administrasi kepegawaian - 30.0 menit', '30'),
('SKP01208', 'Pengurusan administrasi kepegawaian - 15.0 menit', '15'),
('SKP01209', 'Penindakan penyegelan sesuai dengan objek kerja - 60.0 menit', '60'),
('SKP01210', 'Penindakan terhadap pelanggaran Perda - 30.0 menit', '30'),
('SKP01211', 'Penindakan terhadap pelanggaran Perda - 60.0 menit', '60'),
('SKP01212', 'Penindakan terhadap pelanggaran Perda - 90.0 menit', '90'),
('SKP01213', 'Penomoran naskah dinas - 5.0 menit', '5'),
('SKP01214', 'Penyaluran Warga Binaan Sosial (WBS) per kegiatan - 60.0 menit', '60'),
('SKP01215', 'Penyaluran Warga Binaan Sosial (WBS) per kegiatan - 90.0 menit', '90'),
('SKP01216', 'Penyelesaian dokumen pertanggungjawaban belanja (SPJ) - 60.0 menit', '60'),
('SKP01217', 'Penyelesaian dokumen pertanggungjawaban belanja (SPJ) - 30.0 menit', '30'),
('SKP01218', 'Penyusunan Dokumen KUA-PPAS - 120.0 menit', '120'),
('SKP01219', 'Penyusunan Dokumen Rencana Kebutuhan Barang / Jasa - 60.0 menit', '60'),
('SKP01220', 'Penyusunan Dokumen Rencana Kebutuhan Barang / Jasa - 120.0 menit', '120'),
('SKP01221', 'Penyusunan Harga Perkiraan Sendiri (HPS) Barang / Jasa - 30.0 menit', '30'),
('SKP01222', 'Penyusunan Harga Perkiraan Sendiri (HPS) Barang / Jasa - 15.0 menit', '15'),
('SKP01223', 'Penyusunan RAB / HPS dalam Pengadaan Barang / Jasa - 120.0 menit', '120'),
('SKP01224', 'Penyusunan RAB / HPS dalam Pengadaan Barang / Jasa - 60.0 menit', '60'),
('SKP01225', 'Penyusunan Rencana Pelaksanaan Pengadaan Barang / Jasa (per kegiatan) - 120.0 menit', '120'),
('SKP01226', 'Penyusunan Rencana Pelaksanaan Pengadaan Barang / Jasa (per kegiatan) - 60.0 menit', '60'),
('SKP01227', 'Penyusunan Rencana Pemaketan Pekerjaan Pengadaan Barang / Jasa - 60.0 menit', '60'),
('SKP01228', 'Penyusunan Rencana Pemaketan Pekerjaan Pengadaan Barang / Jasa - 120.0 menit', '120'),
('SKP01229', 'Penyusutan Arsip - 30.0 menit', '30'),
('SKP01230', 'Penyusutan Arsip - 5.0 menit', '5'),
('SKP01231', 'Penyusutan Arsip - 15.0 menit', '15'),
('SKP01232', 'Perawatan Kesehatan Warga Binaan Sosial (WBS) per pasien - 10.0 menit', '10'),
('SKP01233', 'Perekaman / Pemotretan Arsip Mikro Film - 30.0 menit', '30'),
('SKP01234', 'Pre / Post Confrence Keperawatan - 20.0 menit', '20'),
('SKP01235', 'Pre / Post Confrence Keperawatan - 30.0 menit', '30'),
('SKP01236', 'Registrasi data pencari kerja - 5.0 menit', '5'),
('SKP01237', 'Registrasi Koleksi KCKR (Karya Cetak dan Karya Rekam) - 30.0 menit', '30'),
('SKP01238', 'Registrasi Koleksi KCKR (Karya Cetak dan Karya Rekam) - 90.0 menit', '90'),
('SKP01239', 'Registrasi Koleksi KCKR (Karya Cetak dan Karya Rekam) - 60.0 menit', '60'),
('SKP01240', 'Rekrutmen Tenaga Non PNS (per kegiatan) - 30.0 menit', '30'),
('SKP01241', 'Restorasi Perbaikan Arsip - 5.0 menit', '5'),
('SKP01242', 'Review Laporan Keuangan - 120.0 menit', '120'),
('SKP01243', 'Review Laporan Keuangan - 180.0 menit', '180'),
('SKP01244', 'Review Laporan Keuangan - 60.0 menit', '60'),
('SKP01245', 'Seleksi Bahan Perpustakaan - 10.0 menit', '10'),
('SKP01246', 'Setting Network pada perangkat keras / lunak - 10.0 menit', '10'),
('SKP01247', 'Supervisi Anggaran - 60.0 menit', '60'),
('SKP01248', 'Supervisi Anggaran - 30.0 menit', '30'),
('SKP01249', 'Supervisi Anggaran - 120.0 menit', '120'),
('SKP01250', 'Ujian Kompetensi Guru dan Pengawas jenjang SD, SMP, SMA, SMK - 180.0 menit', '180'),
('SKP01251', 'Uji Kelayakan Kendaraan Bermotor - 5.0 menit', '5'),
('SKP01252', 'Uji Kelayakan Kendaraan Bermotor - 15.0 menit', '15'),
('SKP01253', 'Uji Kelayakan Kendaraan Bermotor - 30.0 menit', '30'),
('SKP01254', 'Update Content Social Media - 2.0 menit', '2'),
('SKP01255', 'Verifikasi Buku Kas Umum (BKU) dan Buku Pembantu Lainnya - 30.0 menit', '30'),
('SKP01256', 'Verifikasi Buku Kas Umum (BKU) dan Buku Pembantu Lainnya - 60.0 menit', '60'),
('SKP01257', 'Verifikasi Daftar Gaji / Daftar TKD / Daftar tunjangan lainnya - 15.0 menit', '15'),
('SKP01258', 'Verifikasi Daftar Gaji / Daftar TKD / Daftar tunjangan lainnya - 30.0 menit', '30'),
('SKP01259', 'Verifikasi Daftar Gaji / Daftar TKD / Daftar tunjangan lainnya - 60.0 menit', '60'),
('SKP01260', 'Verifikasi dokumen kontrak pengadaan barang / jasa - 90.0 menit', '90'),
('SKP01261', 'Verifikasi dokumen kontrak pengadaan barang / jasa - 30.0 menit', '30'),
('SKP01262', 'Verifikasi dokumen kontrak pengadaan barang / jasa - 60.0 menit', '60'),
('SKP01263', 'Verifikasi Surat Perintah Pembayaran (SPP) - 15.0 menit', '15'),
('SKP01264', 'Verifikasi Surat Perintah Pembayaran (SPP) - 30.0 menit', '30'),
('SKP01265', 'Verifikasi Surat Pertanggungjawaban (SPJ) - 15.0 menit', '15');
INSERT INTO `skp` (`kd_skp`, `skp`, `waktu`) VALUES
('SKP01266', 'Verifikasi Surat Pertanggungjawaban (SPJ) - 30.0 menit', '30'),
('SKP01267', 'Verifikasi Surat Pertanggungjawaban (SPJ) - 60.0 menit', '60'),
('SKP01268', 'Wawancara teknis terhadap pelaku teknis bangunan untuk proses permohonan IPTB baru / perpanjangan - 30.0 menit', '30'),
('SKP01269', 'Melakukan penyuluhan - 60.0 menit', '60'),
('SKP01270', 'Melaksanakan tugas bantuan kesehatan lapangan seperti pada situasi gadar dan bencana - 180.0 menit', '180'),
('SKP01271', 'Melaksanakan / Melayani Konsultasi Individu / kelompok - 30.0 menit', '30'),
('SKP01272', 'Melakukan rujukan - 30.0 menit', '30'),
('SKP01273', 'Melaksanakan imunisasi, vaksinasi, feed additive - 15.0 menit', '15'),
('SKP01274', 'Melaksanakan imunisasi, vaksinasi, feed additive - 60.0 menit', '60'),
('SKP01275', 'Melaksanakan pemeriksaan pasien - 5.0 menit', '5'),
('SKP01276', 'Melaksanakan 5 R (Ringkas, Rapi, Resik, Rawat, Rajin) - 30.0 menit', '30'),
('SKP01277', 'Melaksanakan 5 R (Ringkas, Rapi, Resik, Rawat, Rajin) - 60.0 menit', '60'),
('SKP01278', 'Melaksanakan / Melayani Konsultasi Individu / kelompok - 15.0 menit', '15'),
('SKP01279', 'Melaksanakan pemeriksaan pasien - 15.0 menit', '15'),
('SKP01280', 'Melaksanakan pemeriksaan pasien - 30.0 menit', '30'),
('SKP01281', 'Melaksanakan pengolahan dokumen rekam medis - 15.0 menit', '15'),
('SKP01282', 'Melaksanakan pengolahan dokumen rekam medis - 30.0 menit', '30'),
('SKP01283', 'Melaksanakan / Melayani Konsultasi Individu / kelompok - 60.0 menit', '60'),
('SKP01284', 'Melaksanakan Kegiatan Pembinaan - 30.0 menit', '30'),
('SKP01285', 'Melaksanakan Kegiatan Pembinaan - 60.0 menit', '60'),
('SKP01286', 'Mengikuti rapat koordinasi - 180.0 menit', '180'),
('SKP01287', 'Melaksanakan / mengikuti kegiatan apel / upacara - 90.0 menit', '90'),
('SKP01288', 'Menyusun data / laporan - 15.0 menit', '15'),
('SKP01289', 'Menyusun data / laporan - 30.0 menit', '30'),
('SKP01290', 'Melakukan anamnesa keperawatan per pasien - 5.0 menit', '5'),
('SKP01291', 'Melaksanakan tugas kedinasan lain yang diperintahkan oleh pimpinan baik tertulis maupun lisan - 30.0 menit', '30'),
('SKP01292', 'Melaksanakan tugas kedinasan lain yang diperintahkan oleh pimpinan baik tertulis maupun lisan - 60.0 menit', '60'),
('SKP01293', 'Melakukan tindakan keperawatan - 30.0 menit', '30'),
('SKP01294', 'Melakukan tindakan keperawatan - 20.0 menit', '20'),
('SKP01295', 'Pemeliharaan dan Perawatan alat kesehatan - 10.0 menit', '10'),
('SKP01296', 'Mengikuti rapat koordinasi - 45.0 menit', '45'),
('SKP01297', 'Mengikuti rapat koordinasi - 60.0 menit', '60'),
('SKP01298', 'Mengikuti rapat koordinasi - 90.0 menit', '90'),
('SKP01299', 'Mengikuti rapat koordinasi - 120.0 menit', '120'),
('SKP01300', 'Melaksanakan / mengikuti kegiatan apel / upacara - 60.0 menit', '60'),
('SKP01301', 'Menolong Persalinan - 60.0 menit', '60'),
('SKP01302', 'Melaksanakan Pemeriksaan Bayi baru Lahir - 60.0 menit', '60'),
('SKP01303', 'Melakukan Pemasangan IUD Pasca Plasenta - 30.0 menit', '30'),
('SKP01304', 'Melakukan Kontrol Nifas Pada Ibu - 60.0 menit', '60'),
('SKP01306', 'Melakukan Tindik bayi -30.0 menit', '30'),
('SKP01307', 'Melakukan Observasi Ibu Bersalin -120.0 menit', '120'),
('SKP01308', 'Melaksanakan Sterilisasi Alat -15.0 menit', '15'),
('SKP01309', 'Membuat Surat Rujukan -15.0 menit', '15'),
('SKP01310', 'Melakukan tindakan Kebidanan -30.0 menit', '30'),
('SKP01311', 'Melakukan anamnesa keperawatan per pasien - 5.0 menit', '5'),
('SKP01312', 'Melakukan Skrining Hipotiroid Kongenital -30.0 menit', '30'),
('SKP01313', 'Melakukan Tindakan Kebidanan - 30.0 menit', '30'),
('SKP01314', 'Mengganti Cairan Processing Film - 90.0 menit', '90'),
('SKP01315', 'Mengikuti Orientasi - 120.0 menit', '120');

-- --------------------------------------------------------

--
-- Table structure for table `skpd`
--

CREATE TABLE `skpd` (
  `id_skpd` varchar(8) NOT NULL,
  `n_skpd` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `skpd`
--

INSERT INTO `skpd` (`id_skpd`, `n_skpd`) VALUES
('1.02', 'Dinas Kesehatan Pemprov. DKI Jakarta');

-- --------------------------------------------------------

--
-- Table structure for table `skptahunan`
--

CREATE TABLE `skptahunan` (
  `id_skptahunan` varchar(8) NOT NULL,
  `nip` varchar(30) NOT NULL,
  `kd_skp` varchar(160) NOT NULL,
  `id_bag` varchar(25) NOT NULL,
  `kuant` varchar(5) NOT NULL,
  `kual` varchar(5) NOT NULL,
  `waktu` varchar(8) NOT NULL,
  `t_buat` varchar(8) NOT NULL,
  `t_edit` varchar(8) NOT NULL,
  `waktu_e` int(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `status`
--

CREATE TABLE `status` (
  `id_status` varchar(8) NOT NULL,
  `n_status` varchar(25) NOT NULL,
  `nilai` varchar(8) NOT NULL,
  `id_skpd` varchar(10) NOT NULL,
  `id_ukpd` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `status`
--

INSERT INTO `status` (`id_status`, `n_status`, `nilai`, `id_skpd`, `id_ukpd`) VALUES
('K-2', 'MENIKAH ANAK 2', '1.14', '1.02', '1.02.058'),
('K-1', 'MENIKAH ANAK 1', '1.12', '1.02', '1.02.058'),
('K-0', 'MENIKAH', '1.1', '1.02', '1.02.058'),
('TK-0', 'LAJANG', '1', '1.02', '1.02.058'),
('TK-1', 'JANDA/DUDA ANAK 1', '1.02', '1.02', '1.02.058'),
('TK-2', 'JANDA/DUDA ANAK 2', '1.04', '1.02', '1.02.058');

-- --------------------------------------------------------

--
-- Table structure for table `ukpd`
--

CREATE TABLE `ukpd` (
  `id_ukpd` varchar(8) NOT NULL,
  `n_ukpd` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ukpd`
--

INSERT INTO `ukpd` (`id_ukpd`, `n_ukpd`) VALUES
('1.02.058', 'Puskesmas Kec. Duren Sawit');

-- --------------------------------------------------------

--
-- Table structure for table `user_id`
--

CREATE TABLE `user_id` (
  `userid` varchar(50) NOT NULL,
  `passid` varchar(50) NOT NULL,
  `level_user` varchar(25) NOT NULL,
  `id_skpd` varchar(10) NOT NULL,
  `id_ukpd` varchar(10) NOT NULL,
  `id_bag` varchar(8) NOT NULL,
  `nama` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_id`
--

INSERT INTO `user_id` (`userid`, `passid`, `level_user`, `id_skpd`, `id_ukpd`, `id_bag`, `nama`) VALUES
('admin', 'admin', '11', '', '', '', 'Administrator'),
('10205819880xxxxxxxxxxxxx', '654321', '6', '1.02', '1.02.058', 'B03', 'Putri Medikasari Trijayanti, SE'),
('10205819830xxxxxxxxxxxxx', '654321', '4', '1.02', '1.02.058', 'B03', 'Marga Sucipto,S.Sos'),
('110xxx', '123456', '8', '1.02', '1.02.058', 'Ka. TU', 'Rujianto,S.Sos'),
('kepalaTU', '654321', '9', '1.02', '1.02.058', 'Kasubbag', 'Rujianto,S.Sos'),
('165xxx', '13579', '8', '1.02', '1.02.058', 'Ka. JTN', 'drg. Ami Setyowati'),
('165xxxx', '123456', '8', '1.02', '1.02.058', 'Ka. ELOK', 'dr. Santi Rosamarlia'),
('178792', '123456', '8', '1.02', '1.02.058', 'Ka. CB', 'dr. Istika Rahma'),
('168365', '123456', '8', '1.02', '1.02.058', 'Sat. UKP', 'dr. Ratna Keumala'),
('117887', '123456', '8', '1.02', '1.02.058', 'Ka. PIK', 'drg. Lely Riana'),
('123159', '123456', '8', '1.02', '1.02.058', 'Ka. RT', 'drg. Rita Nadiroha'),
('125414', '123456', '8', '1.02', '1.02.058', 'Ka. CT', 'drg. Apriemi Simanjuntak'),
('118031', '123456', '8', '1.02', '1.02.058', 'Ka. UM', 'drg. Arini Wiwik'),
('162305', '123456', '8', '1.02', '1.02.058', 'Sat. UKM', 'drg. Adrianti Siregar'),
('032003', '123456', '8', '1.02', '1.02.058', 'Ka. TU', 'Saulas Donater Rosdiana N'),
('904253', '123456', '4', '1.02', '1.02.058', 'B04', 'Fahmilla Chatra Marvel'),
('704134', '123456', '4', '1.02', '1.02.058', 'B04', 'dr. Muhammad Adhitya Wicaksono'),
('602145', '123456', '4', '1.02', '1.02.058', 'B04', 'Ahmad Hasan'),
('501047', '123456', '4', '1.02', '1.02.058', 'B04', 'Andina Maryati'),
('190554', '123456', '4', '1.02', '1.02.058', 'B04', 'Andri Harwantono'),
('306042', '123456', '4', '1.02', '1.02.058', 'B04', 'Vevi Indriana'),
('902249', '123456', '4', '1.02', '1.02.058', 'B04', 'Jamilah'),
('501041', '123456', '4', '1.02', '1.02.058', 'B04', 'Handi'),
('405045', '123456', '4', '1.02', '1.02.058', 'B04', 'Tri Indah'),
('706135', '123456', '4', '1.02', '1.02.058', 'B04', 'Iwan Sunarya Purba'),
('902246', '123456', '4', '1.02', '1.02.058', 'B04', 'Sri Intan Yulianingsih'),
('401044', '123456', '4', '1.02', '1.02.058', 'B04', 'Sri Haryati'),
('405164', '123456', '4', '1.02', '1.02.058', 'B04', 'Shinta Febriyanti'),
('301048', '123456', '4', '1.02', '1.02.058', 'B04', 'Abdul Basiyit Ritonga'),
('901237', '123456', '4', '1.02', '1.02.058', 'B04', 'Ade Sugianto'),
('301057', '123456', '4', '1.02', '1.02.058', 'B04', 'Sutardi'),
('902247', '123456', '4', '1.02', '1.02.058', 'B04', 'Alex Wijarnoko'),
('603056', '123456', '4', '1.02', '1.02.058', 'B04', 'Maryani'),
('603053', '123456', '4', '1.02', '1.02.058', 'B04', 'Vita yunita'),
('603054', '123456', '4', '1.02', '1.02.058', 'B04', 'Dimas Pandhanu Kusrianto'),
('603055', '123456', '4', '1.02', '1.02.058', 'B04', 'Eka wulandari'),
('123153', '123456', '4', '1.02', '1.02.058', 'B04', 'Ahmad Mausul'),
('602018', '123456', '4', '1.02', '1.02.058', 'B04', 'Rudi Awal Saputra'),
('703192', '123456', '4', '1.02', '1.02.058', 'B04', 'Primus hadi wijaya'),
('602015', '123456', '4', '1.02', '1.02.058', 'B04', 'Andi Kumar'),
('201110', '123456', '4', '1.02', '1.02.058', 'B04', 'Anggi Putra'),
('602005', '123456', '4', '1.02', '1.02.058', 'B04', 'dr. Neny Rohaeny'),
('602007', '123456', '4', '1.02', '1.02.058', 'B04', 'dr. Dian Fridayani'),
('602008', '123456', '4', '1.02', '1.02.058', 'B04', 'dr. Rizky Dwi Mulyanti'),
('201091', '123456', '4', '1.02', '1.02.058', 'B04', 'dr. Ladoni Amiro'),
('611009', '123456', '4', '1.02', '1.02.058', 'B04', 'dr. Dhimas Hartanto'),
('301113', '123456', '4', '1.02', '1.02.058', 'B04', 'Chandra Ariestadi'),
('603033', '123456', '4', '1.02', '1.02.058', 'B04', 'Eko Mulyadi'),
('603032', '123456', '4', '1.02', '1.02.058', 'B04', 'I Gusti Ayu Agung Ardhi Maharani'),
('712029', '123456', '4', '1.02', '1.02.058', 'B04', 'Mila Hanifah'),
('712028', '123456', '4', '1.02', '1.02.058', 'B04', 'Dalila Rima Azizah'),
('902248', '123456', '4', '1.02', '1.02.058', 'B04', 'Chamelia Pertiwi'),
('805231', '123456', '4', '1.02', '1.02.058', 'B04', 'Ariyani'),
('804219', '123456', '4', '1.02', '1.02.058', 'B04', 'Barliana Restu Saraswqti'),
('804220', '123456', '4', '1.02', '1.02.058', 'B04', 'Ayu Wulandari'),
('602179', '123456', '4', '1.02', '1.02.058', 'B04', 'Margaretha'),
('602183', '123456', '4', '1.02', '1.02.058', 'B04', 'Desty Dwianti'),
('707050', '123456', '4', '1.02', '1.02.058', 'B04', 'Dinar Febriani'),
('902245', '123456', '4', '1.02', '1.02.058', 'B04', 'Dewi Apriyanti'),
('404084', '123456', '4', '1.02', '1.02.058', 'B05', 'EKA SEPTI WAHYUNI'),
('804209', '123456', '4', '1.02', '1.02.058', 'B05', 'LISA PUJI ASTUTI'),
('304193', '123456', '4', '1.02', '1.02.058', 'B05', 'SUSIYAWATI'),
('601198', '123456', '4', '1.02', '1.02.058', 'B05', 'IDIL FITRI'),
('604192', '123456', '4', '1.02', '1.02.058', 'B05', 'NURISKA ASDIANTI'),
('602173', '123456', '4', '1.02', '1.02.058', 'B04', 'Nindy Audyna'),
('608169', '123456', '4', '1.02', '1.02.058', 'B04', 'Febri Mutiarani Putri'),
('707190', '123456', '4', '1.02', '1.02.058', 'B04', 'Mei Anjellyna'),
('804218', '123456', '4', '1.02', '1.02.058', 'B04', 'Lenni Sri Paramitha Brutu'),
('707127', '123456', '4', '1.02', '1.02.058', 'B04', 'Anelia Prasticha Sari'),
('711051', '123456', '4', '1.02', '1.02.058', 'B04', 'Haryanto'),
('123154', '123456', '4', '1.02', '1.02.058', 'B04', 'Rahma Apriana Ulva'),
('608034', '123456', '4', '1.02', '1.02.058', 'B04', 'Indri Saditri'),
('201086', '123456', '4', '1.02', '1.02.058', 'B01', 'dr. Amira'),
('418130', '123456', '4', '1.02', '1.02.058', 'B01', 'Annisa Siskha Septiana'),
('403163', '123456', '4', '1.02', '1.02.058', 'B04', 'Anna Selviana'),
('021147', '123456', '4', '1.02', '1.02.058', 'B01', 'Andini Suci Aprilia'),
('021106', '123456', '4', '1.02', '1.02.058', 'B01', 'Heni Prasetyaningsih'),
('602099', '123456', '4', '1.02', '1.02.058', 'B01', 'Nurseti Handayani'),
('905254', '123456', '4', '1.02', '1.02.058', 'B04', 'Krisna Kurniawan Shihab'),
('804211', '123456', '4', '1.02', '1.02.058', 'B04', 'Maulvi Nazir'),
('608036', '123456', '4', '1.02', '1.02.058', 'B02', 'Muhamad Yusuf'),
('305039', '123456', '4', '1.02', '1.02.058', 'B04', 'Nova Dyah Wanditasari'),
('604013', '123456', '4', '1.02', '1.02.058', 'B04', 'Septi Kusuma Dewi'),
('601043', '123456', '4', '1.02', '1.02.058', 'B04', 'Masanih'),
('510010', '123456', '4', '1.02', '1.02.058', 'B04', 'Nuraini Hasanah'),
('604011', '123456', '4', '1.02', '1.02.058', 'B04', 'Efi Nofitasari'),
('802065', '123456', '4', '1.02', '1.02.058', 'B04', 'Widya Ariaty'),
('608012', '123456', '4', '1.02', '1.02.058', 'B04', 'Yesi Suherlani'),
('902244', '123456', '4', '1.02', '1.02.058', 'B04', 'Nabila Sri Ayu A Abdullah'),
('902243', '123456', '4', '1.02', '1.02.058', 'B04', 'Farikha Fadlika'),
('902242', '123456', '4', '1.02', '1.02.058', 'B04', 'Mega Nur Arif'),
('706189', '123456', '4', '1.02', '1.02.058', 'B04', 'Sidgi'),
('804213', '123456', '4', '1.02', '1.02.058', 'B04', 'Katarina Maria'),
('704116', '123456', '4', '1.02', '1.02.058', 'B04', 'Euis Sri Rahayu'),
('804216', '123456', '4', '1.02', '1.02.058', 'B04', 'Sandi Permana'),
('706171', '123456', '4', '1.02', '1.02.058', 'B04', 'Mirshad Adiresya Putra'),
('707174', '123456', '4', '1.02', '1.02.058', 'B04', 'Bayu Saputra'),
('704196', '123456', '4', '1.02', '1.02.058', 'B04', 'Marda Ardi Arini'),
('608066', '123456', '4', '1.02', '1.02.058', 'B04', 'Oktafiani Purba'),
('704195', '123456', '4', '1.02', '1.02.058', 'B04', 'Fitri Yanti'),
('707191', '123456', '4', '1.02', '1.02.058', 'B04', 'Diah Septiani'),
('805227', '123456', '4', '1.02', '1.02.058', 'B04', 'Rikza Anaupal Dahri'),
('605188', '123456', '4', '1.02', '1.02.058', 'B04', 'Lucinda Corry Fitria'),
('804210', '123456', '4', '1.02', '1.02.058', 'B04', 'Nelson Reynaldo Harahap'),
('711052', '123456', '4', '1.02', '1.02.058', 'B04', 'Nika Hendra Priyatna');

-- --------------------------------------------------------

--
-- Table structure for table `validasi`
--

CREATE TABLE `validasi` (
  `id_validasi` varchar(8) NOT NULL,
  `nip` varchar(20) NOT NULL,
  `nama` varchar(15) NOT NULL,
  `tanggal` date NOT NULL,
  `jabatan` int(30) NOT NULL,
  `n_skp` int(8) NOT NULL,
  `n_anggaran` int(8) NOT NULL,
  `n_prilaku` int(11) NOT NULL,
  `hasil` varchar(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `waktu_k`
--

CREATE TABLE `waktu_k` (
  `id_waktu_k` varchar(8) NOT NULL,
  `nip` varchar(30) NOT NULL,
  `sakit1` int(8) NOT NULL,
  `sakit2` int(8) NOT NULL,
  `alpha` int(8) NOT NULL,
  `telat` int(8) NOT NULL,
  `c_sakit_k` int(8) NOT NULL,
  `c_alasan_k` int(8) NOT NULL,
  `c_persalinan_k` int(8) NOT NULL,
  `c_besar_k` int(8) NOT NULL,
  `izin` int(8) NOT NULL,
  `izin_s` int(8) NOT NULL,
  `meninggal` int(8) NOT NULL,
  `tanggal` date NOT NULL,
  `t_waktu_k` int(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `waktu_kerja`
--

CREATE TABLE `waktu_kerja` (
  `id_waktu` varchar(8) NOT NULL,
  `tanggal` date NOT NULL,
  `hari` varchar(8) NOT NULL,
  `id_skpd` varchar(10) NOT NULL,
  `id_ukpd` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `waktu_kerja`
--

INSERT INTO `waktu_kerja` (`id_waktu`, `tanggal`, `hari`, `id_skpd`, `id_ukpd`) VALUES
('WKK00001', '2017-04-28', '18', '1.02', '1.02.058');

-- --------------------------------------------------------

--
-- Table structure for table `waktu_t`
--

CREATE TABLE `waktu_t` (
  `id_waktu_t` varchar(8) NOT NULL,
  `nip` varchar(30) NOT NULL,
  `c_sakit_t` int(8) NOT NULL,
  `c_alasan_t` int(8) NOT NULL,
  `c_tahunan_t` int(8) NOT NULL,
  `diklat` int(8) NOT NULL,
  `spd` int(8) NOT NULL,
  `haji` int(8) NOT NULL,
  `tanggal` date NOT NULL,
  `t_waktu_t` int(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `absensi`
--
ALTER TABLE `absensi`
  ADD PRIMARY KEY (`id_absensi`);

--
-- Indexes for table `bagian`
--
ALTER TABLE `bagian`
  ADD PRIMARY KEY (`id_bag`);

--
-- Indexes for table `disiplin`
--
ALTER TABLE `disiplin`
  ADD PRIMARY KEY (`id_disiplin`);

--
-- Indexes for table `h_jabatan`
--
ALTER TABLE `h_jabatan`
  ADD PRIMARY KEY (`idh`);

--
-- Indexes for table `jabatan`
--
ALTER TABLE `jabatan`
  ADD PRIMARY KEY (`id_jab`);

--
-- Indexes for table `kinerja`
--
ALTER TABLE `kinerja`
  ADD PRIMARY KEY (`id_kinerja`);

--
-- Indexes for table `kompetensi`
--
ALTER TABLE `kompetensi`
  ADD PRIMARY KEY (`id_kompetensi`);

--
-- Indexes for table `kreatifitas`
--
ALTER TABLE `kreatifitas`
  ADD PRIMARY KEY (`id_kreatifitas`);

--
-- Indexes for table `k_jabatan`
--
ALTER TABLE `k_jabatan`
  ADD PRIMARY KEY (`idkjb`);

--
-- Indexes for table `pegawai`
--
ALTER TABLE `pegawai`
  ADD PRIMARY KEY (`nip`);

--
-- Indexes for table `pelatihan`
--
ALTER TABLE `pelatihan`
  ADD PRIMARY KEY (`id_pelatihan`);

--
-- Indexes for table `pencapaian`
--
ALTER TABLE `pencapaian`
  ADD PRIMARY KEY (`id_pencapaian`);

--
-- Indexes for table `pendidikan`
--
ALTER TABLE `pendidikan`
  ADD PRIMARY KEY (`idp`);

--
-- Indexes for table `pendidikan_t`
--
ALTER TABLE `pendidikan_t`
  ADD PRIMARY KEY (`id_pendidikan`);

--
-- Indexes for table `pengalaman_kerja`
--
ALTER TABLE `pengalaman_kerja`
  ADD PRIMARY KEY (`id_peker`);

--
-- Indexes for table `pengukuran`
--
ALTER TABLE `pengukuran`
  ADD PRIMARY KEY (`id_pengukuran`);

--
-- Indexes for table `penyerapan`
--
ALTER TABLE `penyerapan`
  ADD PRIMARY KEY (`id_penyerapan`);

--
-- Indexes for table `rumpun`
--
ALTER TABLE `rumpun`
  ADD PRIMARY KEY (`id_rumpun`);

--
-- Indexes for table `setting`
--
ALTER TABLE `setting`
  ADD PRIMARY KEY (`id_setting`);

--
-- Indexes for table `set_user`
--
ALTER TABLE `set_user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `skp`
--
ALTER TABLE `skp`
  ADD PRIMARY KEY (`kd_skp`);

--
-- Indexes for table `skpd`
--
ALTER TABLE `skpd`
  ADD PRIMARY KEY (`id_skpd`);

--
-- Indexes for table `skptahunan`
--
ALTER TABLE `skptahunan`
  ADD PRIMARY KEY (`id_skptahunan`);

--
-- Indexes for table `status`
--
ALTER TABLE `status`
  ADD PRIMARY KEY (`id_status`);

--
-- Indexes for table `ukpd`
--
ALTER TABLE `ukpd`
  ADD PRIMARY KEY (`id_ukpd`);

--
-- Indexes for table `user_id`
--
ALTER TABLE `user_id`
  ADD PRIMARY KEY (`userid`);

--
-- Indexes for table `validasi`
--
ALTER TABLE `validasi`
  ADD PRIMARY KEY (`id_validasi`);

--
-- Indexes for table `waktu_k`
--
ALTER TABLE `waktu_k`
  ADD PRIMARY KEY (`id_waktu_k`);

--
-- Indexes for table `waktu_kerja`
--
ALTER TABLE `waktu_kerja`
  ADD PRIMARY KEY (`id_waktu`);

--
-- Indexes for table `waktu_t`
--
ALTER TABLE `waktu_t`
  ADD PRIMARY KEY (`id_waktu_t`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `absensi`
--
ALTER TABLE `absensi`
  MODIFY `id_absensi` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=462;

--
-- AUTO_INCREMENT for table `h_jabatan`
--
ALTER TABLE `h_jabatan`
  MODIFY `idh` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `pelatihan`
--
ALTER TABLE `pelatihan`
  MODIFY `id_pelatihan` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `pendidikan`
--
ALTER TABLE `pendidikan`
  MODIFY `idp` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=304;

--
-- AUTO_INCREMENT for table `pengalaman_kerja`
--
ALTER TABLE `pengalaman_kerja`
  MODIFY `id_peker` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=111;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
