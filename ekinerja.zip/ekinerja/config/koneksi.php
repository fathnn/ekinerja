<? 
error_reporting(0);
 $dbhost="localhost";
 $dbuser="puskesm5_ekin";
 $dbpass="ekin123!@#";
 $dbname="puskesm5_ekin";
 $koneksi=mysql_connect($dbhost,$dbuser,$dbpass) or die ("Gagal Koneksi");
 mysql_select_db($dbname,$koneksi);
?>