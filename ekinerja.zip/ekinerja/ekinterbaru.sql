-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 15, 2020 at 05:39 AM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ekinerjapasming`
--

-- --------------------------------------------------------

--
-- Table structure for table `absensi`
--

CREATE TABLE `absensi` (
  `id_absensi` int(10) NOT NULL,
  `nip` varchar(30) NOT NULL,
  `tanggal_absen` date NOT NULL,
  `jam_masuk` time NOT NULL,
  `jam_keluar` time NOT NULL,
  `status_masuk` enum('Y','N') NOT NULL DEFAULT 'N',
  `status_keluar` enum('Y','N') NOT NULL DEFAULT 'N',
  `ket` char(2) NOT NULL DEFAULT 'NA',
  `terlambat` enum('Y','N') NOT NULL DEFAULT 'N'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `bagian`
--

CREATE TABLE `bagian` (
  `id_bag` varchar(4) NOT NULL,
  `n_bag` varchar(25) NOT NULL,
  `id_skpd` varchar(10) NOT NULL,
  `id_ukpd` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bagian`
--

INSERT INTO `bagian` (`id_bag`, `n_bag`, `id_skpd`, `id_ukpd`) VALUES
('B01', 'Kec Pasar Minggu', '1.02', '1.02.058'),
('B02', 'Kel Pasar Minggu 1', '1.02', '1.02.058'),
('B03', 'Kel Pejaten Barat 1', '1.02', '1.02.058'),
('B04', 'Kel Pejaten Barat 2', '1.02', '1.02.058'),
('B05', 'Kel Pejaten Barat 3', '1.02', '1.02.058'),
('B06', 'Kel Pejaten Timur', '1.02', '1.02.058'),
('B07', 'Kel Cilandak Timur', '1.02', '1.02.058'),
('B08', 'Kel Kebagusan', '1.02', '1.02.058'),
('B09', 'Kel Jati Padang', '1.02', '1.02.058'),
('B10', 'Kel Ragunan', '1.02', '1.02.058'),
('B11', 'ukm', '1.02', '1.02.058'),
('B12', 'ukp', '1.02', '1.02.058');

-- --------------------------------------------------------

--
-- Table structure for table `disiplin`
--

CREATE TABLE `disiplin` (
  `id_disiplin` varchar(8) NOT NULL,
  `nip` varchar(30) NOT NULL,
  `tanggal` date NOT NULL,
  `k_diri` int(8) NOT NULL,
  `k_penampilan` int(8) NOT NULL,
  `k_seragam` int(8) NOT NULL,
  `k_alat` int(8) NOT NULL,
  `k_ruangan` int(8) NOT NULL,
  `k_sarana` int(8) NOT NULL,
  `point` int(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `h_jabatan`
--

CREATE TABLE `h_jabatan` (
  `idh` int(11) NOT NULL,
  `idkjb` varchar(4) NOT NULL,
  `jab_old` varchar(20) NOT NULL,
  `tgl_ajb` date NOT NULL,
  `jabatan_baru` varchar(20) NOT NULL,
  `tgl_kjb` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jabatan`
--

CREATE TABLE `jabatan` (
  `id_jab` varchar(4) NOT NULL,
  `id_skpd` varchar(10) NOT NULL,
  `id_ukpd` varchar(10) NOT NULL,
  `n_jab` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jabatan`
--

INSERT INTO `jabatan` (`id_jab`, `id_skpd`, `id_ukpd`, `n_jab`) VALUES
('J01', '1.02', '1.02.058', 'ADMINISTRASI UMUM'),
('J02', '1.02', '1.02.058', 'ADM BPJS'),
('J03', '1.02', '1.02.058', 'ADM KASIR'),
('J04', '1.02', '1.02.058', 'ADM LOKET'),
('J05', '1.02', '1.02.058', 'ADM PENGADAAN'),
('J06', '1.02', '1.02.058', 'ADM SURAT & UMUM'),
('J07', '1.02', '1.02.058', 'ADM YANMED'),
('J08', '1.02', '1.02.058', 'ADM. JANGMED'),
('J09', '1.02', '1.02.058', 'ADM. KEPERAWATAN'),
('J10', '1.02', '1.02.058', 'AKUNTING'),
('J11', '1.02', '1.02.058', 'ANALIS LAB'),
('J12', '1.02', '1.02.058', 'APOTEKER'),
('J13', '1.02', '1.02.058', 'ASS APOTEKER'),
('J14', '1.02', '1.02.058', 'BIDAN'),
('J15', '1.02', '1.02.058', 'BIDAN RANAP'),
('J16', '1.02', '1.02.058', 'BIDAN VK'),
('J17', '1.02', '1.02.058', 'DIKLAT & PENGEMBANGA'),
('J18', '1.02', '1.02.058', 'DOKTER'),
('J19', '1.02', '1.02.058', 'DOKTER GIGI'),
('J20', '1.02', '1.02.058', 'FISIOTERAPI'),
('J21', '1.02', '1.02.058', 'HUMAS & PEMASARAN'),
('J22', '1.02', '1.02.058', 'IPSRS'),
('J23', '1.02', '1.02.058', 'IT'),
('J24', '1.02', '1.02.058', 'K3'),
('J25', '1.02', '1.02.058', 'KA. SATPEL'),
('J26', '1.02', '1.02.058', 'KEPEGAWAIAN'),
('J27', '1.02', '1.02.058', 'NUTRISIONIS'),
('J28', '1.02', '1.02.058', 'P. JAWAB/KARU'),
('J29', '1.02', '1.02.058', 'P. PIUTANG'),
('J30', '1.02', '1.02.058', 'PENGEMUDI'),
('J31', '1.02', '1.02.058', 'PERAWAT'),
('J32', '1.02', '1.02.058', 'PERAWAT GIGI'),
('J33', '1.02', '1.02.058', 'PERAWAT HCU'),
('J34', '1.02', '1.02.058', 'PERAWAT IGD'),
('J35', '1.02', '1.02.058', 'PERAWAT OK'),
('J36', '1.02', '1.02.058', 'PERAWAT POLI SPES'),
('J37', '1.02', '1.02.058', 'PERAWAT RANAP ANAK'),
('J38', '1.02', '1.02.058', 'PERAWAT RANAP DEWASA'),
('J39', '1.02', '1.02.058', 'PEREKAM MEDIS'),
('J40', '1.02', '1.02.058', 'PERENCANAAN'),
('J41', '1.02', '1.02.058', 'RADIOGRAFER'),
('J42', '1.02', '1.02.058', 'REFRAKSIONIS'),
('J43', '1.02', '1.02.058', 'SANITARIAN'),
('J44', '1.02', '1.02.058', 'EPIDEMIOLOGI'),
('J45', '1.02', '1.02.058', 'VERIFIKATOR');

-- --------------------------------------------------------

--
-- Table structure for table `kinerja`
--

CREATE TABLE `kinerja` (
  `id_kinerja` int(8) NOT NULL,
  `nip` varchar(30) NOT NULL,
  `kd_skp` varchar(160) NOT NULL DEFAULT 'TAMBAHAN',
  `uraian` text NOT NULL,
  `jam_mulai` time NOT NULL,
  `jam_akhir` time NOT NULL,
  `jumlah` int(8) NOT NULL,
  `waktu_e` int(8) NOT NULL,
  `tanggal` date NOT NULL,
  `keterangan` varchar(25) NOT NULL,
  `point` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `kompetensi`
--

CREATE TABLE `kompetensi` (
  `id_kompetensi` varchar(8) NOT NULL,
  `nip` varchar(30) NOT NULL,
  `tanggal` date NOT NULL,
  `menganalisa1` int(8) NOT NULL,
  `menganalisa2` int(8) NOT NULL,
  `komunikasi1` int(8) NOT NULL,
  `komunikasi2` int(8) NOT NULL,
  `kerjasama1` int(8) NOT NULL,
  `kerjasama2` int(8) NOT NULL,
  `kecerdasan1` int(8) NOT NULL,
  `kecerdasan2` int(8) NOT NULL,
  `kecerdasan3` int(8) NOT NULL,
  `fokus1` int(8) NOT NULL,
  `fokus2` int(8) NOT NULL,
  `fokus3` int(8) NOT NULL,
  `tanggung1` int(8) NOT NULL,
  `tanggung2` int(8) NOT NULL,
  `tanggung3` int(8) NOT NULL,
  `tanggung4` int(8) NOT NULL,
  `orientasi_k1` int(8) NOT NULL,
  `orientasi_k2` int(8) NOT NULL,
  `inisiatif1` int(8) NOT NULL,
  `inisiatif2` int(8) NOT NULL,
  `disiplin1` int(8) NOT NULL,
  `disiplin2` int(8) NOT NULL,
  `disiplin3` int(8) NOT NULL,
  `orientasi_p1` int(8) NOT NULL,
  `orientasi_p2` int(8) NOT NULL,
  `orientasi_p3` int(8) NOT NULL,
  `point` varchar(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `kreatifitas`
--

CREATE TABLE `kreatifitas` (
  `id_kreatifitas` varchar(8) NOT NULL,
  `nip` varchar(30) NOT NULL,
  `tanggal` date NOT NULL,
  `wm_k` time NOT NULL,
  `wa_k` time NOT NULL,
  `jumlah` int(8) NOT NULL,
  `kreatifitas` varchar(60) NOT NULL,
  `uraian` varchar(150) NOT NULL,
  `keterangan` varchar(25) NOT NULL,
  `point` int(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `k_jabatan`
--

CREATE TABLE `k_jabatan` (
  `idkjb` varchar(4) NOT NULL,
  `nip` varchar(20) NOT NULL,
  `masa_kerja` int(10) NOT NULL,
  `keterangan` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `pegawai`
--

CREATE TABLE `pegawai` (
  `nip` varchar(30) NOT NULL,
  `nama` varchar(40) NOT NULL,
  `tmpt_lahir` varchar(200) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `jenis_kelamin` enum('L','P') NOT NULL,
  `npwp` varchar(25) NOT NULL,
  `norek` varchar(25) NOT NULL,
  `id_status` varchar(15) NOT NULL,
  `status` varchar(8) NOT NULL,
  `id_pendidikan` varchar(8) NOT NULL,
  `alamat` varchar(200) NOT NULL,
  `tgl_masuk` date NOT NULL,
  `id_rumpun` varchar(8) NOT NULL,
  `id_bag` varchar(4) NOT NULL,
  `id_jab` varchar(4) NOT NULL,
  `id_skpd` varchar(10) NOT NULL,
  `id_ukpd` varchar(10) NOT NULL,
  `bpjsks` varchar(8) NOT NULL,
  `bpjsjkk` varchar(8) NOT NULL,
  `bpjsijht` varchar(8) NOT NULL,
  `bpjsjp` varchar(8) NOT NULL,
  `kasatpel` varchar(30) NOT NULL,
  `kasie` varchar(20) NOT NULL,
  `foto` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pegawai`
--

INSERT INTO `pegawai` (`nip`, `nama`, `tmpt_lahir`, `tgl_lahir`, `jenis_kelamin`, `npwp`, `norek`, `id_status`, `status`, `id_pendidikan`, `alamat`, `tgl_masuk`, `id_rumpun`, `id_bag`, `id_jab`, `id_skpd`, `id_ukpd`, `bpjsks`, `bpjsjkk`, `bpjsijht`, `bpjsjp`, `kasatpel`, `kasie`, `foto`) VALUES
('8112026\r\n', 'FAT HAN FARASHY', 'Jakarta', '1992-10-15', 'L', '', '', 'K-0', 'NON PNS', 'PND3', 'Kp. sugutamu RT 07/ RW 022 Kel. Mekarjaya Kec. sukmajaya - Depok', '2019-08-01', 'Rum10', 'B01', 'J23', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8112001\r\n', 'ABDUL GANI', 'Bandung', '1983-01-24', 'L', '', '', 'K-2', 'NON PNS', 'PND5', 'Jl. Sirsak Rt. 004 Rw. 006 Jagakarsa', '2011-09-01', 'Rum10', 'B01', 'J04', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8112002\r\n', 'ABDURAHMAN H A WAHAB', 'Bima', '1972-03-07', 'L', '', '', 'K-2', 'NON PNS', 'PND3', 'Jl.Kebagusan Gg.Mawar Rt.008/005 Kel.Kebagusan Kec.Pasar Minggu Jakarta Selatan', '2009-02-01', 'Rum10', 'B01', 'J04', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8106001\r\n', 'ADE MARDIANA', 'Jakarta', '1984-03-17', 'P', '', '', 'K-2', 'NON PNS', 'PND4', 'Jl Durian RT 004 RW 004 Kel Jagakarsa Kec Jagakarsa Jakarta Selatan DKI JAKARTA', '2015-01-02', 'Rum08', 'B01', 'J14', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8110001\r\n', 'AISYAH LEGITA', 'Sukadana', '1993-03-23', 'P', '', '', 'TK-0', 'NON PNS', 'PND4', 'Jl. Jati padang Utara rt 03/02 Jati padang, kecamatan Pasar Minggu', '2017-01-02', 'Rum06', 'B08', 'J27', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'kebagusan', 'katu', ''),
('8104001\r\n', 'AJENG DIAN TOPANI', 'kuningan', '1985-04-02', 'P', '', '', 'K-0', 'NON PNS', 'PND4', 'asrama yonkav 7 sersus rt 005/006, kelurahan baru.kecamatan pasar rebo.jakarta timur', '2016-04-01', 'Rum06', 'B01', 'J09', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8106002\r\n	', 'AMALIA JAMIL', 'Jakarta', '1994-04-04', 'P', '', '', 'K-0', 'NON PNS', 'PND4', 'jl. swadaya 1 no 13 rt 008 rw 010 kel. pejaten timur. kec. pasar minggu', '2017-04-03', 'Rum08', 'B07', 'J14', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'cilandaktimur', 'katu', ''),
('8104038\r\n', 'ANDI PRADANA KUSUMA AJI', 'Semuli Raya', '1991-11-23', 'L', '', '', 'K-0', 'NON PNS', 'PND4', 'sumber arum rt 01 rw 14 way lunik, abung selatan, lampung utara', '2019-03-01', 'Rum06', 'B01', 'J31', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8108006\r\n	', 'ANISA DEANIRA PUTRI', 'Bogor', '1996-01-21', 'P', '', '', 'TK-0', 'NON PNS', 'PND4', 'jl.danau tambora V no.80 RT.06/06 kel.abadijaya,kec.sukmajaya,depok,jawa barat', '2019-08-01', 'Rum06', 'B01', 'J11', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8101001\r\n', 'ANNA SAFITRI ARIEF FIANTI', 'Bogor', '1983-09-29', 'P', '', '', 'K-2', 'NON PNS', 'PND2', 'jl. kol. pol. pranoto rt 3 rw 6 tugu cimanggis,  depok', '2017-04-03', 'Rum04', 'B06', 'J19', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'pejatentimur', 'katu', ''),
('8104002\r\n', 'ARIF WIBOWO', 'Jakarta', '1992-07-18', 'L', '', '', 'K-1', 'NON PNS', 'PND4', 'jl. agung raya 2 Rt 006/004 no:30 lenteng agung jakarta selatan kode pos 12610', '2016-04-01', 'Rum08', 'B01', 'J34', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8107001\r\n', 'AYU PUSPITA SARI', 'Jakarta', '1992-10-16', 'P', '', '', 'K-1', 'NON PNS', 'PND4', 'Jln. Mampang Prapatan 8 RT. 003/001 Kel. Tegal Parang Kec. Mampang Prapatan', '2014-06-02', 'Rum08', 'B09', 'J13', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'jatipadang', 'katu', ''),
('8117001\r\n', 'AYU WANDIRA', 'Kumanis', '1992-09-29', 'P', '', '', 'K-0', 'NON PNS', 'PND4', 'Jln. Genteng Ijo Rt 006 / 007 Kel. Karet Kuningan Kec. Setiabudi, Jakarta Selatan', '2019-02-18', 'Rum06', 'B01', 'J39', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8107002\r\n', 'BERLY ANFRILIA', 'Depok', '1994-10-09', 'P', '', '', 'K-1', 'NON PNS', 'PND4', 'Jalan Masjid Lio Rt.003/020 No.62 Kel.Depok Kec.Pancoran Mas 16431', '2014-04-01', 'Rum06', 'B10', 'J13', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'ragunan', 'katu', ''),
('8112003\r\n', 'BOEDI PRADIPAJIWA', 'Jakarta', '1982-10-21', 'L', '', '', 'TK-0', 'NON PNS', 'PND3', 'Jl Kerinci XI no 12 kebayoran baru 12120  ', '2016-01-04', 'Rum10', 'B07', 'J06', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'cilandaktimur', 'katu', ''),
('8102001\r\n', 'CHYNDHIA HERADHINA ISKANDAR', 'Jakarta', '1990-04-14', 'P', '', '', 'K-2', 'NON PNS', 'PND2', 'jalan dukuh 3 no.2 rt01/05 kel.dukuh kec.kramat jati jakarta timur', '2016-04-01', 'Rum04', 'B09', 'J18', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'jatipadang', 'katu', ''),
('8106004\r\n', 'CICI AMALIA', 'Tanjung Gading', '1988-10-01', 'P', '', '', 'TK-2', 'NON PNS', 'PND4', 'Kebagusan Wates No.14 RT/RW 004/004 Kel. Kebagusan Kec. Pasar Minggu Jakarta Selatan', '2016-01-02', 'Rum08', 'B07', 'J14', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'cilandaktimur', 'katu', ''),
('8106005\r\n', 'CYNTIA KUSUMA DEWI', 'Jakarta', '1993-08-04', 'P', '', '', 'TK-0', 'NON PNS', 'PND4', 'Jl. Swadaya I No.20 RT 002 RW 011 Kelurahan Cijantung. Kecamatan Pasar Rebo', '2016-02-01', 'Rum08', 'B07', 'J14', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'cilandaktimur', 'katu', ''),
('8106006\r\n	', 'DALILA RIFAIE', 'Bandar Lampung', '1993-10-31', 'P', '', '', 'TK-0', 'NON PNS', 'PND4', 'Jl. Lontar No. 40A RT 10 RW 03, Lenteng Agung, Jagakarsa, Jakarta Selatan', '2016-02-01', 'Rum08', 'B01', 'J14', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8112004\r\n', 'DAUD YUSUF', 'Jakarta', '1980-05-02', 'L', '', '', 'K-2', 'NON PNS', 'PND5', 'Jl. H Dul No. 57 Rt. 003 Rw. 006 Cipayung - Depok', '2016-01-02', 'Rum10', 'B01', 'J04', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8106007\r\n', 'DEBORA BANJAR NAHOR', 'Sipituhuta', '1988-11-10', 'P', '', '', 'K-1', 'NON PNS', 'PND3', 'Jalan Kelapa Puan RT 10/03 JAGAKARSA', '2019-01-02', 'Rum10', 'B01', 'J14', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8112005\r\n', 'DEDY ANTONIUS SINAGA', 'Simpang Haranggaol', '1990-05-21', 'L', '', '', 'K-1', 'NON PNS', 'PND4', 'JL. KELAPA HIJAU III 08/03, JAGAKARSA', '2016-02-08', 'Rum10', 'B01', 'J23', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8106008\r\n', 'DENI FEBRIANI', 'Inderapura', '1989-02-21', 'P', '', '', 'K-0', 'NON PNS', 'PND4', 'Jl. Masjid Al Fajri No. 14 AX RT 12 RW 01 Kel. Pejaten Barat Kec. Pasar Minggu Jaksel 12510.', '2016-01-02', 'Rum06', 'B01', 'J14', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8111001\r\n', 'DESI FAJAR LESTARI', 'Bogor', '1993-12-25', 'P', '', '', 'K-0', 'NON PNS', 'PND4', 'Jl. M. Kahfi II NO. 66 RT 07 RW 03 CIPEDAK, JAGAKARSA', '2016-04-01', 'Rum06', 'B04', 'J43', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'pejatenbarat2', 'katu', ''),
('8106009\r\n', 'DESI LIANA', 'Jakarta', '1991-12-14', 'P', '', '', 'K-1', 'NON PNS', 'PND4', 'JL. PRAMUKA JATI NO. C51 KEL. PASEBANAN KEC.SENEN ', '2016-02-01', 'Rum08', 'B01', 'J14', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8106010\r\n', 'DESIANA SANTRI', 'Jakarta', '1994-12-10', 'P', '', '', 'TK-0', 'NON PNS', 'PND4', 'Jl. Gotong Royong Rt. 07/08 No. 5A Kel. Kapuk Kec. Cengkareng Jakarta Barat 11720 Indonesia', '2018-04-03', 'Rum06', 'B02', 'J14', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'pasarminggu', 'katu', ''),
('8104003\r\n', 'DEWI JAYANTI', 'Jakarta', '1992-08-21', 'P', '', '', 'K-1', 'NON PNS', 'PND4', 'jl. kp. kalibata rt 001/008 Kel. srengseng sawah kec. jagakarsa', '2018-04-03', 'Rum06', 'B01', 'J34', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8106040\r\n', 'DIAN KURNIASIH', 'Kulon Progo', '1993-03-23', 'P', '', '', 'TK-0', 'NON PNS', 'PND4', 'Beteng, Bligo, Ngluwar, Magelang, Jawa Tengah', '2016-02-01', 'Rum06', 'B09', 'J14', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'jatipadang', 'katu', ''),
('8106011\r\n', 'DIAN PUSPA LESTARI MANALU', 'Tarutung', '1993-09-28', 'P', '', '', 'K-0', 'NON PNS', 'PND4', 'Jalan Raya Centex RT 010 RW 03 No. 60 Kel. Ciracas Kec. Ciracas, Jakarta Timur. 13740', '2016-03-01', 'Rum08', 'B01', 'J14', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8104004\r\n', 'DIAN SAPUTRA', 'Jakarta', '1990-04-15', 'L', '', '', 'TK-0', 'NON PNS', 'PND4', 'Jl. Assakinah II No.48 RT006 RW002 Kel. Kebagusan, Kec. Pasar Minggu', '2017-07-03', 'Rum08', 'B01', 'J34', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8104005\r\n', 'DINA HELVINA', 'Air molek', '1980-12-15', 'P', '', '', 'K-0', 'NON PNS', 'PND2', 'Jl.Abuserin IV no.28 rt 006 rw 006 kel.gandaria selatan kec. Cilandak', '2016-04-01', 'Rum05', 'B01', 'J31', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8112006\r\n', 'DINI AULIA HAYATI', 'Jakarta', '1992-01-05', 'P', '', '', 'K-1', 'NON PNS', 'PND4', 'Kp. Cipedak RT 1/9 No. 24 Kel. Srengseng Sawah,Jagakarsa', '2013-04-01', 'Rum10', 'B10', 'J04', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'ragunan', 'katu', ''),
('8102012\r\n', 'DR SHADRATUL KHAIRAH', 'Aceh Besar', '1986-01-26', 'P', '', '', 'K-2', 'NON PNS', 'PND2', 'Jl. gurame 1 no. 1 kel. karawaci kec. karawaci baru tangerang banten', '2016-04-01', 'Rum04', 'B10', 'J18', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'ragunan', 'katu', ''),
('8102002\r\n', 'DR. DITA INDRASWARI', 'Jakarta', '1980-03-21', 'P', '', '', 'K-1', 'NON PNS', 'PND2', 'Srengseng Sawah RT 012 RW 009 NO.37 Jagakarsa, jakarta selatan', '2012-06-01', 'Rum04', 'B01', 'J18', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8104006\r\n', 'DWI AHMAD ROMADHON', 'Jakarta', '1991-04-04', 'L', '', '', 'K-1', 'NON PNS', 'PND4', 'Jln.Moch Kahfi 1 gg.Nangka RT.003 RW.006, Jagakarsa Jakarta selatan', '2017-10-03', 'Rum08', 'B01', 'J31', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8106012\r\n', 'DWI NURYANTI HANDAYANI', 'Jakarta', '1991-12-21', 'P', '', '', 'TK-0', 'NON PNS', 'PND2', 'asrama dumtruck 6 RT 005/015 NO 46 kel srengseng sawah kec Jagakarsa', '2017-04-03', 'Rum08', 'B01', 'J14', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8108001\r\n', 'DYAH ENI SUSANTI', 'Jakarta', '1993-05-25', 'P', '', '', 'K-0', 'NON PNS', 'PND4', 'Jl.Blok Ringin No.73 RT009/RW03, Kel.Cibubur, Kec.Ciracas, Jakarta Timur', '2016-09-02', 'Rum06', 'B01', 'J11', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8103001\r\n', 'EFRIYAN', 'Pasar Talo', '1983-04-18', 'L', '', '', 'K-2', 'NON PNS', 'PND2', 'Kalibata Pulo RT 015 RW 005 Kelurahan Kalibata, Kecamatan Pancoran Jakarta Selatan', '2016-02-01', 'Rum05', 'B01', 'J12', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8104007\r\n', 'EKO EDI PURNOMO', 'Grobogan', '1991-06-22', 'L', '', '', 'K-0', 'NON PNS', 'PND4', 'Jl.rukun ujung RT 005 RW 005 kelurahan.pejaten Timur kecamatan pasar Minggu Jakarta Selatan', '2013-01-01', 'Rum08', 'B07', 'J31', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'cilandaktimur', 'katu', ''),
('8112007\r\n', 'EKO SETIAWAN', 'Cilacap', '1986-05-23', 'L', '', '', 'K-2', 'NON PNS', 'PND4', 'kp. pondok manggis RT 02 RW 03', '2013-04-01', 'Rum08', 'B01', 'J23', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8104008\r\n', 'ELIA SARI L TORUAN', 'Bengkulu', '1990-03-07', 'P', '', '', 'TK-0', 'NON PNS', 'PND2', 'Jl. Howitzer Raya No 43 RT 10 RW 02 Kel. Sumur Batu, Kec. Pasar Miggu. Jakarta Pusat, DKI Jakarta', '2016-04-01', 'Rum05', 'B01', 'J31', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8110002\r\n', 'ELLIANA RACHMAWATI', 'Jakarta', '1990-03-30', 'P', '', '', 'K-1', 'NON PNS', 'PND4', 'JL. K H Dewantoro Komplek Depkes blok D1 no 16 RT 04 RW0 11, kel Sawah kec Ciputat kota Tangerang Selatan', '2018-01-02', 'Rum06', 'B02', 'J27', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'pasarminggu', 'katu', ''),
('8107003\r\n', 'ELVIANA SARY', 'Jakarta', '1989-03-17', 'P', '', '', 'K-1', 'NON PNS', 'PND5', 'Raffa residence 2, Pasir Putih - Sawangan - Depok', '2012-04-30', 'Rum08', 'B07', 'J13', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'cilandaktimur', 'katu', ''),
('8112008\r\n', 'ENDAH WIDIANINGSIH', 'Jakarta', '1991-01-02', 'P', '', '', 'K-0', 'NON PNS', 'PND5', 'joko 6 Rt 12 Rw 04 no 47 lenteng agung jagakarsa', '2010-05-03', 'Rum10', 'B01', 'J01', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8106013\r\n', 'ENDANG SULASTRI', 'Jakarta', '1989-03-18', 'P', '', '', 'K-1', 'NON PNS', 'PND4', 'Kp.pisangan rt 01 rw 04 no 6a ragunan, pasar minggu,jakarta selatan', '2012-09-24', 'Rum08', 'B01', 'J14', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8104009\r\n', 'ENDIS PERJUANGAN LOMBAN TORUAN', 'Jakarta', '1990-08-02', 'P', '', '', 'K-2', 'NON PNS', 'PND4', 'Jln Musyawarah No 03 rt 02 Rw 01 Raguanan Jakarta Selatan', '2016-02-01', 'Rum08', 'B01', 'J31', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8106014\r\n', 'ERLYANITHA MADUMARIA PURBA', 'Jakarta', '1987-07-23', 'P', '', '', 'K-0', 'NON PNS', 'PND4', 'Jl. Petamburan III no.12 Rt 005/004', '2014-02-01', 'Rum08', 'B08', 'J14', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'kebagusan', 'katu', ''),
('8102003\r\n', 'EVI RATMAYANA', 'lhokseumawe', '1981-06-11', 'P', '', '', 'K-2', 'NON PNS', 'PND2', 'Jln. Jangkrik, Komplek Rumah 24, Kav A2, Kelurahan Ciganjur, Kecamatan Jagakarsa. Jakarta Selatan', '2013-04-01', 'Rum04', 'B01', 'J18', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8102004\r\n', 'FARAH AMSIA KHODIJAH', 'Sukabumi', '1987-04-16', 'P', '', '', 'TK-0', 'NON PNS', 'PND2', 'Komplek Mabad II no.64, Rt.003, Rw.011, kel. Srengseng Sawah, Kec. Jagakarsa, Jakarta-Selatan 12640', '2016-02-01', 'Rum04', 'B01', 'J18', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8104011\r\n', 'FATIA HURIATI', 'Jakarta', '1991-02-18', 'P', '', '', 'TK-0', 'NON PNS', 'PND2', 'Jl. Menteng Wadas 1 RT 09 Rw 10 Kel Pasar Manggis Kec Setia Budi', '2016-02-01', 'Rum05', 'B03', 'J31', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'pejatenbarat1', 'katu', ''),
('8104012\r\n', 'FEBRINA LARASSATI', 'Jakarta', '1994-03-17', 'P', '', '', 'TK-0', 'NON PNS', 'PND4', 'Jl. Kalipasir RT 14 RW 1 Kelurahan Cikini Kecamatan Menteng, Jakarta Pusat', '2016-04-01', 'Rum06', 'B01', 'J31', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8104013\r\n', 'FENTY ARYANI', 'Jakarta', '1989-02-27', 'P', '', '', 'K-2', 'NON PNS', 'PND4', 'Kp Sidamukti No.20 Rt01/04 Kel. Sukamaju Kec.Cilodong Depok', '2016-04-01', 'Rum06', 'B01', 'J31', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8112009\r\n', 'FITRAH MAULANA APRIYADI', 'Jakarta', '1990-04-23', 'L', '', '', 'K-0', 'NON PNS', 'PND4', 'Jln Menteng Granit RT 015, RW 07 Kel Pasar Manggis Kec Setia Budi', '2013-05-01', 'Rum07', 'B01', 'J40', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'pejatenbarat2', 'katu', ''),
('8102005\r\n', 'FITRI ANDAM DEWI', 'Bogor', '1990-12-20', 'P', '', '', 'K-1', 'NON PNS', 'PND2', 'Perumahan bella casa, depok', '2016-02-01', 'Rum04', 'B01', 'J18', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'pejatenbarat1', 'katu', ''),
('8106015\r\n', 'FITRI APRIYANTI', 'Jakarta', '1992-04-06', 'P', '', '', 'K-0', 'NON PNS', 'PND4', 'jl utama no.53 RT03/15 kel.srengseng sawah kec.jagakarsa, jakarta selatan', '2016-02-01', 'Rum06', 'B01', 'J14', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8112010\r\n', 'FITRILIA YANANDA', 'Jakarta', '1994-09-01', 'P', '', '', 'K-0', 'NON PNS', 'PND3', 'Jalan Dipo Baru KRL RT05/04 No. 17, Kel. Ratu Jaya, Kec. Cipayung', '2016-01-06', 'Rum10', 'B09', 'J04', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'jatipadang', 'katu', ''),
('8106017\r\n', 'FITRIYATI AGUSTIN MORRY', 'Depok', '1995-08-23', 'P', '', '', 'K-1', 'NON PNS', 'PND4', 'kp pengarengan Rt.06 Rw.06 kel.Jatinegara kec. cakung', '2017-04-03', 'Rum08', 'B01', 'J14', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8108005\r\n', 'GILANG EKA PERSADA', 'Bandung', '1995-03-13', 'L', '', '', 'TK-0', 'NON PNS', 'PND4', 'Jl. Buaran 1 No.19 RT.005 RW.012 Kel. Klender Kec. Duren Sawit - Jakarta Timur', '2019-08-01', 'Rum06', 'B01', 'J11', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8112011\r\n', 'HASAN ALBANA', 'Jakarta', '1985-02-24', 'L', '', '', 'K-0', 'NON PNS', 'PND3', 'Jl. Raya Bogor Rt 014/011 No.59 Kramatjati - Jakarta Timur', '2012-02-01', 'Rum08', 'B01', 'J10', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8112012\r\n', 'HENDRA', 'Jakarta', '1980-08-01', 'L', '', '', 'K-2', 'NON PNS', 'PND5', 'jl.kebagusan raya rt006 rw007 kel.kebagusan kec.pasarminggu', '2016-01-02', 'Rum10', 'B01', 'J04', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8112013\r\n', 'HERMAWAN', 'Jakarta', '1978-07-19', 'L', '', '', 'K-2', 'NON PNS', 'PND5', 'Jl. Gotong Royong No. 14 Rt. 007 Rw. 001 Kel. Ragunan Kec. Pasar Minggu', '2009-07-01', 'Rum10', 'B01', 'J04', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8104036\r\n', 'HERMAYANI PRATIWI', 'Serang', '1997-05-08', 'P', '', '', 'TK-0', 'NON PNS', 'PND4', 'Jl. Masjid No 43 B Kel. Lenteng Agung Kec. Jagakarsa Jaksel ', '2019-02-18', 'Rum08', 'B04', 'J31', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'pejatenbarat2', 'katu', ''),
('8106018\r\n', 'HESTI YUNITA', 'Jakarta', '1986-06-14', 'P', '', '', 'K-2', 'NON PNS', 'PND4', 'Jl. Poncol I No.13 Rt013 Rw007 Kel.Gandaria Selatan Kec.Cilandak', '2016-02-09', 'Rum06', 'B01', 'J14', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8106019\r\n', 'HUSNIYAH IDRUS', 'Mataram', '1988-01-22', 'P', '', '', 'K-1', 'NON PNS', 'PND4', 'Kp. utan Rt.010/Rw.008 No.43 Kel. Ragunan Kec. Pasar Minggu', '2012-02-01', 'Rum08', 'B01', 'J14', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8101002\r\n', 'IBRAMANTO WARGANEGARA', 'Medan', '1990-12-04', 'L', '', '', 'TK-0', 'NON PNS', 'PND2', 'Jl.Kemuning I. komp.Kemuning utama no.8.Pejaten Timur.Pasar Minggu.Jaksel', '2018-04-01', 'Rum04', 'B03', 'J19', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'pejatenbarat1', 'katu', ''),
('8106020\r\n', 'INA RAHAYU GINTING', 'Bogor', '1995-08-04', 'P', '', '', 'TK-0', 'NON PNS', 'PND4', 'Gang Jambu RT 003 RW 004 kel. Kedaung Kec. Sawangan Depok', '2017-07-03', 'Rum08', 'B07', 'J16', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'cilandaktimur', 'katu', ''),
('8104015\r\n', 'INDRI TIARA FEBRIYANTI', 'Jakarta', '1994-02-13', 'P', '', '', 'K-1', 'NON PNS', 'PND4', 'kampung kramat jl. olahraga 1 rt 003/005 kel. cililitan kecamatan kramat jati jakarta timur', '2016-04-01', 'Rum06', 'B01', 'J31', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8112014\r\n', 'IRAWAN WIBOWO', 'Jakarta', '1986-07-25', 'L', '', '', 'K-1', 'NON PNS', 'PND4', 'Jl. Kebagusan Wates Rt 03 Rw 04 No 90 Kel. Kebagusan Kec. Pasar Minggu', '2013-03-01', 'Rum10', 'B08', 'J01', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'kebagusan', 'katu', ''),
('8111002\r\n', 'IRENE DWI PUTRI', 'Bekasi', '1993-04-15', 'P', '', '', 'TK-0', 'NON PNS', 'PND4', 'perumahan Bekasi griya asri 2 blok e 3 no 26 jalan Nusantara 2 RT 03 RW 027 tambun selatan bekasi', '2017-08-12', 'Rum08', 'B07', 'J43', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'cilandaktimur', 'katu', ''),
('8112015\r\n', 'IRRNY AVIYANTI S', 'Jakarta', '1980-05-24', 'P', '', '', 'K-2', 'NON PNS', 'PND4', 'Jl. Kalisari No. 18 Rt 001 Rw 01 Kel. Kalisari, Kec. Pasar Rebo Jakarta Timur 13790', '2010-06-22', 'Rum10', 'B01', 'J01', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8106021\r\n', 'ISHARYANI MARCELLA . A', 'Jakarta', '1992-03-14', 'P', '', '', 'K-1', 'NON PNS', 'PND4', 'Jl. Gotong Royong No. 12 Rt 006/Rw 001, Kel. Baru, Kec. Pasar Rebo, Jakarta Timur, 13780', '2013-11-06', 'Rum08', 'B07', 'J14', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'cilandaktimur', 'katu', ''),
('8107004\r\n', 'ISMAIL SALEH', 'Jakarta', '1983-08-23', 'L', '', '', 'K-1', 'NON PNS', 'PND4', 'jl. masa lembo Rt 005 Rw 004 Kel. Cijantung Kec. Pasar Rebo Jakarta Timur 13770', '2014-06-02', 'Rum08', 'B01', 'J13', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8106022\r\n', 'ISTIYANAH AYUNINGTIYAS', 'Jakarta', '1990-08-14', 'P', '', '', 'K-0', 'NON PNS', 'PND4', 'Jl.Rancho Indah Rt 02 Rw 02 Kel.Tanjung Barat Kec.Jagakarsa Jakartas Selatan 12530 ', '2017-04-03', 'Rum06', 'B07', 'J14', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'cilandaktimur', 'katu', ''),
('8112016\r\n', 'JANE ROULI MARYAN', 'Jakarta', '1995-01-04', 'P', '', '', 'K-0', 'NON PNS', 'PND5', 'Jl. Kelapa gading No. 19 Rt 007 Rw 002 Kel. Gandaria Selatan Kec. Cilandak', '2016-02-09', 'Rum10', 'B06', 'J04', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'pejatentimur', 'katu', ''),
('8106023\r\n', 'KHAIRUNNISANI', 'Jakarta', '1988-07-24', 'P', '', '', 'K-2', 'NON PNS', 'PND4', 'kp. srengseng sawah rt 001/019 kel. srengseng sawah kec. jagakarsa jakarta selatan', '2017-09-02', 'Rum08', 'B01', 'J14', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8102006\r\n', 'LIA SOFIANA', 'Bireuen', '1987-02-23', 'P', '', '', 'K-2', 'NON PNS', 'PND2', 'villa berlian 4 blok A4, Jl.Sairin RT 01 RW 011, kel.tanah baru , kec.beji, kota depok 16426', '2016-03-28', 'Rum04', 'B06', 'J18', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'pejatentimur', 'katu', ''),
('8104033\r\n', 'LUSIKA RUSWANDI', 'Sukabumi', '1985-10-10', 'P', '', '', 'K-1', 'NON PNS', 'PND4', 'Jl Sawo No 7 RT 008/005,Kel. Cipete Utara, kec. Kebayoran Baru ', '2018-05-14', 'Rum06', 'B03', 'J31', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'pejatenbarat1', 'katu', ''),
('8104016\r\n', 'LYDIA RIANAWATI', 'Madiun', '1979-10-12', 'P', '', '', 'K-0', 'NON PNS', 'PND4', 'Pejaten Timur RT 01 RW 08 kel. Pejaten Timur Kec.Pasar Minggu Jakarta Selatan', '2013-03-01', 'Rum06', 'B01', 'J09', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8104017\r\n', 'M. KHOIRUN NASIKIN', 'bojonegoro', '1989-08-17', 'L', '', '', 'K-0', 'NON PNS', 'PND4', 'jalan h.ipin no.44 rt 11 rw 01 kel.pondok labu kec.cilandak jakarta selatan', '2016-04-01', 'Rum06', 'B01', 'J31', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8112017\r\n', 'MARYATA', 'Kulon Progo', '1973-05-06', 'L', '', '', 'K-1', 'NON PNS', 'PND5', 'Jl. Kebagusan Raya R. 004 Rw. 004 Kebagusan - Pasar Minggu', '2004-01-02', 'Rum10', 'B01', 'J04', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8111003\r\n', 'MAYA ISMAYANTI', 'Ciamis', '1995-12-14', 'P', '', '', 'TK-0', 'NON PNS', 'PND4', 'Kp. Baru Klender RT 03/RW 01 Kel. Jatinegara Kec. Cakung Jakarta Timur', '2017-12-08', 'Rum08', 'B02', 'J43', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'pasarminggu', 'katu', ''),
('8102007\r\n', 'MEIKE FREDERIKA SALAKORY', 'Jakarta ', '1982-05-12', 'P', '', '', 'K-1', 'NON PNS', 'PND2', 'Komp. Duta indah, Jl.Kenanga II,  Book i3 No.5a, Jatimakmur,  Pondok Gede ', '2016-04-01', 'Rum04', 'B01', 'J18', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8104018\r\n', 'MIA AYU PRASETYA DIYAN ASTRI', 'Jakarta', '1990-05-31', 'P', '', '', 'K-0', 'NON PNS', 'PND4', 'Komplek Marinir Cilandak Jl.Memed Raya Blok E 14 RT.09/05 Kel.Cilandak Timur Kec.Pasar Minggu, Jakarta Selatan', '2016-02-01', 'Rum06', 'B01', 'J31', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8107005\r\n', 'MONIKA', 'Jakarta', '1990-09-05', 'P', '', '', 'TK-0', 'NON PNS', 'PND4', 'Jl.Lubang Buaya RT 05/03 No.45 Kel.Lubang Buaya , Kec.Cipayung kodepos 13810', '2016-02-09', 'Rum08', 'B01', 'J13', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8110008\r\n', 'MUTHIA SULISTIANTU PUTRI', 'Bandung', '1996-01-30', 'P', '', '', 'TK-0', 'NON PNS', 'PND4', 'Jl. Sirih Kuning 2 No.12 AA RT.06 RW.15 Kel. Pancoran Mas Kec. Pancoran Mas, Kota Depok', '2019-08-01', 'Rum06', 'B01', 'J27', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'ragunan', 'katu', ''),
('8102024\r\n', 'NABILA NURUL HASANAH', 'Jakarta', '1993-11-08', 'P', '', '', 'TK-0', 'NON PNS', 'PND2', 'Jl. kebagusan Raya No.24 Kav. 12 RT 011 RW 005 Kel Jagakarsa Kec Jagakarsa, Jakarta Selatan', '0000-00-00', 'Rum04', 'B01', 'J18', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8104019\r\n', 'NADIA KHOIRONI', 'Jakarta', '1993-10-18', 'P', '', '', 'K-1', 'NON PNS', 'PND4', 'Jl RM Kahfi I Rt 012 Rw 004, Kel. Cipedak, Kec. Jagakarsa, Jakarta Selatan', '2016-04-01', 'Rum06', 'B01', 'J31', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8112018\r\n', 'NADIA SETYO PRATAMA', 'Banyumas', '1993-01-18', 'L', '', '', 'TK-0', 'NON PNS', 'PND5', 'Kebagusan besar III No 77 RT 02 RW 05', '2016-02-09', 'Rum10', 'B01', 'J04', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8102022\r\n', 'NIMA ULYA DARAJAH', 'Madiun', '1992-12-14', 'P', '', '', 'K-0', 'NON PNS', 'PND2', 'Jl. Penegak V No.13 A RT 009 RW 002 Kel. Palmeriam Kec. Matraman, Jakarta Timur', '2018-10-01', 'Rum04', 'B03', 'J18', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'pejatenbarat1', 'katu', ''),
('8104020\r\n', 'NIZA HATMAINI', 'Jakarta', '1982-11-20', 'P', '', '', 'K-2', 'NON PNS', 'PND4', 'Jatipadang gg.mesjid Al-Ridwan Rt 006 RW 09 No.7 Kel.Jatipadang,Kec.PasarMinggu', '2013-03-01', 'Rum08', 'B08', 'J31', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'kebagusan', 'katu', ''),
('8107014\r\n', 'NOER AFNI ASTUTI', 'Jakarta', '1996-08-22', 'P', '', '', 'K-0', 'NON PNS', 'PND4', 'Jl. Pancoran Buntu 1 Rt 002 Rw 002 no 10 Kel. Pancoran Kec. Pancoran Jakarta Selatan 12780', '2018-05-15', 'Rum08', 'B01', 'J13', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8102008\r\n', 'NOTIKA TIMURIYANINGSIH', 'Klaten', '1984-11-23', 'P', '', '', 'K-2', 'NON PNS', 'PND2', 'Jl. Moch Kahfi I No.24 Rt.008 Rw.002 Kel.Cipedak,  Kec.Jagakarsa. Jakarta Selatan', '2019-04-01', 'Rum04', 'B07', 'J18', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'cilandaktimur', 'katu', ''),
('8110007\r\n', 'NOVIANI DWI SYAFUTRI', 'Jakarta', '1996-11-05', 'P', '', '', 'TK-0', 'NON PNS', 'PND4', 'Jl. Meruyung Raya gg.H. Isan No.72 RT.01/RW.07, Kel. Meruyung Kec. Limo, Kota Depok', '2019-08-01', 'Rum06', 'B04', 'J27', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'pejatenbarat2', 'katu', ''),
('8102009\r\n', 'NUR ALFIANI', 'Jakarta', '1992-10-22', 'P', '', '', 'K-0', 'NON PNS', 'PND2', 'Jl Angsana I 02/06 Pejaten Timur Pasar Minggu Jakarta Selatan DKI Jakarta', '2017-03-04', 'Rum04', 'B01', 'J18', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'pasarminggu', 'katu', ''),
('8104037\r\n', 'NUR FITRI OKTAVIYANI', 'Jakarta', '1990-10-31', 'P', '', '', 'K-2', 'NON PNS', 'PND4', 'Komplek Marinir, Jl. Seroja IV Rt. 07 Rw. 05 No. I-08, Kel. Cilandak Timur, Kec. Pasar Minggu, Jakarta Selatan, 12560', '2019-02-18', 'Rum06', 'B02', 'J31', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'pasarminggu', 'katu', ''),
('8105001\r\n', 'NURANI SUDI RAHAYU', 'Tegal', '1984-03-26', 'P', '', '', 'K-2', 'NON PNS', 'PND4', 'Kebon Nanas, RT003/010 , kel Grogol, kec Kebayoran Lama, Jakarta Selatan', '2014-04-01', 'Rum08', 'B02', 'J32', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'pasarminggu', 'katu', ''),
('8106025\r\n', 'NURATIKAH AULIYAH.Y', 'Jakarta', '1994-06-30', 'P', '', '', 'TK-0', 'NON PNS', 'PND4', 'Kebon Pala II Rt008 Rw008 Kel.Halim Perdana Kusuma Kec.Makasar Jakarta Timur', '2017-07-03', 'Rum06', 'B01', 'J14', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8106041\r\n', 'NURUL FITRIYANI', 'Jakarta ', '1992-06-01', 'P', '', '', 'TK-0', 'NON PNS', 'PND4', 'JL Bambu Kuning 2/36 RT08/05  Kel Pondok Ranggon,  Kec Cipayung Jakarta Timur 13860 ', '2019-02-18', 'Rum06', 'B01', 'J16', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8107006\r\n', 'OKTAVIALIVIA SIBURIAN', 'Batubinumbun', '1996-10-08', 'P', '', '', 'TK-0', 'NON PNS', 'PND4', 'Jl. Kebagusan IV No.130 RT 001 RW 004, Kel.Kebagusan, Kec. Pasar Minggu, Kota Jakarta Selatan', '2017-12-07', 'Rum08', 'B01', 'J13', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8102018\r\n', 'PRADITA ADININGSIH', 'Jakarta', '1991-10-14', 'P', '', '', 'K-0', 'NON PNS', 'PND2', 'Jl. Karang Asri III Blok C6 No.6 Perumahan Bumi Karang Indah RT08/09 Kec Cilandak, Kel. Lebak Bulus. Jakarta Selatan 12440', '2018-05-09', 'Rum04', 'B05', 'J18', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'pejatenbarat3', 'katu', ''),
('8104035\r\n', 'PRATIWI SEPTIANI', 'Bogor', '1995-09-11', 'P', '', '', 'TK-0', 'NON PNS', 'PND4', 'Jl. Kebagusan Wates No. 32 Rt 004 RW 004, Kel. Kebagusan, Kec. Pasar Minggu, Kota Jakarta Selatan', '2018-10-01', 'Rum08', 'B01', 'J31', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8102010\r\n', 'PRITA KURNIA AGUSTINA', 'Jakarta', '1983-08-29', 'P', '', '', 'TK-0', 'NON PNS', 'PND2', 'Jl.Ampera raya kampus iip blok A no 1 rt 01 rw06 kel cilandak timur kec pasar minggu jakarta selatan', '2012-08-01', 'Rum04', 'B01', 'J18', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8108002\r\n', 'PUJI LESTARI', 'Jakarta', '1994-08-30', 'P', '', '', 'TK-0', 'NON PNS', 'PND4', 'jl kiwi rt 10 rt04 kel ciracas kec ciracas jakarta timur', '2016-02-08', 'Rum06', 'B01', 'J11', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8106026\r\n', 'PURHANIYUNG SAYEKTI', 'Jakarta', '1996-01-18', 'P', '', '', 'TK-0', 'NON PNS', 'PND4', 'Kamp Utan RT 004/RW 008, Kel Ragunan, Kec Pasar Minggu, Jakarta Selatan', '2017-04-03', 'Rum06', 'B01', 'J16', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8104021\r\n', 'PUTRI ANASTASIA', 'Tangerang', '1991-12-16', 'P', '', '', 'TK-0', 'NON PNS', 'PND3', 'Jl H. No.8. Rt 3. RW 08. Kebon Baru. Kecamatan Tebet', '2016-04-01', 'Rum05', 'B01', 'J31', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8106027\r\n', 'RAFIKA CHRISTIN MARPAUNG', 'Mentok', '1983-10-25', 'P', '', '', 'K-2', 'NON PNS', 'PND4', 'legenda wisata columbus b8/33 rt 03/13 kel. wanaherang kec. gunung putri ', '2016-02-01', 'Rum08', 'B01', 'J14', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8112019\r\n', 'RAHMANSYAH', 'Jambi', '1975-06-22', 'L', '', '', 'K-2', 'NON PNS', 'PND5', 'Jl. Cilebut TImur Rt. 005 Rw. 005 Sukaraja  - Bogor', '2014-02-01', 'Rum10', 'B01', 'J04', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8107007\r\n', 'RANNY PURNAMA SARI', 'Bogor', '1991-10-20', 'P', '', '', 'K-0', 'NON PNS', 'PND5', 'Jl.Tenggiri I no 292 Rt 01 Rw 010 Kel Depok Jaya Kec.Pancoran Mas', '2014-04-01', 'Rum05', 'B06', 'J13', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'pejatentimur', 'katu', ''),
('8105002\r\n', 'REZA SUMANJAYA', 'Jakarta', '1993-07-27', 'L', '', '', 'K-0', 'NON PNS', 'PND4', 'Jl. Bango 3 No. 10 RT. 008/03  Pondok Labu, Cilandak, Jakarta Selatan', '2016-02-01', 'Rum06', 'B01', 'J32', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8106039\r\n', 'RIANNA PASMAJA', 'Tegal', '1997-01-20', 'P', '', '', 'TK-0', 'NON PNS', 'PND4', 'Jl. Tanah Tinggi XII No 12 RT 18 RW 07 Kel. tanah tinggi Kec. Johar Baru Jakpus', '2018-10-01', 'Rum08', 'B01', 'J14', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8106028\r\n', 'RIJKI HALIYAH', 'Jakarta', '1989-12-25', 'P', '', '', 'K-2', 'NON PNS', 'PND4', 'Jl. Perdamaian Kebagusan Besar III RT 004 Rw 05 No.1 Pasar Minggu Jakarta Selatan 12520', '2016-02-01', 'Rum08', 'B07', 'J14', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'cilandaktimur', 'katu', ''),
('8104022\r\n', 'RIKA LUKMAWATI', 'Klaten', '1982-07-27', 'P', '', '', 'K-0', 'NON PNS', 'PND4', 'Jl Lapangan tembak Komplek HUBAD rt 008/001 Cibubur,Ciracas Jakarta Timur', '2013-04-01', 'Rum06', 'B01', 'J31', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8106029\r\n', 'RINA LESTIANA DEVI', 'Bogor', '1992-12-10', 'P', '', '', 'K-0', 'NON PNS', 'PND4', 'Jl. Bukit Duri Pangkalan NO. 12 RT 5/12 Tebet Jakarta Selatan', '2016-02-01', 'Rum08', 'B01', 'J14', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8104034\r\n', 'RINA TIMUR PUTRI SANDARI', 'Jakarta', '1995-03-01', 'P', '', '', 'TK-0', 'NON PNS', 'PND4', 'jl siaga IV no 65 rt 006/ rw 12 halim perdana kusuma jakarta timur ', '2018-01-10', 'Rum06', 'B09', 'J31', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'jatipadang', 'katu', ''),
('8106030\r\n', 'RINDI INDAH WULANDARI', 'Cianjur', '1988-06-08', 'P', '', '', 'TK-1', 'NON PNS', 'PND4', 'jl. flamboyan 2 no. 17 rt 001/04 kel. mekarjaya kec. sukmajaya kec. depok ', '2016-02-01', 'Rum08', 'B01', 'J14', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8107008\r\n', 'RIZKA PRATIWI', 'Bogor', '1996-06-07', 'P', '', '', 'TK-0', 'NON PNS', 'PND4', 'Dusun Jembatan I RT 01/02 No.13 Desa Puspasari Kec. Citeureup Kab. Bogor Jawa Barat', '2017-12-07', 'Rum08', 'B05', 'J13', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'pejatenbarat3', 'katu', ''),
('8104023\r\n', 'RIZKY NURLIANA', 'Jakarta', '1992-06-17', 'P', '', '', 'K-1', 'NON PNS', 'PND4', 'Jl. Rawa badak no. 33 rt 008 rw 02 kel. Cipedak kec. Jagakarsa jakarta selatan 12630', '2016-04-01', 'Rum08', 'B01', 'J31', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8111004\r\n', 'ROFISIKA HANDARI', 'Jakarta', '1992-06-13', 'P', '', '', 'K-2', 'NON PNS', 'PND4', 'Jl. Nangka No.17 RT 003 RW 02, Kel. Ceger, Kec. Cipayung, Jakarta Timur 13820', '2016-04-01', 'Rum06', 'B08', 'J43', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'kebagusan', 'katu', ''),
('8104024\r\n', 'RORI SYAPUTRA', 'Lubuk Jantan', '1989-01-02', 'L', '', '', 'K-0', 'NON PNS', 'PND4', 'Jl.Masjid baru no 15 rt 07/rw 01 pejaten timur Pasar Minggu Jakarta Selatan', '2017-07-03', 'Rum08', 'B01', 'J31', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8112020\r\n', 'SAEPULOH', 'Cicurug', '1966-10-04', 'L', '', '', 'TK-2', 'NON PNS', 'PND5', 'Jl. Bacang No. 12 Rt. 009 Rw. 001 Kel. Jati Padang KEc. Pasar Minggu', '2009-10-01', 'Rum10', 'B01', 'J04', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8107009\r\n', 'SANDI MUHAMAD RIZKI', 'Garut', '1994-08-21', 'L', '', '', 'TK-0', 'NON PNS', 'PND4', 'Jln. Jati Indah Rt 02/01 No 21 kel. Pondok Pinang Kec.Kebayoran Lama Jakarta Selatan DKI jakarta 12310', '2017-08-02', 'Rum08', 'B01', 'J13', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8108003\r\n', 'SAPARONI', 'Jakarta', '1992-08-17', 'L', '', '', 'K-1', 'NON PNS', 'PND5', 'Jl.Kebagusan GG Mansur Rt 006/Rw 007 No.28 A Kel.Kebagusan Kec.Pasar Minggu Jakarta Selatan', '2013-11-01', 'Rum06', 'B01', 'J11', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8102011\r\n', 'SARI RAHAYU', 'Jakarta', '1987-08-17', 'P', '', '', 'K-2', 'NON PNS', 'PND2', 'jl.kramat jaya rt1/9 Jakarta pusat', '2014-03-05', 'Rum04', 'B04', 'J18', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'pejatenbarat2', 'katu', ''),
('8106031\r\n', 'SELVI OKTARINI', 'Jakarta', '1991-10-12', 'P', '', '', 'K-1', 'NON PNS', 'PND4', 'Jl. Jeruk Purut RT 007/03 Kel. Cilandak Timur Ps Minggu', '2017-04-03', 'Rum08', 'B07', 'J14', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'cilandaktimur', 'katu', ''),
('8105003\r\n', 'SEPTIA DWI KARYONO', 'Brebes', '1985-09-03', 'P', '', '', 'K-0', 'NON PNS', 'PND4', 'jl. Raya PLN gandul rt 12 /re 03 kel. gandul. kec. cinere', '2011-05-01', 'Rum06', 'B01', 'J32', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8106032\r\n', 'SHOFIA MARWA HAMDI', 'Bogor', '1994-07-03', 'P', '', '', 'K-1', 'NON PNS', 'PND4', 'jl. sawangan elok blok b2/2, bojongsari, depok.', '2017-07-03', 'Rum08', 'B01', 'J14', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'cilandaktimur', 'katu', ''),
('8111005\r\n', 'SISKA RAMA YULIANA', 'Bandar Lampung', '1994-07-12', 'P', '', '', 'TK-0', 'NON PNS', 'PND4', 'jl. pisangan lama iii rt 7 rw 5 , pisangan timur, pulo gadung', '2017-12-08', 'Rum08', 'B06', 'J43', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'pejatentimur', 'katu', ''),
('8110006\r\n', 'SISKA SANTOSO', 'Tangerang', '1993-03-23', 'P', '', '', 'K-0', 'NON PNS', 'PND4', 'JL. sektor VII Blok E NO.43 RT 04 RW 09, Sudimara Jaya, Ciledug, Tangerang Banten', '2017-01-01', 'Rum06', 'B06', 'J27', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'pejatentimur', 'katu', ''),
('8106033\r\n', 'SITATUN', 'Mataram Baru', '1975-05-18', 'P', '', '', 'K-2', 'NON PNS', 'PND4', 'jln. raya Sawangan. premier residen blok a8 .rt 01/rw12 rangkapan  jaya.  kecamatan. pancoran mas. depok. ja-bar', '2005-11-01', 'Rum08', 'B06', 'J14', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'pejatentimur', 'katu', ''),
('8104025\r\n', 'SITI ANITA RIZKILILLAH', 'Tangerang', '1984-01-18', 'P', '', '', 'TK-0', 'NON PNS', 'PND4', 'Kavling DKI Blok Q No.34 Rt 005 Rw 006, Kel. Cipedak, Kec. Jagakarsa, Jakarta Selatan', '2007-03-12', 'Rum06', 'B01', 'J31', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8107010\r\n', 'SITI HUMAIRA', 'Jakarta', '1994-05-21', 'P', '', '', 'K-0', 'NON PNS', 'PND4', 'jl. taman Patra xiv RT 001 RW 04 Kel. Kuningan timur kec. Setiabudi jaksel', '2017-12-07', 'Rum08', 'B04', 'J13', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'pejatenbarat2', 'katu', ''),
('8107011\r\n', 'SITI KODARIAH', 'Luragung', '1994-06-21', 'P', '', '', 'TK-0', 'NON PNS', 'PND3', 'Gang P2 RT 03 RW 08 Kel. Utan Panjang Kec. kemayoran. jakarta pusat', '2014-06-02', 'Rum08', 'B02', 'J13', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'pasarminggu', 'katu', ''),
('8107012\r\n', 'SITI NUR MUNZIATI', 'Jakarta', '1993-02-15', 'P', '', '', 'K-0', 'NON PNS', 'PND4', 'Cipulir RT 5 / RW 4 , Kebayoran Lama', '2017-08-02', 'Rum08', 'B08', 'J13', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'kebagusan', 'katu', ''),
('8105005\r\n', 'SITI ZAHRA HUMAIRA', 'Jakarta', '1995-11-22', 'P', '', '', 'K-0', 'NON PNS', 'PND4', 'Jl. H. Sajim RT 007 RW 002 No. 79B, Gandaria Utara, Kebayoran Baru, Jakarta Selatan 12140', '2018-06-01', 'Rum06', 'B01', 'J32', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8104026\r\n', 'SONA GUSTRISNA', 'Jakarta', '1990-08-13', 'L', '', '', 'K-1', 'NON PNS', 'PND4', 'Jl. Kebagusan Besar 2 RT 003 RW 006 NO.69 kel kebagusan kec pasar minggu', '2013-04-01', 'Rum08', 'B01', 'J31', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8112021\r\n', 'SONNY FERNANDO', 'Jakarta', '1984-01-02', 'L', '', '', 'TK-0', 'NON PNS', 'PND4', 'Jl. Mesjid Al Ikhlas NO. 25 011/001 Pondok kelapa Jakarta Timur', '2013-02-08', 'Rum10', 'B05', 'J04', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'pejatenbarat3', 'katu', ''),
('8104027\r\n', 'SRI NAWANGSIH', 'Sragen', '1990-10-30', 'P', '', '', 'TK-0', 'NON PNS', 'PND4', 'JL. Kebagusan Wates NO 18 RT 04 RW 04 kebagusan pasar minggu', '2017-07-03', 'Rum08', 'B10', 'J31', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'ragunan', 'katu', ''),
('8113001\r\n', 'SRI WAHYU LESTARI', 'Purworejo', '1979-03-10', 'P', '', '', 'K-2', 'NON PNS', 'PND5', 'Jl. H Jeran No. 48 Rt. 005 Rw. 001 Cinere - Depok', '2016-02-01', 'Rum11', 'B01', 'J07', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8109001\r\n', 'SUHARTI', 'Jakarta', '1980-05-11', 'P', '', '', 'TK-2', 'NON PNS', 'PND4', 'jl. Gandaria I Rt 06 Rw 09 Kramat Pela Kebayoran Baru Jakarta selatan 12130', '2003-06-06', 'Rum06', 'B01', 'J20', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8113002\r\n', 'SUPADMI', 'Sukoharjo', '1973-07-06', 'P', '', '', 'TK-1', 'NON PNS', 'PND5', 'Jl. Kebagusan Rt 004 Rw. 004 Kebagusan - Pasar Minggu', '2004-01-02', 'Rum11', 'B01', 'J07', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8112022\r\n', 'SUPARMAN', 'Tasikmalaya', '1968-08-11', 'L', '', '', 'K-1', 'NON PNS', 'PND5', 'Jl. Masjid Al Ahyarn 45 Rt. 008 Rw. 008 Kel. Gandul Cinere - Kota Depok', '2007-03-01', 'Rum12', 'B01', 'J04', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8104028\r\n', 'SUPRIYATIN', 'Cirebon ', '1992-11-09', 'P', '', '', 'TK-0', 'NON PNS', 'PND4', 'Komplek Marinir Rt 04/05 Cilandak timur,pasarminggu ', '2017-11-02', 'Rum08', 'B01', 'J31', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8107013\r\n', 'SYIFA AMELIA KHAIRUNNISA', 'Jakarta', '1996-03-10', 'P', '', '', 'TK-0', 'NON PNS', 'PND4', 'Jl. H No.9 Rt.008/Rw.09 Kebon Baru, Tebet, Jakarta Selatan 12830', '2017-12-07', 'Rum08', 'B01', 'J13', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8106034\r\n', 'SYLVIA MEGASARI', 'Jakarta', '1982-10-02', 'P', '', '', 'K-2', 'NON PNS', 'PND4', 'jl. kebagusan besar no.38. rt 011/07. kebagusan.pasar minggu', '2013-05-01', 'Rum08', 'B07', 'J14', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'cilandaktimur', 'katu', ''),
('8102014\r\n', 'TAUFICS ANGGARA', 'Jakarta', '1979-11-08', 'L', '', '', 'TK-0', 'NON PNS', 'PND2', 'jl. Tanah Rendah rt.016/007 Kampung Melayu, Jatinegara, Jakarta Timur', '2008-12-02', 'Rum04', 'B01', 'J18', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8101005\r\n', 'AMARWATI PUTRI AKHARI', '', '0000-00-00', 'P', '', '', '', '', '', '', '0000-00-00', '', '', '', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8102025', 'DR REBEKKA PITA U.S', '', '0000-00-00', 'L', '', '', '', '', '', '', '0000-00-00', '', '', '', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'pasarminggu', 'katu', ''),
('8106042\r\n', 'ULFA RIEZKYA GUSMI', 'Jakarta', '1995-05-02', 'P', '', '', 'K-0', 'NON PNS', 'PND4', 'Jl. Raya ciracas 004/008 No. 59 Kecamatan Ciracas Kelurahan Ciracas Jakarta Timur', '2019-09-03', 'Rum08', 'B01', 'J14', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8104029\r\n', 'VERONICA', 'Jakarta', '1983-04-24', 'P', '', '', 'K-2', 'NON PNS', 'PND4', 'Jl. Komp perumahan mas naga blok D No.22 RT016 RW003 Kel. Pulo gebang, Kec. Cakung', '2016-04-01', 'Rum08', 'B01', 'J34', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8106035\r\n', 'VINA MARDHIANA', 'jakarta', '1986-03-16', 'P', '', '', 'TK-0', 'NON PNS', 'PND4', 'jl. pasir putih perm. mutiara sentosa blok E. 10  rt 001/11 kel. pasir putih kec. sawangan depok ', '2008-02-01', 'Rum08', 'B01', 'J14', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8102016\r\n', 'VINCENTIA DAVANTININGSIH', 'Jakarta', '1985-09-25', 'P', '', '', 'K-2', 'NON PNS', 'PND2', 'JL. Joe Kelapa tiga NO.5 RT 006 RW 003, Jagakarsa Jakarta Selatan 12620', '2016-02-01', 'Rum04', 'B01', 'J18', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8112023\r\n', 'WAHYUNI ROSIANA', 'Medan', '1984-06-04', 'P', '', '', 'K-2', 'NON PNS', 'PND4', 'Komplek Dinas Kebersihan Rt. 005/09 No. 14, kel. Lenteng Agung, kec. Jagakarsa Jakarta selatan', '2013-04-01', 'Rum10', 'B04', 'J04', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8102023\r\n', 'WINDA RAMADANI', 'Jakarta', '1991-04-10', 'P', '', '', 'TK-0', 'NON PNS', 'PND2', 'Perumahan botanica residence blok B8, kp jemblongan, RT 001/012, kel. pancoran mas, kec. Pancoran mas, depok', '2016-02-01', 'Rum04', 'B09', 'J18', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'jatipadang', 'katu', ''),
('8112024\r\n', 'WIWIK WIDHIHASTUTI', 'Jakarta', '1975-02-25', 'P', '', '', 'K-1', 'NON PNS', 'PND4', 'Jl. Joe Kelapa Tiga No. 2a Rt. 002 Rw. 006 Kel. Lenteng Agung  Kec.Jagakarsa - Jakarta Selatan', '2013-04-01', 'Rum08', 'B01', 'J10', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8104030\r\n', 'WULAN QURRIYATI', 'Jakarta', '1988-05-01', 'P', '', '', 'K-2', 'NON PNS', 'PND4', 'Kebagusan Wates Rt 004/Rw 004 No.62 Kel.Kebagusan Kec.PAsar Minggu Jakarta Selatan', '2014-02-06', 'Rum06', 'B01', 'J31', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8102021\r\n', 'YEFTI CAROLINE', 'Jakarta', '1991-08-07', 'P', '', '', 'TK-0', 'NON PNS', 'PND2', 'Jl. Gotong Royong Kp. Areman RT 07/08 No. 48, Tugu, Cimanggis, Depok', '2018-10-01', 'Rum04', 'B08', 'J18', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'kebagusan', 'katu', ''),
('8112025\r\n', 'YOGA OKTOVIAN', 'Yogyakarta', '1986-10-27', 'L', '', '', 'K-1', 'NON PNS', 'PND3', 'Wisma Mas Pondok Cabe Blok E1/31 RT 04 RW 10 Cinangka Sawangan Depok', '2015-04-01', 'Rum08', 'B01', 'J01', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8106036\r\n', 'YOHANA ERITA MANULLANG', 'Medan Labuhan', '1991-12-09', 'P', '', '', 'K-0', 'NON PNS', 'PND4', 'JL. Kelapa tiga RT 10/03 Kel Jagakarsa kec Jagakarsa , Jakarta Selatan', '2016-02-01', 'Rum08', 'B01', 'J14', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8104031\r\n', 'YUANITA MEGA SARI', 'Padang', '1984-05-14', 'P', '', '', 'K-2', 'NON PNS', 'PND4', 'Jl. M, Saun Kp.Poncol No. 14 Rt04 /01 kelurahan Tanah Baru Kecamatan Beji Depok 16426', '2013-04-01', 'Rum06', 'B07', 'J31', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'pejatentimur', 'katu', ''),
('8108004\r\n', 'YUDI ALFANI KUSUMA', 'Jakarta', '1989-07-04', 'L', '', '', 'K-1', 'NON PNS', 'PND4', 'Jl. Pintu air No 31 Rt 02 Rw 07 Kel. Pabuaran Kec. Bojong gede Kab. Bogor.', '2016-02-09', 'Rum06', 'B01', 'J11', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8104032\r\n', 'YUDI PERDIANSYAH', 'Majalengka', '1991-02-24', 'L', '', '', 'K-1', 'NON PNS', 'PND4', 'Jl. gandaria no. 41 RT007/RW002 Kelurahan Pekayon Kecamatan Pasar Rebo Jakarta Timur', '2016-04-01', 'Rum06', 'B01', 'J31', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8105004\r\n', 'YUDITHA  MARSELINA', 'Bekasi', '1992-03-05', 'P', '', '', 'TK-0', 'NON PNS', 'PND4', 'Jl. Melati 8 Blok BS 43 Nomor 1, RT 008 RW 011, Kel Jatisampurna, Kec Jatisampurna, Kranggan Permai, Bekasi 17433', '2014-04-01', 'Rum06', 'B03', 'J32', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'pejatenbarat1', 'katu', ''),
('8106037\r\n', 'YUNI ASTUTI', 'Tangerang', '1992-06-27', 'P', '', '', 'K-0', 'NON PNS', 'PND4', 'Jl. Bahagia no 50 RT 001 RW 001 kelurahan Koangjaya Kecamatan Karawaci Tangerang Banten 15112', '2018-04-03', 'Rum06', 'B08', 'J14', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'kebagusan', 'katu', ''),
('8107015\r\n', 'YUNITA DEWI FATHONAH', 'Jakarta', '1989-06-28', 'P', '', '', 'TK-0', 'NON PNS', 'PND4', 'Jl. Raya Bogor, Komplek Zeni TNI AD 002/08 16 Pekayon Pasar Rebo Jakarta Timur 13710', '2016-02-09', 'Rum08', 'B03', 'J13', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'pejatenbarat1', 'katu', ''),
('8106038\r\n', 'YUNITA MARIANA', 'Medan', '1990-06-18', 'P', '', '', 'TK-0', 'NON PNS', 'PND4', 'Kebagusan Wates No 4 RT 3 RW 4 Kelurahan Kebagusan Kecamatan Pasar Minggu, Jakarta Selatan', '2016-02-01', 'Rum08', 'B01', 'J14', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'validasi', 'katu', ''),
('8111006\r\n', 'YUSUF DAWUDI', 'Jakarta', '1990-07-17', 'L', '', '', 'K-0', 'NON PNS', 'PND3', 'Persada Raya Jl. Kroya G9 No.27 RT 001/RW 008, Kel. Gembor, Kec. Periuk, Kota Tangerang', '2016-02-09', 'Rum06', 'B03', 'J43', '1.02', '1.02.058', '0.02', '0.0054', '0.057', '', 'pejatenbarat1', 'katu', '');

-- --------------------------------------------------------

--
-- Table structure for table `pelatihan`
--

CREATE TABLE `pelatihan` (
  `id_pelatihan` int(4) NOT NULL,
  `nip` varchar(30) NOT NULL,
  `tgl_pelatihan` date NOT NULL,
  `topik_pelatihan` varchar(100) NOT NULL,
  `penyelenggara` text NOT NULL,
  `hasil_pelatihan` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `pencapaian`
--

CREATE TABLE `pencapaian` (
  `id_pencapaian` varchar(8) NOT NULL,
  `nip` varchar(30) NOT NULL,
  `id_bag` varchar(8) NOT NULL,
  `id_jab` varchar(8) NOT NULL,
  `id_status` varchar(8) NOT NULL,
  `id_skpd` varchar(10) NOT NULL,
  `id_ukpd` varchar(10) NOT NULL,
  `id_penyerapan` varchar(20) NOT NULL,
  `nama` varchar(35) NOT NULL,
  `tanggal` date NOT NULL,
  `penilai` varchar(30) NOT NULL,
  `nskp` int(5) NOT NULL,
  `nprilaku` decimal(5,2) NOT NULL,
  `masa_kerja` varchar(25) NOT NULL,
  `rumpun` varchar(45) NOT NULL,
  `bruto` int(25) NOT NULL,
  `tunjangan` int(25) NOT NULL,
  `gapok` int(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `pendidikan`
--

CREATE TABLE `pendidikan` (
  `idp` int(4) NOT NULL,
  `nip` varchar(30) NOT NULL,
  `t_pdk` varchar(20) NOT NULL,
  `d_pdk` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `pendidikan_t`
--

CREATE TABLE `pendidikan_t` (
  `id_pendidikan` varchar(8) NOT NULL,
  `id_skpd` varchar(10) NOT NULL,
  `id_ukpd` varchar(10) NOT NULL,
  `n_pendidikan` varchar(45) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pendidikan_t`
--

INSERT INTO `pendidikan_t` (`id_pendidikan`, `id_skpd`, `id_ukpd`, `n_pendidikan`) VALUES
('PND5', '1.02', '1.02.058', 'SLTA'),
('PND4', '1.02', '1.02.058', 'D III / D IV'),
('PND3', '1.02', '1.02.058', 'S1'),
('PND2', '1.02', '1.02.058', 'S2 / dr./ drg./ Apoteker/ Ners'),
('PND1', '1.02', '1.02.058', 'S3 / dr. Spesialis');

-- --------------------------------------------------------

--
-- Table structure for table `pengalaman_kerja`
--

CREATE TABLE `pengalaman_kerja` (
  `id_peker` int(4) NOT NULL,
  `nip` varchar(30) NOT NULL,
  `nm_pekerjaan` varchar(50) NOT NULL,
  `d_pekerjaan` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `pengukuran`
--

CREATE TABLE `pengukuran` (
  `id_pengukuran` varchar(8) NOT NULL,
  `nip` varchar(30) NOT NULL,
  `tanggal` date NOT NULL,
  `nilai_utama` int(8) NOT NULL,
  `nilai_tambahan` int(8) NOT NULL,
  `nilai_kreatifitas` int(8) NOT NULL,
  `jumlah` int(8) NOT NULL,
  `hari` int(8) NOT NULL,
  `max_waktu` int(8) NOT NULL,
  `point` varchar(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `penyerapan`
--

CREATE TABLE `penyerapan` (
  `id_penyerapan` varchar(8) NOT NULL,
  `id_skpd` varchar(10) NOT NULL,
  `id_ukpd` varchar(10) NOT NULL,
  `tanggal` date NOT NULL,
  `nilai` int(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `penyerapan`
--

INSERT INTO `penyerapan` (`id_penyerapan`, `id_skpd`, `id_ukpd`, `tanggal`, `nilai`) VALUES
('PNY00002', '1.02', '1.02.058', '2018-01-28', 100);

-- --------------------------------------------------------

--
-- Table structure for table `rumpun`
--

CREATE TABLE `rumpun` (
  `id_rumpun` varchar(8) NOT NULL,
  `n_rumpun` varchar(35) NOT NULL,
  `nilai` varchar(8) NOT NULL,
  `id_skpd` varchar(10) NOT NULL,
  `id_ukpd` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rumpun`
--

INSERT INTO `rumpun` (`id_rumpun`, `n_rumpun`, `nilai`, `id_skpd`, `id_ukpd`) VALUES
('Rum01', 'Dokter Spesialis Bedah', '4', '1.02', '1.02.058'),
('Rum02', 'Dokter Spesialis Non Bedah', '2.5', '1.02', '1.02.058'),
('Rum03', 'Dokter Spesialis Penunjang', '1.8', '1.02', '1.02.058'),
('Rum04', 'Dokter Umum / Dokter Gigi', '1.6', '1.02', '1.02.058'),
('Rum05', 'Apoteker / Ners', '1.5', '1.02', '1.02.058'),
('Rum06', 'Radiologi/Analis/DIV/DIII Kes', '0.8', '1.02', '1.02.058'),
('Rum07', 'Teknis Tingkat Ahli', '1.5', '1.02', '1.02.058'),
('Rum08', 'Teknis Tingkat Terampil', '1', '1.02', '1.02.058'),
('Rum09', 'Administrasi Tingkat Ahli', '0.7', '1.02', '1.02.058'),
('Rum10', 'Administrasi Tingkat Terampil', '0.6', '1.02', '1.02.058'),
('Rum11', 'Operasional Tingkat Ahli', '0.5', '1.02', '1.02.058'),
('Rum12', 'Operasional Tingkat Terampil', '0.4', '1.02', '1.02.058');

-- --------------------------------------------------------

--
-- Table structure for table `setting`
--

CREATE TABLE `setting` (
  `id_setting` varchar(4) NOT NULL,
  `pj` int(1) NOT NULL,
  `management` int(1) NOT NULL,
  `kinerja` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `setting`
--

INSERT INTO `setting` (`id_setting`, `pj`, `management`, `kinerja`) VALUES
('ST01', 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `set_user`
--

CREATE TABLE `set_user` (
  `id` int(50) NOT NULL,
  `ket` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Table structure for table `skp`
--

CREATE TABLE `skp` (
  `kd_skp` varchar(8) NOT NULL,
  `skp` varchar(160) NOT NULL,
  `waktu` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `skp`
--

INSERT INTO `skp` (`kd_skp`, `skp`, `waktu`) VALUES
('Manual', 'Manual Input', '0'),
('SKP00001', 'Alih Media Indeksing dan Editing Arsip - 30.0 menit', '30'),
('SKP00002', 'Alih Media Indeksing dan Editing Arsip - 15.0 menit', '15'),
('SKP00003', 'Bertugas menjadi Panitera Pengganti - 60.0 menit', '60'),
('SKP00004', 'Bertugas menjadi Panitera Pengganti - 30.0 menit', '30'),
('SKP00005', 'Bertugas menjadi Panitera Pengganti - 120.0 menit', '120'),
('SKP00006', 'Evaluasi Dokumen Kualifikasi Pengadaan Barang / Jasa (termasuk lelang ulang) - 60.0 menit', '60'),
('SKP00007', 'Evaluasi Dokumen Kualifikasi Pengadaan Barang / Jasa (termasuk lelang ulang) - 120.0 menit', '120'),
('SKP00008', 'Evaluasi Dokumen Kualifikasi Pengadaan Barang / Jasa (termasuk lelang ulang) - 90.0 menit', '90'),
('SKP00009', 'Input Keterangan Absensi Pegawai Melalui Media Elektronik (Per Hari) - 30.0 menit', '30'),
('SKP00010', 'Input Keterangan Absensi Pegawai Melalui Media Elektronik (Per Hari) - 15.0 menit', '15'),
('SKP00011', 'Input PKG Jenjang SD, SMP, SMA, SMK - 60.0 menit', '60'),
('SKP00012', 'Input PKG Jenjang SD, SMP, SMA, SMK - 120.0 menit', '120'),
('SKP00013', 'Inventarisasi permasalahan - 60.0 menit', '60'),
('SKP00014', 'Inventarisasi permasalahan - 30.0 menit', '30'),
('SKP00015', 'Inventarisasi permasalahan - 120.0 menit', '120'),
('SKP00016', 'Klarifikasi dan Negosiasi Penawaran Penyedia Barang / Jasa - 30.0 menit', '30'),
('SKP00017', 'Klarifikasi dan Negosiasi Penawaran Penyedia Barang / Jasa - 60.0 menit', '60'),
('SKP00018', 'Legalisir dokumen (per 5 lembar) - 5.0 menit', '5'),
('SKP00019', 'Melaksakan tugas sebagai pembaca doa (1x acara / event) - 15.0 menit', '15'),
('SKP00020', 'Melaksanakan arahan pimpinan - 15.0 menit', '15'),
('SKP00021', 'Melaksanakan arahan pimpinan - 60.0 menit', '60'),
('SKP00022', 'Melaksanakan arahan pimpinan - 30.0 menit', '30'),
('SKP00023', 'Melaksanakan cap bakar / tanda selar kapal-kapal di bawah 7 GT pada pelabuhan - 30.0 menit', '30'),
('SKP00024', 'Melaksanakan deteksi dini (per lokasi) - 60.0 menit', '60'),
('SKP00025', 'Melaksanakan duplikasi database - 30.0 menit', '30'),
('SKP00026', 'Melaksanakan duplikasi database - 15.0 menit', '15'),
('SKP00027', 'Melaksanakan duplikasi database - 60.0 menit', '60'),
('SKP00028', 'Melaksanakan Grouping ID Radio Trunking - 60.0 menit', '60'),
('SKP00029', 'Melaksanakan Grouping ID Radio Trunking - 120.0 menit', '120'),
('SKP00030', 'Melaksanakan Identifikasi dan asesmen Warga Binaan Sosial - 60.0 menit', '60'),
('SKP00031', 'Melaksanakan imunisasi, vaksinasi, feed additive - 30.0 menit', '30'),
('SKP00032', 'Melaksanakan imunisasi, vaksinasi, feed additive - 180.0 menit', '180'),
('SKP00033', 'Melaksanakan imunisasi, vaksinasi, feed additive - 120.0 menit', '120'),
('SKP00034', 'Melaksanakan Inventaris Alat Ukur Telekomunikasi - 30.0 menit', '30'),
('SKP00035', 'Melaksanakan Kegiatan Pembinaan - 180.0 menit', '180'),
('SKP00036', 'Melaksanakan Kegiatan Pembinaan - 90.0 menit', '90'),
('SKP00037', 'Melaksanakan Kegiatan Pembinaan - 120.0 menit', '120'),
('SKP00038', 'Melaksanakan konfirmasi / rekonsiliasi dengan pusat / provinsi / SKPD / UKPD - 120.0 menit', '120'),
('SKP00039', 'Melaksanakan konfirmasi / rekonsiliasi dengan pusat / provinsi / SKPD / UKPD - 180.0 menit', '180'),
('SKP00040', 'Melaksanakan konfirmasi / rekonsiliasi dengan pusat / provinsi / SKPD / UKPD - 30.0 menit', '30'),
('SKP00041', 'Melaksanakan konfirmasi / rekonsiliasi dengan pusat / provinsi / SKPD / UKPD - 60.0 menit', '60'),
('SKP00042', 'Melaksanakan latihan musik (pada Dinas Damkar) - 30.0 menit', '30'),
('SKP00043', 'Melaksanakan latihan musik (pada Dinas Damkar) - 120.0 menit', '120'),
('SKP00044', 'Melaksanakan latihan musik (pada Dinas Damkar) - 60.0 menit', '60'),
('SKP00045', 'Melaksanakan Layanan Perpustakaan Mobil Keliling - 120.0 menit', '120'),
('SKP00046', 'Melaksanakan Layanan Perpustakaan Mobil Keliling - 180.0 menit', '180'),
('SKP00047', 'Melaksanakan Layanan Perpustakaan Siswa - 30.0 menit', '30'),
('SKP00048', 'Melaksanakan / melakukan Survei / tinjauan lapangan (per lokasi) - 30.0 menit', '30'),
('SKP00049', 'Melaksanakan / melakukan Survei / tinjauan lapangan (per lokasi) - 60.0 menit', '60'),
('SKP00050', 'Melaksanakan / melakukan Survei / tinjauan lapangan (per lokasi) - 120.0 menit', '120'),
('SKP00051', 'Melaksanakan / Melayani Konsultasi Individu / kelompok - 10.0 menit', '10'),
('SKP00052', 'Melaksanakan / Melayani Konsultasi SKPD / UKPD - 30.0 menit', '30'),
('SKP00053', 'Melaksanakan / Melayani Konsultasi SKPD / UKPD - 15.0 menit', '15'),
('SKP00054', 'Melaksanakan / Melayani Konsultasi SKPD / UKPD - 60.0 menit', '60'),
('SKP00055', 'Melaksanakan / mengikuti sosialisasi tingkat kota / provinsi / nasional - 120.0 menit', '120'),
('SKP00056', 'Melaksanakan / mengikuti sosialisasi tingkat kota / provinsi / nasional - 300.0 menit', '300'),
('SKP00057', 'Melaksanakan / mengikuti sosialisasi tingkat kota / provinsi / nasional - 180.0 menit', '180'),
('SKP00058', 'Melaksanakan / mengikuti sosialisasi tingkat kota / provinsi / nasional - 240.0 menit', '240'),
('SKP00059', 'Melaksanakan panen tanaman (per lokasi) - 30.0 menit', '30'),
('SKP00060', 'Melaksanakan panen tanaman (per lokasi) - 60.0 menit', '60'),
('SKP00061', 'Melaksanakan pelatihan per kegiatan - 180.0 menit', '180'),
('SKP00062', 'Melaksanakan pelatihan per kegiatan - 120.0 menit', '120'),
('SKP00063', 'Melaksanakan pelatihan per kegiatan - 60.0 menit', '60'),
('SKP00064', 'Melaksanakan pelayanan kesehatan sesuai dengan objek kerja - 30.0 menit', '30'),
('SKP00065', 'Melaksanakan pelayanan klinis umum, spesialis, gizi kerja dan produktivitas kerja - 30.0 menit', '30'),
('SKP00066', 'Melaksanakan pelayanan klinis umum, spesialis, gizi kerja dan produktivitas kerja - 15.0 menit', '15'),
('SKP00067', 'Melaksanakan pelayanan penanganan satwa liar - 180.0 menit', '180'),
('SKP00068', 'Melaksanakan pelayanan penanganan satwa liar - 120.0 menit', '120'),
('SKP00069', 'Melaksanakan Pemberantasan Sarang Nyamuk (PSN) - 60.0 menit', '60'),
('SKP00070', 'Melaksanakan Pemberantasan Sarang Nyamuk (PSN) - 120.0 menit', '120'),
('SKP00071', 'Melaksanakan Pemberian Peringatan Terhadap Pelanggaran Perizinan dan Non Perizinan - 30.0 menit', '30'),
('SKP00072', 'Melaksanakan pembibitan tanaman (per lokasi) - 30.0 menit', '30'),
('SKP00073', 'Melaksanakan pembibitan tanaman (per lokasi) - 60.0 menit', '60'),
('SKP00074', 'Melaksanakan pembinaan fisik, pembinaan olahraga dan kegiatan pelatihan - 120.0 menit', '120'),
('SKP00075', 'Melaksanakan pembinaan fisik, pembinaan olahraga dan kegiatan pelatihan - 60.0 menit', '60'),
('SKP00076', 'Melaksanakan pemeliharaan dan perbaikan instalasi listrik dan air - 30.0 menit', '30'),
('SKP00077', 'Melaksanakan pemeliharaan dan perbaikan instalasi listrik dan air - 60.0 menit', '60'),
('SKP00078', 'Melaksanakan pemeliharaan / perawatan / pembersihan prasarana dan sarana - 30.0 menit', '30'),
('SKP00079', 'Melaksanakan pemeliharaan / perawatan / pembersihan prasarana dan sarana - 60.0 menit', '60'),
('SKP00080', 'Melaksanakan pemeliharaan / perawatan / pembersihan prasarana dan sarana - 120.0 menit', '120'),
('SKP00081', 'Melaksanakan pemeliharaan / perawatan / pembersihan prasarana dan sarana - 15.0 menit', '15'),
('SKP00082', 'Melaksanakan pemeliharaan tanaman (per lokasi) - 60.0 menit', '60'),
('SKP00083', 'Melaksanakan pemeliharaan tanaman (per lokasi) - 30.0 menit', '30'),
('SKP00084', 'Melaksanakan pemeriksaan ante mortem dan post mortem (per pasien) - 120.0 menit', '120'),
('SKP00085', 'Melaksanakan pemeriksaan ante mortem dan post mortem (per pasien) - 60.0 menit', '60'),
('SKP00086', 'Melaksanakan Pemeriksaan penunjang pelayanan kesehatan olahraga dan kebugaran medical check up pegawai - 90.0 menit', '90'),
('SKP00087', 'Melaksanakan Pemrograman HT / RIG Trunking - 15.0 menit', '15'),
('SKP00088', 'Melaksanakan pemusnahan dokumen / barang (per dokumen / barang) - 15.0 menit', '15'),
('SKP00089', 'Melaksanakan pemusnahan dokumen / barang (per dokumen / barang) - 60.0 menit', '60'),
('SKP00090', 'Melaksanakan pemusnahan dokumen / barang (per dokumen / barang) - 30.0 menit', '30'),
('SKP00091', 'Melaksanakan penagihan pada penyewa - 15.0 menit', '15'),
('SKP00092', 'Melaksanakan Penanganan Gangguan pada BTS Radio Trunking - 120.0 menit', '120'),
('SKP00093', 'Melaksanakan Penanganan Gangguan pada HT / RIG Pengguna - 30.0 menit', '30'),
('SKP00094', 'Melaksanakan penanganan keadaan darurat - 180.0 menit', '180'),
('SKP00095', 'Melaksanakan penanganan keadaan darurat - 120.0 menit', '120'),
('SKP00096', 'Melaksanakan penanganan keadaan darurat - 60.0 menit', '60'),
('SKP00097', 'Melaksanakan penanganan keadaan darurat - 30.0 menit', '30'),
('SKP00098', 'Melaksanakan Pendataan CCTV - 30.0 menit', '30'),
('SKP00099', 'Melaksanakan Pendataan Fisik Menara Telekomunikasi - 30.0 menit', '30'),
('SKP00100', 'Melaksanakan Pendataan HT / RIG Trunking - 30.0 menit', '30'),
('SKP00101', 'Melaksanakan Pendistribusian Logistik dan Penanganan Kedaruratan - 60.0 menit', '60'),
('SKP00102', 'Melaksanakan Penentuan Titik Lokasi CCTV - 30.0 menit', '30'),
('SKP00103', 'Melaksanakan Penerapan rancangan konfigurasi sistem jaringan komputer - 120.0 menit', '120'),
('SKP00104', 'Melaksanakan Penerapan rancangan konfigurasi sistem jaringan komputer - 60.0 menit', '60'),
('SKP00105', 'Melaksanakan Penertiban (per titik / per objek) - 60.0 menit', '60'),
('SKP00106', 'Melaksanakan Penertiban (per titik / per objek) - 120.0 menit', '120'),
('SKP00107', 'Melaksanakan Penertiban (per titik / per objek) - 180.0 menit', '180'),
('SKP00108', 'Melaksanakan Pengambilan Gambar dengan Kamera - 5.0 menit', '5'),
('SKP00109', 'Melaksanakan Pengambilan Gambar dengan Kamera - 15.0 menit', '15'),
('SKP00110', 'Melaksanakan Pengambilan Gambar dengan Kamera - 2.0 menit', '2'),
('SKP00111', 'Melaksanakan pengaturan lalu lintas - 120.0 menit', '120'),
('SKP00112', 'Melaksanakan pengaturan lalu lintas - 30.0 menit', '30'),
('SKP00113', 'Melaksanakan pengaturan lalu lintas - 60.0 menit', '60'),
('SKP00114', 'Melaksanakan penginformasian kepada pengguna jalan dengan Variable Message Sign (VMS) Mobile - 120.0 menit', '120'),
('SKP00115', 'Melaksanakan penginformasian kepada pengguna jalan dengan Variable Message Sign (VMS) Mobile - 60.0 menit', '60'),
('SKP00116', 'Melaksanakan Pengukuran Koordinat - 10.0 menit', '10'),
('SKP00117', 'Melaksanakan Pengukuran Pengukuran Gelombang Elektromagnetik (Radiasi) - 15.0 menit', '15'),
('SKP00118', 'Melaksanakan Pengukuran Pengukuran Gelombang Elektromagnetik (Radiasi) - 30.0 menit', '30'),
('SKP00119', 'Melaksanakan Pengukuran Spektrum Radio Frekuensi - 30.0 menit', '30'),
('SKP00120', 'Melaksanakan Pengukuran Spektrum Radio Frekuensi - 15.0 menit', '15'),
('SKP00121', 'Melaksanakan pengukuran tanah >1000 m2 (per lokasi) - 90.0 menit', '90'),
('SKP00122', 'Melaksanakan pengukuran tanah 500 - 1000 m2 (per lokasi) - 60.0 menit', '60'),
('SKP00123', 'Melaksanakan pengukuran tanah < 500 m2 (per lokasi) - 30.0 menit', '30'),
('SKP00124', 'Melaksanakan Pengukuran Tinggi Menara Telekomunikasi - 10.0 menit', '10'),
('SKP00125', 'Melaksanakan pengumpulan data, validasi data, analisis data dan penyajian (publikasi data) sesuai dengan objek kerja - 60.0 menit', '60'),
('SKP00126', 'Melaksanakan pengumpulan data, validasi data, analisis data dan penyajian (publikasi data) sesuai dengan objek kerja - 120.0 menit', '120'),
('SKP00127', 'Melaksanakan Penilaian Kinerja Guru - 60.0 menit', '60'),
('SKP00128', 'Melaksanakan Penilaian Kinerja Guru - 120.0 menit', '120'),
('SKP00129', 'Melaksanakan Penilaian Kinerja Kepala Sekolah / Pengawas Sekolah - 60.0 menit', '60'),
('SKP00130', 'Melaksanakan Penilaian Kinerja Kepala Sekolah / Pengawas Sekolah - 120.0 menit', '120'),
('SKP00131', 'Melaksanakan penjurian (per hari per kegiatan) - 120.0 menit', '120'),
('SKP00132', 'Melaksanakan penyidikan (per hari per kasus) - 60.0 menit', '60'),
('SKP00133', 'Melaksanakan penyidikan (per hari per kasus) - 120.0 menit', '120'),
('SKP00134', 'Melaksanakan Perakitan dan Instalasi Pemasangan RIG Trunking - 60.0 menit', '60'),
('SKP00135', 'Melaksanakan Perakitan dan Instalasi Pemasangan RIG Trunking - 120.0 menit', '120'),
('SKP00136', 'Melaksanakan perbaikan objek kerja setelah koreksi pimpinan - 30.0 menit', '30'),
('SKP00137', 'Melaksanakan perbaikan objek kerja setelah koreksi pimpinan - 15.0 menit', '15'),
('SKP00138', 'Melaksanakan Registrasi HT / RIG Trunking Ke Sistem - 5.0 menit', '5'),
('SKP00139', 'Melaksanakan sanitasi kandang (perkandang) - 30.0 menit', '30'),
('SKP00140', 'Melaksanakan sensus barang - 120.0 menit', '120'),
('SKP00141', 'Melaksanakan sensus barang - 30.0 menit', '30'),
('SKP00142', 'Melaksanakan sensus barang - 60.0 menit', '60'),
('SKP00143', 'Melaksanakan tera ulang terhadap alat ukur (per alat ukur) - 30.0 menit', '30'),
('SKP00144', 'Melaksanakan tera ulang terhadap alat ukur (per alat ukur) - 15.0 menit', '15'),
('SKP00145', 'Melaksanakan tindakan medis terhadap satwa (per hewan) - 120.0 menit', '120'),
('SKP00146', 'Melaksanakan tindakan medis terhadap satwa (per hewan) - 60.0 menit', '60'),
('SKP00147', 'Melaksanakan tindakan medis terhadap satwa (per hewan) - 30.0 menit', '30'),
('SKP00148', 'Melaksanakan tindakan rawat jalan - 60.0 menit', '60'),
('SKP00149', 'Melaksanakan tindakan rawat jalan - 30.0 menit', '30'),
('SKP00150', 'Melaksanakan tindakan rawat jalan - 10.0 menit', '10'),
('SKP00151', 'Melaksanakan Transaksi Pembayaran ke Pihak Ketiga - 30.0 menit', '30'),
('SKP00152', 'Melaksanakan tugas piket diluar jam kerja - 30.0 menit', '30'),
('SKP00153', 'Melaksanakan tugas piket diluar jam kerja - 120.0 menit', '120'),
('SKP00154', 'Melaksanakan tugas piket diluar jam kerja - 60.0 menit', '60'),
('SKP00155', 'Melaksanakan tugas sebagai asisten pelayanan kesehatan - 10.0 menit', '10'),
('SKP00156', 'Melaksanakan tugas sebagai asisten pelayanan kesehatan - 5.0 menit', '5'),
('SKP00157', 'Melaksanakan tugas sebagai asistensi Pelayanan Kesehatan - 10.0 menit', '10'),
('SKP00158', 'Melaksanakan tugas-tugas pengawasan dengan kompleksitas rendah dalam kegiatan pemantauan - 240.0 menit', '240'),
('SKP00159', 'Melaksanakan tugas-tugas pengawasan dengan kompleksitas rendah dalam kegiatan pemantauan - 120.0 menit', '120'),
('SKP00160', 'Melaksanakan tugas-tugas pengawasan dengan kompleksitas sedang dalam kegiatan pemantauan - 240.0 menit', '240'),
('SKP00161', 'Melaksanakan tugas-tugas pengawasan dengan kompleksitas sedang dalam kegiatan pemantauan - 120.0 menit', '120'),
('SKP00162', 'Melaksanakan tugas untuk kelancaran dan ketertiban di area pelabuhan - 30.0 menit', '30'),
('SKP00163', 'Melaksanakan upaya pencegahan - 30.0 menit', '30'),
('SKP00164', 'Melaksanakan upaya pencegahan - 60.0 menit', '60'),
('SKP00165', 'Melaksanakan Verifikasi (per berkas) - 5.0 menit', '5'),
('SKP00166', 'Melaksanakan Verifikasi (per berkas) - 15.0 menit', '15'),
('SKP00167', 'Melaksanakan Verifikasi (per berkas) - 60.0 menit', '60'),
('SKP00168', 'Melaksanakan Verifikasi (per berkas) - 30.0 menit', '30'),
('SKP00169', 'Melaksanakan Wawancara dengan Pelapor / Saksi - 30.0 menit', '30'),
('SKP00170', 'Melaksanakan Wawancara dengan Pelapor / Saksi - 60.0 menit', '60'),
('SKP00171', 'Melakukan analisa dalam proses pengadaan Barang / Jasa - 60.0 menit', '60'),
('SKP00172', 'Melakukan analisa dalam proses pengadaan Barang / Jasa - 120.0 menit', '120'),
('SKP00173', 'Melakukan analisa / kajian / telaahan - 180.0 menit', '180'),
('SKP00174', 'Melakukan analisa / kajian / telaahan - 30.0 menit', '30'),
('SKP00175', 'Melakukan analisa / kajian / telaahan - 60.0 menit', '60'),
('SKP00176', 'Melakukan analisa / kajian / telaahan - 120.0 menit', '120'),
('SKP00177', 'Melakukan analisa usulan anggaran dan perubahan anggaran SKPD / UKPD - 90.0 menit', '90'),
('SKP00178', 'Melakukan Audit Rutin Sistem - 30.0 menit', '30'),
('SKP00179', 'Melakukan Audit Rutin Sistem - 60.0 menit', '60'),
('SKP00180', 'Melakukan Back Up Aplikasi / Sistem - 60.0 menit', '60'),
('SKP00181', 'Melakukan Back Up Aplikasi / Sistem - 120.0 menit', '120'),
('SKP00182', 'Melakukan Back Up Data - 120.0 menit', '120'),
('SKP00183', 'Melakukan Back Up Data - 60.0 menit', '60'),
('SKP00184', 'Melakukan coding program database - 60.0 menit', '60'),
('SKP00185', 'Melakukan coding program database - 90.0 menit', '90'),
('SKP00186', 'Melakukan deteksi - 60.0 menit', '60'),
('SKP00187', 'Melakukan deteksi - 120.0 menit', '120'),
('SKP00188', 'Melakukan Digitalisasi Arsip (per file) - 30.0 menit', '30'),
('SKP00189', 'Melakukan Digitalisasi Arsip (per file) - 15.0 menit', '15'),
('SKP00190', 'Melakukan dokumentasi kegiatan seperti pengambilan gambar dan cetak gambar - 10.0 menit', '10'),
('SKP00191', 'Melakukan edukasi pasien - 15.0 menit', '15'),
('SKP00192', 'Melakukan evakuasi kegiatan emergency / kecelakaan terhadap sarana dan prasarana lampu lalu lintas - 60.0 menit', '60'),
('SKP00193', 'Melakukan evakuasi penyelamatan - 60.0 menit', '60'),
('SKP00194', 'Melakukan evakuasi penyelamatan - 120.0 menit', '120'),
('SKP00195', 'Melakukan evaluasi - 60.0 menit', '60'),
('SKP00196', 'Melakukan evaluasi - 120.0 menit', '120'),
('SKP00197', 'Melakukan evaluasi - 30.0 menit', '30'),
('SKP00198', 'Melakukan Evaluasi Sistem Akuntabilitas Kinerja Instansi Pemerintah per 1 SKPD - 30.0 menit', '30'),
('SKP00199', 'Melakukan Evaluasi Sistem Akuntabilitas Kinerja Instansi Pemerintah per 1 SKPD - 60.0 menit', '60'),
('SKP00200', 'Melakukan identifikasi - 90.0 menit', '90'),
('SKP00201', 'Melakukan identifikasi - 60.0 menit', '60'),
('SKP00202', 'Melakukan identifikasi - 30.0 menit', '30'),
('SKP00203', 'Melakukan identifikasi - 15.0 menit', '15'),
('SKP00204', 'Melakukan Identifikasi dan Verfikasi Perangkat Keras - 60.0 menit', '60'),
('SKP00205', 'Melakukan Identifikasi dan Verfikasi Perangkat Keras - 30.0 menit', '30'),
('SKP00206', 'Melakukan Inservice Jaringan Online Mainframe - 15.0 menit', '15'),
('SKP00207', 'Melakukan Inservice Printer Online - 15.0 menit', '15'),
('SKP00208', 'Melakukan inspeksi - 60.0 menit', '60'),
('SKP00209', 'Melakukan inspeksi - 120.0 menit', '120'),
('SKP00210', 'Melakukan inspeksi - 30.0 menit', '30'),
('SKP00211', 'Melakukan instalasi perangkat lunak / keras - 15.0 menit', '15'),
('SKP00212', 'Melakukan instalasi perangkat lunak / keras - 30.0 menit', '30'),
('SKP00213', 'Melakukan inventarisasi - 10.0 menit', '10'),
('SKP00214', 'Melakukan inventarisasi - 60.0 menit', '60'),
('SKP00215', 'Melakukan inventarisasi - 30.0 menit', '30'),
('SKP00216', 'Melakukan kalibrasi - 15.0 menit', '15'),
('SKP00217', 'Melakukan kalibrasi - 60.0 menit', '60'),
('SKP00218', 'Melakukan kalibrasi - 30.0 menit', '30'),
('SKP00219', 'Melakukan kegiatan administrasi (Menerima surat, fax, telepon dan mengirim surat, fax) - 10.0 menit', '10'),
('SKP00220', 'Melakukan kegiatan administrasi (Menerima surat, fax, telepon dan mengirim surat, fax) - 5.0 menit', '5'),
('SKP00221', 'Melakukan kegiatan administrasi (Menerima surat, fax, telepon dan mengirim surat, fax) - 15.0 menit', '15'),
('SKP00222', 'Melakukan kegiatan pelayanan (Menerima, memverifikasi dan mencatat berkas / surat / dokumen dan / atau memberi penjelasan) - 15.0 menit', '15'),
('SKP00223', 'Melakukan kegiatan pelayanan (Menerima, memverifikasi, dan mencatat berkas / surat / dokumen dan / atau memberi penjelasan) - 3.0 menit', '3'),
('SKP00224', 'Melakukan kegiatan pelayanan (Menerima, memverifikasi, dan mencatat berkas / surat / dokumen dan / atau memberi penjelasan) - 5.0 menit', '5'),
('SKP00225', 'Melakukan kegiatan promosi kesehatan perorangan - 15.0 menit', '15'),
('SKP00226', 'Melakukan kegiatan Promosi / Pameran / Bazar Investasi Dalam Negeri - 180.0 menit', '180'),
('SKP00227', 'Melakukan kegiatan Promosi / Pameran / Bazar Investasi Dalam Negeri - 120.0 menit', '120'),
('SKP00228', 'Melakukan kegiatan surat menyurat - 15.0 menit', '15'),
('SKP00229', 'Melakukan kegiatan surveilance kasus atau penyakit yang berpotensi menjadi KLB per lokasi - 120.0 menit', '120'),
('SKP00230', 'Melakukan kegiatan surveilance kasus atau penyakit yang berpotensi menjadi KLB per lokasi - 60.0 menit', '60'),
('SKP00231', 'Melakukan kegiatan surveilance kasus atau penyakit yang berpotensi menjadi KLB per lokasi - 180.0 menit', '180'),
('SKP00232', 'Melakukan klaim asuransi - 30.0 menit', '30'),
('SKP00233', 'Melakukan klaim asuransi - 60.0 menit', '60'),
('SKP00234', 'Melakukan konfirmasi gaji dan tunjangan lainnya sebagai data bahan belanja pegawai SKPD - 60.0 menit', '60'),
('SKP00235', 'Melakukan konfirmasi gaji dan tunjangan lainnya sebagai data bahan belanja pegawai SKPD - 30.0 menit', '30'),
('SKP00236', 'Melakukan konversi sistem database - 60.0 menit', '60'),
('SKP00237', 'Melakukan konversi sistem database - 30.0 menit', '30'),
('SKP00238', 'Melakukan koordinasi dengan pusat / provinsi - 60.0 menit', '60'),
('SKP00239', 'Melakukan koordinasi dengan pusat / provinsi - 120.0 menit', '120'),
('SKP00240', 'Melakukan koordinasi dengan SKPD - 30.0 menit', '30'),
('SKP00241', 'Melakukan koordinasi dengan SKPD - 45.0 menit', '45'),
('SKP00242', 'Melakukan koordinasi dengan SKPD - 60.0 menit', '60'),
('SKP00243', 'Melakukan koordinasi dengan subbidang / subbagian dalam satu SKPD - 15.0 menit', '15'),
('SKP00244', 'Melakukan koordinasi dengan subbidang / subbagian dalam satu SKPD - 30.0 menit', '30'),
('SKP00245', 'Melakukan koordinasi melalui media elektronik - 15.0 menit', '15'),
('SKP00246', 'Melakukan kunjungan kerja - 60.0 menit', '60'),
('SKP00247', 'Melakukan kunjungan kerja - 120.0 menit', '120'),
('SKP00248', 'Melakukan kunjungan kerja - 180.0 menit', '180'),
('SKP00249', 'Melakukan kunjungan kerja - 300.0 menit', '300'),
('SKP00250', 'Melakukan Laminasi Arsip - 10.0 menit', '10'),
('SKP00251', 'Melakukan / melaksanakan pemeriksaan / penelitian / uji pada laboratorium - 15.0 menit', '15'),
('SKP00252', 'Melakukan / melaksanakan pemeriksaan / penelitian / uji pada laboratorium - 30.0 menit', '30'),
('SKP00253', 'Melakukan / melaksanakan pemeriksaan / penelitian / uji pada laboratorium - 5.0 menit', '5'),
('SKP00254', 'Melakukan / membuat sistem manajemen mutu - 120.0 menit', '120'),
('SKP00255', 'Melakukan / membuat sistem manajemen mutu - 60.0 menit', '60'),
('SKP00256', 'Melakukan negosiasi dan penyelesaian masalah (per kejadian) - 60.0 menit', '60'),
('SKP00257', 'Melakukan otorisasi / pengesahan objek kerja - 15.0 menit', '15'),
('SKP00258', 'Melakukan otorisasi / pengesahan objek kerja - 5.0 menit', '5'),
('SKP00259', 'Melakukan patroli - 15.0 menit', '15'),
('SKP00260', 'Melakukan patroli - 30.0 menit', '30'),
('SKP00261', 'Melakukan pekerjaan gas medis - 30.0 menit', '30'),
('SKP00262', 'Melakukan pekerjaan linen Rumah Sakit - 30.0 menit', '30'),
('SKP00263', 'Melakukan pekerjaan linen Rumah Sakit - 15.0 menit', '15'),
('SKP00264', 'Melakukan pekerjaan linen Rumah Sakit - 45.0 menit', '45'),
('SKP00265', 'Melakukan pekerjaan rekam medis - 10.0 menit', '10'),
('SKP00266', 'Melakukan pekerjaan rekam medis - 20.0 menit', '20'),
('SKP00267', 'Melakukan pekerjaan rekam medis - 30.0 menit', '30'),
('SKP00268', 'Melakukan pekerjaan rekam medis - 60.0 menit', '60'),
('SKP00269', 'Melakukan Pelayanan Kesehatan Wanita - 20.0 menit', '20'),
('SKP00270', 'Melakukan pelayanan Pap Smear - 20.0 menit', '20'),
('SKP00271', 'Melakukan pelayaran sebagai ABK sesuai dengan prosedur pelayaran - 120.0 menit', '120'),
('SKP00272', 'Melakukan pelayaran sebagai ABK sesuai dengan prosedur pelayaran - 60.0 menit', '60'),
('SKP00273', 'Melakukan pembinaan / penilaian pegawai - 15.0 menit', '15'),
('SKP00274', 'Melakukan pemeliharaan kandang (per lokasi) - 30.0 menit', '30'),
('SKP00275', 'Melakukan pemeliharaan kandang (per lokasi) - 60.0 menit', '60'),
('SKP00276', 'Melakukan pemeliharaan kandang (per lokasi) - 120.0 menit', '120'),
('SKP00277', 'Melakukan pemeliharaan objek kerja - 30.0 menit', '30'),
('SKP00278', 'Melakukan pemeliharaan objek kerja - 60.0 menit', '60'),
('SKP00279', 'Melakukan pemeliharaan objek kerja - 45.0 menit', '45'),
('SKP00280', 'Melakukan pemeliharaan objek kerja - 15.0 menit', '15'),
('SKP00281', 'Melakukan Pemeliharaan Perangkat Keras / Lunak - 30.0 menit', '30'),
('SKP00282', 'Melakukan Pemeliharaan Perangkat Keras / Lunak - 60.0 menit', '60'),
('SKP00283', 'Melakukan pemerikasaan dan pengawasan - 120.0 menit', '120'),
('SKP00284', 'Melakukan pemerikasaan dan pengawasan - 60.0 menit', '60'),
('SKP00285', 'Melakukan pemeriksaan barang / dokumen / berkas - 3.0 menit', '3'),
('SKP00286', 'Melakukan pemeriksaan barang / dokumen / berkas - 5.0 menit', '5'),
('SKP00287', 'Melakukan pemeriksaan berdasarkan temuan, aduan, tangkap tangan - 120.0 menit', '120'),
('SKP00288', 'Melakukan pemeriksaan berdasarkan temuan, aduan, tangkap tangan - 60.0 menit', '60'),
('SKP00289', 'Melakukan pemeriksaan objek pasca bencana (banjir, kebakaran, gempa, dll) - 120.0 menit', '120'),
('SKP00290', 'Melakukan pemeriksaan objek pasca bencana (banjir, kebakaran, gempa, dll) - 180.0 menit', '180'),
('SKP00291', 'Melakukan pemeriksaan okupasi terapi (Formal kasus berat) - 15.0 menit', '15'),
('SKP00292', 'Melakukan pemeriksaan okupasi terapi ( Informal ) - 20.0 menit', '20'),
('SKP00293', 'Melakukan pemeriksaan terhadap alat-alat bukti - 10.0 menit', '10'),
('SKP00294', 'Melakukan pemeriksaan tes kekuatan otot - 15.0 menit', '15'),
('SKP00295', 'Melakukan Pemungutan / Penyetoran Pajak - 60.0 menit', '60'),
('SKP00296', 'Melakukan Pemungutan / Penyetoran Pajak - 30.0 menit', '30'),
('SKP00297', 'Melakukan Penanganan Masalah (Troubleshooting) pada Aplikasi / Sistem - 30.0 menit', '30'),
('SKP00298', 'Melakukan Penanganan Masalah (Troubleshooting) pada Aplikasi / Sistem - 60.0 menit', '60'),
('SKP00299', 'Melakukan penanggulangan KLB dan wabah - 30.0 menit', '30'),
('SKP00300', 'Melakukan penanggulangan KLB dan wabah - 15.0 menit', '15'),
('SKP00301', 'Melakukan penanggulangan KLB dan wabah - 60.0 menit', '60'),
('SKP00302', 'Melakukan pencairan SP2D - 30.0 menit', '30'),
('SKP00303', 'Melakukan Pencatatan dan pelayanan laboratorium - 60.0 menit', '60'),
('SKP00304', 'Melakukan pendampingan kegiatan - 60.0 menit', '60'),
('SKP00305', 'Melakukan pendampingan kegiatan - 180.0 menit', '180'),
('SKP00306', 'Melakukan pendampingan kegiatan - 30.0 menit', '30'),
('SKP00307', 'Melakukan pendampingan kegiatan - 120.0 menit', '120'),
('SKP00308', 'Melakukan pendampingan penyusunan Analisa jabatan, Analisa Beban Kerja dan Evaluasi Jabatan - 120.0 menit', '120'),
('SKP00309', 'Melakukan pendampingan penyusunan Analisa jabatan, Analisa Beban Kerja dan Evaluasi Jabatan - 60.0 menit', '60'),
('SKP00310', 'Melakukan pendampingan sidak (per lokasi sidak) - 120.0 menit', '120'),
('SKP00311', 'Melakukan pendampingan sidak (per lokasi sidak) - 60.0 menit', '60'),
('SKP00312', 'Melakukan pendataan - 60.0 menit', '60'),
('SKP00313', 'Melakukan pendataan - 30.0 menit', '30'),
('SKP00314', 'Melakukan pendataan - 120.0 menit', '120'),
('SKP00315', 'Melakukan pendataan - 90.0 menit', '90'),
('SKP00316', 'Melakukan pendistribusian barang - 60.0 menit', '60'),
('SKP00317', 'Melakukan pendistribusian barang - 30.0 menit', '30'),
('SKP00318', 'Melakukan pendistribusian barang - 15.0 menit', '15'),
('SKP00319', 'Melakukan pendistribusian barang - 120.0 menit', '120'),
('SKP00320', 'Melakukan penelitian - 30.0 menit', '30'),
('SKP00321', 'Melakukan penelitian - 15.0 menit', '15'),
('SKP00322', 'Melakukan penelitian - 60.0 menit', '60'),
('SKP00323', 'Melakukan Pengamanan / Pemantauan Data / Sistem - 120.0 menit', '120'),
('SKP00324', 'Melakukan Pengamanan / Pemantauan Data / Sistem - 60.0 menit', '60'),
('SKP00325', 'Melakukan Pengamatan dan Penggambaran terhadap target operasi - 60.0 menit', '60'),
('SKP00326', 'Melakukan Pengamatan dan Penggambaran terhadap target operasi - 30.0 menit', '30'),
('SKP00327', 'Melakukan pengambilan darah / sampling ke pasien - 5.0 menit', '5'),
('SKP00328', 'Melakukan pengaturan pada objek kerja - 15.0 menit', '15'),
('SKP00329', 'Melakukan pengaturan pada objek kerja - 60.0 menit', '60'),
('SKP00330', 'Melakukan pengaturan pada objek kerja - 30.0 menit', '30'),
('SKP00331', 'Melakukan pengaturan / pengelolaan objek kerja - 15.0 menit', '15'),
('SKP00332', 'Melakukan pengaturan / pengelolaan objek kerja - 30.0 menit', '30'),
('SKP00333', 'Melakukan pengaturan / setting router multiplayer / radio wireless / kamera / cctv (per objek) - 15.0 menit', '15'),
('SKP00334', 'Melakukan pengawasan - 60.0 menit', '60'),
('SKP00335', 'Melakukan pengawasan - 120.0 menit', '120'),
('SKP00336', 'Melakukan pengawasan - 30.0 menit', '30'),
('SKP00337', 'Melakukan pengawasan - 15.0 menit', '15'),
('SKP00338', 'Melakukan Pengawasan dan Audit - 60.0 menit', '60'),
('SKP00339', 'Melakukan Pengawasan dan Audit - 180.0 menit', '180'),
('SKP00340', 'Melakukan Pengawasan dan Audit - 120.0 menit', '120'),
('SKP00341', 'Melakukan pengecekan kelengkapan kapal sesuai prosedur dan arahan pimpinan - 60.0 menit', '60'),
('SKP00342', 'Melakukan pengecekan mutasi aset - 60.0 menit', '60'),
('SKP00343', 'Melakukan pengecekan mutasi aset - 120.0 menit', '120'),
('SKP00344', 'Melakukan pengecekan mutasi aset - 180.0 menit', '180'),
('SKP00345', 'Melakukan pengelolaan / pemeliharaan sistem aplikasi - 60.0 menit', '60'),
('SKP00346', 'Melakukan pengelolaan / pemeliharaan sistem aplikasi - 30.0 menit', '30'),
('SKP00347', 'Melakukan penghitungan terhadap objek kerja - 15.0 menit', '15'),
('SKP00348', 'Melakukan penghitungan terhadap objek kerja - 60.0 menit', '60'),
('SKP00349', 'Melakukan penghitungan terhadap objek kerja - 30.0 menit', '30'),
('SKP00350', 'Melakukan Pengkodean, Pendokumentasian dan Penyimpanan Hasil Uji - 20.0 menit', '20'),
('SKP00351', 'Melakukan Pengujian Atas Analisa Data pada Benda Cagar Budaya / Benda Seni (Per Benda) - 60.0 menit', '60'),
('SKP00352', 'Melakukan Pengujian Atas Analisa Data pada Benda Cagar Budaya / Benda Seni (Per Benda) - 30.0 menit', '30'),
('SKP00353', 'Melakukan pengukuran kapal nelayan untuk penetapan di bawah 7 GT (per kapal) - 60.0 menit', '60'),
('SKP00354', 'Melakukan Pengukuran Objek - 30.0 menit', '30'),
('SKP00355', 'Melakukan Pengukuran Objek - 60.0 menit', '60'),
('SKP00356', 'Melakukan Pengukuran Teknis Postel - 30.0 menit', '30'),
('SKP00357', 'Melakukan Pengukuran Teknis Postel - 120.0 menit', '120'),
('SKP00358', 'Melakukan Pengukuran Teknis Telekomunikasi dan Multimedia - 60.0 menit', '60'),
('SKP00359', 'Melakukan Pengukuran Teknis Telekomunikasi dan Multimedia - 30.0 menit', '30'),
('SKP00360', 'Melakukan penilaian - 60.0 menit', '60'),
('SKP00361', 'Melakukan penilaian - 30.0 menit', '30'),
('SKP00362', 'Melakukan penilaian - 120.0 menit', '120'),
('SKP00363', 'Melakukan penilaian - 10.0 menit', '10'),
('SKP00364', 'Melakukan penilaian angka kredit terhadap JFT - 60.0 menit', '60'),
('SKP00365', 'Melakukan penilaian dalam proses pengadaan barang / jasa - 60.0 menit', '60'),
('SKP00366', 'Melakukan penjilidan dan pendistribusian laporan keuangan - 60.0 menit', '60'),
('SKP00367', 'Melakukan penyegelan terhadap bangunan - 60.0 menit', '60'),
('SKP00368', 'Melakukan penyuluhan - 30.0 menit', '30'),
('SKP00369', 'Melakukan Perawatan Benda Cagar Budaya / Benda Seni - 60.0 menit', '60'),
('SKP00370', 'Melakukan Perawatan Benda Cagar Budaya / Benda Seni - 30.0 menit', '30'),
('SKP00371', 'Melakukan perbaikan objek kerja - 90.0 menit', '90'),
('SKP00372', 'Melakukan perbaikan objek kerja - 15.0 menit', '15'),
('SKP00373', 'Melakukan perbaikan objek kerja - 30.0 menit', '30'),
('SKP00374', 'Melakukan perbaikan objek kerja - 45.0 menit', '45'),
('SKP00375', 'Melakukan perbaikan objek kerja - 60.0 menit', '60'),
('SKP00376', 'Melakukan perbaikan objek kerja - 120.0 menit', '120'),
('SKP00377', 'Melakukan pointing arah antena sentral (per lokasi) - 30.0 menit', '30'),
('SKP00378', 'Melakukan Print Out Borderel, SKP dan TNKB - 60.0 menit', '60'),
('SKP00379', 'Melakukan Print Out Borderel, SKP dan TNKB - 30.0 menit', '30'),
('SKP00380', 'Melakukan proses kegiatan akreditasi - 30.0 menit', '30'),
('SKP00381', 'Melakukan QC, kalibrasi, persiapan reagen masing-masing alat kimia, hematologi, urinalisa, imunologi - 10.0 menit', '10'),
('SKP00382', 'Melakukan Rapat Rekonsiliasi dengan para bendahara pengeluaran - 120.0 menit', '120'),
('SKP00383', 'Melakukan Rapat Rekonsiliasi dengan para PPTK yang memiliki tagihan utang pada pihak ketiga - 120.0 menit', '120'),
('SKP00384', 'Melakukan Rapat Rekonsiliasi dengan pengurus barang dan penyimpan barang - 120.0 menit', '120'),
('SKP00385', 'Melakukan Recovery Data / Aplikasi / Sistem - 120.0 menit', '120'),
('SKP00386', 'Melakukan Recovery Data / Aplikasi / Sistem - 60.0 menit', '60'),
('SKP00387', 'Melakukan rekonsiliasi - 60.0 menit', '60'),
('SKP00388', 'Melakukan rekonsiliasi - 15.0 menit', '15'),
('SKP00389', 'Melakukan rekonsiliasi - 30.0 menit', '30'),
('SKP00390', 'Melakukan rekonsiliasi aset - 60.0 menit', '60'),
('SKP00391', 'Melakukan rekonsiliasi aset - 120.0 menit', '120'),
('SKP00392', 'Melakukan rekonsiliasi data / keuangan / aset - 180.0 menit', '180'),
('SKP00393', 'Melakukan rekonsiliasi data / keuangan / aset - 120.0 menit', '120'),
('SKP00394', 'Melakukan rekonsiliasi data / keuangan / aset - 60.0 menit', '60'),
('SKP00395', 'Melakukan rekonsiliasi data / keuangan / aset - 30.0 menit', '30'),
('SKP00396', 'Melakukan Rekonsiliasi Data per kegiatan - 30.0 menit', '30'),
('SKP00397', 'Melakukan rekonsiliasi Laporan Keuangan - 60.0 menit', '60'),
('SKP00398', 'Melakukan rekonsiliasi Laporan Keuangan - 30.0 menit', '30'),
('SKP00399', 'Melakukan rekonsiliasi Laporan Keuangan - 120.0 menit', '120'),
('SKP00400', 'Melakukan rekrutmen calon tenaga kerja untuk penempatan (per orang) - 60.0 menit', '60'),
('SKP00401', 'Melakukan rekrutmen calon tenaga kerja untuk penempatan (per orang) - 120.0 menit', '120'),
('SKP00402', 'Melakukan rekrutmen calon tenaga kerja untuk penempatan (per orang) - 30.0 menit', '30'),
('SKP00403', 'Melakukan reviu - 120.0 menit', '120'),
('SKP00404', 'Melakukan reviu - 60.0 menit', '30'),
('SKP00405', 'Melakukan reviu - 30.0 menit', '30'),
('SKP00406', 'Melakukan reviu - 180.0 menit', '180'),
('SKP00407', 'Melakukan rujukan - 60.0 menit', '60'),
('SKP00408', 'Melakukan screening palliative - 15.0 menit', '15'),
('SKP00409', 'Melakukan Seleksi Bahan Pustaka - 90.0 menit', '90'),
('SKP00410', 'Melakukan Seleksi Bahan Pustaka - 60.0 menit', '60'),
('SKP00411', 'Melakukan Start Up Aplikasi Online pada Mesin Mainframe - 30.0 menit', '30'),
('SKP00412', 'Melakukan Start Up Aplikasi Online pada Mesin Mainframe - 10.0 menit', '10'),
('SKP00413', 'Melakukan Stock Opname - 60.0 menit', '60'),
('SKP00414', 'Melakukan Stock Opname - 30.0 menit', '30'),
('SKP00415', 'Melakukan Stock Opname - 15.0 menit', '15'),
('SKP00416', 'Melakukan Stop Aplikasi Online pada Mesin Mainframe - 10.0 menit', '10'),
('SKP00417', 'Melakukan Stop Aplikasi Online pada Mesin Mainframe - 30.0 menit', '30'),
('SKP00418', 'Melakukan terapi pada kasus gangguan jiwa / psikososial tingkat sedang kelompok relaksasi / interaksi sosial - 60.0 menit', '60'),
('SKP00419', 'Melakukan terapi pada kasus gangguan jiwa / psikososial tingkat sedang kelompok relaksasi / interaksi sosial - 30.0 menit', '30'),
('SKP00420', 'Melakukan tindakan darurat medik gigi dan mulut kompleks tingkat I - 60.0 menit', '60'),
('SKP00421', 'Melakukan tindakan komplek medis - 120.0 menit', '120'),
('SKP00422', 'Melakukan tindakan komplek medis - 180.0 menit', '180'),
('SKP00423', 'Melakukan tindakan operasi medis - 120.0 menit', '120'),
('SKP00424', 'Melakukan tindakan operasi medis - 90.0 menit', '90'),
('SKP00425', 'Melakukan tindakan processing film - 15.0 menit', '15'),
('SKP00426', 'Melakukan tindakan proteksi radiasi / kalibrasi - 60.0 menit', '60'),
('SKP00427', 'Melakukan tindakan proteksi radiasi / kalibrasi - 15.0 menit', '15'),
('SKP00428', 'Melakukan tindakan proteksi radiasi / kalibrasi - 30.0 menit', '30'),
('SKP00429', 'Melakukan tindakan proteksi radiasi / kalibrasi - 180.0 menit', '180'),
('SKP00430', 'Melakukan tindakan radiologi - 30.0 menit', '30'),
('SKP00431', 'Melakukan tindakan radiologi - 15.0 menit', '15'),
('SKP00432', 'Melakukan tindakan teknik pemeriksaan radiologi USG - 15.0 menit', '15'),
('SKP00433', 'Melakukan tindakan teknik pemeriksaan radiologi USG - 30.0 menit', '30'),
('SKP00434', 'Melakukan tindakan terapi pada problem gerak dan fungsi pada tumbuh kembang anak kasus sedang - 30.0 menit', '30'),
('SKP00435', 'Melakukan tindakan / terapi pengobatan - 15.0 menit', '15'),
('SKP00436', 'Melakukan tindakan / terapi pengobatan - 60.0 menit', '60'),
('SKP00437', 'Melakukan tindakan / terapi pengobatan - 30.0 menit', '30'),
('SKP00438', 'Melakukan transfer pasien antara unit - 5.0 menit', '5'),
('SKP00439', 'Melakukan transfer pasien antara unit - 30.0 menit', '30'),
('SKP00440', 'Melakukan transfer pasien antara unit - 15.0 menit', '15'),
('SKP00441', 'Melakukan uji coba - 120.0 menit', '120'),
('SKP00442', 'Melakukan uji coba - 30.0 menit', '30'),
('SKP00443', 'Melakukan uji coba - 60.0 menit', '60'),
('SKP00444', 'Melakukan Update Berita pada Website - 10.0 menit', '10'),
('SKP00445', 'Melakukan Up Date Data - 15.0 menit', '15'),
('SKP00446', 'Melakukan Up Date Data - 60.0 menit', '60'),
('SKP00447', 'Melakukan Up Date Data - 30.0 menit', '30'),
('SKP00448', 'Melakukan usulan komponen per kode rekening kegiatan - 20.0 menit', '20'),
('SKP00449', 'Melakukan validasi Anggaran per kode rekening kegiatan - 20.0 menit', '20'),
('SKP00450', 'Melakukan validasi Anggaran per kode rekening kegiatan - 30.0 menit', '30'),
('SKP00451', 'Melakukan validasi Anggaran per kode rekening kegiatan - 10.0 menit', '10'),
('SKP00452', 'Melakukan validasi data - 5.0 menit', '5'),
('SKP00453', 'Melakukan validasi data - 15.0 menit', '15'),
('SKP00454', 'Melakukan validasi / verifikasi Analisa Jabatan / Analisa Beban Kerja / Evaluasi Jabatan SKPD / UKPD - 60.0 menit', '60'),
('SKP00455', 'Melakukan validasi / verifikasi Analisa Jabatan / Analisa Beban Kerja / Evaluasi Jabatan SKPD / UKPD - 90.0 menit', '90'),
('SKP00456', 'Melakukan validasi / verifikasi Kelas Jabatan / Nama Jabatan / Formasi Jabatan - 60.0 menit', '60'),
('SKP00457', 'Melakukan validasi / verifikasi Kelas Jabatan / Nama Jabatan / Formasi Jabatan - 30.0 menit', '30'),
('SKP00458', 'Melakukan validasi / verifikasi nama jabatan SKPD / UKPD - 90.0 menit', '90'),
('SKP00459', 'Melakukan validasi / verifikasi nama jabatan SKPD / UKPD - 60.0 menit', '60'),
('SKP00460', 'Melakukan verifikasi dan validasi - 60.0 menit', '60'),
('SKP00461', 'Melakukan verifikasi dan validasi - 15.0 menit', '15'),
('SKP00462', 'Melakukan verifikasi dan validasi - 30.0 menit', '30'),
('SKP00463', 'Melakukan verifikasi gambar perencanaan - 60.0 menit', '60'),
('SKP00464', 'Melakukan verifikasi gambar perencanaan - 30.0 menit', '30'),
('SKP00465', 'Melakukan visum et repertum - 60.0 menit', '60'),
('SKP00466', 'Melakukan visum et repertum - 120.0 menit', '120'),
('SKP00467', 'Melaporkan dan mempertanggungjawabkan pengeluaran Anggaran APBD / APBN ke BPKD, Inspektorat dan Kementerian Keuangan - 30.0 menit', '30'),
('SKP00468', 'Melaporkan hasil kegiatan kepada pimpinan - 15.0 menit', '15'),
('SKP00469', 'Melaporkan hasil kegiatan kepada pimpinan - 10.0 menit', '10'),
('SKP00470', 'Melatih satwa - 30.0 menit', '30'),
('SKP00471', 'Meliput acara - 60.0 menit', '60'),
('SKP00472', 'Memandikan Warga Binaan Sosial (WBS) - 30.0 menit', '30'),
('SKP00473', 'Memandu atraksi satwa - 30.0 menit', '30'),
('SKP00474', 'Memantau pasien - 5.0 menit', '5'),
('SKP00475', 'Memaraf Perbal - 5.0 menit', '5'),
('SKP00476', 'Memaraf Perbal - 2.0 menit', '2'),
('SKP00477', 'Memasang alat kontrasepsi - 20.0 menit', '20'),
('SKP00478', 'Memasang tanda legalitas mendirikan bangunan - 60.0 menit', '60'),
('SKP00479', 'Membawakan acara / MC (Per kegiatan) - 60.0 menit', '60'),
('SKP00480', 'Memberi arahan - 60.0 menit', '60'),
('SKP00481', 'Memberi arahan - 30.0 menit', '30'),
('SKP00482', 'Memberikan asistensi kepada pasien dalam terapi kelompok musculoskeletal (per 1 pasien) - 45.0 menit', '45'),
('SKP00483', 'Memberikan disposisi kepada bawahan - 3.0 menit', '3'),
('SKP00484', 'Memberikan disposisi kepada bawahan - 5.0 menit', '5'),
('SKP00485', 'Memberikan Informasi Layanan Publik - 5.0 menit', '5'),
('SKP00486', 'Memberikan Informasi Layanan Publik - 10.0 menit', '10'),
('SKP00487', 'Memberikan informasi status proses berkas perizinan dan non perizinan - 5.0 menit', '5'),
('SKP00488', 'Memberikan informasi terkait hasil verifikasi berkas perizinan dan non perizinan - 5.0 menit', '5'),
('SKP00489', 'Memberikan Informasi User ID dari Aplikasi SPSE - 20.0 menit', '20'),
('SKP00490', 'Memberikan keterangan mewakili pemerintah provinsi DKI Jakarta kepada pihak berwajib - 180.0 menit', '180'),
('SKP00491', 'Memberikan keterangan mewakili pemerintah provinsi DKI Jakarta kepada pihak berwajib - 60.0 menit', '60'),
('SKP00492', 'Memberikan keterangan mewakili pemerintah provinsi DKI Jakarta kepada pihak berwajib - 120.0 menit', '120'),
('SKP00493', 'Memberikan resep obat / pasien - 1.0 menit', '1'),
('SKP00494', 'Membimbing mahasiswa / peserta Diklat - 30.0 menit', '30'),
('SKP00495', 'Membimbing pelaksanaan Pelayanan kesehatan olahraga dan kebugaran - 15.0 menit', '15'),
('SKP00496', 'Membimbing pelaksanaan Pelayanan kesehatan olahraga dan kebugaran - 30.0 menit', '30'),
('SKP00497', 'Membuat algoritma pemrograman per modul - 60.0 menit', '60'),
('SKP00498', 'Membuat algoritma pemrograman per modul - 30.0 menit', '30'),
('SKP00499', 'Membuat algoritma pemrograman per modul - 60.0 menit', '60'),
('SKP00500', 'Membuat atau memperbaiki pengkayaan kandang (enrichment) - 60.0 menit', '60'),
('SKP00501', 'Membuat Berita Acara - 60.0 menit', '60'),
('SKP00502', 'Membuat Berita Acara - 120.0 menit', '120'),
('SKP00503', 'Membuat Berita Acara - 30.0 menit', '30'),
('SKP00504', 'Membuat bestek - 60.0 menit', '60'),
('SKP00505', 'Membuat bestek - 120.0 menit', '120'),
('SKP00506', 'Membuat buku induk inventaris (BII) - 30.0 menit', '30'),
('SKP00507', 'Membuat buku inventaris (BI) - 30.0 menit', '30'),
('SKP00508', 'Membuat catatan medik gigi dan mulut pasien rawat inap / jalan - 5.0 menit', '5'),
('SKP00509', 'Membuat catatan medik gigi dan mulut pasien rawat inap / jalan - 15.0 menit', '15'),
('SKP00510', 'Membuat catatan medik (per pasien) - 5.0 menit', '5'),
('SKP00511', 'Membuat daftar gaji / tunjangan / penghasilan lainnya - 120.0 menit', '120'),
('SKP00512', 'Membuat daftar gaji / tunjangan / penghasilan lainnya - 30.0 menit', '30'),
('SKP00513', 'Membuat daftar gaji / tunjangan / penghasilan lainnya - 60.0 menit', '60'),
('SKP00514', 'Membuat daftar menu - 60.0 menit', '60'),
('SKP00515', 'Membuat daftar menu - 15.0 menit', '15'),
('SKP00516', 'Membuat daftar menu - 30.0 menit', '30'),
('SKP00517', 'Membuat Daftar Usulan Penilaian Angka Kredit (DUPAK) - 30.0 menit', '30'),
('SKP00518', 'Membuat dan melaporkan SPT kepada Kantor Pelayanan Pajak - 30.0 menit', '30'),
('SKP00519', 'Membuat dan melaporkan SPT kepada Kantor Pelayanan Pajak - 60.0 menit', '60'),
('SKP00520', 'Membuat dan memasang Nomor Ujian (per objek) - 5.0 menit', '5'),
('SKP00521', 'Membuat dan menempel barcode aset tetap SKPD / UKPD - 5.0 menit', '5'),
('SKP00522', 'Membuat data kunjungan mancanegara - 30.0 menit', '30'),
('SKP00523', 'Membuat Detail Engineering Drawing (DED) konstruksi fisik - 180.0 menit', '180'),
('SKP00524', 'Membuat Detail Engineering Drawing (DED) konstruksi fisik - 120.0 menit', '120'),
('SKP00525', 'Membuat Detail Engineering Drawing (DED) konstruksi fisik - 90.0 menit', '90'),
('SKP00526', 'Membuat File PDF Perda / Pergub - 5.0 menit', '5'),
('SKP00527', 'Membuat gambar perencanaan - 120.0 menit', '120'),
('SKP00528', 'Membuat gambar perencanaan - 60.0 menit', '60'),
('SKP00529', 'Membuat gugatan / jawaban / replik / duplik / akta bukti / kesimpulan untuk persidangan di pengadilan - 60.0 menit', '60'),
('SKP00530', 'Membuat gugatan / jawaban / replik / duplik / akta bukti / kesimpulan untuk persidangan di pengadilan - 180.0 menit', '180'),
('SKP00531', 'Membuat gugatan / jawaban / replik / duplik / akta bukti / kesimpulan untuk persidangan di pengadilan - 120.0 menit', '120'),
('SKP00532', 'Membuat Instruksi Gubernur - 60.0 menit', '60'),
('SKP00533', 'Membuat Instruksi Gubernur - 30.0 menit', '30'),
('SKP00534', 'Membuat Instruksi Gubernur - 90.0 menit', '90'),
('SKP00535', 'Membuat instruksi Kepala SKPD / UKPD - 60.0 menit', '60'),
('SKP00536', 'Membuat instruksi Kepala SKPD / UKPD - 30.0 menit', '30'),
('SKP00537', 'Membuat instruksi Sekertaris Daerah - 30.0 menit', '30'),
('SKP00538', 'Membuat instruksi Sekertaris Daerah - 60.0 menit', '60'),
('SKP00539', 'Membuat instruksi Sekertaris Daerah - 90.0 menit', '90'),
('SKP00540', 'Membuat inventaris barang ( KIB) - 30.0 menit', '30'),
('SKP00541', 'Membuat jadwal kegiatan - 15.0 menit', '15'),
('SKP00542', 'Membuat jadwal kegiatan - 30.0 menit', '30'),
('SKP00543', 'Membuat jawaban - 120.0 menit', '120'),
('SKP00544', 'Membuat jawaban - 30.0 menit', '30'),
('SKP00545', 'Membuat jawaban - 60.0 menit', '60'),
('SKP00546', 'Membuat jurnal / catatan kondisi kapal secara berkala sesuai prosedur dan arahan pimpinan agar dapat mengetahui kondisi kapal - 45.0 menit', '45'),
('SKP00547', 'Membuat Karya Ilmiah / Makalah - 120.0 menit', '120'),
('SKP00548', 'Membuat karya tulis / karya ilmiah hasil pengkajian di bidang pengawasan yang dipublikasikan dalam bentuk buku yang diterbitkan dan diedarkan secara nasional / ', '120'),
('SKP00549', 'Membuat Kliping Berita - 30.0 menit', '30'),
('SKP00550', 'Membuat Kliping Berita - 15.0 menit', '15'),
('SKP00551', 'Membuat konsep expose - 60.0 menit', '60'),
('SKP00552', 'Membuat konsep expose - 30.0 menit', '30'),
('SKP00553', 'Membuat konsep keputusan gubernur kenaikan gaji berkala / pangkat / pensiun / PNS / CPNS / Mutasi - 30.0 menit', '30'),
('SKP00554', 'Membuat konsep keputusan gubernur kenaikan gaji berkala / pangkat / pensiun / PNS / CPNS / Mutasi - 60.0 menit', '60'),
('SKP00555', 'Membuat konsep Lakip Kota (asumsi bahan lengkap) - 180.0 menit', '180'),
('SKP00556', 'Membuat konsep Lakip Kota (asumsi bahan lengkap) - 120.0 menit', '120'),
('SKP00557', 'Membuat konsep Lakip Kota (asumsi bahan lengkap) - 60.0 menit', '60'),
('SKP00558', 'Membuat konsep MOU / perjanjian / kontrak - 120.0 menit', '120'),
('SKP00559', 'Membuat konsep MOU / perjanjian / kontrak - 30.0 menit', '30'),
('SKP00560', 'Membuat MOU / perjanjian / kontrak - 60.0 menit', '60'),
('SKP00561', 'Membuat Konsep Perhitungan Masa Kerja dan Jumlah Besaran Hak Pensiun atas Permintaan Sendiri - 5.0 menit', '5'),
('SKP00562', 'Membuat konsep Surat Dinas / Nota Dinas - 15.0 menit', '15'),
('SKP00563', 'Membuat konsep Surat Dinas / Nota Dinas - 30.0 menit', '30'),
('SKP00564', 'Membuat konsep Surat Dinas / Nota Dinas - 60.0 menit', '60'),
('SKP00565', 'Membuat konsep Surat Dinas / Nota Dinas - 45.0 menit', '45'),
('SKP00566', 'Membuat konsep Surat Edaran Gubernur - 60.0 menit', '60'),
('SKP00567', 'Membuat konsep Surat Edaran Sekretaris Daerah - 120.0 menit', '120'),
('SKP00568', 'Membuat konsep Surat Edaran Sekretaris Daerah - 90.0 menit', '90'),
('SKP00569', 'Membuat konsep Surat Edaran Sekretaris Daerah - 60.0 menit', '60'),
('SKP00570', 'Membuat konsep Surat Keputusan / Penetapan - 60.0 menit', '60'),
('SKP00571', 'Membuat konsep Surat Keputusan / Penetapan - 30.0 menit', '30'),
('SKP00572', 'Membuat konsep TOR atau KAK - 120.0 menit', '120'),
('SKP00573', 'Membuat konsep TOR atau KAK - 60.0 menit', '60'),
('SKP00574', 'Membuat laporan - 180.0 menit', '180'),
('SKP00575', 'Membuat laporan - 120.0 menit', '120'),
('SKP00576', 'Membuat laporan - 15.0 menit', '15'),
('SKP00577', 'Membuat laporan - 30.0 menit', '30'),
('SKP00578', 'Membuat laporan - 60.0 menit', '60'),
('SKP00579', 'Membuat Laporan Penggunaan Barang Pakai Habis (ATK, Obat, Alkes) - 30.0 menit', '30'),
('SKP00580', 'Membuat laporan Realisasi Keuangan - 120.0 menit', '120'),
('SKP00581', 'Membuat Media Pembelajaran / pelatihan dan bimbingan Pendidikan - 120.0 menit', '120'),
('SKP00582', 'Membuat Media Pembelajaran / pelatihan dan bimbingan Pendidikan - 90.0 menit', '90'),
('SKP00583', 'Membuat / melaksanakan administrasi - 15.0 menit', '15'),
('SKP00584', 'Membuat / melaksanakan administrasi - 30.0 menit', '30'),
('SKP00585', 'Membuat / melaksanakan administrasi - 60.0 menit', '60'),
('SKP00586', 'Membuat / menyiapkan bahan paparan - 60.0 menit', '60'),
('SKP00587', 'Membuat / menyiapkan bahan paparan - 30.0 menit', '30'),
('SKP00588', 'Membuat / menyiapkan bahan paparan - 120.0 menit', '120'),
('SKP00589', 'Membuat / menyusun Standar Operasional Prosedur (SOP) - 180.0 menit', '180'),
('SKP00590', 'Membuat / menyusun Standar Operasional Prosedur (SOP) - 60.0 menit', '60'),
('SKP00591', 'Membuat / menyusun Standar Operasional Prosedur (SOP) - 30.0 menit', '30'),
('SKP00592', 'Membuat notulen rapat - 20.0 menit', '20'),
('SKP00593', 'Membuat notulen rapat - 30.0 menit', '30'),
('SKP00594', 'Membuat notulen rapat - 45.0 menit', '45'),
('SKP00595', 'Membuat notulen rapat - 60.0 menit', '60'),
('SKP00596', 'Membuat otorisasi akses database - 15.0 menit', '15'),
('SKP00597', 'Membuat otorisasi akses database - 60.0 menit', '60'),
('SKP00598', 'Membuat otorisasi akses database - 30.0 menit', '30'),
('SKP00599', 'Membuat Pakta Integritas - 15.0 menit', '15'),
('SKP00600', 'Membuat Pakta Integritas - 5.0 menit', '5'),
('SKP00601', 'Membuat Penatausahaan Keuangan oleh bendahara dan PPK SKPD - 15.0 menit', '15'),
('SKP00602', 'Membuat Penetapan / penunjukan Penyedia barang / Jasa - 30.0 menit', '30'),
('SKP00603', 'Membuat Penetapan / penunjukan Penyedia barang / Jasa - 15.0 menit', '15'),
('SKP00604', 'Membuat penetapan terhadap pemutusan pelaksanaan Pengadaan Barang / Jasa - 60.0 menit', '60'),
('SKP00605', 'Membuat penetapan terhadap pemutusan pelaksanaan Pengadaan Barang / Jasa - 30.0 menit', '30'),
('SKP00606', 'Membuat pengumuman dan upload dokumen rencana umum pengadaan Barang / Jasa (per kegiatan) - 15.0 menit', '15'),
('SKP00607', 'Membuat perbaikan / koreksi Peraturan Perundang-undangan - 60.0 menit', '60'),
('SKP00608', 'Membuat perbaikan / koreksi Peraturan Perundang-undangan - 30.0 menit', '30'),
('SKP00609', 'Membuat perbaikan / koreksi Peraturan Perundang-undangan - 120.0 menit', '120'),
('SKP00610', 'Membuat perbaikan / koreksi / revisi objek kerja - 15.0 menit', '15'),
('SKP00611', 'Membuat perbaikan / koreksi / revisi objek kerja - 30.0 menit', '30'),
('SKP00612', 'Membuat perbaikan / koreksi / revisi objek kerja - 60.0 menit', '60'),
('SKP00613', 'Membuat perbaikan Surat Keputusan - 30.0 menit', '30'),
('SKP00614', 'Membuat perbaikan Surat Keputusan - 15.0 menit', '15'),
('SKP00615', 'Membuat perbaikan Surat Keputusan - 60.0 menit', '60'),
('SKP00616', 'Membuat perbal naskah dinas - 10.0 menit', '10'),
('SKP00617', 'Membuat perbal Peraturan Gubernur - 15.0 menit', '15'),
('SKP00618', 'Membuat perencanaan kebutuhan, penempatan, mutasi, pengembangan kompetensi pegawai - 30.0 menit', '30');
INSERT INTO `skp` (`kd_skp`, `skp`, `waktu`) VALUES
('SKP00619', 'Membuat peta - 60.0 menit', '60'),
('SKP00620', 'Membuat peta - 30.0 menit', '30'),
('SKP00621', 'Membuat pointers / agenda rapat - 30.0 menit', '30'),
('SKP00622', 'Membuat pointers / agenda rapat - 15.0 menit', '15'),
('SKP00623', 'Membuat press release - 60.0 menit', '60'),
('SKP00624', 'Membuat press release - 30.0 menit', '30'),
('SKP00625', 'Membuat program fisioterapi - 15.0 menit', '15'),
('SKP00626', 'Membuat program fisioterapi - 60.0 menit', '60'),
('SKP00627', 'Membuat program fisioterapi - 30.0 menit', '30'),
('SKP00628', 'Membuat rancangan aplikasi / sistem informasi lainnya - 60.0 menit', '60'),
('SKP00629', 'Membuat rancangan aplikasi / sistem informasi lainnya - 90.0 menit', '90'),
('SKP00630', 'Membuat Rancangan Keputusan Gubernur - 30.0 menit', '30'),
('SKP00631', 'Membuat Rancangan Keputusan Gubernur - 120.0 menit', '120'),
('SKP00632', 'Membuat Rancangan Keputusan Gubernur - 60.0 menit', '60'),
('SKP00633', 'Membuat rancangan Peraturan Daerah - 120.0 menit', '120'),
('SKP00634', 'Membuat rancangan Peraturan Daerah - 180.0 menit', '180'),
('SKP00635', 'Membuat rancangan Peraturan Daerah - 240.0 menit', '240'),
('SKP00636', 'Membuat rancangan Peraturan Gubernur - 60.0 menit', '60'),
('SKP00637', 'Membuat rancangan Peraturan Gubernur - 180.0 menit', '180'),
('SKP00638', 'Membuat rancangan Peraturan Gubernur - 120.0 menit', '120'),
('SKP00639', 'Membuat rekapitulasi data - 60.0 menit', '60'),
('SKP00640', 'Membuat rekapitulasi data - 120.0 menit', '120'),
('SKP00641', 'Membuat rekapitulasi data - 30.0 menit', '30'),
('SKP00642', 'Membuat Rencana Kerja Bidang Pendidikan - 60.0 menit', '60'),
('SKP00643', 'Membuat Rencana Kerja Bidang Pendidikan - 120.0 menit', '120'),
('SKP00644', 'Membuat RENJA - 180.0 menit', '180'),
('SKP00645', 'Membuat RENJA - 60.0 menit', '60'),
('SKP00646', 'Membuat RENJA - 120.0 menit', '120'),
('SKP00647', 'Membuat RENSTRA - 120.0 menit', '120'),
('SKP00648', 'Membuat RENSTRA - 60.0 menit', '60'),
('SKP00649', 'Membuat RENSTRA - 180.0 menit', '180'),
('SKP00650', 'Membuat resep - 1.0 menit', '1'),
('SKP00651', 'Membuat sambutan / pidato pejabat - 30.0 menit', '30'),
('SKP00652', 'Membuat sambutan / pidato pejabat - 15.0 menit', '15'),
('SKP00653', 'Membuat Sasaran Kerja Pegawai - 30.0 menit', '30'),
('SKP00654', 'Membuat sistem / aplikasi IT - 60.0 menit', '60'),
('SKP00655', 'Membuat sistem / aplikasi IT - 120.0 menit', '120'),
('SKP00656', 'Membuat SK Petikan (per 1 SK) - 3.0 menit', '3'),
('SKP00657', 'Membuat soal ujian - 60.0 menit', '60'),
('SKP00658', 'Membuat soal ujian - 120.0 menit', '120'),
('SKP00659', 'Membuat SPM - 15.0 menit', '15'),
('SKP00660', 'Membuat SPT Pajak Tahunan Pegawai - 10.0 menit', '10'),
('SKP00661', 'Membuat Surat Edaran - 30.0 menit', '30'),
('SKP00662', 'Membuat Surat Edaran - 60.0 menit', '60'),
('SKP00663', 'Membuat Surat Gugatan / Memori atau Kontra Memori - 300.0 menit', '300'),
('SKP00664', 'Membuat surat jawaban atas pengaduan masyarakat - 60.0 menit', '60'),
('SKP00665', 'Membuat Surat Pengantar Rekomendasi Teknis ke instansi terkait sesuai dengan bidang perizinan - 30.0 menit', '30'),
('SKP00666', 'Membuat Surat Penyediaan Dana (SPD) - 30.0 menit', '30'),
('SKP00667', 'Membuat Surat Perintah Pencairan (SPP) - 30.0 menit', '30'),
('SKP00668', 'Membuat Surat Pernyataan Pelantikan - 5.0 menit', '5'),
('SKP00669', 'Membuat Surat Setoran Pajak (SSP) - 10.0 menit', '10'),
('SKP00670', 'Membuat Surat Tanda Setoran (STS) - 10.0 menit', '10'),
('SKP00671', 'Membuat Surat Teguran - 30.0 menit', '30'),
('SKP00672', 'Membuat terjemahan / menyadur buku dan bahan lainnya - 30.0 menit', '30'),
('SKP00673', 'Membuat transkrip nilai peserta pelatihan per kegiatan - 30.0 menit', '30'),
('SKP00674', 'Membuat transkrip nilai peserta pelatihan per kegiatan - 60.0 menit', '60'),
('SKP00675', 'Membuat uji kelayakan terhadap objek kerja - 30.0 menit', '30'),
('SKP00676', 'Membuat uji kelayakan terhadap objek kerja - 60.0 menit', '60'),
('SKP00677', 'Membuat user ID baru pada aplikasi - 15.0 menit', '15'),
('SKP00678', 'Membuka / menutup rincian kegiatan SKPD / UKPD dalam sistem informasi - 5.0 menit', '5'),
('SKP00679', 'Memelihara peralatan operasional truk / bis / kendaraan lain - 60.0 menit', '60'),
('SKP00680', 'Memeriksa dan mencocokan nomor kendaraan yang meninggalkan areal parkir - 2.0 menit', '2'),
('SKP00681', 'Memeriksa dan mengklasifikasikan bahan dan data objek kerja - 10.0 menit', '10'),
('SKP00682', 'Memeriksa dokumen kapal nelayan / bakgan / kapal tradisonal (per kapal) - 30.0 menit', '30'),
('SKP00683', 'Memeriksa keadaan muatan sesuai prosedur yg berlaku untuk kelancaran pelaksanan pelayaran - 30.0 menit', '30'),
('SKP00684', 'Memeriksa kelengkapan surat / dokumen - 15.0 menit', '15'),
('SKP00685', 'Memeriksa kelengkapan surat / dokumen - 30.0 menit', '30'),
('SKP00686', 'Memeriksa kelengkapan surat / dokumen - 10.0 menit', '10'),
('SKP00687', 'Memeriksa kelengkapan surat / dokumen - 5.0 menit', '5'),
('SKP00688', 'Memeriksa kelengkapan surat kendaraan bermotor (Per 1 dokumen) - 15.0 menit', '15'),
('SKP00689', 'Memeriksa / meneliti hasil kegiatan / kerja - 15.0 menit', '15'),
('SKP00690', 'Memeriksa / meneliti hasil kegiatan / kerja - 30.0 menit', '30'),
('SKP00691', 'Memfasilitasi Permintaan Dari PA / KPA / PPK / ULP / Pejabat Pengadaan Berkaitan Dengan Blacklist Terhadap Penyedia Barang / Jasa - 30.0 menit', '30'),
('SKP00692', 'Memimpin rapat - 30.0 menit', '30'),
('SKP00693', 'Memimpin rapat - 120.0 menit', '120'),
('SKP00694', 'Memimpin rapat - 180.0 menit', '180'),
('SKP00695', 'Memimpin rapat - 60.0 menit', '60'),
('SKP00696', 'Mempelajari / membuat resume peraturan - 60.0 menit', '60'),
('SKP00697', 'Memperbaiki / memeriksa objek kerja - 30.0 menit', '30'),
('SKP00698', 'Memperbaiki / memeriksa objek kerja - 5.0 menit', '5'),
('SKP00699', 'Memperbaiki / memeriksa objek kerja - 15.0 menit', '15'),
('SKP00700', 'Memperbaiki / memeriksa objek kerja - 60.0 menit', '60'),
('SKP00701', 'Mempersiapkan acara / kegiatan - 120.0 menit', '120'),
('SKP00702', 'Mempersiapkan acara / kegiatan - 60.0 menit', '60'),
('SKP00703', 'Mempersiapkan acara / kegiatan - 30.0 menit', '30'),
('SKP00704', 'Mempersiapkan acara / kegiatan - 90.0 menit', '90'),
('SKP00705', 'Mempersiapkan alat kerja - 5.0 menit', '5'),
('SKP00706', 'Mempersiapkan alat kerja - 15.0 menit', '15'),
('SKP00707', 'Mempersiapkan alat kerja - 30.0 menit', '30'),
('SKP00708', 'Mempersiapkan operasional pertunjukan - 30.0 menit', '30'),
('SKP00709', 'Mempersiapkan peralatan dan bahan penunjang untuk pengambilan spesimen / sample Laboratorium - 5.0 menit', '5'),
('SKP00710', 'Mempersiapkan ruangan dan peralatan dalam kondisi siap pakai (Kasus berat okupasi terapi) - 5.0 menit', '5'),
('SKP00711', 'Memposting data usulan komponen / kode rekening SKPD / UKPD (per 10 item) - 15.0 menit', '15'),
('SKP00712', 'Memungut dan menyetorkan Pajak yang ditarik dari Pihak Ketiga ke Kantor Pajak - 60.0 menit', '60'),
('SKP00713', 'Memvalidasi dokumen Surat Permintaan Pembayaran (SPP) dan Laporan Keuangan - 180.0 menit', '180'),
('SKP00714', 'Memvalidasi dokumen Surat Permintaan Pembayaran (SPP) dan Laporan Keuangan - 60.0 menit', '60'),
('SKP00715', 'Memvalidasi dokumen Surat Permintaan Pembayaran (SPP) dan Laporan Keuangan - 120.0 menit', '120'),
('SKP00716', 'Memverifikasi / meneliti / memvalidasi / memaraf dokumen terkait penerbitan Surat Penyediaan Dana (SPD) - 15.0 menit', '15'),
('SKP00717', 'Memverifikasi / meneliti / memvalidasi / memaraf dokumen terkait penerbitan Surat Penyediaan Dana (SPD) - 5.0 menit', '5'),
('SKP00718', 'Memverifikasi / meneliti / memvalidasi / memaraf dokumen terkait penerbitan Surat Penyediaan Dana (SPD) - 10.0 menit', '10'),
('SKP00719', 'Memverifikasi penatausahaan keuangan oleh bendahara dan PPK SKPD - 20.0 menit', '20'),
('SKP00720', 'Memverifikasi Penetapan Angka Kredit (PAK) Jabatan Fungsional Tertentu - 60.0 menit', '60'),
('SKP00721', 'Memverifikasi Penetapan Angka Kredit (PAK) Jabatan Fungsional Tertentu - 15.0 menit', '15'),
('SKP00722', 'Memverifikasi Penetapan Angka Kredit (PAK) Jabatan Fungsional Tertentu - 30.0 menit', '30'),
('SKP00723', 'Memverifikasi usulan masyarakat hasil Musrenbang Kecamatan melalui website e-Musrenbang DKI - 30.0 menit', '30'),
('SKP00724', 'Memverifikasi usulan Standar Satuan Harga (SSH) / Analisis Standar Biaya (ASB) (per 2 SSH) - 10.0 menit', '10'),
('SKP00725', 'Menaklik Tiknet Perbal Naskah Dinas - 60.0 menit', '60'),
('SKP00726', 'Menaklik Tiknet Perbal Naskah Dinas - 30.0 menit', '30'),
('SKP00727', 'Menanam pohon / tumbuhan / bibit (per lokasi) - 120.0 menit', '120'),
('SKP00728', 'Menanam pohon / tumbuhan / bibit (per lokasi) - 60.0 menit', '60'),
('SKP00729', 'Menanam pohon / tumbuhan / bibit (per lokasi) - 30.0 menit', '30'),
('SKP00730', 'Menandatangani / memaraf Surat Kedinasan / dokumen / petikan - 10.0 menit', '10'),
('SKP00731', 'Menandatangani / memaraf Surat Kedinasan / dokumen / petikan - 5.0 menit', '5'),
('SKP00732', 'Menata Koleksi Bahan Pustaka - 30.0 menit', '30'),
('SKP00733', 'Menata / Menyusun Arsip - 5.0 menit', '5'),
('SKP00734', 'Menata / Menyusun Arsip - 60.0 menit', '30'),
('SKP00735', 'Menata / Menyusun Arsip - 15.0 menit', '15'),
('SKP00736', 'Mencatat BKU (per transaksi) - 2.0 menit', '2'),
('SKP00737', 'Mencatat dan Membukukan Buku Kas Umum (BKU) dan Buku Pembantu Lainnya - 5.0 menit', '5'),
('SKP00738', 'Mencatat dan menghitung waktu tunggu pasien rawat inap - 15.0 menit', '15'),
('SKP00739', 'Mencatat dan menghitung waktu tunggu pasien rawat inap - 10.0 menit', '10'),
('SKP00740', 'Mencatat dan menghitung waktu tunggu pasien rawat inap - 5.0 menit', '5'),
('SKP00741', 'Mencatat transaksi pembayaran via Bendahara Pengeluaran Pembantu - 30.0 menit', '30'),
('SKP00742', 'Mencetak - 0.1 menit', '1'),
('SKP00743', 'Mencetak - 0.2 menit', '2'),
('SKP00744', 'Mencetak hasil input Renja melalui sistem informasi - 5.0 menit', '5'),
('SKP00745', 'Mencetak Perda sebagai bahan APBD / APBD Perubahan - 10.0 menit', '10'),
('SKP00746', 'Mencetak Pergub sebagai bahan APBD / APBD Perubahan - 10.0 menit', '10'),
('SKP00747', 'Mendampingi kegiatan pelatihan keterampilan - 120.0 menit', '120'),
('SKP00748', 'Mendampingi kegiatan pelatihan keterampilan - 60.0 menit', '60'),
('SKP00749', 'Mendesain sertifikat, spanduk dan piagam - 30.0 menit', '30'),
('SKP00750', 'Mendistribusikan hasil audit BPK (temuan sementara dan jurnal) - 60.0 menit', '60'),
('SKP00751', 'Mendokumentasikan dokumen penting - 15.0 menit', '15'),
('SKP00752', 'Mendokumentasikan dokumen penting - 5.0 menit', '5'),
('SKP00753', 'Mendokumentasikan kegiatan (per kegiatan) - 15.0 menit', '15'),
('SKP00754', 'Mendokumentasikan kegiatan (per kegiatan) - 30.0 menit', '30'),
('SKP00755', 'Meneliti Berita Acara Serah Terima (BAST) - 15.0 menit', '15'),
('SKP00756', 'Meneliti Berita Acara Serah Terima (BAST) - 30.0 menit', '30'),
('SKP00757', 'Meneliti dan memverifikasi Analisis Standar Biaya (ASB) / Harga Satuan Pokok Kegiatan (HSPK) - 30.0 menit', '30'),
('SKP00758', 'Meneliti dan memverifikasi Analisis Standar Biaya (ASB) / Harga Satuan Pokok Kegiatan (HSPK) - 60.0 menit', '60'),
('SKP00759', 'Meneliti dan memverifikasi Analisis Standar Biaya (ASB) / Harga Satuan Pokok Kegiatan (HSPK) - 90.0 menit', '90'),
('SKP00760', 'Meneliti dan memverifikasi RKA / DPA - 90.0 menit', '90'),
('SKP00761', 'Meneliti dan memverifikasi RKA / DPA - 60.0 menit', '60'),
('SKP00762', 'Meneliti dan memverifikasi RKA / DPA - 30.0 menit', '30'),
('SKP00763', 'Meneliti dan memverifikasi Standar Satuan Harga (SSH) / kode rekening - 20.0 menit', '20'),
('SKP00764', 'Meneliti dan memverifikasi Standar Satuan Harga (SSH) / kode rekening - 30.0 menit', '30'),
('SKP00765', 'Meneliti dan memverifikasi Standar Satuan Harga (SSH) / kode rekening - 10.0 menit', '10'),
('SKP00766', 'Meneliti dan memverifikasi Standar Satuan Harga (SSH) / kode rekening - 5.0 menit', '5'),
('SKP00767', 'Meneliti dan mencocokan bukti-bukti pengeluaran dan penerimaan dengan laporan realisasi keuangan dan Buku Kas - 15.0 menit', '15'),
('SKP00768', 'Meneliti data - 15.0 menit', '15'),
('SKP00769', 'Meneliti data - 60.0 menit', '60'),
('SKP00770', 'Meneliti data - 30.0 menit', '30'),
('SKP00771', 'Meneliti data - 5.0 menit', '5'),
('SKP00772', 'Meneliti data - 10.0 menit', '10'),
('SKP00773', 'Meneliti data entry gaji dan tunjangan lainnya sebagai bahan konfirmasi belanja pegawai dengan SKPD - 30.0 menit', '30'),
('SKP00774', 'Meneliti laporan - 5.0 menit', '5'),
('SKP00775', 'Meneliti laporan - 30.0 menit', '30'),
('SKP00776', 'Meneliti laporan - 10.0 menit', '10'),
('SKP00777', 'Meneliti Laporan Keuangan - 120.0 menit', '120'),
('SKP00778', 'Meneliti Laporan Keuangan - 180.0 menit', '180'),
('SKP00779', 'Meneliti Laporan Keuangan - 60.0 menit', '60'),
('SKP00780', 'Meneliti, memeriksa, memvalidasi konsep Surat Keputusan - 30.0 menit', '30'),
('SKP00781', 'Meneliti, memeriksa, memvalidasi konsep Surat Keputusan - 15.0 menit', '15'),
('SKP00782', 'Meneliti, memeriksa, memvalidasi Surat Keputusan - 15.0 menit', '15'),
('SKP00783', 'Meneliti surat usulan penyampaian data belanja pegawai SKPD dalam rangka penyusunan APBD / APBD-P - 30.0 menit', '30'),
('SKP00784', 'Menempatkan Benda Cagar Budaya / Benda Seni (Per Benda) - 30.0 menit', '30'),
('SKP00785', 'Menempatkan Benda Cagar Budaya / Benda Seni (Per Benda) - 60.0 menit', '60'),
('SKP00786', 'Menerbitkan Surat Rekomendasi / Surat Izin - 30.0 menit', '30'),
('SKP00787', 'Menerima dan menyampaikan berita lewat Rig / HT - 3.0 menit', '3'),
('SKP00788', 'Menerima dan menyampaikan berita lewat Rig / HT - 5.0 menit', '5'),
('SKP00789', 'Menerima dan menyetor retribusi - 20.0 menit', '20'),
('SKP00790', 'Menerima dan menyortir bukti-bukti pengeluaran dan penerimaan serta Buku Kas - 15.0 menit', '15'),
('SKP00791', 'Menerima Konsul dari dokter spesialis lain - 20.0 menit', '20'),
('SKP00792', 'Menerima kunjungan kerja (1x kunjungan) - 180.0 menit', '180'),
('SKP00793', 'Menerima kunjungan kerja (1x kunjungan) - 60.0 menit', '60'),
('SKP00794', 'Menerima kunjungan kerja (1x kunjungan) - 120.0 menit', '120'),
('SKP00795', 'Menerima / memeriksa jumlah dan jenis barang / hasil pekerjaan - 60.0 menit', '60'),
('SKP00796', 'Menerima / memeriksa jumlah dan jenis barang / hasil pekerjaan - 90.0 menit', '90'),
('SKP00797', 'Menerima, mencatat bahan / objek kerja - 15.0 menit', '15'),
('SKP00798', 'Menerima, mencatat bahan / objek kerja - 10.0 menit', '10'),
('SKP00799', 'Menerima, mencatat bahan / objek kerja - 1.0 menit', '1'),
('SKP00800', 'Menerima, mencatat, memberi lembar disposisi - 5.0 menit', '5'),
('SKP00801', 'Menerima, mencatat, memberi lembar disposisi - 3.0 menit', '3'),
('SKP00802', 'Menerima pendaftaran - 5.0 menit', '5'),
('SKP00803', 'Menerima pendaftaran - 15.0 menit', '15'),
('SKP00804', 'Menerima pendaftaran pasien (per pasien) - 3.0 menit', '3'),
('SKP00805', 'Menerima Pengaduan Masyarakat (per aduan) - 15.0 menit', '15'),
('SKP00806', 'Menerima permohonan Penyelesaian Sengketa Informasi (PSI) - 5.0 menit', '5'),
('SKP00807', 'Menerima satwa yang baru datang / sakit - 30.0 menit', '30'),
('SKP00808', 'Menerima tamu dan mencatat keperluannya - 5.0 menit', '5'),
('SKP00809', 'Menerjemahkan Bahasa (1x kunjungan) - 60.0 menit', '60'),
('SKP00810', 'Mengadministrasikan surat - 5.0 menit', '5'),
('SKP00811', 'Mengajarkan Senam - 60.0 menit', '30'),
('SKP00812', 'Mengajarkan Senam - 90.0 menit', '90'),
('SKP00813', 'Mengajarkan senam lansia - 60.0 menit', '60'),
('SKP00814', 'Mengajar / melatih - 120.0 menit', '120'),
('SKP00815', 'Mengajar / melatih - 60.0 menit', '60'),
('SKP00816', 'Mengajar / Melatih Diklat di Bidang Pengadaan Barang / Jasa - 90.0 menit', '90'),
('SKP00817', 'Mengajukan gugatan / banding / kasasi / peninjauan kembali / memori / kontra memori ke pengadilan - 60.0 menit', '60'),
('SKP00818', 'Mengambil / mengantar dokumen / surat / berkas - 60.0 menit', '60'),
('SKP00819', 'Mengambil / mengantar dokumen / surat / berkas - 30.0 menit', '30'),
('SKP00820', 'Mengambil / mengantar dokumen / surat / berkas - 15.0 menit', '15'),
('SKP00821', 'Mengambil / mengantar dokumen / surat / berkas - 120.0 menit', '120'),
('SKP00822', 'Mengambil / mengantar dokumen / surat / berkas - 5.0 menit', '5'),
('SKP00823', 'Menganalisa formasi Izin Belajar / Tugas Belajar - 30.0 menit', '30'),
('SKP00824', 'Menganalisa formasi Izin Belajar / Tugas Belajar - 15.0 menit', '15'),
('SKP00825', 'Menganalisa hasil uji - 30.0 menit', '30'),
('SKP00826', 'Menganalisa hasil uji - 60.0 menit', '60'),
('SKP00827', 'Menganalisis aktivitas (Kasus ringan okupasi terapi) - 20.0 menit', '20'),
('SKP00828', 'Menganalisis / Validasi Perbal Naskah Dinas - 120.0 menit', '120'),
('SKP00829', 'Menganalisis / Validasi Perbal Naskah Dinas - 60.0 menit', '60'),
('SKP00830', 'Menganalisis / Validasi Perbal Naskah Dinas - 30.0 menit', '30'),
('SKP00831', 'Mengantar / Menjemput / Mengemudi Kendaraan Operasional - 60.0 menit', '60'),
('SKP00832', 'Mengantar / Menjemput / Mengemudi Kendaraan Operasional - 120.0 menit', '120'),
('SKP00833', 'Mengantar / Menjemput / Mengemudi Kendaraan Operasional - 30.0 menit', '30'),
('SKP00834', 'Mengawasi pelaksanaan karantina satwa - 60.0 menit', '60'),
('SKP00835', 'Mengawasi pengolahan sampah - 30.0 menit', '30'),
('SKP00836', 'Mengawasi pengolahan sampah - 60.0 menit', '60'),
('SKP00837', 'Mengecek kondisi kapal sesuai prosedur yg berlaku untuk kelancaran pelaksanaan pelayaran - 60.0 menit', '60'),
('SKP00838', 'Mengelola alokasi area database - 60.0 menit', '60'),
('SKP00839', 'Mengelola alokasi area database - 30.0 menit', '30'),
('SKP00840', 'Mengelola alokasi area database - 15.0 menit', '15'),
('SKP00841', 'Mengelola surat - 5.0 menit', '5'),
('SKP00842', 'Mengembangkan dan atau meremajakan rancangan rinci sistem informasi - 120.0 menit', '120'),
('SKP00843', 'Mengembangkan dan atau meremajakan rancangan rinci sistem informasi - 60.0 menit', '60'),
('SKP00844', 'Mengembangkan / meremajakan aplikasi / sistem informasi - 30.0 menit', '30'),
('SKP00845', 'Mengembangkan / meremajakan aplikasi / sistem informasi - 60.0 menit', '60'),
('SKP00846', 'Mengendalikan kapal sebagai nahkoda sesuai dengan prosedur pelayaran - 120.0 menit', '120'),
('SKP00847', 'Mengendalikan kapal sebagai nahkoda sesuai dengan prosedur pelayaran - 60.0 menit', '60'),
('SKP00848', 'Mengestimasi Pendapatan (per tagihan) - 15.0 menit', '15'),
('SKP00849', 'Mengestimasi Pendapatan (per tagihan) - 15.0 menit', '15'),
('SKP00850', 'Mengetik Surat - 15.0 menit', '15'),
('SKP00851', 'Mengevaluasi / meneliti hasil konfirmasi gaji dan tunjangan lainnya dengan SKPD - 30.0 menit', '30'),
('SKP00852', 'Menggandakan dan Memberikan cap stempel naskah dinas - 0.2 menit', '0.2'),
('SKP00853', 'Menghadiri acara seremonial - 60.0 menit', '60'),
('SKP00854', 'Menghadiri acara seremonial - 90.0 menit', '90'),
('SKP00855', 'Menghadiri acara seremonial - 30.0 menit', '30'),
('SKP00856', 'Menghadiri kegiatan pemberdayaan dan kesejahteraan keluarga (PKK ) bagi pegawai kelurahan - 120.0 menit', '120'),
('SKP00857', 'Menghadiri / mendampingi persidangan - 60.0 menit', '60'),
('SKP00858', 'Menghadiri / mendampingi persidangan - 120.0 menit', '120'),
('SKP00859', 'Menghadiri / mendampingi persidangan - 180.0 menit', '180'),
('SKP00860', 'Menghadiri sidang di pengadilan - 120.0 menit', '120'),
('SKP00861', 'Menghadiri sidang di pengadilan - 180.0 menit', '180'),
('SKP00862', 'Menghadiri sidang di pengadilan - 60.0 menit', '60'),
('SKP00863', 'Menghidupkan mesin - 5.0 menit', '5'),
('SKP00864', 'Menghidupkan mesin kapal - 15.0 menit', '15'),
('SKP00865', 'Menghimpun, mencocokan dan meneliti tagihan penyediaan jasa TALI dan IPAL - 30.0 menit', '30'),
('SKP00866', 'Menghimpun usulan Rencana Kerja dan Anggaran - 60.0 menit', '60'),
('SKP00867', 'Menghitung Besaran Retribusi Pemakaian Alat Ukur - 10.0 menit', '10'),
('SKP00868', 'Menghitung Besaran Retribusi Pemakaian Alat Ukur - 30.0 menit', '30'),
('SKP00869', 'Menghitung pemakaian barang habis pakai - 60.0 menit', '60'),
('SKP00870', 'Menghitung pemakaian barang habis pakai - 30.0 menit', '30'),
('SKP00871', 'Menghubungi keluarga anak asuh dalam rangka konsultasi dan monitoring perkembangan anak asuh - 10.0 menit', '10'),
('SKP00872', 'Mengidentifikasi dan memverifikasi data - 30.0 menit', '30'),
('SKP00873', 'Mengidentifikasi dan memverifikasi data - 5.0 menit', '5'),
('SKP00874', 'Mengidentifikasi dan memverifikasi data - 15.0 menit', '15'),
('SKP00875', 'Mengikuti kegiatan kerja bakti - 60.0 menit', '60'),
('SKP00876', 'Mengikuti kegiatan kerja bakti - 90.0 menit', '90'),
('SKP00877', 'Mengikuti kegiatan kerja bakti - 45.0 menit', '45'),
('SKP00878', 'Mengikuti kegiatan Rapat Kerja Nasional / Rembug Nasional - 360.0 menit', '360'),
('SKP00879', 'Mengikuti kegiatan Rapat Kerja Nasional / Rembug Nasional - 180.0 menit', '180'),
('SKP00880', 'Mengikuti kegiatan Rapat Kerja Nasional / Rembug Nasional - 300.0 menit', '300'),
('SKP00881', 'Mengikuti pelatihan input / supervisi e-Musrenbang - 120.0 menit', '120'),
('SKP00882', 'Mengikuti pelatihan / sosialisasi / pendidikan - 60.0 menit', '60'),
('SKP00883', 'Mengikuti pelatihan / sosialisasi / pendidikan - 300.0 menit', '300'),
('SKP00884', 'Mengikuti pelatihan / sosialisasi / pendidikan - 240.0 menit', '240'),
('SKP00885', 'Mengikuti pelatihan / sosialisasi / pendidikan - 180.0 menit', '180'),
('SKP00886', 'Mengikuti pelatihan / sosialisasi / pendidikan - 120.0 menit', '120'),
('SKP00887', 'Mengikuti pembahasan dalam sidang Musrenbang - 180.0 menit', '180'),
('SKP00888', 'Mengikuti pembahasan dalam sidang Musrenbang - 120.0 menit', '120'),
('SKP00889', 'Mengikuti pembahasan dalam sidang Musrenbang tingkat provinsi / kota / kabupaten / kecamatan / kelurahan - 120.0 menit', '120'),
('SKP00890', 'Mengikuti pembahasan dalam sidang Musrenbang tingkat provinsi / kota / kabupaten / kecamatan / kelurahan - 180.0 menit', '180'),
('SKP00891', 'Mengikuti Proses Ujian Sekolah (per mata pelajaran) - 120.0 menit', '120'),
('SKP00892', 'Mengikuti rapat teknis - 120.0 menit', '120'),
('SKP00893', 'Mengikuti rapat teknis - 60.0 menit', '60'),
('SKP00894', 'Mengikuti rapat teknis - 45.0 menit', '45'),
('SKP00895', 'Mengikuti rapat teknis - 90.0 menit', '90'),
('SKP00896', 'Mengikuti rapat teknis - 180.0 menit', '180'),
('SKP00897', 'Mengikuti RAPIM Gubernur - 60.0 menit', '60'),
('SKP00898', 'Mengikuti RAPIM Gubernur - 120.0 menit', '120'),
('SKP00899', 'Mengikuti RAPIM Gubernur - 180.0 menit', '180'),
('SKP00900', 'Mengikuti RAPIM Wakil Gubernur - 180.0 menit', '180'),
('SKP00901', 'Mengikuti RAPIM Wakil Gubernur - 60.0 menit', '60'),
('SKP00902', 'Mengikuti RAPIM Wakil Gubernur - 120.0 menit', '120'),
('SKP00903', 'Mengikuti ronde keperawatan - 60.0 menit', '60'),
('SKP00904', 'Mengikuti ronde keperawatan - 120.0 menit', '120'),
('SKP00905', 'Mengikuti ronde keperawatan - 30.0 menit', '30'),
('SKP00906', 'Mengikuti seminar / lokakarya / konferensi - 120.0 menit', '120'),
('SKP00907', 'Mengikuti seminar / lokakarya / konferensi - 60.0 menit', '60'),
('SKP00908', 'Mengikuti Senam - 90.0 menit', '90'),
('SKP00909', 'Mengikuti Senam - 60.0 menit', '60'),
('SKP00910', 'Mengikuti tes kompetensi - 120.0 menit', '120'),
('SKP00911', 'Mengikuti tes kompetensi - 180.0 menit', '180'),
('SKP00912', 'Mengikuti visit dokter - 30.0 menit', '30'),
('SKP00913', 'Mengikuti visit dokter - 60.0 menit', '60'),
('SKP00914', 'Mengikuti visit dokter - 10.0 menit', '10'),
('SKP00915', 'Mengikuti visit dokter (per 1 pasien) - 5.0 menit', '5'),
('SKP00916', 'Menginput Data / informasi (Per Kegiatan / Paket) - 15.0 menit', '15'),
('SKP00917', 'Menginput Data / informasi (Per Kegiatan / Paket) - 30.0 menit', '30'),
('SKP00918', 'Menginput Data / informasi (Per Kegiatan / Paket) - 5.0 menit', '5'),
('SKP00919', 'Menginput Data / informasi (Per Kegiatan / Paket) - 10.0 menit', '10'),
('SKP00920', 'Menginput data ke dalam sistem - 5.0 menit', '5'),
('SKP00921', 'Menginput data ke dalam sistem - 15.0 menit', '15'),
('SKP00922', 'Menginput data ke dalam sistem - 30.0 menit', '30'),
('SKP00923', 'Menginput jurnal SP2D ke aplikasi LPJ SIPKD BPKD Provinsi DKI Jakarta - 180.0 menit', '180'),
('SKP00924', 'Menginput jurnal SP2D ke aplikasi LPJ SIPKD BPKD Provinsi DKI Jakarta - 120.0 menit', '120'),
('SKP00925', 'Menginput jurnal SPJ ke aplikasi LPJ SIPKD BPKD Provinsi DKI Jakarta - 60.0 menit', '60'),
('SKP00926', 'Menginput jurnal SPJ / SP2D ke aplikasi LPJ SIPKD BPKD Provinsi DKI Jakarta - 60.0 menit', '60'),
('SKP00927', 'Menginput jurnal SPJ / SP2D ke aplikasi LPJ SIPKD BPKD Provinsi DKI Jakarta - 120.0 menit', '120'),
('SKP00928', 'Menginput jurnal SPJ / SP2D ke aplikasi LPJ SIPKD BPKD Provinsi DKI Jakarta - 15.0 menit', '15'),
('SKP00929', 'Menginput jurnal SPJ / SP2D ke aplikasi LPJ SIPKD BPKD Provinsi DKI Jakarta - 30.0 menit', '30'),
('SKP00930', 'Menginput Usulan Pensiun BUP ke dalam Sistem Aplikasi Pelayanan Kepegawaian (SAPK) BKN - 5.0 menit', '5'),
('SKP00931', 'Menginventarisasi surat usulan anggaran - 5.0 menit', '5'),
('SKP00932', 'Menginventarisir daftar pajak terutang - 60.0 menit', '60'),
('SKP00933', 'Menginventarisir daftar pajak terutang - 30.0 menit', '30'),
('SKP00934', 'Menginventarisir pendapatan jasa giro - 30.0 menit', '30'),
('SKP00935', 'Mengisi Buku Induk Siswa - 15.0 menit', '15'),
('SKP00936', 'Mengisi resume medis - 10.0 menit', '10'),
('SKP00937', 'Mengolah data - 60.0 menit', '60'),
('SKP00938', 'Mengolah data - 5.0 menit', '5'),
('SKP00939', 'Mengolah data - 15.0 menit', '15'),
('SKP00940', 'Mengolah data - 30.0 menit', '30'),
('SKP00941', 'Mengolah data - 10.0 menit', '10'),
('SKP00942', 'Mengolah data perencanaan dan anggaran - 90.0 menit', '90'),
('SKP00943', 'Mengolah / menyiapkan / menyajikan data - 30.0 menit', '30'),
('SKP00944', 'Mengolah / menyiapkan / menyajikan data - 15.0 menit', '15'),
('SKP00945', 'Mengontrol keamanan gedung dan lingkungan kantor pada siang / malam hari - 90.0 menit', '90'),
('SKP00946', 'Mengontrol keamanan gedung dan lingkungan kantor pada siang / malam hari - 30.0 menit', '30'),
('SKP00947', 'Mengontrol keamanan gedung dan lingkungan kantor pada siang / malam hari - 60.0 menit', '60'),
('SKP00948', 'Mengoperasikan pertunjukan (teater) - 60.0 menit', '60'),
('SKP00949', 'Mengoperasikan sarana dan prasarana penanggulangan kedaruratan - 60.0 menit', '60'),
('SKP00950', 'Mengoreksi hasil tes peserta pelatihan - 30.0 menit', '30'),
('SKP00951', 'Mengoreksi hasil tes peserta pelatihan - 60.0 menit', '60'),
('SKP00952', 'Menguji calon Pegawai baru -15.0 menit', '15'),
('SKP00953', 'Menguji pegawai / Mahasiswa / siswa - 30.0 menit', '30'),
('SKP00954', 'Menguji pegawai / Mahasiswa / siswa - 60.0 menit', '60'),
('SKP00955', 'Mengumpulkan bahan kerja - 15.0 menit', '15'),
('SKP00956', 'Mengumpulkan bahan kerja - 30.0 menit', '30'),
('SKP00957', 'Mengumpulkan Berkas / Dokumen - 15.0 menit', '15'),
('SKP00958', 'Mengumpulkan Berkas / Dokumen - 30.0 menit', '30'),
('SKP00959', 'Mengumpulkan dan mengedit artikel / media foto / video / audio untuk publikasi - 30.0 menit', '30'),
('SKP00960', 'Mengumpulkan dan mengedit artikel untuk publikasi - 60.0 menit', '60'),
('SKP00961', 'Mengumpulkan data / berkas / dokumen - 10.0 menit', '10'),
('SKP00962', 'Mengumpulkan data / berkas / dokumen - 15.0 menit', '15'),
('SKP00963', 'Mengumpulkan data / berkas / dokumen - 5.0 menit', '5'),
('SKP00964', 'Mengumpulkan data / berkas / dokumen - 30.0 menit', '30'),
('SKP00965', 'Mengumpulkan jawaban ujian - 15.0 menit', '15'),
('SKP00966', 'Mengumpulkan laporan keuangan - 30.0 menit', '30'),
('SKP00967', 'Mengupload Data / Artikel Kedalam Sistem Informasi - 15.0 menit', '15'),
('SKP00968', 'Mengupload Data / Artikel Kedalam Sistem Informasi - 30.0 menit', '30'),
('SKP00969', 'Mengurus kelengkapan kendaraan bermotor - 30.0 menit', '30'),
('SKP00970', 'Mengurus perizinan keluar masuk satwa - 90.0 menit', '90'),
('SKP00971', 'Menilai Usulan Pengembangan atau Pembangunan Sistem Informasi Baru dan Mengidetifikasi Dampak - 60.0 menit', '60'),
('SKP00972', 'Menilai Usulan Pengembangan atau Pembangunan Sistem Informasi Baru dan Mengidetifikasi Dampak - 30.0 menit', '30'),
('SKP00973', 'Menindaklanjuti pertanyaan masyarakat melalui QLUE / CROPS / sistem aplikasi lainnya - 30.0 menit', '30'),
('SKP00974', 'Menindaklanjuti pertanyaan masyarakat melalui QLUE / CROPS / sistem aplikasi lainnya - 15.0 menit', '15'),
('SKP00975', 'Menindaklanjuti pertanyaan masyarakat melalui QLUE / CROPS / sistem aplikasi lainnya - 5.0 menit', '5'),
('SKP00976', 'Meningkatkan kinerja perangkat lunak pada komputer mainframe / server - 15.0 menit', '15'),
('SKP00977', 'Meningkatkan kinerja perangkat lunak pada komputer mainframe / server - 30.0 menit', '30'),
('SKP00978', 'Menjadi instruktur senam kesehatan - 60.0 menit', '60'),
('SKP00979', 'Menjadi moderator - 120.0 menit', '120'),
('SKP00980', 'Menjadi moderator - 60.0 menit', '60'),
('SKP00981', 'Menjadi narasumber - 60.0 menit', '60'),
('SKP00982', 'Menjadi narasumber - 120.0 menit', '120'),
('SKP00983', 'Menjadi petugas upacara / apel - 30.0 menit', '30'),
('SKP00984', 'Menjadi petugas upacara / apel - 60.0 menit', '60'),
('SKP00985', 'Menjustir alat ukur - 30.0 menit', '30'),
('SKP00986', 'Menjustir alat ukur - 60.0 menit', '60'),
('SKP00987', 'Menyandarkan kapal setelah pelaksanan pelayaran sesuai prosedur yang berlaku agar kapal terjaga keamananya - 30.0 menit', '30'),
('SKP00988', 'Menyediakan data untuk Rapim Gubernur - 30.0 menit', '30'),
('SKP00989', 'Menyediakan data untuk Rapim Gubernur - 60.0 menit', '60'),
('SKP00990', 'Menyelenggarakan event kegiatan - 30.0 menit', '30'),
('SKP00991', 'Menyelenggarakan event kegiatan - 120.0 menit', '120'),
('SKP00992', 'Menyelenggarakan event kegiatan - 60.0 menit', '60'),
('SKP00993', 'Menyelenggarakan pelayanan pemulasaraan jenazah - 30.0 menit', '30'),
('SKP00994', 'Menyelenggarakan senam lansia - 60.0 menit', '60'),
('SKP00995', 'Menyetorkan Surat Tanda Setoran Langsung / Uang Persediaan / Ganti Uang / Tambah Uang (STS- LS / UP / GU / TU) - 60.0 menit', '60'),
('SKP00996', 'Menyiapkan bahan - 30.0 menit', '30'),
('SKP00997', 'Menyiapkan bahan - 60.0 menit', '60'),
('SKP00998', 'Menyiapkan bahan - 5.0 menit', '5'),
('SKP00999', 'Menyiapkan bahan - 10.0 menit', '10'),
('SKP01000', 'Menyiapkan Bahan laporan - 30.0 menit', '30'),
('SKP01001', 'Menyiapkan Bahan laporan - 60.0 menit', '60'),
('SKP01002', 'Menyiapkan bahan yang dibutuhkan oleh Lembaga Pemeriksa - 120.0 menit', '120'),
('SKP01003', 'Menyiapkan bahan yang dibutuhkan oleh Lembaga Pemeriksa - 60.0 menit', '60'),
('SKP01004', 'Menyiapkan Laporan Barang Pengguna Barang Semesteran (LBPS) dan Laporan Barang Pengguna Tahunan (LBPT) serta laporan inventarisasi 5 (lima) tahunan yang berada ', '60'),
('SKP01005', 'Menyiapkan, menganalisis, menyajikan dokumen untuk kebutuhan sertifikasi ISO - 120.0 menit', '120'),
('SKP01006', 'Menyiapkan, menganalisis, menyajikan dokumen untuk kebutuhan sertifikasi ISO - 60.0 menit', '60'),
('SKP01007', 'Menyiapkan / meracik obat berdasarkan resep dokter - 15.0 menit', '15'),
('SKP01008', 'Menyiapkan / meracik obat berdasarkan resep dokter - 5.0 menit', '5'),
('SKP01009', 'Menyiapkan naskah soal ujian perkegiatan - 15.0 menit', '15'),
('SKP01010', 'Menyiapkan rapat / diklat (Snack, daftar hadir) (Per 1 kegiatan) - 15.0 menit', '15'),
('SKP01011', 'Menyiapkan rapat / diklat (Snack, daftar hadir) (Per 1 kegiatan) - 30.0 menit', '30'),
('SKP01012', 'Menyusun Analisa Beban Kerja - 60.0 menit', '60'),
('SKP01013', 'Menyusun Analisa Beban Kerja - 30.0 menit', '30'),
('SKP01014', 'Menyusun angka konsolidasi aset - 120.0 menit', '120'),
('SKP01015', 'Menyusun angka konsolidasi aset - 60.0 menit', '60'),
('SKP01016', 'Menyusun angka konsolidasi selain aset - 60.0 menit', '60'),
('SKP01017', 'Menyusun angka konsolidasi selain aset - 120.0 menit', '120'),
('SKP01018', 'Menyusun angka konsolidasi selain aset - 30.0 menit', '30'),
('SKP01019', 'Menyusun bahan pembahasan rancangan Kebijakan - 60.0 menit', '60'),
('SKP01020', 'Menyusun bahan pembahasan rancangan Kebijakan - 120.0 menit', '120'),
('SKP01021', 'Menyusun daftar pajak terutang beserta fotokopi SSP - 60.0 menit', '60'),
('SKP01022', 'Menyusun dan mengerjakan SPJ Langsung (LS) per paket - 60.0 menit', '60'),
('SKP01023', 'Menyusun dan mengerjakan SPJ Langsung (LS) per paket - 30.0 menit', '30'),
('SKP01024', 'Menyusun dan menyiapkan bahan evaluasi - 120.0 menit', '120'),
('SKP01025', 'Menyusun dan menyiapkan bahan evaluasi - 60.0 menit', '60'),
('SKP01026', 'Menyusun data jabatan SKPD / UKPD - 90.0 menit', '90'),
('SKP01027', 'Menyusun data laporan jurnal SPJ - 30.0 menit', '30'),
('SKP01028', 'Menyusun data rekonsiliasi belanja - 180.0 menit', '180'),
('SKP01029', 'Menyusun data rekonsiliasi belanja - 120.0 menit', '120'),
('SKP01030', 'Menyusun data rekonsiliasi belanja - 60.0 menit', '60'),
('SKP01031', 'Menyusun data setoran SP2D Langsung (LS) - 300.0 menit', '300'),
('SKP01032', 'Menyusun data setoran SP2D Langsung (LS) - 60.0 menit', '60'),
('SKP01033', 'Menyusun data setoran SP2D Langsung (LS) - 120.0 menit', '120'),
('SKP01034', 'Menyusun data setoran SP2D Uang Persediaan (UP) - 120.0 menit', '120'),
('SKP01035', 'Menyusun data setoran SP2D Uang Persediaan (UP) - 300.0 menit', '300'),
('SKP01036', 'Menyusun data setoran SP2D Uang Persediaan (UP) - 60.0 menit', '60'),
('SKP01037', 'Menyusun Dokumen - 15.0 menit', '15'),
('SKP01038', 'Menyusun Dokumen - 10.0 menit', '10'),
('SKP01039', 'Menyusun Dokumen - 5.0 menit', '5'),
('SKP01040', 'Menyusun Dokumen RPJPD / RPJMD / RKPD - 120.0 menit', '120'),
('SKP01041', 'Menyusun Dokumen RPJPD / RPJMD / RKPD - 60.0 menit', '60'),
('SKP01042', 'Menyusun Dokumen RPJPD / RPJMD / RKPD - 180.0 menit', '180'),
('SKP01043', 'Menyusun draft Catatan atas Laporan Keuangan (CaLK) - 60.0 menit', '60'),
('SKP01044', 'Menyusun draft Catatan atas Laporan Keuangan (CaLK) - 120.0 menit', '120'),
('SKP01045', 'Menyusun draft Laporan Realisasi Anggaran (LRA) - 120.0 menit', '120'),
('SKP01046', 'Menyusun draft Laporan Realisasi Anggaran (LRA) - 60.0 menit', '60'),
('SKP01047', 'Menyusun draft Neraca - 120.0 menit', '120'),
('SKP01048', 'Menyusun draft Neraca - 60.0 menit', '60'),
('SKP01049', 'Menyusun Evaluasi Jabatan / Kelas Jabatan - 30.0 menit', '30'),
('SKP01050', 'Menyusun Evaluasi Jabatan / Kelas Jabatan - 60.0 menit', '60'),
('SKP01051', 'Menyusun Formasi Jabatan Pelaksana / Fungsional - 30.0 menit', '30'),
('SKP01052', 'Menyusun Formasi Jabatan Pelaksana / Fungsional - 60.0 menit', '60'),
('SKP01053', 'Menyusun formasi pegawai non PNS - 120.0 menit', '120'),
('SKP01054', 'Menyusun formasi pegawai non PNS - 60.0 menit', '60'),
('SKP01055', 'Menyusun indikator perjanjian kinerja SKPD / UKPD - 120.0 menit', '120'),
('SKP01056', 'Menyusun indikator perjanjian kinerja SKPD / UKPD - 180.0 menit', '180'),
('SKP01057', 'Menyusun Jadwal Anggaran Per Kegiatan Dalam Aplikasi Sistem informasi - 30.0 menit', '30'),
('SKP01058', 'Menyusun Jadwal Anggaran Per Kegiatan Dalam Aplikasi Sistem informasi - 60.0 menit', '60'),
('SKP01059', 'Menyusun kamus jabatan - 60.0 menit', '60'),
('SKP01060', 'Menyusun kamus jabatan - 120.0 menit', '120'),
('SKP01061', 'Menyusun Kebutuhan Formasi PNS - 30.0 menit', '30'),
('SKP01062', 'Menyusun Kebutuhan Formasi PNS - 120.0 menit', '120'),
('SKP01063', 'Menyusun Kebutuhan Formasi PNS - 60.0 menit', '60'),
('SKP01064', 'Menyusun konsep rincian anggaran - 30.0 menit', '30'),
('SKP01065', 'Menyusun konsep rincian anggaran - 60.0 menit', '60'),
('SKP01066', 'Menyusun Kurikulum / Buku / Diktat / Modul - 120.0 menit', '120'),
('SKP01067', 'Menyusun Kurikulum / Buku / Diktat / Modul - 60.0 menit', '60'),
('SKP01068', 'Menyusun Kurikulum / Buku / Diktat / Modul - 180.0 menit', '180'),
('SKP01069', 'Menyusun LAKIP - 60.0 menit', '60'),
('SKP01070', 'Menyusun LAKIP - 180.0 menit', '180'),
('SKP01071', 'Menyusun LAKIP - 120.0 menit', '120'),
('SKP01072', 'Menyusun laporan jurnal SP2D - 60.0 menit', '60'),
('SKP01073', 'Menyusun laporan jurnal SP2D - 30.0 menit', '30'),
('SKP01074', 'Menyusun laporan keuangan SKPD - 60.0 menit', '60'),
('SKP01075', 'Menyusun laporan keuangan SKPD - 180.0 menit', '180'),
('SKP01076', 'Menyusun laporan keuangan SKPD - 120.0 menit', '120'),
('SKP01077', 'Menyusun laporan pendapatan jasa giro - 30.0 menit', '30'),
('SKP01078', 'Menyusun Laporan Pertanggungjawaban Keuangan (bendahara pengeluaran) - 30.0 menit', '30'),
('SKP01079', 'Menyusun laporan tutup buku - 180.0 menit', '180'),
('SKP01080', 'Menyusun laporan tutup buku - 120.0 menit', '120'),
('SKP01081', 'Menyusun LKPJ (Laporan Kinerja Pertanggungjawaban) gubernur - 180.0 menit', '180'),
('SKP01082', 'Menyusun matriks - 120.0 menit', '120'),
('SKP01083', 'Menyusun matriks - 30.0 menit', '30'),
('SKP01084', 'Menyusun matriks - 60.0 menit', '60'),
('SKP01085', 'Menyusun / Membuat Sasaran Kerja Pegawai (SKP) - 60.0 menit', '60'),
('SKP01086', 'Menyusun Naskah Akademis - 60.0 menit', '60'),
('SKP01087', 'Menyusun Naskah Akademis - 120.0 menit', '120'),
('SKP01088', 'Menyusun Nota Keuangan - 180.0 menit', '180'),
('SKP01089', 'Menyusun Nota Keuangan - 120.0 menit', '120'),
('SKP01090', 'Menyusun pedoman / petunjuk teknis / petunjuk pelaksanaan - 90.0 menit', '90'),
('SKP01091', 'Menyusun pedoman / petunjuk teknis / petunjuk pelaksanaan - 120.0 menit', '120'),
('SKP01092', 'Menyusun pedoman / petunjuk teknis / petunjuk pelaksanaan - 60.0 menit', '60'),
('SKP01093', 'Menyusun Rancangan APBD / APBD-P - 120.0 menit', '120'),
('SKP01094', 'Menyusun Rancangan APBD / APBD-P - 60.0 menit', '60'),
('SKP01095', 'Menyusun Rancangan APBD / APBD-P - 180.0 menit', '180'),
('SKP01096', 'Menyusun rencana induk sistem informasi keseluruhan (Master Plan) - 60.0 menit', '60'),
('SKP01097', 'Menyusun rencana induk sistem informasi keseluruhan (Master Plan) - 120.0 menit', '120'),
('SKP01098', 'Menyusun rencana kebutuhan - 30.0 menit', '30'),
('SKP01099', 'Menyusun rencana kebutuhan - 15.0 menit', '15'),
('SKP01100', 'Menyusun Rencana Kegiatan / Anggaran - 120.0 menit', '120'),
('SKP01101', 'Menyusun Rencana Kegiatan / Anggaran - 30.0 menit', '30'),
('SKP01102', 'Menyusun Rencana Kegiatan / Anggaran - 60.0 menit', '60'),
('SKP01103', 'Menyusun rencana pemeriksaan okupasi terapi (Kasus ringan) - 10.0 menit', '10'),
('SKP01104', 'Menyusun rincian usulan Formasi kebutuhan pegawai - 120.0 menit', '120'),
('SKP01105', 'Menyusun rincian usulan Formasi kebutuhan pegawai - 180.0 menit', '180'),
('SKP01106', 'Menyusun ringkasan surat masuk Gubernur (Membuat resume) - 10.0 menit', '10'),
('SKP01107', 'Menyusun ringkasan surat masuk Gubernur (Membuat resume) - 15.0 menit', '15'),
('SKP01108', 'Menyusun RKA dan DPA - 120.0 menit', '120'),
('SKP01109', 'Menyusun RKA dan DPA - 60.0 menit', '60'),
('SKP01110', 'Menyusun studi kelayakan sistem - 60.0 menit', '60'),
('SKP01111', 'Menyusun studi kelayakan sistem - 30.0 menit', '30'),
('SKP01112', 'Menyusun studi kelayakan sistem - 120.0 menit', '120'),
('SKP01113', 'Menyusun tabel manual anggaran per kegiatan tahun anggaran - 60.0 menit', '60'),
('SKP01114', 'Menyusun Tindak Lanjut Temuan BPK - 30.0 menit', '30'),
('SKP01115', 'Menyusun Tindak Lanjut Temuan BPK - 60.0 menit', '60'),
('SKP01116', 'Meracik pakan satwa - 45.0 menit', '45'),
('SKP01117', 'Merawat satwa (per hewan) - 60.0 menit', '60'),
('SKP01118', 'Merawat satwa (per hewan) - 30.0 menit', '30'),
('SKP01119', 'Merevisi Rencana Kerja dan Anggaran per kegiatan - 30.0 menit', '30'),
('SKP01120', 'Mewarnai sediaan / Objek Kerja - 5.0 menit', '5'),
('SKP01121', 'Migrasi database - 60.0 menit', '30'),
('SKP01122', 'Migrasi database - 15.0 menit', '15'),
('SKP01123', 'Migrasi database - 30.0 menit', '30'),
('SKP01124', 'Monitoring CCTV lalu lintas melalui ruang pusat kendali lalu lintas ITS - 30.0 menit', '30'),
('SKP01125', 'Monitoring kegiatan - 120.0 menit', '120'),
('SKP01126', 'Monitoring kegiatan - 15.0 menit', '15'),
('SKP01127', 'Monitoring kegiatan - 30.0 menit', '30'),
('SKP01128', 'Monitoring kegiatan - 90.0 menit', '90'),
('SKP01129', 'Monitoring kegiatan - 60.0 menit', '60'),
('SKP01130', 'Narator pertunjukan teater bintang - 60.0 menit', '60'),
('SKP01131', 'Nomerator Bahan Perpustakaan (Per 5 Buku) - 5.0 menit', '5'),
('SKP01132', 'Observasi jasa pos - 30.0 menit', '30'),
('SKP01133', 'Observasi jasa pos - 60.0 menit', '60'),
('SKP01134', 'Observasi Jasa Telekomunikasi - 60.0 menit', '60'),
('SKP01135', 'Observasi Jasa Telekomunikasi - 30.0 menit', '30'),
('SKP01136', 'Observasi Multimedia - 60.0 menit', '60'),
('SKP01137', 'Observasi Multimedia - 30.0 menit', '30'),
('SKP01138', 'Panitia pada pelaksanaan kegiatan di SKPD / UKPD - 60.0 menit', '60'),
('SKP01139', 'Panitia pada pelaksanaan kegiatan di SKPD / UKPD - 120.0 menit', '120'),
('SKP01140', 'Panitia pada pelaksanaan kegiatan di SKPD / UKPD - 180.0 menit', '180'),
('SKP01141', 'Pelaksanaan gugus kendali mutu - 120.0 menit', '120'),
('SKP01142', 'Pelaksanaan gugus kendali mutu - 60.0 menit', '60'),
('SKP01143', 'Pelaksanaan rembuk RW - 180.0 menit', '180'),
('SKP01144', 'Pelaksanaan rembuk RW - 120.0 menit', '120'),
('SKP01145', 'Pelaporan dan pertanggungjawaban pelaksanaan tugas dan fungsi Inspektorat Pembantu - 120.0 menit', '120'),
('SKP01146', 'Pelaporan dan pertanggungjawaban pelaksanaan tugas dan fungsi Inspektorat Pembantu - 240.0 menit', '240'),
('SKP01147', 'Pelaporan dan pertanggungjawaban pelaksanaan tugas dan fungsi Inspektorat Pembantu - 180.0 menit', '180'),
('SKP01148', 'Pelayanan Makan Warga Binaan Sosial (WBS) perpasien - 15.0 menit', '15'),
('SKP01149', 'Pelayanan Surat PM1 / pernyataan / keterangan - 10.0 menit', '10'),
('SKP01150', 'Pemantauan kegiatan posyandu - 60.0 menit', '60'),
('SKP01151', 'Pemantauan kegiatan posyandu - 120.0 menit', '120'),
('SKP01152', 'Pemantauan Unjuk Rasa - 120.0 menit', '120'),
('SKP01153', 'Pemantauan Unjuk Rasa - 60.0 menit', '60'),
('SKP01154', 'Pembahasan KUA-PPAS Bersama DPRD - 120.0 menit', '120'),
('SKP01155', 'Pembahasan KUA-PPAS Bersama DPRD - 180.0 menit', '180'),
('SKP01156', 'Pembahasan RAPBD / RAPBD-P dengan DPRD - 120.0 menit', '120'),
('SKP01157', 'Pembahasan RAPBD / RAPBD-P dengan DPRD - 180.0 menit', '180'),
('SKP01158', 'Pembahasan RAPBD / RAPBD-P dengan Pemerintah Pusat - 180.0 menit', '180'),
('SKP01159', 'Pemberian keterangan ahli / saksi / sebagai pendamping di persidangan - 120.0 menit', '120'),
('SKP01160', 'Pemberian keterangan ahli / saksi / sebagai pendamping di persidangan - 180.0 menit', '180'),
('SKP01161', 'Pembuatan Album Foto Peserta Ujian Nasional - 60.0 menit', '60'),
('SKP01162', 'Pembuatan karya tulis / karya ilmiah - 60.0 menit', '60'),
('SKP01163', 'Pembuatan karya tulis / karya ilmiah - 120.0 menit', '120'),
('SKP01164', 'Pembuatan Tanda Nomor Pemeriksaan Uji pada Fisik Kendaraan - 5.0 menit', '5'),
('SKP01165', 'Pemeriksaan dan Pengujian Khusus Objek Kesehatan Keselamatan Kerja (K3 ) - 60.0 menit', '60'),
('SKP01166', 'Pemeriksaan gambar pelaksanaan bangunan / shop drawing / as built drawing (Per Gambar) - 30.0 menit', '30'),
('SKP01167', 'Pemeriksaan gambar pelaksanaan bangunan / shop drawing / as built drawing (Per Gambar) - 60.0 menit', '60'),
('SKP01168', 'Pemeriksaan Lab. Kesehatan - 10.0 menit', '10'),
('SKP01169', 'Pemeriksaan Lab. Kesehatan - 20.0 menit', '20'),
('SKP01170', 'Pemeriksaan Lab. Kesehatan - 15.0 menit', '15'),
('SKP01171', 'Pemeriksaan Operasi K3 Konstruksi - 120.0 menit', '120'),
('SKP01172', 'Pemeriksaan Operasi K3 Konstruksi - 60.0 menit', '60'),
('SKP01173', 'Pemeriksaan / pengawasan terhadap konstruksi / bangunan - 120.0 menit', '120'),
('SKP01174', 'Pemeriksaan / pengawasan terhadap konstruksi / bangunan - 180.0 menit', '180'),
('SKP01175', 'Pemeriksaan Specimen - 5.0 menit', '5'),
('SKP01176', 'Pemutakhiran data aset - 120.0 menit', '120'),
('SKP01177', 'Pemutakhiran data aset - 60.0 menit', '60'),
('SKP01178', 'Penandatanganan Berkas Perizinan dan Non Perizinan - 5.0 menit', '5'),
('SKP01179', 'Penanganan kegawatdaruratan - 30.0 menit', '30'),
('SKP01180', 'Penanganan kegawatdaruratan - 60.0 menit', '60'),
('SKP01181', 'Penataan arsip kantor - 30.0 menit', '30'),
('SKP01182', 'Penataan arsip kantor - 15.0 menit', '15'),
('SKP01183', 'Penataan arsip kantor - 45.0 menit', '45'),
('SKP01184', 'Pencairan SPM ke kantor kas daerah - 60.0 menit', '60'),
('SKP01185', 'Pendampingan Terhadap Penggunaan SPSE dan Aplikasi e-Procurement Lainnya - 30.0 menit', '30'),
('SKP01186', 'Penelitian berkas permohonan perizinan (per aplikasi pengajuan) - 60.0 menit', '60'),
('SKP01187', 'Penelitian berkas permohonan perizinan (per aplikasi pengajuan) - 30.0 menit', '30'),
('SKP01188', 'Penelitian berkas permohonan perizinan (per aplikasi pengajuan) - 15.0 menit', '15'),
('SKP01189', 'Penelitian berkas permohonan perizinan (per aplikasi pengajuan) - 5.0 menit', '5'),
('SKP01190', 'Penelitian berkas permohonan perizinan (teknis) - 10.0 menit', '10'),
('SKP01191', 'Penelitian berkas permohonan perizinan (teknis) - 5.0 menit', '5'),
('SKP01192', 'Penelitian berkas permohonan perizinan (teknis) - 15.0 menit', '15'),
('SKP01193', 'Penerimaan Hasil Pengadaan Barang / Jasa - 60.0 menit', '60'),
('SKP01194', 'Penerimaan Hasil Pengadaan Barang / Jasa - 30.0 menit', '30'),
('SKP01195', 'Pengawasan / Pelaksanaan Kegiatan Perencanaan dan Evaluasi Pengawasan / Melaksanakan kegiatan perencanaan pengawasan - 180.0 menit', '180'),
('SKP01196', 'Pengawasan / Pelaksanaan Kegiatan Perencanaan dan Evaluasi Pengawasan / Melaksanakan kegiatan perencanaan pengawasan - 60.0 menit', '60'),
('SKP01197', 'Pengawasan / Pelaksanaan Kegiatan Perencanaan dan Evaluasi Pengawasan / Melaksanakan kegiatan perencanaan pengawasan - 120.0 menit', '120'),
('SKP01198', 'Pengecapan Identitas Bahan Perpustakaan (Per 5 Buku) - 5.0 menit', '5'),
('SKP01199', 'Pengendalian organisme pengganggu tanaman (OPT) - 60.0 menit', '60'),
('SKP01200', 'Pengesahan gambar pelaksanaan bangunan / shop drawing / as built drawing untuk SLF (Per Gambar) - 15.0 menit', '15'),
('SKP01201', 'Pengesahan gambar pelaksanaan bangunan / shop drawing / as built drawing untuk SLF (Per Gambar) - 30.0 menit', '30'),
('SKP01202', 'Pengetikan Call Number Bahan Perpustakaan (Per 5 Buku) - 5.0 menit', '5'),
('SKP01203', 'Penggandaan berkas / dokumen - 0.1 menit', '0.1'),
('SKP01204', 'Penggandaan berkas / dokumen - 0.2 menit', '0.2'),
('SKP01205', 'Penginputan sisa mati anggaran - 30.0 menit', '30'),
('SKP01206', 'Pengurusan administrasi kepegawaian - 60.0 menit', '60'),
('SKP01207', 'Pengurusan administrasi kepegawaian - 30.0 menit', '30'),
('SKP01208', 'Pengurusan administrasi kepegawaian - 15.0 menit', '15'),
('SKP01209', 'Penindakan penyegelan sesuai dengan objek kerja - 60.0 menit', '60'),
('SKP01210', 'Penindakan terhadap pelanggaran Perda - 30.0 menit', '30'),
('SKP01211', 'Penindakan terhadap pelanggaran Perda - 60.0 menit', '60'),
('SKP01212', 'Penindakan terhadap pelanggaran Perda - 90.0 menit', '90'),
('SKP01213', 'Penomoran naskah dinas - 5.0 menit', '5'),
('SKP01214', 'Penyaluran Warga Binaan Sosial (WBS) per kegiatan - 60.0 menit', '60'),
('SKP01215', 'Penyaluran Warga Binaan Sosial (WBS) per kegiatan - 90.0 menit', '90'),
('SKP01216', 'Penyelesaian dokumen pertanggungjawaban belanja (SPJ) - 60.0 menit', '60'),
('SKP01217', 'Penyelesaian dokumen pertanggungjawaban belanja (SPJ) - 30.0 menit', '30'),
('SKP01218', 'Penyusunan Dokumen KUA-PPAS - 120.0 menit', '120'),
('SKP01219', 'Penyusunan Dokumen Rencana Kebutuhan Barang / Jasa - 60.0 menit', '60'),
('SKP01220', 'Penyusunan Dokumen Rencana Kebutuhan Barang / Jasa - 120.0 menit', '120'),
('SKP01221', 'Penyusunan Harga Perkiraan Sendiri (HPS) Barang / Jasa - 30.0 menit', '30'),
('SKP01222', 'Penyusunan Harga Perkiraan Sendiri (HPS) Barang / Jasa - 15.0 menit', '15'),
('SKP01223', 'Penyusunan RAB / HPS dalam Pengadaan Barang / Jasa - 120.0 menit', '120'),
('SKP01224', 'Penyusunan RAB / HPS dalam Pengadaan Barang / Jasa - 60.0 menit', '60'),
('SKP01225', 'Penyusunan Rencana Pelaksanaan Pengadaan Barang / Jasa (per kegiatan) - 120.0 menit', '120'),
('SKP01226', 'Penyusunan Rencana Pelaksanaan Pengadaan Barang / Jasa (per kegiatan) - 60.0 menit', '60'),
('SKP01227', 'Penyusunan Rencana Pemaketan Pekerjaan Pengadaan Barang / Jasa - 60.0 menit', '60'),
('SKP01228', 'Penyusunan Rencana Pemaketan Pekerjaan Pengadaan Barang / Jasa - 120.0 menit', '120'),
('SKP01229', 'Penyusutan Arsip - 30.0 menit', '30'),
('SKP01230', 'Penyusutan Arsip - 5.0 menit', '5'),
('SKP01231', 'Penyusutan Arsip - 15.0 menit', '15'),
('SKP01232', 'Perawatan Kesehatan Warga Binaan Sosial (WBS) per pasien - 10.0 menit', '10'),
('SKP01233', 'Perekaman / Pemotretan Arsip Mikro Film - 30.0 menit', '30'),
('SKP01234', 'Pre / Post Confrence Keperawatan - 20.0 menit', '20'),
('SKP01235', 'Pre / Post Confrence Keperawatan - 30.0 menit', '30'),
('SKP01236', 'Registrasi data pencari kerja - 5.0 menit', '5'),
('SKP01237', 'Registrasi Koleksi KCKR (Karya Cetak dan Karya Rekam) - 30.0 menit', '30'),
('SKP01238', 'Registrasi Koleksi KCKR (Karya Cetak dan Karya Rekam) - 90.0 menit', '90'),
('SKP01239', 'Registrasi Koleksi KCKR (Karya Cetak dan Karya Rekam) - 60.0 menit', '60'),
('SKP01240', 'Rekrutmen Tenaga Non PNS (per kegiatan) - 30.0 menit', '30'),
('SKP01241', 'Restorasi Perbaikan Arsip - 5.0 menit', '5'),
('SKP01242', 'Review Laporan Keuangan - 120.0 menit', '120'),
('SKP01243', 'Review Laporan Keuangan - 180.0 menit', '180'),
('SKP01244', 'Review Laporan Keuangan - 60.0 menit', '60'),
('SKP01245', 'Seleksi Bahan Perpustakaan - 10.0 menit', '10'),
('SKP01246', 'Setting Network pada perangkat keras / lunak - 10.0 menit', '10'),
('SKP01247', 'Supervisi Anggaran - 60.0 menit', '60'),
('SKP01248', 'Supervisi Anggaran - 30.0 menit', '30'),
('SKP01249', 'Supervisi Anggaran - 120.0 menit', '120'),
('SKP01250', 'Ujian Kompetensi Guru dan Pengawas jenjang SD, SMP, SMA, SMK - 180.0 menit', '180'),
('SKP01251', 'Uji Kelayakan Kendaraan Bermotor - 5.0 menit', '5'),
('SKP01252', 'Uji Kelayakan Kendaraan Bermotor - 15.0 menit', '15'),
('SKP01253', 'Uji Kelayakan Kendaraan Bermotor - 30.0 menit', '30'),
('SKP01254', 'Update Content Social Media - 2.0 menit', '2'),
('SKP01255', 'Verifikasi Buku Kas Umum (BKU) dan Buku Pembantu Lainnya - 30.0 menit', '30'),
('SKP01256', 'Verifikasi Buku Kas Umum (BKU) dan Buku Pembantu Lainnya - 60.0 menit', '60'),
('SKP01257', 'Verifikasi Daftar Gaji / Daftar TKD / Daftar tunjangan lainnya - 15.0 menit', '15'),
('SKP01258', 'Verifikasi Daftar Gaji / Daftar TKD / Daftar tunjangan lainnya - 30.0 menit', '30'),
('SKP01259', 'Verifikasi Daftar Gaji / Daftar TKD / Daftar tunjangan lainnya - 60.0 menit', '60'),
('SKP01260', 'Verifikasi dokumen kontrak pengadaan barang / jasa - 90.0 menit', '90'),
('SKP01261', 'Verifikasi dokumen kontrak pengadaan barang / jasa - 30.0 menit', '30'),
('SKP01262', 'Verifikasi dokumen kontrak pengadaan barang / jasa - 60.0 menit', '60'),
('SKP01263', 'Verifikasi Surat Perintah Pembayaran (SPP) - 15.0 menit', '15'),
('SKP01264', 'Verifikasi Surat Perintah Pembayaran (SPP) - 30.0 menit', '30'),
('SKP01265', 'Verifikasi Surat Pertanggungjawaban (SPJ) - 15.0 menit', '15');
INSERT INTO `skp` (`kd_skp`, `skp`, `waktu`) VALUES
('SKP01266', 'Verifikasi Surat Pertanggungjawaban (SPJ) - 30.0 menit', '30'),
('SKP01267', 'Verifikasi Surat Pertanggungjawaban (SPJ) - 60.0 menit', '60'),
('SKP01268', 'Wawancara teknis terhadap pelaku teknis bangunan untuk proses permohonan IPTB baru / perpanjangan - 30.0 menit', '30'),
('SKP01269', 'Melakukan penyuluhan - 60.0 menit', '60'),
('SKP01270', 'Melaksanakan tugas bantuan kesehatan lapangan seperti pada situasi gadar dan bencana - 180.0 menit', '180'),
('SKP01271', 'Melaksanakan / Melayani Konsultasi Individu / kelompok - 30.0 menit', '30'),
('SKP01272', 'Melakukan rujukan - 30.0 menit', '30'),
('SKP01273', 'Melaksanakan imunisasi, vaksinasi, feed additive - 15.0 menit', '15'),
('SKP01274', 'Melaksanakan imunisasi, vaksinasi, feed additive - 60.0 menit', '60'),
('SKP01275', 'Melaksanakan pemeriksaan pasien - 5.0 menit', '5'),
('SKP01276', 'Melaksanakan 5 R (Ringkas, Rapi, Resik, Rawat, Rajin) - 30.0 menit', '30'),
('SKP01277', 'Melaksanakan 5 R (Ringkas, Rapi, Resik, Rawat, Rajin) - 60.0 menit', '60'),
('SKP01278', 'Melaksanakan / Melayani Konsultasi Individu / kelompok - 15.0 menit', '15'),
('SKP01279', 'Melaksanakan pemeriksaan pasien - 15.0 menit', '15'),
('SKP01280', 'Melaksanakan pemeriksaan pasien - 30.0 menit', '30'),
('SKP01281', 'Melaksanakan pengolahan dokumen rekam medis - 15.0 menit', '15'),
('SKP01282', 'Melaksanakan pengolahan dokumen rekam medis - 30.0 menit', '30'),
('SKP01283', 'Melaksanakan / Melayani Konsultasi Individu / kelompok - 60.0 menit', '60'),
('SKP01284', 'Melaksanakan Kegiatan Pembinaan - 30.0 menit', '30'),
('SKP01285', 'Melaksanakan Kegiatan Pembinaan - 60.0 menit', '60'),
('SKP01286', 'Mengikuti rapat koordinasi - 180.0 menit', '180'),
('SKP01287', 'Melaksanakan / mengikuti kegiatan apel / upacara - 90.0 menit', '90'),
('SKP01288', 'Menyusun data / laporan - 15.0 menit', '15'),
('SKP01289', 'Menyusun data / laporan - 30.0 menit', '30'),
('SKP01290', 'Melakukan anamnesa keperawatan per pasien - 5.0 menit', '5'),
('SKP01291', 'Melaksanakan tugas kedinasan lain yang diperintahkan oleh pimpinan baik tertulis maupun lisan - 30.0 menit', '30'),
('SKP01292', 'Melaksanakan tugas kedinasan lain yang diperintahkan oleh pimpinan baik tertulis maupun lisan - 60.0 menit', '60'),
('SKP01293', 'Melakukan tindakan keperawatan - 30.0 menit', '30'),
('SKP01294', 'Melakukan tindakan keperawatan - 20.0 menit', '20'),
('SKP01295', 'Pemeliharaan dan Perawatan alat kesehatan - 10.0 menit', '10'),
('SKP01296', 'Mengikuti rapat koordinasi - 45.0 menit', '45'),
('SKP01297', 'Mengikuti rapat koordinasi - 60.0 menit', '60'),
('SKP01298', 'Mengikuti rapat koordinasi - 90.0 menit', '90'),
('SKP01299', 'Mengikuti rapat koordinasi - 120.0 menit', '120'),
('SKP01300', 'Melaksanakan / mengikuti kegiatan apel / upacara - 60.0 menit', '60'),
('SKP01301', 'Menolong Persalinan - 60.0 menit', '60'),
('SKP01302', 'Melaksanakan Pemeriksaan Bayi baru Lahir - 60.0 menit', '60'),
('SKP01303', 'Melakukan Pemasangan IUD Pasca Plasenta - 30.0 menit', '30'),
('SKP01304', 'Melakukan Kontrol Nifas Pada Ibu - 60.0 menit', '60'),
('SKP01306', 'Melakukan Tindik bayi -30.0 menit', '30'),
('SKP01307', 'Melakukan Observasi Ibu Bersalin -120.0 menit', '120'),
('SKP01308', 'Melaksanakan Sterilisasi Alat -15.0 menit', '15'),
('SKP01309', 'Membuat Surat Rujukan -15.0 menit', '15'),
('SKP01310', 'Melakukan tindakan Kebidanan -30.0 menit', '30'),
('SKP01311', 'Melakukan anamnesa keperawatan per pasien - 5.0 menit', '5'),
('SKP01312', 'Melakukan Skrining Hipotiroid Kongenital -30.0 menit', '30'),
('SKP01313', 'Melakukan Tindakan Kebidanan - 30.0 menit', '30'),
('SKP01314', 'Mengganti Cairan Processing Film - 90.0 menit', '90'),
('SKP01315', 'Mengikuti Orientasi - 120.0 menit', '120'),
('TAMBAHAN', 'Aktifitas Tambahan', '0'),
('UTAMA', 'Aktifitas Utama', '0');

-- --------------------------------------------------------

--
-- Table structure for table `skpd`
--

CREATE TABLE `skpd` (
  `id_skpd` varchar(8) NOT NULL,
  `n_skpd` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `skpd`
--

INSERT INTO `skpd` (`id_skpd`, `n_skpd`) VALUES
('1.02', 'Dinas Kesehatan Pemprov. DKI Jakarta');

-- --------------------------------------------------------

--
-- Table structure for table `skptahunan`
--

CREATE TABLE `skptahunan` (
  `id_skptahunan` varchar(8) NOT NULL,
  `nip` varchar(30) NOT NULL,
  `kd_skp` varchar(160) NOT NULL,
  `id_bag` varchar(25) NOT NULL,
  `kuant` varchar(5) NOT NULL,
  `kual` varchar(5) NOT NULL,
  `waktu` varchar(8) NOT NULL,
  `t_buat` varchar(8) NOT NULL,
  `t_edit` varchar(8) NOT NULL,
  `waktu_e` int(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `status`
--

CREATE TABLE `status` (
  `id_status` varchar(8) NOT NULL,
  `n_status` varchar(25) NOT NULL,
  `nilai` varchar(8) NOT NULL,
  `id_skpd` varchar(10) NOT NULL,
  `id_ukpd` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `status`
--

INSERT INTO `status` (`id_status`, `n_status`, `nilai`, `id_skpd`, `id_ukpd`) VALUES
('K-2', 'MENIKAH ANAK 2', '1.14', '1.02', '1.02.058'),
('K-1', 'MENIKAH ANAK 1', '1.12', '1.02', '1.02.058'),
('K-0', 'MENIKAH', '1.1', '1.02', '1.02.058'),
('TK-0', 'LAJANG', '1', '1.02', '1.02.058'),
('TK-1', 'JANDA/DUDA ANAK 1', '1.02', '1.02', '1.02.058'),
('TK-2', 'JANDA/DUDA ANAK 2', '1.04', '1.02', '1.02.058');

-- --------------------------------------------------------

--
-- Table structure for table `ukpd`
--

CREATE TABLE `ukpd` (
  `id_ukpd` varchar(8) NOT NULL,
  `n_ukpd` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ukpd`
--

INSERT INTO `ukpd` (`id_ukpd`, `n_ukpd`) VALUES
('1.02.058', 'Puskesmas Kec Pasar Minggu');

-- --------------------------------------------------------

--
-- Table structure for table `user_id`
--

CREATE TABLE `user_id` (
  `userid` varchar(50) NOT NULL,
  `passid` varchar(50) NOT NULL,
  `level_user` varchar(25) NOT NULL,
  `id_skpd` varchar(10) NOT NULL,
  `id_ukpd` varchar(10) NOT NULL,
  `id_bag` varchar(8) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `nip` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_id`
--

INSERT INTO `user_id` (`userid`, `passid`, `level_user`, `id_skpd`, `id_ukpd`, `id_bag`, `nama`, `nip`) VALUES
('admin', 'admpsm', '11', '', '', '', 'Administrator', ''),
('kapus', '123456', '9', '1.02', '1.02.058', 'Kapus', 'dr Sri Rejeki Amelia', ''),
('katu', '123456', '9', '1.02', '1.02.058', 'Ka. TU', 'Dumauli, SKM,. Kep', ''),
('validasi', '123456', '8', '1.02', '1.02.058', 'validasi', 'Dumauli, SKM,. Kep', ''),
('pasarminggu', '123456', '8', '1.02', '1.02.058', 'Ka. PSM', 'drg Wahyu Erni Irawati', ''),
('pejatenbarat1', '123456', '8', '1.02', '1.02.058', 'Ka. PB1', 'dr Mona Fardiana', ''),
('pejatenbarat2', '123456', '8', '1.02', '1.02.058', 'Ka. PB2', 'drg Nurlaelah', ''),
('pejatenbarat3', '123456', '8', '1.02', '1.02.058', 'Ka. PB3', 'drg Ningtje Wibisono', ''),
('pejatentimur', '123456', '8', '1.02', '1.02.058', 'Ka. PTR', 'dr Sri Ratnawati', ''),
('cilandaktimur', '123456', '8', '1.02', '1.02.058', 'Ka. CTM', 'dr Wida Wildani', ''),
('kebagusan', '123456', '8', '1.02', '1.02.058', 'Ka. KB', 'drg Widyastari', ''),
('jatipadang', '123456', '8', '1.02', '1.02.058', 'Ka. JP', 'drg Emmy Madu Retno', ''),
('ragunan', '123456', '8', '1.02', '1.02.058', 'Ka. RGN', 'dr Eksap Nurhati Ulfah', ''),
('fathan', 'fathan', '7', '1.02', '1.02.058', 'B01', 'FAT HAN FARASHY', '8112026\r\n'),
('abdulgani', 'abdulgani', '7', '1.02', '1.02.058', 'B01', 'ABDUL GANI', '8112001\r\n'),
('abdurahman', 'abdurahman', '7', '1.02', '1.02.058', 'B01', 'ABDURAHMAN H A WAHAB', '8112002\r\n'),
('ademardiana', 'ademardiana', '7', '1.02', '1.02.058', 'B01', 'ADE MARDIANA', '8106001\r\n'),
('aisyah', 'aisyah', '7', '1.02', '1.02.058', 'B08', 'AISYAH LEGITA', '8110001\r\n'),
('ajeng', 'ajeng', '7', '1.02', '1.02.058', 'B01', 'AJENG DIAN TOPANI', '8104001\r\n'),
('amalia', 'amalia', '7', '1.02', '1.02.058', 'B07', 'AMALIA JAMIL', '8106002\r\n	'),
('andi', 'andi', '7', '1.02', '1.02.058', 'B01', 'ANDI PRADANA KUSUMA AJI', '8104038\r\n'),
('anisa', 'anisa', '7', '1.02', '1.02.058', 'B01', 'ANISA DEANIRA PUTRI', '8108006\r\n	'),
('anna', 'anna', '7', '1.02', '1.02.058', 'B06', 'ANNA SAFITRI ARIEF FIANTI', '8101001\r\n'),
('arifwibowo', 'arifwibowo', '7', '1.02', '1.02.058', 'B01', 'ARIF WIBOWO', '8104002\r\n'),
('ayupuspita', 'ayupuspita', '7', '1.02', '1.02.058', 'B09', 'AYU PUSPITA SARI', '8107001\r\n'),
('ayuwandira', 'ayuwandira', '7', '1.02', '1.02.058', 'B01', 'AYU WANDIRA', '8117001\r\n'),
('berly', 'berly', '7', '1.02', '1.02.058', 'B10', 'BERLY ANFRILIA', '8107002\r\n'),
('boedi', 'boedi', '7', '1.02', '1.02.058', 'B07', 'BOEDI PRADIPAJIWA', '8112003\r\n'),
('chyndhia', 'chyndhia', '7', '1.02', '1.02.058', 'B09', 'CHYNDHIA HERADHINA ISKANDAR', '8102001\r\n'),
('ciciamalia', 'ciciamalia', '7', '1.02', '1.02.058', 'B07', 'CICI AMALIA', '8106004\r\n'),
('cyntia', 'cyntia', '7', '1.02', '1.02.058', 'B07', 'CYNTIA KUSUMA DEWI', '8106005\r\n'),
('dalila', 'dalila', '7', '1.02', '1.02.058', 'B01', 'DALILA RIFAIE', '8106006\r\n	'),
('daudyusuf', 'daudyusuf', '7', '1.02', '1.02.058', 'B01', 'DAUD YUSUF', '8112004\r\n'),
('debora', 'debora', '7', '1.02', '1.02.058', 'B01', 'DEBORA BANJAR NAHOR', '8106007\r\n'),
('dedy', 'dedy', '7', '1.02', '1.02.058', 'B01', 'DEDY ANTONIUS SINAGA', '8112005\r\n'),
('deni', 'deni', '7', '1.02', '1.02.058', 'B01', 'DENI FEBRIANI', '8106008\r\n'),
('desi', 'desi', '7', '1.02', '1.02.058', 'B04', 'DESI FAJAR LESTARI', '8111001\r\n'),
('desiliana', 'desiliana', '7', '1.02', '1.02.058', 'B01', 'DESI LIANA', '8106009\r\n'),
('desiana', 'desiana', '7', '1.02', '1.02.058', 'B02', 'DESIANA SANTRI', '8106010\r\n'),
('dewi', 'dewi', '7', '1.02', '1.02.058', 'B01', 'DEWI JAYANTI', '8104003\r\n'),
('diankurniasih', 'diankurniasih', '7', '1.02', '1.02.058', 'B09', 'DIAN KURNIASIH', '8106040\r\n'),
('dianpuspa', 'dianpuspa', '7', '1.02', '1.02.058', 'B01', 'DIAN PUSPA LESTARI MANALU', '8106011\r\n'),
('diansaputra', 'diansaputra', '7', '1.02', '1.02.058', 'B01', 'DIAN SAPUTRA', '8104004\r\n'),
('dinahelvina', 'dinahelvina', '7', '1.02', '1.02.058', 'B01', 'DINA HELVINA', '8104005\r\n'),
('dini', 'dini', '7', '1.02', '1.02.058', 'B10', 'DINI AULIA HAYATI', '8112006\r\n'),
('shadratul', 'shadratul', '7', '1.02', '1.02.058', 'B10', 'DR SHADRATUL KHAIRAH', '8102012\r\n'),
('dita', 'dita', '7', '1.02', '1.02.058', 'B01', 'DR. DITA INDRASWARI', '8102002\r\n'),
('dwi', 'dwi', '7', '1.02', '1.02.058', 'B01', 'DWI AHMAD ROMADHON', '8104006\r\n'),
('dwinuryanti', 'dwinuryanti', '7', '1.02', '1.02.058', 'B01', 'DWI NURYANTI HANDAYANI', '8106012\r\n'),
('dyah', 'dyah', '7', '1.02', '1.02.058', 'B01', 'DYAH ENI SUSANTI', '8108001\r\n'),
('efriyan', 'efriyan', '7', '1.02', '1.02.058', 'B01', 'EFRIYAN', '8103001\r\n'),
('ekoedi', 'ekoedi', '7', '1.02', '1.02.058', 'B07', 'EKO EDI PURNOMO', '8104007\r\n'),
('ekosetiawan', 'ekosetiawan', '7', '1.02', '1.02.058', 'B01', 'EKO SETIAWAN', '8112007\r\n'),
('elia', 'elia', '7', '1.02', '1.02.058', 'B01', 'ELIA SARI L TORUAN', '8104008\r\n'),
('elliana', 'elliana', '7', '1.02', '1.02.058', 'B02', 'ELLIANA RACHMAWATI', '8110002\r\n'),
('elviana', 'elviana', '7', '1.02', '1.02.058', 'B07', 'ELVIANA SARY', '8107003\r\n'),
('endah', 'endah', '7', '1.02', '1.02.058', 'B01', 'ENDAH WIDIANINGSIH', '8112008\r\n'),
('endang', 'endang', '7', '1.02', '1.02.058', 'B01', 'ENDANG SULASTRI', '8106013\r\n'),
('endis', 'endis', '7', '1.02', '1.02.058', 'B01', 'ENDIS PERJUANGAN LOMBAN TORUAN', '8104009\r\n'),
('erlyanitha', 'erlyanitha', '7', '1.02', '1.02.058', 'B08', 'ERLYANITHA MADUMARIA PURBA', '8106014\r\n'),
('evi', 'evi', '7', '1.02', '1.02.058', 'B01', 'EVI RATMAYANA', '8102003\r\n'),
('farah', 'farah', '7', '1.02', '1.02.058', 'B01', 'FARAH AMSIA KHODIJAH', '8102004\r\n'),
('fatia', 'fatia', '7', '1.02', '1.02.058', 'B03', 'FATIA HURIATI', '8104011\r\n'),
('febrina', 'febrina', '7', '1.02', '1.02.058', 'B01', 'FEBRINA LARASSATI', '8104012\r\n'),
('fenty', 'fenty', '7', '1.02', '1.02.058', 'B01', 'FENTY ARYANI', '8104013\r\n'),
('fitrah', 'fitrah', '7', '1.02', '1.02.058', 'B04', 'FITRAH MAULANA APRIYADI', '8112009\r\n'),
('fitriandam', 'fitriandam', '7', '1.02', '1.02.058', 'B03', 'FITRI ANDAM DEWI', '8102005\r\n'),
('fitriapriyanti', 'fitriapriyanti', '7', '1.02', '1.02.058', 'B01', 'FITRI APRIYANTI', '8106015\r\n'),
('fitrilia', 'fitrilia', '7', '1.02', '1.02.058', 'B09', 'FITRILIA YANANDA', '8112010\r\n'),
('fitriyati', 'fitriyati', '7', '1.02', '1.02.058', 'B01', 'FITRIYATI AGUSTIN MORRY', '8106017\r\n'),
('gilangeka', 'gilangeka', '7', '1.02', '1.02.058', 'B01', 'GILANG EKA PERSADA', '8108005\r\n'),
('amarwati', 'amarwati', '7', '1.02', '1.02.058', 'B01', 'AMARWATI PUTRI AKHARI', '8101005\r\n'),
('hasan', 'hasan', '7', '1.02', '1.02.058', 'B01', 'HASAN ALBANA', '8112011\r\n'),
('hendra', 'hendra', '7', '1.02', '1.02.058', 'B01', 'HENDRA', '8112012\r\n'),
('hermawan', 'hermawan', '7', '1.02', '1.02.058', 'B01', 'HERMAWAN', '8112013\r\n'),
('hermayani', 'hermayani', '7', '1.02', '1.02.058', 'B04', 'HERMAYANI PRATIWI', '8104036\r\n'),
('hesti', 'hesti', '7', '1.02', '1.02.058', 'B01', 'HESTI YUNITA', '8106018\r\n'),
('husniyah', 'husniyah', '7', '1.02', '1.02.058', 'B01', 'HUSNIYAH IDRUS', '8106019\r\n'),
('ibramanto', 'ibramanto', '7', '1.02', '1.02.058', 'B03', 'IBRAMANTO WARGANEGARA', '8101002\r\n'),
('inarahayu', 'inarahayu', '7', '1.02', '1.02.058', 'B07', 'INA RAHAYU GINTING', '8106020\r\n'),
('indri', 'indri', '7', '1.02', '1.02.058', 'B01', 'INDRI TIARA FEBRIYANTI', '8104015\r\n'),
('irawanwibowo', 'irawanwibowo', '7', '1.02', '1.02.058', 'B08', 'IRAWAN WIBOWO', '8112014\r\n'),
('irene', 'irene', '7', '1.02', '1.02.058', 'B07', 'IRENE DWI PUTRI', '8111002\r\n'),
('irrny', 'irrny', '7', '1.02', '1.02.058', 'B01', 'IRRNY AVIYANTI S', '8112015\r\n'),
('isharyani', 'isharyani', '7', '1.02', '1.02.058', 'B07', 'ISHARYANI MARCELLA . A', '8106021\r\n'),
('ismail', 'ismail', '7', '1.02', '1.02.058', 'B01', 'ISMAIL SALEH', '8107004\r\n'),
('istiyanah', 'istiyanah', '7', '1.02', '1.02.058', 'B07', 'ISTIYANAH AYUNINGTIYAS', '8106022\r\n'),
('jane', 'jane', '7', '1.02', '1.02.058', 'B06', 'JANE ROULI MARYAN', '8112016\r\n'),
('khairunnisani', 'khairunnisani', '7', '1.02', '1.02.058', 'B01', 'KHAIRUNNISANI', '8106023\r\n'),
('liasofiana', 'liasofiana', '7', '1.02', '1.02.058', 'B06', 'LIA SOFIANA', '8102006\r\n'),
('lusika', 'lusika', '7', '1.02', '1.02.058', 'B03', 'LUSIKA RUSWANDI', '8104033\r\n'),
('lydia', 'lydia', '7', '1.02', '1.02.058', 'B01', 'LYDIA RIANAWATI', '8104016\r\n'),
('khoirun', 'khoirun', '7', '1.02', '1.02.058', 'B01', 'M. KHOIRUN NASIKIN', '8104017\r\n'),
('maryata', 'maryata', '7', '1.02', '1.02.058', 'B01', 'MARYATA', '8112017\r\n'),
('maya', 'maya', '7', '1.02', '1.02.058', 'B02', 'MAYA ISMAYANTI', '8111003\r\n'),
('meike', 'meike', '7', '1.02', '1.02.058', 'B01', 'MEIKE FREDERIKA SALAKORY', '8102007\r\n'),
('miaayu', 'miaayu', '7', '1.02', '1.02.058', 'B01', 'MIA AYU PRASETYA DIYAN ASTRI', '8104018\r\n'),
('monika', 'monika', '7', '1.02', '1.02.058', 'B01', 'MONIKA', '8107005\r\n'),
('muthia', 'muthia', '7', '1.02', '1.02.058', 'B10', 'MUTHIA SULISTIANTU PUTRI', '8110008\r\n'),
('nabila', 'nabila', '7', '1.02', '1.02.058', 'B01', 'NABILA NURUL HASANAH', '8102024\r\n'),
('nadia', 'nadia', '7', '1.02', '1.02.058', 'B01', 'NADIA KHOIRONI', '8104019\r\n'),
('setyo', 'setyo', '7', '1.02', '1.02.058', 'B01', 'NADIA SETYO PRATAMA', '8112018\r\n'),
('nima', 'nima', '7', '1.02', '1.02.058', 'B03', 'NIMA ULYA DARAJAH', '8102022\r\n'),
('niza', 'niza', '7', '1.02', '1.02.058', 'B08', 'NIZA HATMAINI', '8104020\r\n'),
('noer', 'noer', '7', '1.02', '1.02.058', 'B01', 'NOER AFNI ASTUTI', '8107014\r\n'),
('notika', 'notika', '7', '1.02', '1.02.058', 'B07', 'NOTIKA TIMURIYANINGSIH', '8102008\r\n'),
('noviani', 'noviani', '7', '1.02', '1.02.058', 'B04', 'NOVIANI DWI SYAFUTRI', '8110007\r\n'),
('nuralfiani', 'nuralfiani', '7', '1.02', '1.02.058', 'B02', 'NUR ALFIANI', '8102009\r\n'),
('nurfitri', 'nurfitri', '7', '1.02', '1.02.058', 'B02', 'NUR FITRI OKTAVIYANI', '8104037\r\n'),
('nurani', 'nurani', '7', '1.02', '1.02.058', 'B02', 'NURANI SUDI RAHAYU', '8105001\r\n'),
('nuratikah', 'nuratikah', '7', '1.02', '1.02.058', 'B01', 'NURATIKAH AULIYAH.Y', '8106025\r\n'),
('nurul', 'nurul', '7', '1.02', '1.02.058', 'B01', 'NURUL FITRIYANI', '8106041\r\n'),
('oktavialivia', 'oktavialivia', '7', '1.02', '1.02.058', 'B01', 'OKTAVIALIVIA SIBURIAN', '8107006\r\n'),
('pradita', 'pradita', '7', '1.02', '1.02.058', 'B05', 'PRADITA ADININGSIH', '8102018\r\n'),
('pratiwi', 'pratiwi', '7', '1.02', '1.02.058', 'B01', 'PRATIWI SEPTIANI', '8104035\r\n'),
('prita', 'prita', '7', '1.02', '1.02.058', 'B01', 'PRITA KURNIA AGUSTINA', '8102010\r\n'),
('puji', 'puji', '7', '1.02', '1.02.058', 'B01', 'PUJI LESTARI', '8108002\r\n'),
('purhaniyung', 'purhaniyung', '7', '1.02', '1.02.058', 'B01', 'PURHANIYUNG SAYEKTI', '8106026\r\n'),
('putri', 'putri', '7', '1.02', '1.02.058', 'B01', 'PUTRI ANASTASIA', '8104021\r\n'),
('rafika', 'rafika', '7', '1.02', '1.02.058', 'B01', 'RAFIKA CHRISTIN MARPAUNG', '8106027\r\n'),
('rahmansyah', 'rahmansyah', '7', '1.02', '1.02.058', 'B01', 'RAHMANSYAH', '8112019\r\n'),
('ranny', 'ranny', '7', '1.02', '1.02.058', 'B06', 'RANNY PURNAMA SARI', '8107007\r\n'),
('reza', 'reza', '7', '1.02', '1.02.058', 'B01', 'REZA SUMANJAYA', '8105002\r\n'),
('rianna', 'rianna', '7', '1.02', '1.02.058', 'B01', 'RIANNA PASMAJA', '8106039\r\n'),
('rijki', 'rijki', '7', '1.02', '1.02.058', 'B07', 'RIJKI HALIYAH', '8106028\r\n'),
('rika', 'rika', '7', '1.02', '1.02.058', 'B01', 'RIKA LUKMAWATI', '8104022\r\n'),
('rinalestiana', 'rinalestiana', '7', '1.02', '1.02.058', 'B01', 'RINA LESTIANA DEVI', '8106029\r\n'),
('rinatimur', 'rinatimur', '7', '1.02', '1.02.058', 'B09', 'RINA TIMUR PUTRI SANDARI', '8104034\r\n'),
('rindi', 'rindi', '7', '1.02', '1.02.058', 'B01', 'RINDI INDAH WULANDARI', '8106030\r\n'),
('rizka', 'rizka', '7', '1.02', '1.02.058', 'B05', 'RIZKA PRATIWI', '8107008\r\n'),
('rizky', 'rizky', '7', '1.02', '1.02.058', 'B01', 'RIZKY NURLIANA', '8104023\r\n'),
('rofisika', 'rofisika', '7', '1.02', '1.02.058', 'B08', 'ROFISIKA HANDARI', '8111004\r\n'),
('rori', 'rori', '7', '1.02', '1.02.058', 'B01', 'RORI SYAPUTRA', '8104024\r\n'),
('saepuloh', 'saepuloh', '7', '1.02', '1.02.058', 'B01', 'SAEPULOH', '8112020\r\n'),
('sandi', 'sandi', '7', '1.02', '1.02.058', 'B01', 'SANDI MUHAMAD RIZKI', '8107009\r\n'),
('saparoni', 'saparoni', '7', '1.02', '1.02.058', 'B01', 'SAPARONI', '8108003\r\n'),
('sari', 'sari', '7', '1.02', '1.02.058', 'B04', 'SARI RAHAYU', '8102011\r\n'),
('selvi', 'selvi', '7', '1.02', '1.02.058', 'B07', 'SELVI OKTARINI', '8106031\r\n'),
('septia', 'septia', '7', '1.02', '1.02.058', 'B01', 'SEPTIA DWI KARYONO', '8105003\r\n'),
('shofia', 'shofia', '7', '1.02', '1.02.058', 'B07', 'SHOFIA MARWA HAMDI', '8106032\r\n'),
('siskarama', 'siskarama', '7', '1.02', '1.02.058', 'B06', 'SISKA RAMA YULIANA', '8111005\r\n'),
('siskasantoso', 'siskasantoso', '7', '1.02', '1.02.058', 'B06', 'SISKA SANTOSO', '8110006\r\n'),
('sitatun', 'sitatun', '7', '1.02', '1.02.058', 'B06', 'SITATUN', '8106033\r\n'),
('sitianita', 'sitianita', '7', '1.02', '1.02.058', 'B01', 'SITI ANITA RIZKILILLAH', '8104025\r\n'),
('sitihumaira', 'sitihumaira', '7', '1.02', '1.02.058', 'B04', 'SITI HUMAIRA', '8107010\r\n'),
('sitikodariah', 'sitikodariah', '7', '1.02', '1.02.058', 'B02', 'SITI KODARIAH', '8107011\r\n'),
('sitinur', 'sitinur', '7', '1.02', '1.02.058', 'B08', 'SITI NUR MUNZIATI', '8107012\r\n'),
('sitizahra', 'sitizahra', '7', '1.02', '1.02.058', 'B01', 'SITI ZAHRA HUMAIRA', '8105005\r\n'),
('sona', 'sona', '7', '1.02', '1.02.058', 'B01', 'SONA GUSTRISNA', '8104026\r\n'),
('sonny', 'sonny', '7', '1.02', '1.02.058', 'B05', 'SONNY FERNANDO', '8112021\r\n'),
('srinawangsih', 'srinawangsih', '7', '1.02', '1.02.058', 'B10', 'SRI NAWANGSIH', '8104027\r\n'),
('sriwahyu', 'sriwahyu', '7', '1.02', '1.02.058', 'B01', 'SRI WAHYU LESTARI', '8113001\r\n'),
('suharti', 'suharti', '7', '1.02', '1.02.058', 'B01', 'SUHARTI', '8109001\r\n'),
('supadmi', 'supadmi', '7', '1.02', '1.02.058', 'B01', 'SUPADMI', '8113002\r\n'),
('suparman', 'suparman', '7', '1.02', '1.02.058', 'B01', 'SUPARMAN', '8112022\r\n'),
('supriyatin', 'supriyatin', '7', '1.02', '1.02.058', 'B01', 'SUPRIYATIN', '8104028\r\n'),
('syifa', 'syifa', '7', '1.02', '1.02.058', 'B01', 'SYIFA AMELIA KHAIRUNNISA', '8107013\r\n'),
('sylvia', 'sylvia', '7', '1.02', '1.02.058', 'B07', 'SYLVIA MEGASARI', '8106034\r\n'),
('taufics', 'taufics', '7', '1.02', '1.02.058', 'B01', 'TAUFICS ANGGARA', '8102014\r\n'),
('ulfa', 'ulfa', '7', '1.02', '1.02.058', 'B01', 'ULFA RIEZKYA GUSMI', '8106042\r\n'),
('veronica', 'veronica', '7', '1.02', '1.02.058', 'B01', 'VERONICA', '8104029\r\n'),
('vina', 'vina', '7', '1.02', '1.02.058', 'B01', 'VINA MARDHIANA', '8106035\r\n'),
('vincentia', 'vincentia', '7', '1.02', '1.02.058', 'B01', 'VINCENTIA DAVANTININGSIH', '8102016\r\n'),
('wahyuni', 'wahyuni', '7', '1.02', '1.02.058', 'B01', 'WAHYUNI ROSIANA', '8112023\r\n'),
('winda', 'winda', '7', '1.02', '1.02.058', 'B09', 'WINDA RAMADANI', '8102023\r\n'),
('wiwik', 'wiwik', '7', '1.02', '1.02.058', 'B01', 'WIWIK WIDHIHASTUTI', '8112024\r\n'),
('wulan', 'wulan', '7', '1.02', '1.02.058', 'B01', 'WULAN QURRIYATI', '8104030\r\n'),
('yefti', 'yefti', '7', '1.02', '1.02.058', 'B08', 'YEFTI CAROLINE', '8102021\r\n'),
('yoga', 'yoga', '7', '1.02', '1.02.058', 'B01', 'YOGA OKTAVIAN', '8112025\r\n'),
('yohana', 'yohana', '7', '1.02', '1.02.058', 'B01', 'YOHANA ERITA MANULLANG', '8106036\r\n'),
('yuanita', 'yuanita', '7', '1.02', '1.02.058', 'B07', 'YUANITA MEGA SARI', '8104031\r\n'),
('yudialfani', 'yudialfani', '7', '1.02', '1.02.058', 'B01', 'YUDI ALFANI KUSUMA', '8108004\r\n'),
('yudiperdiansyah', 'yudiperdiansyah', '7', '1.02', '1.02.058', 'B01', 'YUDI PERDIANSYAH', '8104032\r\n'),
('yuditha', 'yuditha', '7', '1.02', '1.02.058', 'B03', 'YUDITHA  MARSELINA', '8105004\r\n'),
('yuni', 'yuni', '7', '1.02', '1.02.058', 'B08', 'YUNI ASTUTI', '8106037\r\n'),
('yunitadewi', 'yunitadewi', '7', '1.02', '1.02.058', 'B03', 'YUNITA DEWI FATHONAH', '8107015\r\n'),
('yunitamariana', 'yunitamariana', '7', '1.02', '1.02.058', 'B01', 'YUNITA MARIANA\r\n', '8106038\r\n'),
('yusuf', 'yusuf', '7', '1.02', '1.02.058', 'B03', 'YUSUF DAWUDI', '8111006\r\n'),
('ukp', '123456', '8', '1.02', '1.02.058', 'B12', 'dr Sari Agustina', ''),
('ukm', '123456', '8', '1.02', '1.02.058', 'B11', 'dr Evi', ''),
('adm', 'admpsm', '4', '1.02', '1.02.058', '', 'Admin', ''),
('rebekka', 'rebekka', '7', '1.02', '1.02.058', 'B02', 'DR REBEKKA PITA U.S', '8102025');

-- --------------------------------------------------------

--
-- Table structure for table `validasi`
--

CREATE TABLE `validasi` (
  `id_validasi` varchar(8) NOT NULL,
  `nip` varchar(20) NOT NULL,
  `nama` varchar(15) NOT NULL,
  `tanggal` date NOT NULL,
  `jabatan` int(30) NOT NULL,
  `n_skp` int(8) NOT NULL,
  `n_anggaran` int(8) NOT NULL,
  `n_prilaku` int(11) NOT NULL,
  `hasil` varchar(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `waktu_k`
--

CREATE TABLE `waktu_k` (
  `id_waktu_k` varchar(8) NOT NULL,
  `nip` varchar(30) NOT NULL,
  `sakit1` int(8) NOT NULL,
  `sakit2` int(8) NOT NULL,
  `alpha` int(8) NOT NULL,
  `telat` int(8) NOT NULL,
  `c_sakit_k` int(8) NOT NULL,
  `c_alasan_k` int(8) NOT NULL,
  `c_persalinan_k` int(8) NOT NULL,
  `c_besar_k` int(8) NOT NULL,
  `izin` int(8) NOT NULL,
  `izin_s` int(8) NOT NULL,
  `meninggal` int(8) NOT NULL,
  `tanggal` date NOT NULL,
  `t_waktu_k` int(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `waktu_kerja`
--

CREATE TABLE `waktu_kerja` (
  `id_waktu` varchar(8) NOT NULL,
  `tanggal` date NOT NULL,
  `hari` varchar(8) NOT NULL,
  `id_skpd` varchar(10) NOT NULL,
  `id_ukpd` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `waktu_kerja`
--

INSERT INTO `waktu_kerja` (`id_waktu`, `tanggal`, `hari`, `id_skpd`, `id_ukpd`) VALUES
('WKK00001', '2017-04-28', '18', '1.02', '1.02.058');

-- --------------------------------------------------------

--
-- Table structure for table `waktu_t`
--

CREATE TABLE `waktu_t` (
  `id_waktu_t` varchar(8) NOT NULL,
  `nip` varchar(30) NOT NULL,
  `c_sakit_t` int(8) NOT NULL,
  `c_alasan_t` int(8) NOT NULL,
  `c_tahunan_t` int(8) NOT NULL,
  `diklat` int(8) NOT NULL,
  `spd` int(8) NOT NULL,
  `haji` int(8) NOT NULL,
  `tanggal` date NOT NULL,
  `t_waktu_t` int(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `absensi`
--
ALTER TABLE `absensi`
  ADD PRIMARY KEY (`id_absensi`);

--
-- Indexes for table `bagian`
--
ALTER TABLE `bagian`
  ADD PRIMARY KEY (`id_bag`);

--
-- Indexes for table `disiplin`
--
ALTER TABLE `disiplin`
  ADD PRIMARY KEY (`id_disiplin`);

--
-- Indexes for table `h_jabatan`
--
ALTER TABLE `h_jabatan`
  ADD PRIMARY KEY (`idh`);

--
-- Indexes for table `jabatan`
--
ALTER TABLE `jabatan`
  ADD PRIMARY KEY (`id_jab`);

--
-- Indexes for table `kinerja`
--
ALTER TABLE `kinerja`
  ADD PRIMARY KEY (`id_kinerja`);

--
-- Indexes for table `kompetensi`
--
ALTER TABLE `kompetensi`
  ADD PRIMARY KEY (`id_kompetensi`);

--
-- Indexes for table `kreatifitas`
--
ALTER TABLE `kreatifitas`
  ADD PRIMARY KEY (`id_kreatifitas`);

--
-- Indexes for table `k_jabatan`
--
ALTER TABLE `k_jabatan`
  ADD PRIMARY KEY (`idkjb`);

--
-- Indexes for table `pegawai`
--
ALTER TABLE `pegawai`
  ADD PRIMARY KEY (`nip`);

--
-- Indexes for table `pelatihan`
--
ALTER TABLE `pelatihan`
  ADD PRIMARY KEY (`id_pelatihan`);

--
-- Indexes for table `pencapaian`
--
ALTER TABLE `pencapaian`
  ADD PRIMARY KEY (`id_pencapaian`);

--
-- Indexes for table `pendidikan`
--
ALTER TABLE `pendidikan`
  ADD PRIMARY KEY (`idp`);

--
-- Indexes for table `pendidikan_t`
--
ALTER TABLE `pendidikan_t`
  ADD PRIMARY KEY (`id_pendidikan`);

--
-- Indexes for table `pengalaman_kerja`
--
ALTER TABLE `pengalaman_kerja`
  ADD PRIMARY KEY (`id_peker`);

--
-- Indexes for table `pengukuran`
--
ALTER TABLE `pengukuran`
  ADD PRIMARY KEY (`id_pengukuran`);

--
-- Indexes for table `penyerapan`
--
ALTER TABLE `penyerapan`
  ADD PRIMARY KEY (`id_penyerapan`);

--
-- Indexes for table `rumpun`
--
ALTER TABLE `rumpun`
  ADD PRIMARY KEY (`id_rumpun`);

--
-- Indexes for table `setting`
--
ALTER TABLE `setting`
  ADD PRIMARY KEY (`id_setting`);

--
-- Indexes for table `set_user`
--
ALTER TABLE `set_user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `skp`
--
ALTER TABLE `skp`
  ADD PRIMARY KEY (`kd_skp`);

--
-- Indexes for table `skpd`
--
ALTER TABLE `skpd`
  ADD PRIMARY KEY (`id_skpd`);

--
-- Indexes for table `skptahunan`
--
ALTER TABLE `skptahunan`
  ADD PRIMARY KEY (`id_skptahunan`);

--
-- Indexes for table `status`
--
ALTER TABLE `status`
  ADD PRIMARY KEY (`id_status`);

--
-- Indexes for table `ukpd`
--
ALTER TABLE `ukpd`
  ADD PRIMARY KEY (`id_ukpd`);

--
-- Indexes for table `user_id`
--
ALTER TABLE `user_id`
  ADD PRIMARY KEY (`userid`);

--
-- Indexes for table `validasi`
--
ALTER TABLE `validasi`
  ADD PRIMARY KEY (`id_validasi`);

--
-- Indexes for table `waktu_k`
--
ALTER TABLE `waktu_k`
  ADD PRIMARY KEY (`id_waktu_k`);

--
-- Indexes for table `waktu_kerja`
--
ALTER TABLE `waktu_kerja`
  ADD PRIMARY KEY (`id_waktu`);

--
-- Indexes for table `waktu_t`
--
ALTER TABLE `waktu_t`
  ADD PRIMARY KEY (`id_waktu_t`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `absensi`
--
ALTER TABLE `absensi`
  MODIFY `id_absensi` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=462;

--
-- AUTO_INCREMENT for table `h_jabatan`
--
ALTER TABLE `h_jabatan`
  MODIFY `idh` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `kinerja`
--
ALTER TABLE `kinerja`
  MODIFY `id_kinerja` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `pelatihan`
--
ALTER TABLE `pelatihan`
  MODIFY `id_pelatihan` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `pendidikan`
--
ALTER TABLE `pendidikan`
  MODIFY `idp` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=304;

--
-- AUTO_INCREMENT for table `pengalaman_kerja`
--
ALTER TABLE `pengalaman_kerja`
  MODIFY `id_peker` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=111;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
