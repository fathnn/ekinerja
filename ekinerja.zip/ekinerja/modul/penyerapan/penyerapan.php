<script>
    function validasi(){
        var tanggal        = input.tanggal.value;
        var kd_skp 			= input.kd_skp.value;
        var jam_mulai       = input.jam_mulai.value;
		 var jam_akhir       = input.jam_akhir.value;
        var pesan = '';
         
        if (tanggal == '') {
            tanggal = '-Nama tidak boleh kosong\n';
        }
         
        if (tanggal!= '' && !tanggal.match(tanggalValid)) {
            pesan += '-nama tidak valid\n';
        }
         
        if (kd_skp == '') {
            pesan += '-SKP harus dipilih\n';
        }
         
        if (jam_mulai == '') {
            pesan += '-Jam Mulai tidak boleh kosong\n';
        }
         
       if (jam_akhir == '') {
            pesan += '-Jam Akhir tidak boleh kosong\n';
        }
         
        if (pesan != '') {
            alert('Maaf, ada kesalahan pengisian Formulir : \n'+pesan);
            return false;
        }
    return true
    }
</script>

<?php

$aksi="modul/penyerapan/aksi_penyerapan.php";

switch($_GET[act]){
	default:
	$tampil=mysql_query("select * from penyerapan where id_ukpd LIKE '%$_SESSION[id_ukpd]%' order by id_penyerapan DESC");
	echo "<h2 class='head'>DATA PENYERAPAN</h2>
	<div>
	<input type=button value='Tambah Data' onclick=\"window.location.href='?module=penyerapan&act=input';\">
	</div>
	<table class='table table-bordered table-hover table-striped'>
	<thead>
  <tr>
    <td>No</td>
    <td>Id Penyerapan</td>
    <td>Bulan</td>
	<td>Nilai Penyerapan</td>
	<td>Control</td>
  </tr>
  </thead>";
  $no=1;
  while($dt=mysql_fetch_array($tampil)){
  $day = date('F Y', strtotime($dt['tanggal']));
  echo "<tr>
    <td>$no</td>
    <td>$dt[id_penyerapan]</td>
    <td>$day</td>
	<td>$dt[nilai]</td>
	<td><span><a href='?module=penyerapan&act=edit&id_penyerapan=$dt[id_penyerapan]'>Edit</a></span><span>
	<a href=\"$aksi?module=penyerapan&act=hapus&id_penyerapan=$dt[id_penyerapan]\" onClick=\"return confirm('Apakah Anda benar-benar mau menghapusnya?')\">Hapus</a></span></td>
  </tr>";
  $no++;
  }
echo "  
</table>
	";
	
	break;
	
	case "input":
	$tahun =  date("Y");
	$bulan = date("M");
	echo "<h2 class='head'>Entry Data Penyerapan</h2>
	<form action='$aksi?module=penyerapan&act=input' name='input' method='post'>
	<div class='panel-body'> 
            <div class='table-responsive'> 
	<table>
	<tr>
	<td>ID PENYERAPAN</td><td>:</td><td><input class='form-control' name='id_penyerapan' type='text' value=".kdauto(penyerapan,PNY)." readonly>
	<input class='form-control' type='hidden' name='id_skpd' value='$_SESSION[id_skpd]' ><input class='form-control' type='hidden' name='id_ukpd' value='$_SESSION[id_ukpd]' ></td>
	</tr>
	<tr>
	<td>TANGGAL</td><td>:</td><td><select  name='bulan'>
            	<option value='' selected='selected'>--Pilih bulan--</option>
				<option value='1'>Januari</option>
				<option value='2'>Februari</option>
				<option value='3'>Maret</option>
				<option value='4'>April</option>
				<option value='5'>Mei</option>
				<option value='6'>Juni</option>
				<option value='7'>Juli</option>
				<option value='8'>Agustus</option>
				<option value='9'>September</option>
				<option value='10'>Oktober</option>
				<option value='11'>November</option>
				<option value='12'>Desember</option>
			</select>
	<select name='tahun' >";
	for ($x = $tahun; $x <= $tahun+10; $x++) {
	    
        echo "<option value='$x' class='form-control' ";
        if ($x == $tahun){echo "selected='selected'";} 
	    echo "readonly>$x</option>";
    }
            
				
	echo "</select></td>
	</tr>
	<tr>
	<tr>
	<td>NILAI PENYERAPAN</td><td>:</td><td><input class='form-control' name='nilai' type='text'></td>
	</tr>
	<tr>
	<td></td><td></td><td><input type=submit value=Simpan>
	<input type=button value=Batal onclick=self.history.back()>
	</td>
	</tr>
	</table>
	</form>
	";
	break;
	
	case "edit":
	$edit=mysql_query("select * from penyerapan where id_penyerapan='$_GET[id_penyerapan]'");
	$data=mysql_fetch_array($edit);
	$date=$data['tanggal'];
	$tanggal=date("m/d/Y",strtotime($date));
	echo "<h2>Entry Data Penyerapan</h2>
	<form action='$aksi?module=penyerapan&act=edit' name='input' method='post'>
	<table>
	<tr>
	<td>ID PENYERAPAN</td><td>:</td><td><input class='form-control' name='id_penyerapan' type='text' value='$data[id_penyerapan]' Readonly>
	<input class='form-control' type='hidden' name='id_skpd' value='$_SESSION[id_skpd]' ><input class='form-control' type='hidden' name='id_ukpd' value='$_SESSION[id_ukpd]' ></td>
	</tr>
	<tr>
	<td>TANGGAL</td><td>:</td><td><input class='form-control' name='tanggal' type='text' id='calender' value='$tanggal'></td>
	</tr>
	<tr>
	<td>NILAI PENYERAPAN</td><td>:</td><td><input class='form-control' name='nilai' type='text' value='$data[nilai]'></td>
	</tr>
	<tr>
	<td></td><td></td><td><input type=submit value=Update>
	<input type=button value=Batal onclick=self.history.back()>
	</td>
	</tr>
	</table>
	</form>";
	break;
	
	case "hapus":
	
	break;
}


?>