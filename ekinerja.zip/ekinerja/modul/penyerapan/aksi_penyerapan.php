<?php 
include "../../config/koneksi.php";
include "../../config/fungsi_indotgl.php";
include "../../config/class_paging.php";
include "../../config/kode_auto.php";

$module=$_GET['module'];
$act=$_GET['act'];
$date="$_POST[tanggal]";
$tanggal=date("y-m-d",strtotime($date));
if($module=='penyerapan' AND $act=='input' ){
$tm="$_POST[tahun]-$_POST[bulan]-28]";
	mysql_query("insert into penyerapan set id_penyerapan='$_POST[id_penyerapan]', nilai='$_POST[nilai]',id_skpd='$_POST[id_skpd]',id_ukpd='$_POST[id_ukpd]', tanggal='$tm'");
	header('location:../../media.php?module='.$module);
}

elseif($module=='penyerapan' AND $act=='edit' ){
	mysql_query("update penyerapan set tanggal='$tanggal', nilai='$_POST[nilai]',id_skpd='$_POST[id_skpd]',id_ukpd='$_POST[id_ukpd]' where id_penyerapan='$_POST[id_penyerapan]'");
	header('location:../../media.php?module='.$module);
}

elseif($module=='penyerapan' AND $act=='hapus' ){
	mysql_query("delete from penyerapan where id_penyerapan='$_GET[id_penyerapan]'");
	header('location:../../media.php?module='.$module);
}


?>