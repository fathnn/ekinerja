<?php 
include "../../config/koneksi.php";
include "../../config/fungsi_indotgl.php";
include "../../config/class_paging.php";
include "../../config/kode_auto.php";

$module=$_GET['module'];
$act=$_GET['act'];


if($module=='skp' AND $act=='input' ){
	mysql_query("insert into skp set kd_skp='$_POST[kd_skp]', skp='$_POST[skp]', waktu='$_POST[waktu]'");
	header('location:../../media.php?module='.$module);
}

elseif($module=='skp' AND $act=='edit' ){
	mysql_query("update skp set skp='$_POST[skp]' where kd_skp='$_POST[kd_skp]'");
	header('location:../../media.php?module='.$module);
}

elseif($module=='skp' AND $act=='hapus' ){
	mysql_query("delete from skp where kd_skp='$_GET[kd_skp]'");
	header('location:../../media.php?module='.$module);
}


?>