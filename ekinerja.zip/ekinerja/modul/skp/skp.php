<?php

$aksi="modul/skp/aksi_skp.php";

switch($_GET[act]){
	default:
	$tampil=mysql_query("select * from skp order by kd_skp DESC");
	echo "<h2 class='head'>DATA LIST SKP PEGAWAI</h2>
	<div>
	<!--<input type=button value='Tambah Data' onclick=\"window.location.href='?module=skp&act=input';\">
	</div>-->
	<table class='table table-bordered table-hover table-striped'>
	<thead>
  <tr>
    <td>No</td>
    <td>Kode SKP</td>
    <td>Nama SKP</td>
	<td>Waktu Efektif </td>
	<td>Control</td>
  </tr>
  </thead>";
  $no=1;
  while($dt=mysql_fetch_array($tampil)){
  echo "<tr>
    <td>$no</td>
    <td>$dt[kd_skp]</td>
    <td>$dt[skp]</td>
	 <td>$dt[waktu] Menit</td>
	<td><span><a href='?module=skp&act=edit&kd_skp=$dt[kd_skp]'>Edit</a></span><span>
	<a href=\"$aksi?module=skp&act=hapus&kd_skp=$dt[kd_skp]\" onClick=\"return confirm('Apakah Anda benar-benar mau menghapusnya?')\">Hapus</a></span></td>
  </tr>";
  $no++;
  }
echo "  
</table>
	";
	
	break;
	
	case "input":
	echo "<h2 class='head'>Entry Data SKP</h2>
	<form action='$aksi?module=skp&act=input' method='post'>
	<table class='tabelform'>
	<tr>
	<td>Kode SKP</td><td>:</td><td><input class='form-control' name='kd_skp' type='text' value=".kdauto(skp,SKP)."></td>
	</tr>
	<tr>
	<td>NAMA SKP</td><td>:</td><td><input class='form-control' name='skp' type='text'></td>
	</tr>
	<tr>
	<tr>
	<td>WAKTU EFEKTIF<td>:</td><td><input class='form-control' name='waktu' type='text'></td>
	</tr>
	<tr>
	<td></td><td></td><td><input type=submit value=Simpan>
	<input type=button value=Batal onclick=self.history.back()>
	</td>
	</tr>
	</table>
	</form>
	";
	break;
	
	case "edit":
	$edit=mysql_query("select * from skp where kd_skp='$_GET[kd_skp]'");
	$data=mysql_fetch_array($edit);
	echo "<h2>Entry Data Bagian</h2>
	<form action='$aksi?module=skp&act=edit' method='post'>
	<table>
	<tr>
	<td>Kode SKP</td><td>:</td><td><input class='form-control' name='kd_skp' type='text' value='$data[kd_skp]'></td>
	</tr>
	<tr>
	<td>NAMA SKP</td><td>:</td><td><input class='form-control' name='skp' type='text' value='$data[skp]'></td>
	</tr>
	<tr>
	<tr>
	<td>WAKTU EFEKTIF</td><td>:</td><td><input class='form-control' name='waktu' type='text' value='$data[waktu]'></td>
	</tr>
	<tr>
	<td></td><td></td><td><input type=submit value=Update>
	<input type=button value=Batal onclick=self.history.back()>
	</td>
	</tr>
	</table>
	</form>";
	break;
	
	case "hapus":
	
	break;
}


?>