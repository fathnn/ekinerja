<?php 
include "../../config/koneksi.php";
include "../../config/fungsi_indotgl.php";
include "../../config/class_paging.php";
include "../../config/kode_auto.php";

$module=$_GET['module'];
$act=$_GET['act'];


if($module=='kasie' AND $act=='input' ){
	mysql_query("insert into user_id set userid='$_POST[userid]', passid='$_POST[passid]',id_bag='$_POST[id_bag]',id_skpd='$_POST[id_skpd]',id_ukpd='$_POST[id_ukpd]',  level_user='2', nama='$_POST[nama]'");
	header('location:../../media.php?module='.$module);
}

elseif($module=='kasie' AND $act=='edit' ){
	mysql_query("update user_id set nama='$_POST[nama]',id_bag='$_POST[id_bag]' where userid='$_POST[userid]'");
	header('location:../../media.php?module='.$module);
}

elseif($module=='kasie' AND $act=='hapus' ){
	mysql_query("delete from user_id where userid='$_GET[userid]'");
	header('location:../../media.php?module='.$module);
}


?>