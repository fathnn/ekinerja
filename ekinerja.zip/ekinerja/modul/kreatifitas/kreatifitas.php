<script type="text/javascript">
function validasi_input(form){
  if (form.tanggal.value == ""){
    alert("tanggal masih kosong!");
    form.tanggal.focus();
    return (false);
  }
  if (form.kreatifitas.value == ""){
    alert("kreatifitas masih kosong!");
    form.kreatifitas.focus();
    return (false);
  }
  if (form.uraian.value == ""){
    alert("uraian masih kosong!");
    form.uraian.focus();
    return (false);
  }
  if (form.wm_k.value == ""){
    alert("jam mulai belum di pilih!");
    form.wm_k.focus();
    return (false);
  }
  if (form.wa_k.value == ""){
    alert("jam selesai belum di pilih!");
    form.wa_k.focus();
    return (false);
  }
  if (form.waktu_e.value == ""){
    alert("ada kesalahan di waktu efektif!");
    form.kd_skp.focus();
    return (false);
  }
return (true);
}
</script>
<?php
error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
$aksi="modul/kreatifitas/aksi_kreatifitas.php";
$nip=trim($_SESSION['nip']);
$keterangan=date("d/m/Y H:i:s");
switch($_GET[act]){
	default:
	echo"
<a href='?module=kreatifitas&act=detail&nip=$nip'>Data Sudah Selesai Di Proses lanjutkan</a>";
	break;
	
	case "awalan":
	$tampil=mysql_query("select * from kreatifitas,pegawai where kinerja_t.nip=pegawai.nip  order by id_kinerja_t");
	echo "<h2 class='head'>DATA AKTIFITAS TAMBAHAN</h2>
	<div>
	<input type=button value='Tambah Data' onclick=\"window.location.href='?module=aktifitas&act=input';\">
	</div>
	<table class='table table-bordered table-hover table-striped'>
	<thead>
  <tr>
  <td>No</td>
  <td>Tanggal</td>
    <td>Nip</td>
    <td>Nama Pegawai</td>
	<td>Kreatifitas</td>
	<td>Uraian</td>
	<td>Jam Mulai</td>
	<td>Jam Selesai</td>
	<td>Durasi Pekerjaan</td>
	<td>Control</td>
  </tr>
  </thead>";
  $no=1;
  while($dt=mysql_fetch_array($tampil)){
  $vol=$dt['jumlah']/$dt['waktu'];
  echo "<tr>
  <td>$no</td>
  <td>$dt[tanggal]</td>
    <td>$dt[nip]</td>
    <td>$dt[nama]</td>
	 <td>$dt[kreatifitas]</td>
	 <td>$dt[uraian]</td>
	<td>$dt[wm_k]</td>
	<td>$dt[wa_k]</td>
	<td>$dt[jumlah] Menit</td>
	<td><span><a href='?module=kreatifitas&act=edit&id_kinerja_t=$dt[id_kinerja_t]'>Edit</a></span><span>
	<a href=\"$aksi?module=aktifitas&act=hapus&id_kinerja_t=$dt[id_kinerja_t]\" onClick=\"return confirm('Apakah Anda benar-benar mau menghapusnya?')\">Hapus</a></span>
	</td>
  </tr>";
  $no++;
  }
echo "  
</table>
	";
	break;
	
	case "input":
	echo "<h2 class='head'>Entry Data Kreatifitas Tambahan</h2>
	<form action='$aksi?module=kreatifitas&act=input' onsubmit='return validasi_input(this)' method='post' enctype='multipart/form-data' >
	<table class='tabelform tabpad'>
	<tr>
	<td>Nip</td><td>:</td><td><input class='form-control' name='nip' type='text' value='$nip' readonly > </td>
	</tr>
	<tr>
	<td>Tanggal</td><td>:</td><td><input class='form-control' name='tanggal' type='text' id='calender'>
	<input class='form-control' name='keterangan' type='hidden' value='$keterangan'></td>
	</tr>
	<tr>
	<td>Kreatifitas</td><td>:</td><td><textarea class='form-control' name='kreatifitas'></textarea></td>
	</tr>
	<tr>
	<td>uraian</td><td>:</td><td><textarea class='form-control' name='uraian'></textarea></td>
	</tr>
	<tr>
	<td>Jam Mulai</td><td>:</td><td>
	<div class='input-group clockpicker pull-center' data-placement='right' data-align='top' data-autoclose='true'>
	<input class='form-control' name='wm_k' type='text' value='' readonly>
	<span class='input-group-addon'>
					<span class='glyphicon glyphicon-time'></span>
				</span>
			</div></td>
	</tr>
	<tr>
	<td>Jam Selesai</td><td>:</td><td>
	<div class='input-group clockpicker pull-center' data-placement='right' data-align='top' data-autoclose='true'>
	<input class='form-control' name='wa_k' type='text' value='' readonly>
	<span class='input-group-addon'>
					<span class='glyphicon glyphicon-time'></span>
				</span>
			</div></td>
	</tr>
	<tr>
	<td></td><td></td><td><input type=submit value=Simpan>
	<input type=button value=Batal onclick=self.history.back()>
	</td>
	</tr>
	</table>
	</form>
	";
	break;
	
	
	
	
	case "penambahan":
	$tampil1=mysql_query("select * from pegawai where nip='$_GET[nip]' ");
	while($dt=mysql_fetch_array($tampil)){
	$nip1=$dt['nip'];
	}
	$tgl= date('Y-m-d');
	echo "<h2 class='head'>Entry Penambahan Waktu Efektif</h2>
	<form action='$aksi?module=waktu&act=input_t' method='post' enctype='multipart/form-data' >
	<table class='tabelform tabpad'>
	
	<tr>
	<td>Nip</td>
	<td>:</td>
	<td><input class='form-control' name='nip' type='text' value='$_GET[nip]' readonly > </td>
	<td></td>
	</tr>
	
	<tr>
	<td>Tanggal</td>
	<td>:</td>
	<td><input class='form-control' name='tanggal' type='text' value='$tgl' readonly></td>
	<td></td>
	</tr>
	
	<tr>
	<td>Cuti Sakit</td>
	<td>:</td>
	<td><input class='form-control' name='c_sakit_t' type='text'></td>
	<td>Hari</td>
	</tr>
	
	<tr>
	<td>Cuti Alasan Penting < 6 hari</td>
	<td>:</td>
	<td><input class='form-control' name='c_alasan_t' type='text'></td>
	<td>Hari</td>
	</tr>
	
	<tr>
	<td>Cuti Tahunan</td>
	<td>:</td>
	<td><input class='form-control' name='c_tahunan_t' type='text'></td>
	<td>Hari</td>
	</tr>
	
	<tr>
	<td>Diklat</td>
	<td>:</td>
	<td><input class='form-control' name='diklat' type='text'></td>
	<td>Hari</td>
	</tr>
	
	<tr>
	<td>SPD</td>
	<td>:</td>
	<td><input class='form-control' name='spd' type='text'></td>
	<td>Hari</td>
	</tr>
	
	<tr>
	<td>Haji</td>
	<td>:</td>
	<td><input class='form-control' name='haji' type='text'></td>
	<td>Hari</td>
	</tr>
	
	<tr>
	<td></td>
	<td></td>
	<td><input type=submit value=Simpan>
	<input type=button value=Batal onclick=self.history.back()>
	</td>
	</tr>
	
	</table>
	</form>
	";
	break;
	
	
	case "pengurangan":
	$tampil1=mysql_query("select * from pegawai where nip='$_GET[nip]' ");
	while($dt=mysql_fetch_array($tampil)){
	$nip1=$dt['nip'];
	}
	$tgl= date('Y-m-d');
	echo "<h2 class='head'>Entry Pengurangan Waktu Efektif</h2>
	<form action='$aksi?module=waktu&act=input_k' method='post' enctype='multipart/form-data' >
	<table class='tabelform tabpad'>
	
	<tr>
	<td>Nip</td>
	<td>:</td>
	<td><input class='form-control' name='nip' type='text' value='$_GET[nip]' readonly > </td>
	<td></td>
	</tr>
	
    <tr>
	<td>Tanggal</td>
	<td>:</td>
	<td><input class='form-control' name='tanggal' type='text' value='$tgl' readonly></td>
	<td></td>
	</tr>
	
	<tr>
	<td>Sakit</td>
	<td>:</td>
	<td><input class='form-control' name='sakit' type='text'> </td>
	<td>Hari</td>
	</tr>
	
	<tr>
	<td>Alpha</td>
	<td>:</td>
	<td><input class='form-control' name='alpha' type='text'> </td>
	<td>Hari</td>
	</tr>
	
		
	<tr>
	<td>Izin</td>
	<td>:</td>
	<td><input class='form-control' name='izin' type='text'></td>
	<td>Hari</td>
	</tr>
	
	<tr>
	<td>Izin Setengah Hari</td>
	<td>:</td>
	<td><input class='form-control' name='izin_s' type='text'></td>
	<td>Hari</td>
	</tr>
	
	<tr>
	<td>Meninggal</td>
	<td>:</td>
	<td><input class='form-control' name='meninggal' type='text'></td>
	<td>Hari</td>
	</tr>
	
	<tr>
	<td>Telat</td>
	<td>:</td>
	<td><input class='form-control' name='telat' type='text'> </td>
	<td>Menit</td>
	</tr>
	
	<tr>
	<td>Cuti Sakit</td>
	<td>:</td>
	<td><input class='form-control' name='c_sakit_k' type='text'></td>
	<td>Hari</td>
	</tr>
	
	<tr>
	<td>Cuti Alasan Penting >= 6 hari</td>
	<td>:</td>
	<td><input class='form-control' name='c_alasan_k' type='text'></td>
	<td>Hari</td>
	</tr>
	
	<tr>
	<td>Cuti Pesalinan</td>
	<td>:</td>
	<td><input class='form-control' name='c_persalinan_k' type='text'></td>
	<td>Hari</td>
	</tr>
	
	<tr>
	<td>Cuti Besar</td>
	<td>:</td>
	<td><input class='form-control' name='c_besar_k' type='text'></td>
	<td>Hari</td>
	</tr>
	
	<tr>
	<td></td>
	<td></td>
	<td><input type=submit value=Simpan>
	<input type=button value=Batal onclick=self.history.back()>
	</td>
	</tr>
	
	</table>
	</form>
	";
	break;
	
	
	case "pengukuran":
	echo"<h2 class='head'>Pengukuran</h2>";
	$tampil1=mysql_query("select * from pegawai where nip='$_GET[nip]' ");
	while($dt=mysql_fetch_array($tampil)){
	$nip1=$dt['nip'];
	}
  $tgl= date('Y-m-d');
	$per=explode('-',$tgl);
	$bln=$per[1];
	$thn=$per[0];
	$waktu= date ('H:i:s');
	$kinerja=mysql_query("select SUM(point) from kinerja where 
						 Month(kinerja.tanggal)='$bln' 
						 and Year(kinerja.tanggal)='$thn' and nip='$_GET[nip]'
						 order by id_kinerja ASC ");
        $point_kinerja=mysql_fetch_array($kinerja);
        $point=$point_kinerja[0];
		$we=min(5000,6300)/6300*100;
        $s=number_format($we,2);
	echo"<table class='tabelform tabpad'>
	<tr>
	<td>NIP</td>
	<td>:</td>
	<td>$_GET[nip]<input class='form-control' name='nip' type='text' value='$_GET[nip]' hidden > </td>
	<td></td>
	</tr>
	<tr>
	<td>CAPAIAN WAKTU EFEKTIVITAS UTAMA</td>
	<td>:</td>
	<td>$point<input class='form-control' name='nip' type='text' value='$point' hidden > </td>
	<td></td>
	</tr>
	<tr>
	<td>CAPAIAN WAKTU EFEKTIVITAS TAMBAHAN</td>
	<td>:</td>
	<td>$point<input class='form-control' name='nip' type='text' value='$point' hidden > </td>
	<td></td>
	</tr>
	<tr>
	<td>CAPAIAN WAKTU KREATIVITAS</td>
	<td>:</td>
	<td>$point<input class='form-control' name='nip' type='text' value='$point' hidden > </td>
	<td></td>
	</tr>
	<tr>
	<td>TOTAL CAPAIAN WAKTU EFEKTIVITAS</td>
	<td>:</td>
	<td>$point<input class='form-control' name='nip' type='text' value='$point' hidden > </td>
	<td></td>
	</tr>
	<tr>
	<td colspan='4'><hr></td>
	</tr>
	<tr>
	<td>Jumlah Waktu Kerja</td>
	<td>:</td>
	<td><input class='form-control' name='nip' type='text' value='21' readonly > </td>
	<td></td>
	</tr>
	<tr>
	<td>Jam Kerja</td>
	<td>:</td>
	<td>300<input class='form-control' name='jk' type='text' value='300' hidden > </td>
	<td></td>
	</tr>
	<tr>
	<td>Maksimal Waktu Efektif</td>
	<td>:</td>
	<td>6300<input class='form-control' name='jk' type='text' value='$we' hidden > </td>
	<td></td>
	</tr>
	<tr>
	<td>Point Aktivitas</td>
	<td>:</td>
	<td>$s<input class='form-control' name='jk' type='text' value='$we' hidden > </td>
	<td></td>
	</tr>
	<table>
	";
  
		
	break;
	
	case "lihat":	
	$nip=$_SESSION['namauser'];
	$dat=mktime(0, 0, 0, date("m")-1, date("d"), date("Y"));
	$tgl= date('Y-m-30',$dat);
	$per=explode('-',$tgl);
	$bln=$per[1];
	$thn=$per[0];
	$waktu= date ('H:i:s');
	$tampil=mysql_query("select * from kreatifitas where 
						 Month(kreatifitas.tanggal)='$bln' 
						 and Year(kreatifitas.tanggal)='$thn' and nip='$_GET[nip]'
						 order by tanggal DESC  ");
	$tampil1=mysql_query("select * from pegawai where nip='$_GET[nip]' ");
	while($dt=mysql_fetch_array($tampil1)){
    $nip1=$dt['nip']; 
	$nama=$dt['nama'];
	}
	echo "<h2 class='head'>DATA KREATIFITAS PEGWAI</h2>
	<div>
	<input type=button value=Kembali onclick=self.history.back()>
	</div>
	<table class='table table-bordered table-hover table-striped'>
	<thead>
  <tr>
  <td>No</td>
  <td>ID Kinerja</td>
  <td>Tanggal</td>
    <td>Nip</td>
	<td>Kreatifitas</td>
	<td>Uraian</td>
	<td>Jam Mulai</td>
	<td>Jam Selesai</td>
	<td>Durasi Pekerjaan</td>
	<td>Validasi</td>
	<td>Point</td>
  </tr>
  </thead>";
  $no=1;
  while($dt=mysql_fetch_array($tampil)){
  $nilai=$dt['jumlah']*1;
  echo "<tr>
  <td>$no</td>
  <td>$dt[id_kreatifitas]</td>
  <td>$dt[tanggal]</td>
    <td>$dt[nip]</td>
	 <td>$dt[kreatifitas]</td>
	 <td>$dt[uraian]</td>
	<td>$dt[wm_k]</td>
	<td>$dt[wa_k]</td>
	<td>$dt[jumlah] Menit </td>
	<td>
	<a href='?module=kreatifitas&act=validasi&id_kreatifitas=$dt[id_kreatifitas]'><input type=submit value='Validasi' name='validas'></s><a href='?module=kreatifitas&act=batal&id_kreatifitas=$dt[id_kreatifitas]'><input type=submit value='Batal Validasi' name='validas'></s></td>
    <td>$dt[point] </td>
  </tr>
  ";
  $no++;
  }echo"
  </tr>
  <tr>
  <td colspan=10 > NILAI
  </td>
  <td>"; 
  $dat=mktime(0, 0, 0, date("m")-1, date("d"), date("Y"));
	$tgl= date('Y-m-30',$dat);
	$per=explode('-',$tgl);
	$bln=$per[1];
	$thn=$per[0];
	$waktu= date ('H:i:s');
	
  $qry_jumlah_b=mysql_query("select SUM(point) from kreatifitas where 
						 Month(kreatifitas.tanggal)='$bln' 
						 and Year(kreatifitas.tanggal)='$thn' and nip='$_GET[nip]'
						 order by id_kreatifitas ASC ");
        $data_b=mysql_fetch_array($qry_jumlah_b);
        $nilai=$data_b[0];
        echo $nilai;
		echo"</td>
  </tr>";
echo "  
</table>

	";
	
	break;
	
	case "lihatpj":	
	$nip=$_SESSION['namauser'];
	$tgl=$_POST['tanggal'];
	$per=explode('-',$tgl);
	$bln=$per[1];
	$thn=$per[0];
	$waktu= date ('H:i:s');
	$tampil=mysql_query("select * from kreatifitas where 
						 Month(kreatifitas.tanggal)='$bln' 
						 and Year(kreatifitas.tanggal)='$thn' and nip='$_GET[nip]'
						 order by tanggal DESC   ");
	$tampil1=mysql_query("select * from pegawai where nip='$_GET[nip]' ");
	while($dt=mysql_fetch_array($tampil1)){
    $nip1=$dt['nip']; 
	$nama=$dt['nama'];
	}
	echo "<h2 class='head'>DATA KREATIFITAS PEGWAI</h2>
	<div>
	<input type=button value=Kembali onclick=self.history.back()>
	</div>
	
	<table class='table table-bordered table-hover table-striped'>
	<thead>
  <tr>
  <td>No</td>
  <td>ID Kinerja</td>
  <td>Tanggal</td>
    <td>Nip</td>
	<td>Kreatifitas</td>
	<td>Uraian</td>
	<td>Jam Mulai</td>
	<td>Jam Selesai</td>
	<td>Durasi Pekerjaan</td>
	<td>Validasi</td>
	<td>Point</td>
  </tr>
  </thead>";
  $no=1;
  while($dt=mysql_fetch_array($tampil)){
  $nilai=$dt['jumlah']*1;
  echo "<tr>
  <td>$no</td>
  <td>$dt[id_kreatifitas]</td>
  <td>$dt[tanggal]</td>
    <td>$dt[nip]</td>
	 <td>$dt[kreatifitas]</td>
	 <td>$dt[uraian]</td>
	<td>$dt[wm_k]</td>
	<td>$dt[wa_k]</td>
	<td>$dt[jumlah] Menit </td>
	<td>
	<a href='?module=kreatifitas&act=validasipj&id_kreatifitas=$dt[id_kreatifitas]'><input type=submit value='Validasi' name='validas'></s><a href='?module=kreatifitas&act=batalpj&id_kreatifitas=$dt[id_kreatifitas]'><input type=submit value='Batal Validasi' name='validas'></s></td>
    <td>$dt[point] </td>
  </tr>
  ";
  $no++;
  }echo"
  </tr>
  <tr>
  <td colspan=10 > NILAI
  </td>
  <td>"; 
  $tgl=$_POST['tanggal'];
	$per=explode('-',$tgl);
	$bln=$per[1];
	$thn=$per[0];
	$waktu= date ('H:i:s');
	
  $qry_jumlah_b=mysql_query("select SUM(point) from kreatifitas where 
						 Month(kreatifitas.tanggal)='$bln' 
						 and Year(kreatifitas.tanggal)='$thn' and nip='$_GET[nip]'
						 order by id_kreatifitas ASC ");
        $data_b=mysql_fetch_array($qry_jumlah_b);
        $nilai=$data_b[0];
        echo $nilai;
		echo"</td>
  </tr>";
echo "  
</table>

	";
	
	break;
	
	case "lihatm":	
	$nip=$_SESSION['namauser'];
	$tgl= date('Y-m-d');
	$per=explode('-',$tgl);
	$bln=$per[1];
	$thn=$per[0];
	$waktu= date ('H:i:s');
	$tampil=mysql_query("select * from kreatifitas where 
						 Month(kreatifitas.tanggal)='$bln' 
						 and Year(kreatifitas.tanggal)='$thn' and nip='$_GET[nip]'
						 order by tanggal DESC   ");
	echo "<h2 class='head'>DATA KREATIFITAS PEGWAI</h2>
	<div>
	<input type=button value=Kembali onclick=self.history.go(-2)>
	</div>
	
	<table class='table table-bordered table-hover table-striped'>
	<thead>
  <tr>
  <td>No</td>
  <td>ID Kinerja</td>
  <td>Tanggal</td>
    <td>Nip</td>
	<td>Kreatifitas</td>
	<td>Uraian</td>
	<td>Jam Mulai</td>
	<td>Jam Selesai</td>
	<td>Durasi Pekerjaan</td>
	<td>Validasi</td>
	<td>Point</td>
  </tr>
  </thead>";
  $no=1;
  while($dt=mysql_fetch_array($tampil)){
  $nilai=$dt['jumlah']*1;
  echo "<tr>
  <td>$no</td>
  <td>$dt[id_kreatifitas]</td>
  <td>$dt[tanggal]</td>
    <td>$dt[nip]</td>
	 <td>$dt[kreatifitas]</td>
	 <td>$dt[uraian]</td>
	<td>$dt[wm_k]</td>
	<td>$dt[wa_k]</td>
	<td>$dt[jumlah] Menit </td>
	<td>
	<a href='?module=kreatifitas&act=validasi&id_kreatifitas=$dt[id_kreatifitas]'><input type=submit value='Validasi' name='validas'></s><a href='?module=kreatifitas&act=batal&id_kreatifitas=$dt[id_kreatifitas]'><input type=submit value='Batal Validasi' name='validas'></s></td>
    <td>$dt[point] </td>
  </tr>
  ";
  $no++;
  }echo"
  </tr>
  <tr>
  <td colspan=10 > NILAI
  </td>
  <td>"; 
  $tgl= date('Y-m-d');
	$per=explode('-',$tgl);
	$bln=$per[1];
	$thn=$per[0];
	$waktu= date ('H:i:s');
	
  $qry_jumlah_b=mysql_query("select SUM(point) from kreatifitas where 
						 Month(kreatifitas.tanggal)='$bln' 
						 and Year(kreatifitas.tanggal)='$thn' and nip='$_GET[nip]'
						 order by id_kreatifitas ASC ");
        $data_b=mysql_fetch_array($qry_jumlah_b);
        $nilai=$data_b[0];
        echo $nilai;
		echo"</td>
  </tr>";
echo "  
</table>

	";
	
	break;
	
	case "validasi":
	$ambil=mysql_query("select * from kreatifitas where id_kreatifitas='$_GET[id_kreatifitas]'");
	$ed=mysql_fetch_array($ambil);
	echo "Yakin anda Ingin Menyetujui Validasi Ini  ??
	<form action='$aksi?module=kreatifitas&act=val' method='post' enctype='multipart/form-data' >
	<input type='hidden' name='id_kreatifitas' readonly value='$ed[id_kreatifitas]' >
	<table class='tabelform tabpad'>
	<tr>
	<td><input class='form-control' name='id_kreatifitas' type='text' value='$ed[id_kreatifitas]' readonly ></td>
	</tr>
	<tr>
	<td> <input type='text' name='nip' readonly value='$ed[nip]' readonly>
	</td>
	</tr>	
	<tr>
	<td><input class='form-control' name='tanggal' type='date' value='$ed[tanggal]' readonly ></td>
	</tr>
	
	<tr>
	<td><input class='form-control' name='kreatifitas' type='text' value='$ed[kreatifitas]' readonly></td>
	</tr>
	
	<tr>
	<td><input class='�nput' name='uraian' value='$ed[uraian]' readonly></td>
	</tr>
	
	<tr>
	<td><input class='form-control' name='wm_k' type='time' value='$ed[wm_k]' readonly></td>
	</tr>
	
	<tr>
	<td><input class='form-control' name='wa_k' type='time' value='$ed[wa_k]' readonly></td>
	</tr>
	<tr>
	<td><input class='form-control' name='point' type='text' value='$ed[jumlah]' readonly></td>
	</tr>
	<tr>
	<td><input type=submit value=Iya>
	<input type=button value=Batal onclick=self.history.back()>
	</td>
	</tr>
	</table>
	</form>
	";
	break;
	
	
	case "validasipj":
	$ambil=mysql_query("select * from kreatifitas where id_kreatifitas='$_GET[id_kreatifitas]'");
	$ed=mysql_fetch_array($ambil);
	echo "Yakin anda Ingin Menyetujui Validasi Ini  ??
	<form action='$aksi?module=kreatifitas&act=valpj' method='post' enctype='multipart/form-data' >
	<input type='hidden' name='id_kreatifitas' readonly value='$ed[id_kreatifitas]' >
	<table class='tabelform tabpad'>
	<tr>
	<td><input class='form-control' name='id_kreatifitas' type='text' value='$ed[id_kreatifitas]' readonly ></td>
	</tr>
	<tr>
	<td> <input type='text' name='nip' readonly value='$ed[nip]' readonly>
	</td>
	</tr>	
	<tr>
	<td><input class='form-control' name='tanggal' type='date' value='$ed[tanggal]' readonly ></td>
	</tr>
	
	<tr>
	<td><input class='form-control' name='kreatifitas' type='text' value='$ed[kreatifitas]' readonly></td>
	</tr>
	
	<tr>
	<td><input class='�nput' name='uraian' value='$ed[uraian]' readonly></td>
	</tr>
	
	<tr>
	<td><input class='form-control' name='wm_k' type='time' value='$ed[wm_k]' readonly></td>
	</tr>
	
	<tr>
	<td><input class='form-control' name='wa_k' type='time' value='$ed[wa_k]' readonly></td>
	</tr>
	<tr>
	<td><input class='form-control' name='point' type='text' value='$ed[jumlah]' readonly></td>
	</tr>
	<tr>
	<td><input type=submit value=Iya>
	<input type=button value=Batal onclick=self.history.go(-2)>
	</td>
	</tr>
	</table>
	</form>
	";
	break;
	
	case "batal":
	$ambil=mysql_query("select * from kreatifitas where id_kreatifitas='$_GET[id_kreatifitas]'");
	$ed=mysql_fetch_array($ambil);
	echo "Yakin anda Ingin Membatalkan Validasi Ini  ??
	<form action='$aksi?module=kreatifitas&act=val' method='post' enctype='multipart/form-data' >
	<input type='hidden' name='id_kreatifitas' readonly value='$ed[id_kreatifitas]' >
	<table class='tabelform tabpad'>
	<tr>
	<td><input class='form-control' name='id_kreatifitas' type='text' value='$ed[id_kreatifitas]' readonly ></td>
	</tr>
	<tr>
	<td> <input type='text' name='nip' readonly value='$ed[nip]' readonly>
	</td>
	</tr>	
	<tr>
	<td><input class='form-control' name='tanggal' type='date' value='$ed[tanggal]' readonly ></td>
	</tr>
	
	<tr>
	<td><input class='form-control' name='kreatifitas' type='text' value='$ed[kreatifitas]' readonly></td>
	</tr>
	
	<tr>
	<td><input class='�nput' name='uraian' value='$ed[uraian]' readonly></td>
	</tr>
	
	<tr>
	<td><input class='form-control' name='wm_k' type='time' value='$ed[wm_k]' readonly></td>
	</tr>
	
	<tr>
	<td><input class='form-control' name='wa_k' type='time' value='$ed[wa_k]' readonly></td>
	</tr>
	<tr>
	<td><input class='form-control' name='' type='text' value='$ed[jumlah]' readonly><input class='form-control' name='point' type='text' value='0' hidden></td>
	</tr>
	<tr>
	<td><input type=submit value=Iya>
	<input type=button value=Batal onclick=self.history.back()>
	</td>
	</tr>
	</table>
	</form>
	";
	break;
	
	
	case "batalpj":
	$ambil=mysql_query("select * from kreatifitas where id_kreatifitas='$_GET[id_kreatifitas]'");
	$ed=mysql_fetch_array($ambil);
	echo "Yakin anda Ingin Membatalkan Validasi Ini  ??
	<form action='$aksi?module=kreatifitas&act=valpj' method='post' enctype='multipart/form-data' >
	<input type='hidden' name='id_kreatifitas' readonly value='$ed[id_kreatifitas]' >
	<table class='tabelform tabpad'>
	<tr>
	<td><input class='form-control' name='id_kreatifitas' type='text' value='$ed[id_kreatifitas]' readonly ></td>
	</tr>
	<tr>
	<td> <input type='text' name='nip' readonly value='$ed[nip]' readonly>
	</td>
	</tr>	
	<tr>
	<td><input class='form-control' name='tanggal' type='date' value='$ed[tanggal]' readonly ></td>
	</tr>
	
	<tr>
	<td><input class='form-control' name='kreatifitas' type='text' value='$ed[kreatifitas]' readonly></td>
	</tr>
	
	<tr>
	<td><input class='�nput' name='uraian' value='$ed[uraian]' readonly></td>
	</tr>
	
	<tr>
	<td><input class='form-control' name='wm_k' type='time' value='$ed[wm_k]' readonly></td>
	</tr>
	
	<tr>
	<td><input class='form-control' name='wa_k' type='time' value='$ed[wa_k]' readonly></td>
	</tr>
	<tr>
	<td><input class='form-control' name='' type='text' value='$ed[jumlah]' readonly><input class='form-control' name='point' type='text' value='0' hidden></td>
	</tr>
	<tr>
	<td><input type=submit value=Iya>
	<input type=button value=Batal onclick=self.history.go(-2)>
	</td>
	</tr>
	</table>
	</form>
	";
	break;
	
	case "edit":
	$ambil=mysql_query("select * from kreatifitas where id_kreatifitas='$_GET[id_kreatifitas]'");
	$ed=mysql_fetch_array($ambil);
	$date=$ed['tanggal'];
	$tanggal=date("m/d/Y",strtotime($date));
	echo "<h2 class='head'>Edit Data Kreatifitas Pegwai</h2>
	<form action='$aksi?module=kreatifitas&act=edit' method='post' onsubmit='return validasi_input(this)' enctype='multipart/form-data' >
	<input type='hidden' name='id_kreatifitas' readonly value='$ed[id_kreatifitas]' >
	<table class='tabelform tabpad'>
	<tr>
	<td>Id Kinerja</td><td>:</td><td><input class='form-control' name='id_kreatifitas' type='text' value='$ed[id_kreatifitas]' readonly >
	<input class='form-control' name='keterangan' type='hidden' value='$keterangan'></td>
	</tr>
	<tr>
	<td>Nip</td><td>:</td><td> <input type='text' class='form-control' name='nip' readonly value='$ed[nip]' >"; 
	echo "</td>
	</tr>	
	<tr>
	<td>Tanggal</td><td>:</td><td><input class='form-control' name='tanggal' type='text' id='calender' value='$tanggal' ></td>
	</tr>
	
	<tr>
	<td>Aktifitas</td><td>:</td><td><textarea name='kreatifitas' class='form-control'  >$ed[kreatifitas]</textarea></td>
	</tr>
	
	<tr>
	<td>Uraian</td><td>:</td><td><textarea name='uraian'  class='form-control'>$ed[uraian]</textarea></td>
	</tr>
	
	<tr>
	<td>Jam Mulai</td><td>:</td><td>
	<div class='input-group clockpicker pull-center' data-placement='right' data-align='top' data-autoclose='true'>
	<input class='form-control' name='wm_k' type='text' value='$ed[wm_k]'>
	<span class='input-group-addon'>
					<span class='glyphicon glyphicon-time'></span>
				</span>
			</div></td>
	</tr>
	
	<tr>
	<td>Jam Akhir</td><td>:</td><td>
	<div class='input-group clockpicker pull-center' data-placement='right' data-align='top' data-autoclose='true'>
	<input class='form-control' name='wa_k' type='text' value='$ed[wa_k]'>
	<span class='input-group-addon'>
					<span class='glyphicon glyphicon-time'></span>
				</span>
			</div></td>
	</tr>
	
	<tr>
	<td></td><td></td><td><input type=submit value=Simpan>
	<input type=button value=Batal onclick=self.history.back()>
	</td>
	</tr>
	</table>
	</form>
	";
	break;
	
	case "detail":
	$nip=trim($_SESSION['nip']);
	$tgl= date('Y-m-d');
	$per=explode('-',$tgl);
	$bln=$per[1];
	$thn=$per[0];
	$waktu= date ('H:i:s');
	
	$dat=mktime(0, 0, 0, date("m")-1, date("d"), date("Y"));
	$tgl1= date('Y-m-28',$dat);
	$per1=explode('-',$tgl1);
	$bln1=$per1[1];
	$thn1=$per1[0];
	$tahun =  date("Y");
	$set=mysql_query("select * from setting ");
	$knj=mysql_fetch_array($set);
	$ekin=$knj['kinerja'];
	if($ekin=="1"){
	$tampil=mysql_query("select * from kreatifitas where 
						 Month(kreatifitas.tanggal)='$bln' 
						 and Year(kreatifitas.tanggal)='$thn' and nip='$nip'
						 order by tanggal,wm_k DESC  ");
	$tam=mysql_query("select * from skp  ");
	}
	else
	// Month(kreatifitas.tanggal)='$bln1' and Year(kreatifitas.tanggal)='$thn' and 
	$tampil=mysql_query("select * from kreatifitas where nip='$nip'
						 order by tanggal,wm_k DESC  ");
	$tam=mysql_query("select * from skp  ");
	echo "<h2 class='head'>DATA KREATIFITAS PEGAWAI</h2>
	<div>
	<input type=button value='Tambah Data' onclick=\"window.location.href='?module=kreatifitas&act=input';\">
	</div>
	<div align='right'><form action='?module=kreatifitas&act=c_kreatifitas' method='POST' >
	TANGGAL <select  name='bulan'>
            	<option value='' selected='selected'>--Pilih bulan--</option>
				<option value='1'>Januari</option>
				<option value='2'>Februari</option>
				<option value='3'>Maret</option>
				<option value='4'>April</option>
				<option value='5'>Mei</option>
				<option value='6'>Juni</option>
				<option value='7'>Juli</option>
				<option value='8'>Agustus</option>
				<option value='9'>September</option>
				<option value='10'>Oktober</option>
				<option value='11'>November</option>
				<option value='12'>Desember</option>
			</select>
			<select name='tahun'>
            <option value='$tahun' class='form-control' selected='selected'>Pilih Tahun</option>";
			$saiki = 2015;
			for($l=$saiki; $l<=$tahun; $l++)
			{
				echo"<option value=",$l,">",$l,"</option>";
			}	
	echo "</select> 
	<input type='submit' value='Tampilkan'>
			 </div>
	<table class='table table-bordered table-hover table-striped'>
	<thead>
  <tr>
  <td>No</td>
  <td>ID Kreatifitas</td>
  <td>Tanggal</td>
    <td>Nip</td>
	<td>Kreatifitas</td>
	<td>Uraian</td>
	<td>Jam Mulai</td>
	<td>Jam Selesai</td>
	<td>Durasi Pekerjaan</td>
	<td>Penginputan</td>
	<td>Control</td>
  </tr>
  </thead>";
  $no=1;
  while($dt=mysql_fetch_array($tam)){
  $time=$dt['waktu'];
  }
  while($dt=mysql_fetch_array($tampil)){
  $vol=$dt['jumlah']/$time;
  echo "<tr>
  <td>$no</td>
  <td>$dt[id_kreatifitas]</td>
  <td>$dt[tanggal]</td>
    <td>$dt[nip]</td>
	 <td>$dt[kreatifitas]</td>
	 <td>$dt[uraian]</td>
	<td>$dt[wm_k]</td>
	<td>$dt[wa_k]</td>
	<td>$dt[jumlah] Menit</td>
	<td>$dt[keterangan] WIB</td>
	<td><span><a href='?module=kreatifitas&act=edit&id_kreatifitas=$dt[id_kreatifitas]'>Edit</a></span><span>
	<a href=\"$aksi?module=kreatifitas&act=hapus&id_kreatifitas=$dt[id_kreatifitas]\" onClick=\"return confirm('Apakah Anda benar-benar mau menghapusnya?')\">Hapus</a></span>
	</td>
  </tr>";
  $no++;
  }
echo "  
</table>
	";
	break;
	
	case "c_kreatifitas":
	$nip=$_SESSION['namauser'];
	$tm="$_POST[tahun]-$_POST[bulan]-28";
	$tgl=$tm;
	$periode=$_POST['bulan']-$_POST['tahun'];
	$day = date('F Y', strtotime($tgl));
	$per=explode('-',$tgl);
	$bln=$per[1];
	$thn=$per[0];
	$waktu= date ('H:i:s');
	$tampil=mysql_query("select * from kreatifitas where 
						 Month(kreatifitas.tanggal)='$bln' 
						 and Year(kreatifitast.tanggal)='$thn' and nip='$nip'
						 order by tanggal,wm_k DESC  ");
	$tahun =$_POST['tahun'];
	?>
	<h2 class='head'>DATA KINERJA TAMBAHAN </h2>
      
	
	<? echo"Periode : $day
	<div align='right'><form action='?module=kreatifitas&act=c_kreatifitas' method='POST' >
	TANGGAL <select  name='bulan'>
            	<option value='' selected='selected'>--Pilih bulan--</option>
				<option value='1'>Januari</option>
				<option value='2'>Februari</option>
				<option value='3'>Maret</option>
				<option value='4'>April</option>
				<option value='5'>Mei</option>
				<option value='6'>Juni</option>
				<option value='7'>Juli</option>
				<option value='8'>Agustus</option>
				<option value='9'>September</option>
				<option value='10'>Oktober</option>
				<option value='11'>November</option>
				<option value='12'>Desember</option>
			</select>
			<select name='tahun'>
            <option value='$tahun' class='form-control' selected='selected'>$tahun</option>";
			$saiki = 2015;
			for($l=$saiki; $l<=$now; $l++)
			{
				echo"<option value=",$l,">",$l,"</option>";
			}	
	echo "</select> 
	<input type='submit' value='Tampilkan'>
			 </div>
	<table class='table table-bordered table-hover table-striped'>
	<thead>
  <tr>
  <td>No</td>
  <td>ID Kinerja</td>
  <td>Tanggal</td>
    <td>Nip</td>
	<td>kegiatan</td>
	<td>Uraian</td>
	<td>Jam Mulai</td>
	<td>Jam Selesai</td>
	<td>Durasi Pekerjaan</td>
	<td>Peninputan</td>
	<td>Status</td>
  </tr>
  </thead>";
  $no=1;
  while($dt=mysql_fetch_array($tampil)){
  $n1=$dt['point'];
  echo "<tr>
  <td>$no</td>
  <td>$dt[id_kreatifitas]</td>
  <td>$dt[tanggal]</td>
    <td>$dt[nip]</td>
	 <td>$dt[kreatifitas]</td>
	 <td>$dt[uraian]</td>
	<td>$dt[wm_k]</td>
	<td>$dt[wa_k]</td>
	<td>$dt[jumlah] Menit</td>
	<td>$dt[keterangan] WIB</td>
	<td>";
	if ($n1 > 0 )
	echo"<font color='green'>Tevalidasi</font>";
	else
	echo"<font color='red'>Pending/Tidak di Validasi<font>";
	echo"
	</td>
  </tr>";
  $no++;
  } 
echo "  
</table> 
<div style='text-align:center;padding:20px;'>
	<input class='noPrint' type='button' value='Cetak Halaman' onclick='window.print()'>
	";
	break;
	
	case "cari":
	$t1=$_POST['t1'];
	$t2=$_POST['t2'];
	echo"yang di cari tanggal $t1 sampai $t2";
	$tampil=mysql_query("select * from kreatifitas where tanggal between '$t1' and '$t2'  ");
    
	echo "<div>
	<input type=button value=Kembali onclick=self.history.back()>
	</div>
	<h2 class='head'>DATA KREATIFITAS PEGAWAI</h2>
	<table class='table table-bordered table-hover table-striped'>
	<thead>
  <tr>
  <td>No</td>
  <td>ID Kinerja</td>
  <td>Tanggal</td>
    <td>Nip</td>
	<td>Kreatifitas</td>
	<td>Uraian</td>
	<td>Jam Mulai</td>
	<td>Jam Selesai</td>
	<td>Durasi Pekerjaan</td>
	<td>Control</td>
	<td>Point</td>
  </tr>
  </thead>";
  $no=1;
  while($dt=mysql_fetch_array($tampil)){
  echo "<tr>
  <td>$no</td>
  <td>$dt[id_kinerja_t]</td>
  <td>$dt[tanggal]</td>
    <td>$dt[nip]</td>
	 <td>$dt[kreatifitas]</td>
	 <td>$dt[uraian]</td>
	<td>$dt[wm_k]</td>
	<td>$dt[wa_k]</td>
	<td>$dt[jumlah] Menit</td>
	<td><span><a href='?module=kreatifitas&act=validasi&id_kreatifitas=$dt[id_kreatifitas]'><input type=submit value='Validasi' name='validas'></s><a href='?module=kreatifitas&act=batal&id_kreatifitas=$dt[id_kreatifitas]'><input type=submit value='Batal Validasi' name='validas'></s></span><span>
	</span>
	<td>$dt[point] </td>
	</td>
  </tr>";
  $no++;
  }
echo " 
<tr>
  <td colspan=10 > NILAI
  </td>
  <td>"; 
  $tgl= date('Y-m-d');
	$per=explode('-',$tgl);
	$bln=$per[1];
	$thn=$per[0];
	$waktu= date ('H:i:s');
	
  $qry_jumlah_b=mysql_query("select SUM(point) from kreatifitas where tanggal between '$t1' and '$t2' ");
        $data_b=mysql_fetch_array($qry_jumlah_b);
        $nilai=$data_b[0];
        echo $nilai;
		echo"</td>
  </tr> 
</table>
	";
	
}


?>