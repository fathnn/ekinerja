<?php 
error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
include "../../config/koneksi.php";
include "../../config/fungsi_indotgl.php";
include "../../config/class_paging.php";
include "../../config/kode_auto.php";
include "../../config/fungsi_thumb.php";

$module=$_GET['module'];
$act=$_GET['act'];

if($module=='kinerja' AND $act=='hapus' ){ 
	mysql_query("delete from kinerja where id_kinerja='$_GET[id_kinerja]'");
	header('location:../../media.php?module='.$module);
}

$mulai="$_POST[wm_k]"; //jam dalam format STRING
$selesai="$_POST[wa_k]"; //jam dalam format DATE real itme

$mulai_time=(is_string($mulai)?strtotime($mulai):$mulai);// memaksa mebentuk format time untuk string
$selesai_time=(is_string($selesai)?strtotime($selesai):$selesai);
$date="$_POST[tanggal]";
$tanggal=date("y-m-d",strtotime($date));
$detik=$selesai_time-$mulai_time; //hitung selisih dalam detik
$menit=floor($detik/60); //hiutng menit
$sisa_detik=$detik%$menit; //hitung sisa detik

if($module=='waktu' AND $act=='input_t' ){
$tl="$menit";
$id=kdauto(waktu_t,WKT);
$cst=$_POST["c_sakit_t"]*60;
$cat=$_POST["c_alasan_t"]*300;
$ctt=$_POST["c_tahunan_t"]*300;
$diklat=$_POST["diklat"]*300;
$spd=$_POST["spd"]*300;
$haji=$_POST["haji"]*300;
$t_waktu_t=$cst+$cat+$ctt+$diklat+$spd+$haji;
	mysql_query("insert into waktu_t set id_waktu_t='$id',nip='$_POST[nip]',c_sakit_t='$_POST[c_sakit_t]',c_alasan_t='$_POST[c_alasan_t]',
										   c_tahunan_t='$_POST[c_tahunan_t]', diklat='$_POST[diklat]',
										   spd='$_POST[spd]', haji='$_POST[haji]', tanggal='$tanggal', t_waktu_t='$t_waktu_t'
										   ");
	echo "<script>alert('Lanjutkan Memvalidasi'); window.location = 'javascript:history.go(-2)'</script>";
}

elseif($module=='kreatifitas' AND $act=='input' ){
$tl="$menit";
$date=$_POST['tanggal'];
$tanggal=date("y-m-d",strtotime($date));
$id=kdauto(kreatifitas,KFT);
	mysql_query("insert into kreatifitas set id_kreatifitas='$id',nip='$_POST[nip]',kreatifitas='$_POST[kreatifitas]',uraian='$_POST[uraian]',
										   wm_k='$_POST[wm_k]', wa_k='$_POST[wa_k]',keterangan='$_POST[keterangan]',
										   jumlah='$tl', tanggal='$tanggal', point='$_POST[point]'
										   ");
	header('location:../../media.php?module='.$module);
}


elseif($module=='kreatifitas' AND $act=='edit' ){
$tl="$menit";
$date=$_POST['tanggal'];
$tanggal=date("y-m-d",strtotime($date));
	mysql_query("update kreatifitas set kreatifitas='$_POST[kreatifitas]',
										   uraian='$_POST[uraian]',
										   wm_k='$_POST[wm_k]',
										   wa_k='$_POST[wa_k]',keterangan='$_POST[keterangan]',
										   jumlah='$tl',tanggal='$tanggal'
										   where id_kreatifitas='$_POST[id_kreatifitas]'
										   ");
	header('location:../../media.php?module='.$module);
}
elseif($module=='kreatifitas' AND $act=='val' ){
$tl="$menit";
mysql_query("update kreatifitas set 	   kreatifitas='$_POST[kreatifitas]',
										   uraian='$_POST[uraian]',
										   wm_k='$_POST[wm_k]',
										   wa_k='$_POST[wa_k]',
										   jumlah='$tl',tanggal='$_POST[tanggal]',point='$_POST[point]'
										   where id_kreatifitas='$_POST[id_kreatifitas]'
										   ");
										   $bagian=$_SESSION['id_bag'];
										    echo "<script>alert('Lanjutkan Memvalidasi'); window.location = 'javascript:history.go(-2)'</script>";
}
elseif($module=='kreatifitas' AND $act=='valpj' ){
$tl="$menit";
mysql_query("update kreatifitas set 	   kreatifitas='$_POST[kreatifitas]',
										   uraian='$_POST[uraian]',
										   wm_k='$_POST[wm_k]',
										   wa_k='$_POST[wa_k]',
										   jumlah='$tl',tanggal='$_POST[tanggal]',point='$_POST[point]'
										   where id_kreatifitas='$_POST[id_kreatifitas]'
										   ");
										   $bagian=$_SESSION['id_bag'];
										    echo "<script>alert('Lanjutkan Memvalidasi'); window.location = 'javascript:history.go(-3)'</script>";
}

elseif($module=='kreatifitas' AND $act=='hapus' ){
	mysql_query("delete from kreatifitas where id_kreatifitas = '$_GET[id_kreatifitas]'");
	header('location:../../media.php?module='.$module);
}


?>