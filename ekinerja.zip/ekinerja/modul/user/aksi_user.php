<?php 
include "../../config/koneksi.php";
include "../../config/fungsi_indotgl.php";
include "../../config/class_paging.php";
include "../../config/kode_auto.php";

$module=$_GET['module'];
$act=$_GET['act'];


if($module=='user' AND $act=='input' ){
	mysql_query("insert into user_id set userid='$_POST[userid]', passid='$_POST[passid]',id_skpd='$_POST[id_skpd]',id_ukpd='$_POST[id_ukpd]',  level_user='$_POST[level_user]'");
	header('location:../../media.php?module='.$module);
}

elseif($module=='user' AND $act=='edit' ){
	mysql_query("update userskpd set id_skpd='$_POST[id_skpd]', id_ukpd='$_POST[id_ukpd]',leveluser='$_POST[leveluser]', passid='$_POST[passid]'");
	header('location:../../media.php?module='.$module);
}

elseif($module=='user' AND $act=='hapus' ){
	mysql_query("delete from userskpd whereuserid='$_GET[userid]'");
	header('location:../../media.php?module='.$module);
}


?>