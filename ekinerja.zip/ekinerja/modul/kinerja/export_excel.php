
<body>
	<style type="text/css">
	body{
		font-family: sans-serif;
	}
	table{
		margin: 20px auto;
		border-collapse: collapse;
	}
	table th,
	table td{
		border: 1px solid #3c3c3c;
		padding: 3px 8px;
 
	}
	a{
		background: blue;
		color: #fff;
		padding: 8px 10px;
		text-decoration: none;
		border-radius: 2px;
	}
	</style>
 
	<?php
	header("Content-type: application/vnd-ms-excel");
	header("Content-Disposition: attachment; filename=DATA KINERJA PEGAWAI.xls");
	
include "../../config/koneksi.php";
	 $nip = $_GET[nip];
                $tm = "$_GET[tahun]-$_GET[bulan]-28";
                $tgl = $tm;
                $periode = "$_GET[bulan]-$_GET[tahun]";
                $day = date('F Y', strtotime($tgl));
                $per = explode('-', $tgl);
                $bln = $per[1];
                $thn = $per[0];
                $waktu = date('H:i:s');
                $tampil = mysql_query("select * from kinerja where 
        Month(kinerja.tanggal)='$bln' 
        and Year(kinerja.tanggal)='$thn' and nip='$nip'
        order by tanggal,jam_mulai DESC  ");
                $tam = mysql_query("select * from skp  ");
                $tahun = $_GET['tahun'];
                echo"
        <table class='table table-bordered table-hover table-striped'>
        <thead>
        <tr>
        <td>No</td>
        <td>ID Kinerja</td>
        <td>Tanggal</td>
        <td>Nip</td>
        <td>kd_skp</td>
        <td>Uraian</td>
        <td>Jam Mulai</td>
        <td>Jam Selesai</td>
        <td>Durasi Pekerjaan</td>
        <td>Volume</td>
        <td>Penginputan</td>
        <td>Status</td>
        </tr>
        </thead>";
                $no = 1;
                while ($dt = mysql_fetch_array($tam)) {
                    $time = $dt['waktu'];
                }
                while ($dt = mysql_fetch_array($tampil)) {
                    $vol = $dt['jumlah'] / $dt['waktu_e'];
                    $vol1 = number_format($vol, 0);
                    $n1 = $dt['point'];
                    echo "<tr>
        <td>$no</td>
        <td>$dt[id_kinerja]</td>
        <td>$dt[tanggal]</td>
        <td>$dt[nip]</td>
        <td>$dt[kd_skp]</td>
        <td>$dt[uraian]</td>
        <td>$dt[jam_mulai]</td>
        <td>$dt[jam_akhir]</td>
        <td>$dt[jumlah] Menit</td>
        <td>$vol1</td>
        <td>$dt[keterangan] WIB</td>
        <td>";
                    if ($n1 > 0)
                        echo"<font color='green'>Tervalidasi</font>";
                    else
                        echo"<font color='red'>Pending/Tidak di Validasi<font>";
                    echo"
        </td>
        </tr>";
                    $no++;
                }
                echo "  
        </table> ";?>
        </body>