<?php

include "../../config/koneksi.php";
include "../../config/fungsi_indotgl.php";
include "../../config/class_paging.php";
include "../../config/kode_auto.php";
include "../../config/fungsi_thumb.php";
error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
$module = $_GET['module'];
$act = $_GET['act'];
$mulai = $_POST['jam_mulai']; //jam dalam format STRING
$selesai = $_POST['jam_akhir']; //jam dalam format DATE real itme
$date = $_POST['tanggal'];
$tanggal = date("y-m-d", strtotime($date));
$mulai_time = (is_string($mulai) ? strtotime($mulai) : $mulai); // memaksa mebentuk format time untuk string
$selesai_time = (is_string($selesai) ? strtotime($selesai) : $selesai);

$detik = $selesai_time - $mulai_time; //hitung selisih dalam detik
$menit = floor($detik / 60); //hiutng menit
$sisa_detik = $detik % $menit; //hitung sisa detik
if ($module == 'kinerja' AND $act == 'hapus') {
    mysql_query("delete from kinerja where id_kinerja='$_GET[id_kinerja]'");
    header('location:../../media.php?module=' . $module);
}

if ($module == 'kinerja' AND $act == 'input') {

    $tl = $menit;
    $id = kdauto('kinerja', 'KNJ');
    mysql_query("insert into kinerja set id_kinerja='$id',nip='$_POST[nip]',kd_skp='$_POST[kd_skp]',waktu_e='$_POST[waktu_e]',uraian='$_POST[uraian]',
										   jam_mulai='$_POST[jam_mulai]', jam_akhir='$_POST[jam_akhir]',
										   jumlah='$tl', tanggal='$tanggal', point='$_POST[point]',keterangan='$_POST[keterangan]'
										   ");
    header('location:../../media.php?module=' . $module);
} elseif ($module == 'kinerja' AND $act == 'edit') {
    $tl = $menit;
    mysql_query("update kinerja set 	   kd_skp='$_POST[kd_skp]',
										   uraian='$_POST[uraian]',
										   jam_mulai='$_POST[jam_mulai]',waktu_e='$_POST[waktu_e]',
										   jam_akhir='$_POST[jam_akhir]',
										   jumlah='$tl',tanggal='$tanggal',keterangan='$_POST[keterangan]'
										   where id_kinerja='$_POST[id_kinerja]'
										   ");
    header('location:../../media.php?module=' . $module);
} elseif ($module == 'kinerja' AND $act == 'val') {
    $tl = "$menit";
    mysql_query("update kinerja set 	   point='$_POST[point]'
										   where id_kinerja='$_POST[id_kinerja]'
										   ");
    $bagian = $_SESSION['id_bag'];
    echo "<script>alert('Lanjutkan Memvalidasi'); window.location = 'javascript:history.go(-2)'</script>";
} elseif ($module == 'kinerja' AND $act == 'valpj') {
    $tl = '$menit';
    mysql_query("update kinerja set point='$_POST[point]' where id_kinerja='$_POST[id_kinerja]'");
    echo "<script>alert('Lanjutkan Memvalidasi'); window.location = 'javascript:history.go(-1)'</script>";
} elseif ($module == 'kinerja' AND $act == 'hapus') {
    mysql_query("delete from kinerja where id_kinerja = '$_GET[id_kinerja]'");
    header('location:../../media.php?module=' . $module);
} elseif ($module == 'kinerja' AND $act == 'validasiall') {
    mysql_query("update kinerja set point=jumlah where nip='$_GET[nip]'");

    echo "<script>alert('Lanjutkan'); window.location = 'javascript:history.go(-1)'</script>";
}
?>