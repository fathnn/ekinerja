<script type="text/javascript">
    
	function validasi_input(form) {
        
		if (form.tanggal.value == "") {
          
		alert("tanggal masih kosong!");
            
		form.tanggal.focus();
            
		return (false);
        
		}

        
	if (form.kd_skp.value == "--SKP--") {
            
		alert("SKP Belum di Pilih!");
            
		form.kd_skp.focus();
            
		return (false);
        
		}

        if (form.uraian.value == "") {
            
		alert("uraian masih kosong!");
            
		form.uraian.focus();
            
		return (false);

	        }

        if (form.jam_mulai.value == "") {

        	alert("jam mulai belum di pilih!");
            
		form.jam_mulai.focus();
            
		return (false);
        
		}
        
	if (form.jam_akhir.value == "") {
            
		alert("jam selesai belum di pilih!");
            
		form.jam_akhir.focus();
            
		return (false);
        
		}
        
	if (form.waktu_e.value == "") {
            
		alert("ada kesalahan di waktu efektif!");
            
		form.kd_skp.focus();
            
		return (false);
        
		}
        
		return (true);
    
		}

</script>


<?php
error_reporting(0);
$aksi = "modul/kinerja/aksi_kinerja.php";
$nip = trim($_SESSION['nip']);

date_default_timezone_set('asia/jakarta');
$keterangan = date("d/m/Y, H:i:s");
switch ($_GET[act]) 
{

default:
        
echo"
<a href='?module=kinerja&act=detail&nip=$_SESSION[nip]'>Data Sudah Selesai Di Proses lanjutkan</a>";
        
break;

    
case "awalan":
        
$tampil = mysql_query("select * from kinerja,pegawai,skp where kinerja.nip=pegawai.nip  order by id_kinerja");
        
echo "<h2 class='head'>DATA KINERJA PEGAWAI</h2>
	
<div>
	
<input type=button value='Tambah Data' onclick=\"window.location.href='?module=kinerja&act=input';\">
	
</div>
	
<table class='tabel'>
	
<thead>
  
<tr>
  
<td>Tanggal</td>
   
 <td>Nip</td>
    
<td>Nama Pegawai</td>
	
<td>kd_skp</td>
	<td>Uraian</td>
	<td>Jam Mulai</td>
	<td>Jam Selesai</td>
	<td>Durasi Pekerjaan</td>
	<td>Volume</td>
	<td>Control</td>
  </tr>
  </thead>";
        $no = 1;
        while ($dt = mysql_fetch_array($tampil)) {
            $vol = $dt['jumlah'] / $dt['waktu'];
            echo "<tr>
  <td>$dt[tanggal]</td>
    <td>$dt[nip]</td>
    <td>$dt[nama]</td>
	 <td>$dt[kd_skp]</td>
	 <td>$dt[uraian]</td>
	<td>$dt[jam_mulai]</td>
	<td>$dt[jam_akhir]</td>
	<td>$dt[jumlah] Menit</td>
	<td>$vol</td>
	<td><span><a href='?module=kinerja&act=edit&id_kinerja=$dt[id_kinerja]'>Edit</a></span><span>
	<a href=\"$aksi?module=kinerja&act=hapus&id_kinerja=$dt[id_kinerja]\" onClick=\"return confirm('Apakah Anda benar-benar mau menghapusnya?')\">Hapus</a></span>
	</td>
  </tr>";
            $no++;
        }
        echo "  
</table>
	";

        break;

    case "input":
        $nippeg = trim($_SESSION[nip]);
        echo "<h2 class='head'>ENTRY KINERJA </h2>
	<form action='$aksi?module=kinerja&act=input' onsubmit='return validasi_input(this)' method='post' enctype='multipart/form-data' >
	<table class='tabelform tabpad'>
	<tr>
	<td class='form-group'><label>Nip</label></td><td>:</td><td><input class='form-control' placeholder='Placeholder' name='nip' type='text' value='$_SESSION[nip]' readonly > </td>
	</tr>
	<tr>
	<td class='form-group'>Tanggal</td><td>:</td><td><input class='form-control' name='tanggal' id='calender' type='text' autocomplete='off'>
	<input class='form-control' name='keterangan' type='hidden' value='$keterangan'></td>
	</tr>
	<tr>
	<td class='form-group'>Kode Aktifitas</td><td>:</td><td>";
        $result = mysql_query("select * FROM skptahunan WHERE nip='$nippeg'");
        $jsArray = "var prdName = new Array();\n";
        echo '<select class="form-control" name="kd_skp" onchange="document.getElementById(\'prd_name\').value = prdName[this.value]">';
        echo '<option>--List Aktifitas--</option>';
        while ($row = mysql_fetch_array($result)) {
            echo '<option value="' . $row['kd_skp'] . '">' . $row['kd_skp'] . '</option>';
            $jsArray .= "prdName['" . $row['kd_skp'] . "'] = '" . addslashes($row['waktu_e']) . "';\n";
        }
        echo '</select></td></tr>';
        ?>
        <!--<tr>
            <td >Efektif</td><td>:</td><td>
                <input class="form-control" type="text" width="30" name="waktu_e" id="prd_name" title="Menit" readonly/>
                <script type="text/javascript">
        <?php echo $jsArray; ?>
                </script>
                <?php
                echo"</td>
        </tr>-->
        <tr>
        <td class='form-group'>uraian</td><td>:</td><td><textarea class='form-control' name='uraian'></textarea></td>
        </tr>
        <tr>
        <td class='form-group'>Jam Mulai</td><td>:</td><td>
        <div class='input-group clockpicker pull-center' data-placement='right' data-align='top' data-autoclose='true'>
        <input type='text' class='form-control' name='jam_mulai' value=''>
        <span class='input-group-addon'>
        <span class='glyphicon glyphicon-time'></span>
        </span>
        </div>
        </td>
        </tr>
        <tr>
        <td class='form-group'>Jam Selesai</td><td>:</td><td>
        <div class='input-group clockpicker pull-center' data-placement='right' data-align='top' data-autoclose='true'>
        <input class='form-control'' name='jam_akhir' type='text'>
        <span class='input-group-addon'>
        <span class='glyphicon glyphicon-time'></span>
        </span>
        </div></td>
        </tr>
        <tr>
        <td class='form-group'></td><td></td><td><input type='submit' value='Simpan'>
        <input type='button' value='Batal' onclick='self.history.back()'>
        </td>
        </tr>
        </table>
        </form>
        ";
                break;


            case "detail":
                $nip = trim($_SESSION['nip']);
                $tgl = date('Y-m-d');
                $per = explode('-', $tgl);
                $bln = $per[1];
                $thn = $per[0];
                $waktu = date('H:i:s');

                $dat = mktime(0, 0, 0, date("m") - 1, date("d"), date("Y"));
                $tgl1 = date('Y-m-28', $dat);
                $tgl2 = date('Y-m-01', $dat);
                $per1 = explode('-', $tgl1);
                $bln1 = $per1[1];
                $thn1 = $per1[0];

                $set = mysql_query("select * from setting ");
                $knj = mysql_fetch_array($set);
                $ekin = $knj['kinerja'];
                if ($ekin == "1") {
                    $tampil = mysql_query("select * from kinerja where 
        Month(kinerja.tanggal)='$bln' 
        and Year(kinerja.tanggal)='$thn' and nip='$nip'
        order by keterangan DESC  ");
                    $tam = mysql_query("select * from skp  ");
                } else{
    //Month(kinerja.tanggal)='$bln1' and Year(kinerja.tanggal)='$thn1' and
                    $tampil = mysql_query("select * from kinerja where nip='$nip' order by keterangan DESC");
                $tam = mysql_query("select * from skp  ");
                $tahun = date("Y");
                }?>
                <h2 class='head'>DATA KINERJA PEGAWAI </h2>


                <?php
                echo"<input type=button value='Tambah Data' onclick=\"window.location.href='?module=kinerja&act=input';\">
        <div align='right'><form action='?module=kinerja&act=c_kinerja'' method='POST' >
        TANGGAL <select  name='bulan'>
        <option value='' selected='selected'>--Pilih bulan--</option>
        <option value='1'>Januari</option>
        <option value='2'>Februari</option>
        <option value='3'>Maret</option>
        <option value='4'>April</option>
        <option value='5'>Mei</option>
        <option value='6'>Juni</option>
        <option value='7'>Juli</option>
        <option value='8'>Agustus</option>
        <option value='9'>September</option>
	    <option value='10'>Oktober</option>
        <option value='11'>November</option>
        <option value='12'>Desember</option>
        </select>
        <select name='tahun'>
        <option value='$tahun' class='form-control' selected='selected'>Pilih Tahun</option>";
                $saiki = 2018;
                for ($l = $saiki; $l <= 2030; $l++) {
                    echo"<option value=", $l, ">", $l, "</option>";
                }
                echo "</select> 
        <input type='submit' value='Tampilkan'>
        </div>

        <table class='table table-bordered table-hover table-striped'>
        <thead>
        <tr>
        <td>No</td>
        <td>ID Kinerja</td>
        <td>Tanggal</td>
        <td>Nip</td>
        <td>kd_skp</td>
        <td>Uraian</td>
        <td>Jam Mulai</td>
        <td>Jam Selesai</td>
        <td>Durasi Pekerjaan</td>
        <td>Volume</td>
        <td>Penginputan</td>
        <td>Control</td>
        <td>Status</td>
        </tr>
        </thead>";
                $no = 1;
                while ($dt = mysql_fetch_array($tam)) {
                    $time = $dt['waktu'];
                }
                while ($dt = mysql_fetch_array($tampil)) {
                    $skpwaktu = mysql_query("select * from skp WHERE skp = '$dt[kd_skp]' ");
                     while ($dtwww = mysql_fetch_array($skpwaktu)) {
                        $w_volume = $dtwww['waktu'];
                    }
                    $vol = $dt['jumlah'] / $w_volume;
                    $vol1 = number_format($vol, 0);
                    $n1 = $dt['point'];
                    echo "<tr>
        <td>$no</td>
        <td>$dt[id_kinerja]</td>
        <td>$dt[tanggal]</td>
        <td>$dt[nip]</td>
        <td>$dt[kd_skp]</td>
        <td>$dt[uraian]</td>
        <td>$dt[jam_mulai]</td>
        <td>$dt[jam_akhir]</td>
        <td>$dt[jumlah] Menit</td>
        <td>$vol</td>
        <td>$dt[keterangan] WIB</td>
        <td><!--<span><a href='?module=kinerja&act=edit&id_kinerja=$dt[id_kinerja]'>Edit</a></span>--><span>
        <a href=\"$aksi?module=kinerja&act=hapus&id_kinerja=$dt[id_kinerja]\" onClick=\"return confirm('Apakah Anda benar-benar mau menghapusnya?')\">Hapus</a></span>
        </td>
        <td>";
                    if ($n1 > 0)
                        echo"<font color='green'>Tervalidasi</font>";
                    else
                        echo"<font color='red'>Pending/Tidak di Validasi<font>";
                    echo"
        </td>
        </tr>";
                    $no++;
                }

                echo "  
        </table> </div>
        </div>
        </div>
        </div>
        ";

                break;

            case "c_kinerja":
                $nip = trim($_SESSION['nip']);
                $tm = "$_POST[tahun]-$_POST[bulan]-28";
                $tgl = $tm;
                $periode = "$_POST[bulan]-$_POST[tahun]";
                $day = date('F Y', strtotime($tgl));
                $per = explode('-', $tgl);
                $bln = $per[1];
                $thn = $per[0];
                $waktu = date('H:i:s');
                $tampil = mysql_query("select * from kinerja where 
        Month(kinerja.tanggal)='$bln' 
        and Year(kinerja.tanggal)='$thn' and nip='$nip'
        order by tanggal,jam_mulai DESC  ");
                $tam = mysql_query("select * from skp  ");
                $tahun = $_POST['tahun'];
                ?>
                <h2 class='head'>DATA KINERJA PEGAWAI </h2>


                <?php
                echo"Periode : $day
        <div align='right'><form action='?module=kinerja&act=c_kinerja' method='POST' >
        TANGGAL <select  name='bulan'>
        <option value='' selected='selected'>--Pilih bulan--</option>
        <option value='1'>Januari</option>
        <option value='2'>Februari</option>
        <option value='3'>Maret</option>
        <option value='4'>April</option>
        <option value='5'>Mei</option>
        <option value='6'>Juni</option>
        <option value='7'>Juli</option>
        <option value='8'>Agustus</option>
        <option value='9'>September</option>
        <option value='10'>Oktober</option>
        <option value='11'>November</option>
        <option value='12'>Desember</option>
        </select>
        <select name='tahun'>
        <option value='$tahun' class='form-control' selected='selected'>$tahun</option>";
                $saiki = 2018;
                for ($l = $saiki; $l <= $now; $l++) {
                    echo"<option value=", $l, ">", $l, "</option>";
                }
                echo "</select> 
        <input type='submit' value='Tampilkan'>
        </div>
        <table class='table table-bordered table-hover table-striped'>
        <thead>
        <tr>
        <td>No</td>
        <td>ID Kinerja</td>
        <td>Tanggal</td>
        <td>Nip</td>
        <td>kd_skp</td>
        <td>Uraian</td>
        <td>Jam Mulai</td>
        <td>Jam Selesai</td>
        <td>Durasi Pekerjaan</td>
        <td>Volume</td>
        <td>Penginputan</td>
        <td>Control</td>
        <td>Status</td>
        </tr>
        </thead>";
                $no = 1;
                while ($dt = mysql_fetch_array($tam)) {
                    $time = $dt['waktu'];
                }
                while ($dt = mysql_fetch_array($tampil)) {
                    $vol = $dt['jumlah'] / $dt['waktu_e'];
                    $vol1 = number_format($vol, 0);
                    $n1 = $dt['point'];
                    echo "<tr>
        <td>$no</td>
        <td>$dt[id_kinerja]</td>
        <td>$dt[tanggal]</td>
        <td>$dt[nip]</td>
        <td>$dt[kd_skp]</td>
        <td>$dt[uraian]</td>
        <td>$dt[jam_mulai]</td>
        <td>$dt[jam_akhir]</td>
        <td>$dt[jumlah] Menit</td>
        <td>$vol1</td>
        <td>$dt[keterangan] WIB</td>
        <td><span><a href='?module=kinerja&act=edit&id_kinerja=$dt[id_kinerja]'>Edit</a></span><span>
        <a href=\"$aksi?module=kinerja&act=hapus&id_kinerja=$dt[id_kinerja]\" onClick=\"return confirm('Apakah Anda benar-benar mau menghapusnya?')\">Hapus</a></span>
        </td>
        <td>";
                    if ($n1 > 0)
                        echo"<font color='green'>Tervalidasi</font>";
                    else
                        echo"<font color='red'>Pending/Tidak di Validasi<font>";
                    echo"
        </td>
        </tr>";
                    $no++;
                }
                echo "  
        </table> 
        <div style='text-align:center;padding:20px;'>
        <input class='noPrint' type='button' value='Cetak Halaman' onclick='window.print()'>
        <a type='button' target='_blank' href='modul/kinerja/export_excel.php?tahun=$_POST[tahun]&bulan=$_POST[bulan]&nip=$nip'>Download</a>
        ";
       

                break;

            case "lihat":
                $nip = $_SESSION['nip'];
                $dat = mktime(0, 0, 0, date("m") - 1, date("d"), date("Y"));
                $tgl = date('Y-m-28', $dat);
                $per = explode('-', $tgl);
                $bln = $per[1];
                $thn = $per[0];
                $waktu = date('H:i:s');
//        Month(kinerja.tanggal)='$bln'  and Year(kinerja.tanggal)='$thn' and
                $tampil = mysql_query("select * from kinerja where  nip='$_GET[nip]' and MONTH(tanggal) = '$bln' AND YEAR(tanggal) = '$thn'  order by tanggal, jam_mulai asc  ");
                $tampil1 = mysql_query("select * from pegawai where nip='$_GET[nip]' ");
                while ($dt = mysql_fetch_array($tampil1)) {
                    $nip1 = $dt['nip'];
                    $nama = $dt['nama'];
                }
                echo "<h2 class='head'>DATA KINERJA UNIT USER</h2>
        <div>
        <input type=button value=Kembali onclick=self.history.back()>
       <a href='$aksi?module=kinerja&act=validasiall&nip=$_GET[nip]'><input type='button' value='Validasi Semua'></a>
        </div>
        <table class='table table-bordered table-hover table-striped'>
        <thead>
        <tr>
        <td>No</td>
        <td>ID Kinerja</td>
        <td>Tanggal</td>
        <td>Nip</td>
        <td>Nama kp</td>
        <td>Uraian</td>
        <td>Jam Mulai</td>
        <td>Jam Selesai</td>
        <td>Durasi Pekerjaan</td>
        <td>Validasi</td>
        <td>Point</td>
        </tr>
        </thead>";
                $no = 1;
                while ($dt = mysql_fetch_array($tampil)) {
                    $nilai = $dt['jumlah'] * 1;
                    echo "<tr>
        <td>$no</td>
        <td>$dt[id_kinerja]</td>
        <td>$dt[tanggal]</td>
        <td>$dt[nip]</td>
        <td>$dt[kd_skp]</td>
        <td>$dt[uraian]</td>
        <td>$dt[jam_mulai]</td>
        <td>$dt[jam_akhir]</td>
        <td>$dt[jumlah] Menit </td>
        <td>
        <form action='$aksi?module=kinerja&act=valpj' method='post'>
        <input type='text' name='id_kinerja' value='$dt[id_kinerja]' hidden>
        <input type='text' name='point' value='$dt[jumlah]' hidden>
        <input type='submit' value='Validasi' name='validasi'></form></s>

        <form action='$aksi?module=kinerja&act=valpj' method='post'>
        <input type='text' name='id_kinerja' value='$dt[id_kinerja]' hidden>
        <input type='text' name='point' value='0' hidden>
        <input type='submit' value='Batal Validasi' name='validas'></form></s></td>
        <td>$dt[point] </td>
        </tr>
        ";
                    $no++;
                }echo"
        </tr>
        <tr>
        <td colspan=10 > NILAI
        </td>
        <td>";
                $dat = mktime(0, 0, 0, date("m") - 1, date("d"), date("Y"));
                $tgl = date('Y-m-28', $dat);
                $per = explode('-', $tgl);
                $bln = $per[1];
                $thn = $per[0];
                $waktu = date('H:i:s');
//Month(kinerja.tanggal)='$bln' and Year(kinerja.tanggal)='$thn' and
                $qry_jumlah_b = mysql_query("select SUM(point) from kinerja where nip='$_GET[nip]' and year(tanggal) = '$thn' and month(tanggal)= '$bln'
        order by tanggal DESC ");
                $data_b = mysql_fetch_array($qry_jumlah_b);
                $nilai = $data_b[0];
                echo $nilai;
                echo" </td>
        </tr>";
                echo "  
        </table>

        ";

                break;

            case "lihatpj":
                $nip = $_SESSION['nip'];
                $tgl = $_POST['tanggal'];
                $per = explode('-', $tgl);
                $bln = $per[1];
                $thn = $per[0];
                $waktu = date('H:i:s');
                $tampil = mysql_query("select * from kinerja where 
        Month(kinerja.tanggal)='$bln' 
        and Year(kinerja.tanggal)='$thn' and nip='$_GET[nip]'
        order by id_kinerja ASC  ");
                echo"
        <div>
        <input type=button value=Kembali onclick=self.history.back(-2)>
        </div>
        <table class='table table-bordered table-hover table-striped'>
        <thead>
        <tr>
        <td>No</td>
        <td>ID Kinerja</td>
        <td>Tanggal</td>
        <td>Nip</td>
        <td>Nama kp</td>
        <td>Uraian</td>
        <td>Jam Mulai</td>
        <td>Jam Selesai</td>
        <td>Durasi Pekerjaan</td>
        <td>Validasi</td>
        <td>Point</td>
        </tr>
        </thead>";
                $no = 1;
                while ($dt = mysql_fetch_array($tampil)) {
                    $nilai = $dt['jumlah'] * 1;
                    echo "<tr>
        <td>$no</td>
        <td>$dt[id_kinerja]</td>
        <td>$dt[tanggal]</td>
        <td>$dt[nip]</td>
        <td>$dt[kd_skp]</td>
        <td>$dt[uraian]</td>
        <td>$dt[jam_mulai]</td>
        <td>$dt[jam_akhir]</td>
        <td>$dt[jumlah] Menit </td>
        <td>

        <input type='text' name='id_kinerja' value='$dt[id_kinerja]' hidden>
        <input type='text' name='kd_skp' value='$dt[kd_skp]' hidden>
        <input type='text' name='tanggal' value='$dt[tanggal]' hidden>
        <input type='text' name='nip' value='$dt[nip]' hidden>
        <input type='text' name='uraian' value='$dt[uraian]' hidden>
        <input type='text' name='jam_mulai' value='$dt[jam_mulai]' hidden>
        <input type='text' name='jam_akhir' value='$dt[jam_akhir]' hidden>
        <input type='text' name='jumlah' value='$dt[jumlah]' hidden>
        <input type='text' name='point' value='$dt[jumlah]' hidden>
        <a href='?module=kinerja&act=validasipj&id_kinerja=$dt[id_kinerja]'><input type=submit value='Validasi' name='validas'></s><a href='?module=kinerja&act=batalpj&id_kinerja=$dt[id_kinerja]'><input type=submit value='Batal Validasi' name='validas'></s></td>
        <td>$dt[point] </td>
        </tr>
        ";
                    $no++;
                }echo"
        </tr>
        <tr>
        <td colspan=10 > NILAI
        </td>
        <td>";
                $tgl = $_POST['tanggal'];
                $per = explode('-', $tgl);
                $bln = $per[1];
                $thn = $per[0];
                $waktu = date('H:i:s');

                $qry_jumlah_b = mysql_query("select SUM(point) from kinerja where 
        Month(kinerja.tanggal)='$bln' 
        and Year(kinerja.tanggal)='$thn' and nip='$_GET[nip]'
        order by id_kinerja ASC ");
                $data_b = mysql_fetch_array($qry_jumlah_b);
                $nilai = $data_b[0];
                echo $nilai;
                echo"</td>
        </tr>";
                echo "  
        </table>

        ";

                break;

            case "lihatm":
                $nip = $_SESSION['nip'];
                $tgl = date('Y-m-d');
                $per = explode('-', $tgl);
                $bln = $per[1];
                $thn = $per[0];
                $waktu = date('H:i:s');
                $tampil = mysql_query("select * from kinerja where 
        Month(kinerja.tanggal)='$bln' 
        and Year(kinerja.tanggal)='$thn' and nip='$_GET[nip]'
        order by id_kinerja ASC  ");
                echo "<h2 class='head'>DATA KINERJA UNIT USER</h2>
        <div>
        <input type=button value=Kembali onclick=self.history.go(-2)>
        </div>

        <table class='table table-bordered table-hover table-striped'>
        <thead>
        <tr>
        <td>No</td>
        <td>ID Kinerja</td>
        <td>Tanggal</td>
        <td>Nip</td>
        <td>Nama kp</td>
        <td>Uraian</td>
        <td>Jam Mulai</td>
        <td>Jam Selesai</td>
        <td>Durasi Pekerjaan</td>
        <td>Validasi</td>
        <td>Point</td>
        </tr>
        </thead>";
                $no = 1;
                while ($dt = mysql_fetch_array($tampil)) {
                    $nilai = $dt['jumlah'] * 1;
                    echo "<tr>
        <td>$no</td>
        <td>$dt[id_kinerja]</td>
        <td>$dt[tanggal]</td>
        <td>$dt[nip]</td>
        <td>$dt[kd_skp]</td>
        <td>$dt[uraian]</td>
        <td>$dt[jam_mulai]</td>
        <td>$dt[jam_akhir]</td>
        <td>$dt[jumlah] Menit </td>
        <td>

        <input type='text' name='id_kinerja' value='$dt[id_kinerja]' hidden>
        <input type='text' name='kd_skp' value='$dt[kd_skp]' hidden>
        <input type='text' name='tanggal' value='$dt[tanggal]' hidden>
        <input type='text' name='nip' value='$dt[nip]' hidden>
        <input type='text' name='uraian' value='$dt[uraian]' hidden>
        <input type='text' name='jam_mulai' value='$dt[jam_mulai]' hidden>
        <input type='text' name='jam_akhir' value='$dt[jam_akhir]' hidden>
        <input type='text' name='jumlah' value='$dt[jumlah]' hidden>
        <input type='text' name='point' value='$dt[jumlah]' hidden>
        <a href='?module=kinerja&act=validasim&id_kinerja=$dt[id_kinerja]'><input type=submit value='Validasi' name='validas'></s><a href='?module=kinerja&act=batalm&id_kinerja=$dt[id_kinerja]'><input type=submit value='Batal Validasi' name='validas'></s></td>
        <td>$dt[point] </td>
        </tr>
        ";
                    $no++;
                }echo"
        </tr>
        <tr>
        <td colspan=10 > NILAI
        </td>
        <td>";
                $tgl = $_POST['tanggal'];
                $per = explode('-', $tgl);
                $bln = $per[1];
                $thn = $per[0];
                $waktu = date('H:i:s');

                $qry_jumlah_b = mysql_query("select SUM(point) from kinerja where Month(kinerja.tanggal)='$bln' and Year(kinerja.tanggal)='$thn' and nip='$_GET[nip]'order by id_kinerja ASC ");
                $data_b = mysql_fetch_array($qry_jumlah_b);
                $nilai = $data_b[0];
                echo $nilai;
                echo"</td>
        </tr>";
                echo "  
        </table>

        ";

                break;

            case "validasi":
                $ambil = mysql_query("select * from kinerja where id_kinerja='$_GET[id_kinerja]'");
                $ed = mysql_fetch_array($ambil);
                echo "Yakin anda Ingin Menyetujui Validasi Ini  ??
        <form action='$aksi?module=kinerja&act=val' method='post' enctype='multipart/form-data' >
        <input  type='hidden' name='id_kinerja' readonly value='$ed[id_kinerja]' >
        <table class='tabelform tabpad'>
        <tr>
        <td class='form-group'><input class='form-control' name='id_kinerja' type='text' value='$ed[id_kinerja]' readonly ></td>
        </tr>
        <tr>
        <td class='form-group'> <input class='form-control' type='text' name='nip' readonly value='$ed[nip]' readonly>
        </td>
        </tr>	
        <tr>
        <td class='form-group'><input class='form-control' name='tanggal' type='date' value='$ed[tanggal]' readonly ></td>
        </tr>

        <tr>
        <td class='form-group'><input class='form-control' name='kd_skp' type='text' value='$ed[kd_skp]' readonly></td>
        </tr>

        <tr>
        <td class='form-group'><input class='form-control' name='uraian' value='$ed[uraian]' readonly></td>
        </tr>

        <tr>
        <td class='form-group'><input class='form-control' name='jam_mulai' type='time' value='$ed[jam_mulai]' readonly></td>
        </tr>

        <tr>
        <td class='form-group'><input class='form-control' name='jam_akhir' type='time' value='$ed[jam_akhir]' readonly></td>
        </tr>
        <tr>
        <td class='form-group'><input class='form-control' name='point' type='text' value='$ed[jumlah]' readonly></td>
        </tr>
        <tr>
        <td class='form-group'><input type=submit value=Iya>
        <input type=button value=Batal onclick=self.history.back()>
        </td>
        </tr>
        </table>
        </form>
        ";
                break;

            case "validasipj":
                $ambil = mysql_query("select * from kinerja where id_kinerja='$_GET[id_kinerja]'");
                $ed = mysql_fetch_array($ambil);
                echo "Yakin anda Ingin Menyetujui Validasi Ini  ??
        <form action='$aksi?module=kinerja&act=valpj' method='post' enctype='multipart/form-data' >
        <input  type='hidden' name='id_kinerja' readonly value='$ed[id_kinerja]' >
        <table class='tabelform tabpad'>
        <tr>
        <td class='form-group'><input class='form-control' name='id_kinerja' type='text' value='$ed[id_kinerja]' readonly ></td>
        </tr>
        <tr>
        <td class='form-group'> <input class='form-control' type='text' name='nip' readonly value='$ed[nip]' readonly>
        </td>
        </tr>	
        <tr>
        <td class='form-group'><input class='form-control' name='tanggal' type='date' value='$ed[tanggal]' readonly ></td>
        </tr>

        <tr>
        <td class='form-group'><input class='form-control' name='kd_skp' type='text' value='$ed[kd_skp]' readonly></td>
        </tr>

        <tr>
        <td class='form-group'><input class='form-control' name='uraian' value='$ed[uraian]' readonly></td>
        </tr>

        <tr>
        <td class='form-group'><input class='form-control' name='jam_mulai' type='time' value='$ed[jam_mulai]' readonly></td>
        </tr>

        <tr>
        <td class='form-group'><input class='form-control' name='jam_akhir' type='time' value='$ed[jam_akhir]' readonly></td>
        </tr>
        <tr>
        <td class='form-group'><input class='form-control' name='point' type='text' value='$ed[jumlah]' readonly></td>
        </tr>
        <tr>
        <td class='form-group'><input type=submit value=Iya>
        <input type=button value=Batal onclick=self.history.go(-2)>
        </td>
        </tr>
        </table>
        </form>
        ";
                break;

            case "batal":
                $ambil = mysql_query("select * from kinerja where id_kinerja='$_GET[id_kinerja]'");
                $ed = mysql_fetch_array($ambil);
                echo "Yakin anda Ingin Membatalkan Validasi Ini  ??
        <form action='$aksi?module=kinerja&act=val' method='post' enctype='multipart/form-data' >
        <input type='hidden' name='id_kinerja' readonly value='$ed[id_kinerja]' >
        <table class='tabelform tabpad'>
        <tr>
        <td class='form-group'><input class='form-control' name='id_kinerja' type='text' value='$ed[id_kinerja]' readonly ></td>
        </tr>
        <tr >
        <td class='form-group'> <input class='form-control' type='text' name='nip' readonly value='$ed[nip]' readonly>
        </td>
        </tr>	
        <tr>
        <td class='form-group'><input class='form-control' name='tanggal' type='date' value='$ed[tanggal]' readonly ></td>
        </tr>

        <tr>
        <td class='form-group'><input class='form-control' name='kd_skp' type='text' value='$ed[kd_skp]' readonly></td>
        </tr>

        <tr>
        <td class='form-group'><input class='form-control' name='uraian' value='$ed[uraian]' readonly></td>
        </tr>

        <tr>
        <td class='form-group'><input class='form-control' name='jam_mulai' type='time' value='$ed[jam_mulai]' readonly></td>
        </tr>

        <tr>
        <td class='form-group'><input class='form-control' name='jam_akhir' type='time' value='$ed[jam_akhir]' readonly></td>
        </tr>
        <tr>
        <td class='form-group'><input class='form-control' name='' type='text' value='$ed[jumlah]' readonly><input class='input' name='point' type='text' value='0' hidden></td>
        </tr>
        <tr>
        <td class='form-group'><input type=submit value=Iya>
        <input type=button value=Batal onclick=self.history.back()>
        </td>
        </tr>
        </table>
        </form>
        ";
                break;

            case "batalpj":
                $ambil = mysql_query("select * from kinerja where id_kinerja='$_GET[id_kinerja]'");
                $ed = mysql_fetch_array($ambil);
                echo "Yakin anda Ingin Membatalkan Validasi Ini  ??
        <form action='$aksi?module=kinerja&act=valpj' method='post' enctype='multipart/form-data' >
        <input type='hidden' name='id_kinerja' readonly value='$ed[id_kinerja]' >
        <table class='tabelform tabpad'>
        <tr>
        <td class='form-group'><input class='form-control' name='id_kinerja' type='text' value='$ed[id_kinerja]' readonly ></td>
        </tr>
        <tr >
        <td class='form-group'> <input class='form-control' type='text' name='nip' readonly value='$ed[nip]' readonly>
        </td>
        </tr>	
        <tr>
        <td class='form-group'><input class='form-control' name='tanggal' type='date' value='$ed[tanggal]' readonly ></td>
        </tr>

        <tr>
        <td class='form-group'><input class='form-control' name='kd_skp' type='text' value='$ed[kd_skp]' readonly></td>
        </tr>

        <tr>
        <td class='form-group'><input class='form-control' name='uraian' value='$ed[uraian]' readonly></td>
        </tr>

        <tr>
        <td class='form-group'><input class='form-control' name='jam_mulai' type='time' value='$ed[jam_mulai]' readonly></td>
        </tr>

        <tr>
        <td class='form-group'><input class='form-control' name='jam_akhir' type='time' value='$ed[jam_akhir]' readonly></td>
        </tr>
        <tr>
        <td class='form-group'><input class='form-control' name='' type='text' value='$ed[jumlah]' readonly><input class='input' name='point' type='text' value='0' hidden></td>
        </tr>
        <tr>
        <td class='form-group'><input type=submit value=Iya>
        <input type=button value=Batal onclick=self.history.go(-2)>
        </td>
        </tr>
        </table>
        </form>
        ";
                break;

            case "validasim":
                $ambil = mysql_query("select * from kinerja where id_kinerja='$_GET[id_kinerja]'");
                $ed = mysql_fetch_array($ambil);
                echo "Yakin anda Ingin Menyetujui Validasi Ini  ??
        <form action='$aksi?module=kinerja&act=val' method='post' enctype='multipart/form-data' >
        <input  type='hidden' name='id_kinerja' readonly value='$ed[id_kinerja]' >
        <table class='tabelform tabpad'>
        <tr>
        <td class='form-group'><input class='form-control' name='id_kinerja' type='text' value='$ed[id_kinerja]' readonly ></td>
        </tr>
        <tr>
        <td class='form-group'> <input class='form-control' type='text' name='nip' readonly value='$ed[nip]' readonly>
        </td>
        </tr>	
        <tr>
        <td class='form-group'><input class='form-control' name='tanggal' type='date' value='$ed[tanggal]' readonly ></td>
        </tr>

        <tr>
        <td class='form-group'><input class='form-control' name='kd_skp' type='text' value='$ed[kd_skp]' readonly></td>
        </tr>

        <tr>
        <td class='form-group'><input class='form-control' name='uraian' value='$ed[uraian]' readonly></td>
        </tr>

        <tr>
        <td class='form-group'><input class='form-control' name='jam_mulai' type='time' value='$ed[jam_mulai]' readonly></td>
        </tr>

        <tr>
        <td class='form-group'><input class='form-control' name='jam_akhir' type='time' value='$ed[jam_akhir]' readonly></td>
        </tr>
        <tr>
        <td class='form-group'><input class='form-control' name='point' type='text' value='$ed[jumlah]' readonly></td>
        </tr>
        <tr>
        <td class='form-group'><input type=submit value=Iya>
        <input type=button value=Batal onclick=self.history.back()>
        </td>
        </tr>
        </table>
        </form>
        ";
                break;

            case "batalm":
                $ambil = mysql_query("select * from kinerja where id_kinerja='$_GET[id_kinerja]'");
                $ed = mysql_fetch_array($ambil);
                echo "Yakin anda Ingin Membatalkan Validasi Ini  ??
        <form action='$aksi?module=kinerja&act=val' method='post' enctype='multipart/form-data' >
        <input type='hidden' name='id_kinerja' readonly value='$ed[id_kinerja]' >
        <table class='tabelform tabpad'>
        <tr>
        <td class='form-group'><input class='form-control' name='id_kinerja' type='text' value='$ed[id_kinerja]' readonly ></td>
        </tr>
        <tr >
        <td class='form-group'> <input class='form-control' type='text' name='nip' readonly value='$ed[nip]' readonly>
        </td>
        </tr>	
        <tr>
        <td class='form-group'><input class='form-control' name='tanggal' type='date' value='$ed[tanggal]' readonly ></td>
        </tr>

        <tr>
        <td class='form-group'><input class='form-control' name='kd_skp' type='text' value='$ed[kd_skp]' readonly></td>
        </tr>

        <tr>
        <td class='form-group'><input class='form-control' name='uraian' value='$ed[uraian]' readonly></td>
        </tr>

        <tr>
        <td class='form-group'><input class='form-control' name='jam_mulai' type='time' value='$ed[jam_mulai]' readonly></td>
        </tr>

        <tr>
        <td class='form-group'><input class='form-control' name='jam_akhir' type='time' value='$ed[jam_akhir]' readonly></td>
        </tr>
        <tr>
        <td class='form-group'><input class='form-control' name='' type='text' value='$ed[jumlah]' readonly><input class='input' name='point' type='text' value='0' hidden></td>
        </tr>
        <tr>
        <td class='form-group'><input type=submit value=Iya>
        <input type=button value=Batal onclick=self.history.back()>
        </td>
        </tr>
        </table>
        </form>
        ";
                break;

            case "edit":
                $nippeg = trim($_SESSION[nip]);
                $ambil = mysql_query("select * from kinerja where id_kinerja='$_GET[id_kinerja]'");
                $ed = mysql_fetch_array($ambil);
                $date = $ed['tanggal'];
                $tanggal = date("m/d/Y", strtotime($date));
                $keterangan = date("d/m/Y H:i:s");
                echo "<h2 class='head'>Edit Data Kinerja</h2>
        <form action='$aksi?module=kinerja&act=edit' onsubmit='return validasi_input(this)' method='post' enctype='multipart/form-data' >
        <input type='hidden' name='id_kinerja' readonly value='$ed[id_kinerja]' >
        <table class='tabelform tabpad'>
        <tr></td>
        </tr>
        <td class='form-group'>Id Kinerja</td><td>:</td><td><input class='form-control' name='id_kinerja' type='text' value='$ed[id_kinerja]' readonly >
        <tr>
        <td class='form-group'>Nip</td><td>:</td><td> <input class='form-control' type='text' name='nip' readonly value='$ed[nip]' >
        <input class='form-control' type='hidden' name='keterangan' value='$keterangan' >
        </td>
        </tr>	
        <tr>
        <td class='form-group'>Tanggal</td><td>:</td><td><input class='form-control' name='tanggal' type='text' id='calender' value='$tanggal' readonly ></td>
        </tr>

        <tr>
        <td class='form-group'>Kode Aktifitas</td><td>:</td><td>";
        $result = mysql_query("select * FROM skptahunan WHERE nip='$nippeg'");
        $jsArray = "var prdName = new Array();\n";
        echo '<select class="form-control" name="kd_skp" onchange="document.getElementById(\'prd_name\').value = prdName[this.value]">';
        echo '<option>--List Aktifitas--</option>';
        while ($row = mysql_fetch_array($result)) {
            echo '<option value="' . $row['kd_skp'] . '">' . $row['kd_skp'] . '</option>';
            $jsArray .= "prdName['" . $row['kd_skp'] . "'] = '" . addslashes($row['waktu_e']) . "';\n";
        }
        echo '</select></td></tr>';
        ?>
        <tr>
            <td >Efektif</td><td>:</td><td>
                <input class="form-control" type="text" width="30" name="waktu_e" value="<?php echo"$ed[waktu_e]"; ?>" id="prd_name" title="Menit" readonly/>
                <script type="text/javascript">
        <?php echo $jsArray; ?>
                </script>
                <?php
                echo"</td>
        </tr>

        <tr>
        <td class='form-group'>Uraian</td><td>:</td><td><textarea class='form-control' name='uraian'  cols='100' rows='10' tabindex='4'>$ed[uraian]</textarea></td>
        </tr>

        <tr>
        <td class='form-group'>Jam Mulai</td><td>:</td><td>
        <div class='input-group clockpicker pull-center' data-placement='right' data-align='top' data-autoclose='true'>
        <input class='form-control' name='jam_mulai' type='text' value='$ed[jam_mulai]'>
        <span class='input-group-addon'>
        <span class='glyphicon glyphicon-time'></span>
        </span>
        </div>
        </td>
        </tr>

        <tr>
        <td class='form-group'>Jam Akhir</td><td>:</td><td>
        <div class='input-group clockpicker pull-center' data-placement='right' data-align='top' data-autoclose='true'>
        <input class='form-control' name='jam_akhir' type='text' value='$ed[jam_akhir]'>
        <span class='input-group-addon'>
        <span class='glyphicon glyphicon-time'></span>
        </span>
        </div>
        </td>
        </tr>

        <tr>
        <td class='form-group'></td><td></td><td><input type=submit value=Simpan>
        <input type=button value=Batal onclick=self.history.back()>
        </td>
        </tr>
        </table>
        </form>
        ";
                break;




            case "cari":
                $t1 = $_POST['t1'];
                $t2 = $_POST['t2'];
                echo"yang di cari tanggal $t1 sampai $t2";
                $tampil = mysql_query("select * from kinerja where tanggal between '$t1' and '$t2' and nip='$_GET[nip]  ");

                echo "<div>
        <input type=button value=Kembali onclick=self.history.back()>
        </div>
        <h2 class='head'>DATA KINERJA PEGAWAI</h2>
        <table class='table table-bordered table-hover table-striped'>
        <thead>
        <tr>
        <td>No</td>
        <td>ID Kinerja</td>
        <td>Tanggal</td>
        <td>Nip</td>
        <td>kd_skp</td>
        <td>Uraian</td>
        <td>Jam Mulai</td>
        <td>Jam Selesai</td>
        <td>Durasi Pekerjaan</td>
        <td>Control</td>
        <td>Point</td>
        </tr>
        </thead>";
                $no = 1;
                while ($dt = mysql_fetch_array($tampil)) {
                    echo "<tr>
        <td>$no</td>
        <td>$dt[id_kinerja]</td>
        <td>$dt[tanggal]</td>
        <td>$dt[nip]</td>
        <td>$dt[kd_skp]</td>
        <td>$dt[uraian]</td>
        <td>$dt[jam_mulai]</td>
        <td>$dt[jam_akhir]</td>
        <td>$dt[jumlah] Menit</td>
        <td><span><a href='?module=kinerja&act=validasi&id_kinerja=$dt[id_kinerja]'><input type=submit value='Validasi' name='validas'></s><a href='?module=kinerja&act=batal&id_kinerja=$dt[id_kinerja]'><input type=submit value='Batal Validasi' name='validas'></s></span><span>
        </span>
        <td>$dt[point] </td>
        </td>
        </tr>";
                    $no++;
                }
                echo " 
        <tr>
        <td colspan=10 > NILAI
        </td>
        <td>";
                $tgl = date('Y-m-d');
                $per = explode('-', $tgl);
                $bln = $per[1];
                $thn = $per[0];
                $waktu = date('H:i:s');

                $qry_jumlah_b = mysql_query("select SUM(point) from kinerja where tanggal between '$t1' and '$t2' ");
                $data_b = mysql_fetch_array($qry_jumlah_b);
                $nilai = $data_b[0];
                echo $nilai;
                echo"</td>
        </tr> 
        </table>
        ";
        }
        ?>