<?php 
error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
include "../../config/koneksi.php";
include "../../config/fungsi_indotgl.php";
include "../../config/class_paging.php";
include "../../config/kode_auto.php";
include "../../config/fungsi_thumb.php";

$module=$_GET['module'];
$act=$_GET['act'];

if($module=='pegawai' AND $act=='hapus' ){ 
	mysql_query("delete from pegawai where nip='$_GET[id]'");
	mysql_query("delete from user_id where userid='$_GET[id]'");
	mysql_query("delete from kinerja where nip='$_GET[id]'");
	mysql_query("delete from pengalaman_kerja where nip='$_GET[id]'");
	mysql_query("delete from kinerja_t where nip='$_GET[id]'");
	mysql_query("delete from kreatifitas where nip='$_GET[id]'");
	mysql_query("delete from pendidikan where nip='$_GET[id]'");
	mysql_query("delete from skptahunan where nip='$_GET[id]'");
	mysql_query("delete from waktu_k where nip='$_GET[id]'");
	mysql_query("delete from waktu_t where nip='$_GET[id]'");
	mysql_query("delete from k_jabatan where nip='$_GET[id]'");
	mysql_query("delete from kompetensi where nip='$_GET[id]'");
	mysql_query("delete from h_jabatan where nip='$_GET[id]'");
	mysql_query("delete from disiplin where nip='$_GET[id]'");
	header('location:../../media.php?module='.$module);
}

if($module=='pegawai' AND $act=='input' ){
  $lokasi_file    = $_FILES['fupload']['tmp_name'];
  $tipe_file      = $_FILES['fupload']['type'];
  $nama_file      = $_FILES['fupload']['name'];
  $acak           = rand(000000,999999);
  $nama_file_unik = $acak.$nama_file;
	if (!empty($lokasi_file)){  
	$tll="$_POST[tahun]-$_POST[bulan]-$_POST[hari]";
	$tm="$_POST[tm]-$_POST[bm]-$_POST[hm]";
	Uploadfoto($nama_file_unik);
	mysql_query("insert into pegawai set nip='$_POST[nip]',
										 nama='$_POST[nama]',
										 tmpt_lahir='$_POST[tls]',
										 tgl_lahir='$tll',
										 jenis_kelamin='$_POST[jk]',
										 alamat='$_POST[almt]',
										 tgl_masuk='$tm',
										 id_bag='$_POST[bagian]',
										 bpjsks='$_POST[bpjsks]',
										 bpjsjkk='$_POST[bpjsjkk]',
										 npwp='$_POST[npwp]',
										 norek='$_POST[norek]',
										 status='$_POST[status]',
										 kasatpel='$_POST[kasatpel]',
										 bpjsijht='$_POST[bpjsijht]',
										 bpjsjp='$_POST[bpjsjp]',
										 id_skpd='$_POST[id_skpd]',id_ukpd='$_POST[id_ukpd]',
										 id_status='$_POST[id_status]',
										 id_pendidikan='$_POST[id_pendidikan]',
										 id_rumpun='$_POST[id_rumpun]',
										 kasie='$_POST[kasie]',
										 id_jab='$_POST[jabatan]',
										 foto='$nama_file_unik'
										 ");
	mysql_query("insert into user_id set userid='$_POST[nip]', passid='$_POST[psl]',id_skpd='$_POST[id_skpd]',id_ukpd='$_POST[id_ukpd]',  level_user='$_POST[level_user]', id_bag='$_POST[bagian]', nama='$_POST[nama]'");
	
	header('location:../../media.php?module='.$module);
	} else {
	$tll="$_POST[tahun]-$_POST[bulan]-$_POST[hari]";
	$tm="$_POST[tm]-$_POST[bm]-$_POST[hm]";
	mysql_query("insert into pegawai set nip='$_POST[nip]',
										 nama='$_POST[nama]',
										 tmpt_lahir='$_POST[tls]',
										 tgl_lahir='$tll',
										 jenis_kelamin='$_POST[jk]',
										 alamat='$_POST[almt]',
										 kasie='$_POST[kasie]',
										 bpjsks='$_POST[bpjsks]',
										 bpjsjkk='$_POST[bpjsjkk]',
										 npwp='$_POST[npwp]',
										 norek='$_POST[norek]',
										 bpjsijht='$_POST[bpjsijht]',
										 bpjsjp='$_POST[bpjsjp]',
										 status='$_POST[status]',
										 kasatpel='$_POST[kasatpel]',
										 id_skpd='$_POST[id_skpd]',id_ukpd='$_POST[id_ukpd]',
										 id_pendidikan='$_POST[id_pendidikan]',
										 id_status='$_POST[id_status]',
										 id_rumpun='$_POST[id_rumpun]',
										 tgl_masuk='$tm',
										 id_bag='$_POST[bagian]',
										 id_jab='$_POST[jabatan]'
										 ");
	mysql_query("insert into user_id set userid='$_POST[nip]', passid='$_POST[psl]',id_skpd='$_POST[id_skpd]',id_ukpd='$_POST[id_ukpd]',  level_user='$_POST[level_user]', id_bag='$_POST[bagian]', nama='$_POST[nama]'");
	header('location:../../media.php?module='.$module);
	}
}

elseif($module=='pegawai' AND $act=='edit' ){
  $lokasi_file    = $_FILES['fupload']['tmp_name'];
  $tipe_file      = $_FILES['fupload']['type'];
  $nama_file      = $_FILES['fupload']['name'];
  $acak           = rand(000000,999999);
  $nama_file_unik = $acak.$nama_file;
	if (!empty($lokasi_file)){  
	$tll="$_POST[tl]-$_POST[btl]-$_POST[ttl]";
	$tm="$_POST[tt]-$_POST[bt]-$_POST[ht]";
	Uploadfoto($nama_file_unik);
	mysql_query("update pegawai set 	 nama='$_POST[nama]',
										 tmpt_lahir='$_POST[tls]',
										 tgl_lahir='$tll',
										 jenis_kelamin='$_POST[jk]',
										 alamat='$_POST[almt]',
										 tgl_masuk='$tm',
										 npwp='$_POST[npwp]',
										 norek='$_POST[norek]',
										 id_bag='$_POST[bagian]',
										 bpjsks='$_POST[bpjsks]',
										 bpjsjkk='$_POST[bpjsjkk]',
										 bpjsijht='$_POST[bpjsijht]',
										 bpjsjp='$_POST[bpjsjp]',
										 status='$_POST[status]',
										 kasatpel='$_POST[kasatpel]',
										 id_status='$_POST[id_status]',
										 id_skpd='$_POST[id_skpd]',id_ukpd='$_POST[id_ukpd]',
										 id_pendidikan='$_POST[id_pendidikan]',
										 id_rumpun='$_POST[id_rumpun]',
										 id_jab='$_POST[jabatan]',
										 kasie='$_POST[kasie]',
										 foto='$nama_file_unik'
										 where nip='$_POST[nip]'");
    mysql_query("update user_id set id_bag='$_POST[bagian]', nama='$_POST[nama]',id_skpd='$_POST[id_skpd]',id_ukpd='$_POST[id_ukpd]', level_user='$_POST[level_user]'  where userid='$_POST[nip]'");
	echo "<script>alert('Data Sudah Di Update'); window.location = 'javascript:history.go(-3)'</script>";
	} else {
	$tll="$_POST[tl]-$_POST[btl]-$_POST[ttl]";
	$tm="$_POST[tt]-$_POST[bt]-$_POST[ht]";
	mysql_query("update pegawai set 	 nama='$_POST[nama]',
										 tmpt_lahir='$_POST[tls]',
										 tgl_lahir='$tll',
										 jenis_kelamin='$_POST[jk]',
										 alamat='$_POST[almt]',
										 tgl_masuk='$tm',
										 npwp='$_POST[npwp]',
										 norek='$_POST[norek]',
										 bpjsks='$_POST[bpjsks]',
										 bpjsjkk='$_POST[bpjsjkk]',
										 bpjsijht='$_POST[bpjsijht]',
										 bpjsjp='$_POST[bpjsjp]',
										 status='$_POST[status]',
										 kasatpel='$_POST[kasatpel]',
										 id_rumpun='$_POST[id_rumpun]',
										 id_pendidikan='$_POST[id_pendidikan]',
										 id_skpd='$_POST[id_skpd]',id_ukpd='$_POST[id_ukpd]',
										 id_status='$_POST[id_status]',
										 id_bag='$_POST[bagian]',
										 kasie='$_POST[kasie]',
										 id_jab='$_POST[jabatan]'
										 where nip='$_POST[nip]'");
	mysql_query("update user_id set id_bag='$_POST[bagian]', nama='$_POST[nama]',id_skpd='$_POST[id_skpd]',id_ukpd='$_POST[id_ukpd]', level_user='$_POST[level_user]'  where userid='$_POST[nip]'");
		echo "<script>alert('Data Sudah Di Update'); window.location = 'javascript:history.go(-3)'</script>";
	}
}

elseif($module=='pegawai' AND $act=='edit1' ){
  $lokasi_file    = $_FILES['fupload']['tmp_name'];
  $tipe_file      = $_FILES['fupload']['type'];
  $nama_file      = $_FILES['fupload']['name'];
  $acak           = rand(000000,999999);
  $nama_file_unik = $acak.$nama_file;
	if (!empty($lokasi_file)){  
	$tll="$_POST[tl]-$_POST[btl]-$_POST[ttl]";
	$tm="$_POST[tt]-$_POST[bt]-$_POST[ht]";
	Uploadfoto($nama_file_unik);
	mysql_query("update pegawai set 	 nama='$_POST[nama]',
										 tmpt_lahir='$_POST[tls]',
										 tgl_lahir='$tll',
										 jenis_kelamin='$_POST[jk]',
										 alamat='$_POST[almt]',
										 tgl_masuk='$tm',
										 npwp='$_POST[npwp]',
										 norek='$_POST[norek]',
										 id_bag='$_POST[bagian]',
										 id_status='$_POST[id_status]',
										 bpjsks='$_POST[bpjsks]',
										 bpjsjkk='$_POST[bpjsjkk]',
										 bpjsijht='$_POST[bpjsijht]',
										 bpjsjp='$_POST[bpjsjp]',
										 status='$_POST[status]',
										 kasatpel='$_POST[kasatpel]',
										 id_pendidikan='$_POST[id_pendidikan]',
										 id_skpd='$_POST[id_skpd]',id_ukpd='$_POST[id_ukpd]',
										 id_rumpun='$_POST[id_rumpun]',
										 id_jab='$_POST[jabatan]',
										 kasie='$_POST[kasie]',
										 foto='$nama_file_unik'
										 where nip='$_POST[nip]'");
    mysql_query("update user_id set id_bag='$_POST[bagian]', nama='$_POST[nama]',id_skpd='$_POST[id_skpd]',id_ukpd='$_POST[id_ukpd]', level_user='$_POST[level_user]'  where userid='$_POST[nip]'");
	echo "<script>alert('Data Sudah Di Update'); window.location = 'javascript:history.go(-3)'</script>";
	} else {
	$tll="$_POST[tl]-$_POST[btl]-$_POST[ttl]";
	$tm="$_POST[tt]-$_POST[bt]-$_POST[ht]";
	mysql_query("update pegawai set 	 nama='$_POST[nama]',
										 tmpt_lahir='$_POST[tls]',
										 tgl_lahir='$tll',
										 jenis_kelamin='$_POST[jk]',
										 alamat='$_POST[almt]',
										 tgl_masuk='$tm',
										 npwp='$_POST[npwp]',
										 norek='$_POST[norek]',
										 id_rumpun='$_POST[id_rumpun]',
										 bpjsks='$_POST[bpjsks]',
										 bpjsjkk='$_POST[bpjsjkk]',
										 bpjsijht='$_POST[bpjsijht]',
										 bpjsjp='$_POST[bpjsjp]',
										 status='$_POST[status]',
										 kasatpel='$_POST[kasatpel]',
										 id_skpd='$_POST[id_skpd]',id_ukpd='$_POST[id_ukpd]',
										 id_pendidikan='$_POST[id_pendidikan]',
										 id_status='$_POST[id_status]',
										 id_bag='$_POST[bagian]',
										 kasie='$_POST[kasie]',
										 id_jab='$_POST[jabatan]'
										 where nip='$_POST[nip]'");
	mysql_query("update user_id set id_bag='$_POST[bagian]', nama='$_POST[nama]',id_skpd='$_POST[id_skpd]',id_ukpd='$_POST[id_ukpd]', level_user='$_POST[level_user]'  where userid='$_POST[nip]'");
		echo "<script>alert('Data Sudah Di Update'); window.location = 'javascript:history.go(-3)'</script>";
	}
}


elseif($module=='pegawai' AND $act=='ubah' ){
  $lokasi_file    = $_FILES['fupload']['tmp_name'];
  $tipe_file      = $_FILES['fupload']['type'];
  $nama_file      = $_FILES['fupload']['name'];
  $acak           = rand(000000,999999);
  $nama_file_unik = $acak.$nama_file;
	if (!empty($lokasi_file)){  
	$tll="$_POST[tl]-$_POST[btl]-$_POST[ttl]";
	$tm="$_POST[tt]-$_POST[bt]-$_POST[ht]";
	Uploadfoto($nama_file_unik);
	mysql_query("update pegawai set 	 nama='$_POST[nama]',
										 tmpt_lahir='$_POST[tls]',
										 tgl_lahir='$tll',
										 npwp='$_POST[npwp]',
										 norek='$_POST[norek]',
										 jenis_kelamin='$_POST[jk]',
										 alamat='$_POST[almt]',
										 foto='$nama_file_unik'
										 where nip='$_POST[nip]'");
    mysql_query("update user_id set nama='$_POST[nama]' where userid='$_POST[nip]'");
	echo "<script>alert('Data Sudah Di Update'); window.location = 'javascript:history.go(-2)'</script>";
	} else {
	$tll="$_POST[tl]-$_POST[btl]-$_POST[ttl]";
	$tm="$_POST[tt]-$_POST[bt]-$_POST[ht]";
	mysql_query("update pegawai set 	  nama='$_POST[nama]',
										 tmpt_lahir='$_POST[tls]',
										 tgl_lahir='$tll',
										 npwp='$_POST[npwp]',
										 norek='$_POST[norek]',
										 jenis_kelamin='$_POST[jk]',
										 alamat='$_POST[almt]'
										 where nip='$_POST[nip]'");
	mysql_query("update user_id set nama='$_POST[nama]'  where userid='$_POST[nip]'");
		echo "<script>alert('Data Sudah Di Update'); window.location = 'javascript:history.go(-2)'</script>";
	}
}



elseif($module=='pegawai' AND $act=='rp' ){
	mysql_query("insert into pendidikan set nip='$_POST[nip]', t_pdk='$_POST[tahun]', d_pdk='$_POST[dp]'");
	header('location:../../media.php?module=pegawai&act=detail&id='.$_POST['nip']);
}

elseif($module=='pegawai' AND $act=='rpedit' ){
	mysql_query("update pendidikan set t_pdk='$_POST[tahun]', d_pdk='$_POST[dp]' where idp='$_POST[idp]'");
	header('location:../../media.php?module=pegawai&act=detail&id='.$_POST['nip']);
}

elseif($module=='pegawai' AND $act=='rpdel' ){
	mysql_query("delete from pendidikan where idp = '$_GET[id]'");
	header('location:../../media.php?module=pegawai&act=detail&id='.$_GET['nip']);
}


elseif($module=='pegawai' AND $act=='pk' ){
	mysql_query("insert into pengalaman_kerja set nip='$_POST[nip]', nm_pekerjaan='$_POST[np]', d_pekerjaan='$_POST[dp]'");
	header('location:../../media.php?module=pegawai&act=detail&id='.$_POST['nip']);
}

elseif($module=='pegawai' AND $act=='pkedit' ){
	mysql_query("update pengalaman_kerja set nm_pekerjaan='$_POST[np]', d_pekerjaan='$_POST[dp]'
	where id_peker='$_POST[idp]'");
	header('location:../../media.php?module=pegawai&act=detail&id='.$_POST['nip']);
}

elseif($module=='pegawai' AND $act=='pkdel' ){
	mysql_query("delete from pengalaman_kerja where id_peker='$_GET[id]'");
	header('location:../../media.php?module=pegawai&act=detail&id='.$_GET['nip']);
}

elseif($module=='pegawai' AND $act=='pwd' ){
	$cek=mysql_query("select * from user_id where userid='$_POST[nip]' and passid='$_POST[pl]' ");
	if(mysql_num_rows($cek)==0){
	echo "<script>alert('Gagal ganti password !! pasword lama salah ! ');window.location.href='../../media.php?module=pegawai&act=detail&id=$_POST[nip]';</script>";
	} else {
		mysql_query("update user_id set passid='$_POST[pb]' where userid='$_POST[nip]'");
		echo "<script>alert('Password sukses diubah !!');window.location.href='../../media.php?module=pegawai&act=detail&id=$_POST[nip]';</script>";
	}
	
}




?>