<?php
error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
$aksi="modul/pegawai/aksi_pegawai.php";
$skpd=$_SESSION['id_skpd'];
$ukpd=$_SESSION['id_ukpd'];
switch($_GET[act]){
	default:
	$tampil=mysql_query("select * from pegawai where id_ukpd LIKE '%$_SESSION[id_ukpd]%' ");
	echo "<h2 class='head'>DATA PEGAWAI</h2>
	<form action='?module=pegawai&act=cariunit' method='POST' ><table border='0' align='right'>
	<tr>
	<td>
	 </td>
	</tr>
	</table>
	</form>
	<form action='?module=pegawai&act=cari' method='POST' ><table border='0' align='left'>
	<tr>
	<td><input class='input'  width='60' name='cek' type='' placeholder='Cari Nama Pegawai'><input type=submit value='Search' > </td>
	</tr>
	</table>
	</form>
	<div>
	<!--<input type=button value='Tambah Data' onclick=\"window.location.href='?module=pegawai&act=registrasi';\">
	</div-->
	<table class='table table-bordered table-hover table-striped'>
	<thead>
  <tr>
    <td>No</td>
    <td>Nip</td>
    <td>Nama </td>
	<td>Tgl Masuk</td>
	<td>Bagian</td>
	<td>Pendidikan Terakhir</td>
	<td>Status</td>
	<td>Rumpun</td>
	<td>Kasie</td>
	<td>Level User</td>
	<td>Control</td>
  </tr>
  </thead>";
  $no=1;
  while($dt=mysql_fetch_array($tampil)){
  	$pimpinan=mysql_query("select * from user_id where userid='$dt[kasie]'");
	$b=mysql_fetch_array($pimpinan);
	$pp=$b['nama'];
	$st=mysql_query("select * from status where id_status='$dt[id_status]'");
	$s=mysql_fetch_array($st);
	$sts=$s['n_status'];
	$pndd=mysql_query("select * from pendidikan_t where id_pendidikan='$dt[id_pendidikan]'");
	$pndk=mysql_fetch_array($pndd);
	$pndkn=$pndk['n_pendidikan'];
	$rmp=mysql_query("select * from rumpun where id_rumpun='$dt[id_rumpun]'");
	$rmpn=mysql_fetch_array($rmp);
	$rmpnn=$rmpn['n_rumpun'];
  echo "<tr>
    <td>$no</td>
    <td>$dt[nip]</td>
    <td>$dt[nama]</td>
	<td>".tgl_indo($dt['tgl_masuk'])."</td>
    <td>";
	$bag=mysql_query("select * from bagian where id_bag='$dt[id_bag]'");
	$b=mysql_fetch_array($bag);
	echo "$b[n_bag]";	
	echo "</td>
	<td>";
	$pend=mysql_query("select * from pendidikan_t where id_pendidikan='$dt[id_pendidikan]'");
	$b=mysql_fetch_array($pend);
	echo "$b[n_pendidikan]";	
	echo "</td>
	<td>";
	$st=mysql_query("select * from status where id_status='$dt[id_status]'");
	$b=mysql_fetch_array($st);
	echo "$b[n_status]";	
	echo "</td>
	<td>";
	$rm=mysql_query("select * from rumpun where id_rumpun='$dt[id_rumpun]'");
	$b=mysql_fetch_array($rm);
	echo "$b[n_rumpun]";	
	echo "</td>
	<td>$pp</td>
	<td>";
	$lv=mysql_query("select * from user_id where userid='$dt[nip]'");
	$b=mysql_fetch_array($lv);
	echo "$b[level_user]";	
	echo "</td>
	<td><span><a href='?module=pegawai&act=edit&id=$dt[nip]'>Edit</a></span><span>
	<a href=\"$aksi?module=pegawai&act=hapus&id=$dt[nip]\" onClick=\"return confirm('Apakah Anda benar-benar mau menghapusnya?')\">Hapus</a></span>
	<span><a href='?module=pegawai&act=detail&id=$dt[nip]'>Detail</a></span></td>
  </tr>";
  $no++;
  }
echo "  
</table>
	";
	
	break;
	
	case "registrasi":
	echo "<h2 class='hd-r'>REGISTRASI PEGAWAI</h2>
	<form action='$aksi?module=pegawai&act=input' method='post' enctype='multipart/form-data' class='f-r' >
	<table >
	<tr>
	<td>Nama SKPD</td><td>:</td><td><input class='form-control' type='text' name='id_skpd' value='$_SESSION[id_skpd]' readonly></td>
	</tr>
	<tr>
	<td>Nama UKPD</td><td>:</td><td><input class='form-control' type='text' name='id_ukpd' value='$_SESSION[id_ukpd]' readonly>
	</td>
	</tr>
	<tr>
	<td >Nip</td><td>:</td><td><input class='form-control' name='nip' type='text'></td>
	</tr>
	<tr>
	<td>Password Login</td><td>:</td><td><input class='form-control' name='psl' type='password'></td>
	</tr>
	<tr>
	<td>Nama Pegawai</td><td>:</td><td><input class='form-control' name='nama' type='text'></td>
	</tr>
	<tr>
	<td>Tempat Lahir</td><td>:</td><td><input class='form-control' name='tls' type='text'></td>
	</tr>
	<tr>
	<td>Tanggal Lahir</td><td>:</td><td>
	<select name='hari'>
                <option value='none' selected='selected'>Tgl*</option>";
			for($h=1; $h<=31; $h++) 
			{ 
				echo"<option value=",$h,">",$h,"</option>";
			} 
	echo"</select>
	<select  name='bulan'>
            	<option value='none' selected='selected'>Bulan*</option>
				<option value='1'>Januari</option>
				<option value='2'>Februari</option>
				<option value='3'>Maret</option>
				<option value='4'>April</option>
				<option value='5'>Mei</option>
				<option value='6'>Juni</option>
				<option value='7'>Juli</option>
				<option value='8'>Agustus</option>
				<option value='9'>September</option>
				<option value='10'>Oktober</option>
				<option value='11'>November</option>
				<option value='12'>Desember</option>
			</select>
	<select name='tahun'>
            <option value='none' class='form-control' selected='selected'>Tahun*</option>";
			$now =  date("Y");
			$saiki = 1965;
			for($l=$saiki; $l<=$now; $l++)
			{
				echo"<option value=",$l,">",$l,"</option>";
			}	
	echo "</select>
	</td>
	</tr>
	
	<tr>
	<td>Jenis Kelamin</td><td>:</td><td><input  name='jk' type='radio' value='L' />Pria <input name='jk'  type='radio' value='P' />Wanita</td>
	</tr>
	
	<tr>
	<td>Alamat</td><td>:</td><td><textarea  class='form-control' name='almt' ></textarea></td>
	</tr>
	
	<tr>
	<td>NPWP</td><td>:</td><td><input class='form-control' name='npwp' type='text'></td>
	</tr>
	
	<tr>
	<td>No Rek DKI</td><td>:</td><td><input class='form-control' name='norek' type='text'></td>
	</tr>
	
	<tr>
	<td>Tanggal Masuk</td><td>:</td><td>
	<select  name='hm'>
                <option value='none' selected='selected'>Tgl*</option>";
			for($h=1; $h<=31; $h++) 
			{ 
				echo"<option value=",$h,">",$h,"</option>";
			} 
	echo"</select>
	<select  name='bm'>
            	<option value='none' selected='selected'>Bulan*</option>
				<option value='1'>Januari</option>
				<option value='2'>Februari</option>
				<option value='3'>Maret</option>
				<option value='4'>April</option>
				<option value='5'>Mei</option>
				<option value='6'>Juni</option>
				<option value='7'>Juli</option>
				<option value='8'>Agustus</option>
				<option value='9'>September</option>
				<option value='10'>Oktober</option>
				<option value='11'>November</option>
				<option value='12'>Desember</option>
			</select>
	<select  name='tm'>
            <option value='none' selected='selected'>Tahun*</option>";
			$now =  date("Y");
			$saiki = 2000;
			for($l=$saiki; $l<=$now; $l++)
			{
				echo"<option value=",$l,">",$l,"</option>";
			}	
	echo "</select>
	</td>
	</tr>
	<tr>
	<td>Status Pernikahan</td><td>:</td><td><select class='form-control' name='id_status'>
	<option value='' selected >--Pilih Status--</option>";
	$st=mysql_query("select * from status where id_ukpd LIKE '%$_SESSION[id_ukpd]%'");
	while($j=mysql_fetch_array($st)){
	echo "<option value='$j[id_status]'>$j[n_status]</option>";
	}
	echo "</select></td>
	</tr>
	<tr>
	<td>Status Pegawai</td><td>:</td><td><input  name='status' type='radio' value='PNS' />PNS <input name='status'  type='radio' value='NON PNS' />NON PNS</td>
	</tr>
	<tr>
	<td>Pendidikan Terakhir</td><td>:</td><td><select class='form-control' name='id_pendidikan'>
	<option value='' selected >--Pilih Pendidkan Terkahir--</option>";
	$pnd=mysql_query("select * from pendidikan_t where id_ukpd LIKE '%$_SESSION[id_ukpd]%'");
	while($j=mysql_fetch_array($pnd)){
	echo "<option value='$j[id_pendidikan]'>$j[n_pendidikan]</option>";
	}
	echo "</select></td>
	</tr>
	<tr>
	<td>Rumpun Jabatan</td><td>:</td><td><select class='form-control' name='id_rumpun'>
	<option value='' selected >--Pilih Rumpun Jabatan--</option>";
	$jab=mysql_query("select * from rumpun where id_ukpd LIKE '%$_SESSION[id_ukpd]%'");
	while($j=mysql_fetch_array($jab)){
	echo "<option value='$j[id_rumpun]'>$j[n_rumpun]</option>";
	}
	echo "</select></td>
	</tr>
	<tr>
	<td>Bagian</td><td>:</td><td><select class='form-control' name='bagian'>
	<option value='' selected >Pilih Bagian</option>";
	$jab=mysql_query("select * from bagian where id_ukpd LIKE '%$_SESSION[id_ukpd]%'");
	while($j=mysql_fetch_array($jab)){
	echo "<option value='$j[id_bag]'>$j[n_bag]</option>";
	}
	echo "</select></td>
	</tr>
	
	<tr>
	<td>Jabatan</td><td>:</td><td><select class='form-control' name='jabatan'>	
	<option value='' selected >Pilih Jabatan</option>";
	$jab=mysql_query("select * from jabatan where id_ukpd LIKE '%$_SESSION[id_ukpd]%'");
	while($j=mysql_fetch_array($jab)){
	echo "<option value='$j[id_jab]'  >$j[n_jab]</option>";
	}
	echo "</select></td>
	</tr>
	<tr>
	<td>BPJS Kesehatan</td><td>:</td><td><input type='checkbox'  name='bpjsks' value='0.02'> BPJS Kesehatan </td>
	</tr>
	<tr>
	<td>BPJS Ketenegakerjaan</td><td>:</td><td><input type='checkbox' name='bpjsjkk' value='0.0054'> JKK & JKM   
	    <input type='checkbox' name='bpjsijht' value='0.057'> IJHT   
	<input type='checkbox' name='bpjsjp' value='0.03'> JP</td>
	</tr>
	<tr>
	<td>Level User</td><td>:</td><td><select class='form-control' name='level_user'>	
	<option value='' selected >Pilih Level User</option>";
	$set=mysql_query("select * from set_user ");
	while($ls=mysql_fetch_array($set)){
	echo "<option value='$ls[id]'  >$ls[ket]</option>";
	}
	echo "</select></td>
	</tr>
	<tr>
	<td>Kasatpel</td><td>:</td><td><select class='form-control' name='kasatpel'>
	<option value='' selected >--Pilih Kasatpel--</option>";
	$ks=mysql_query("select * from user_id where id_ukpd LIKE '%$_SESSION[id_ukpd]%' and level_user LIKE '%3%'");
	while($j=mysql_fetch_array($ks)){
	echo "<option value='$j[userid]'>$j[nama]</option>";
	}
	echo "</select></td>
	</tr>
	<tr>
	<td>Kasie</td><td>:</td><td><select class='form-control' name='kasie'>
	<option value='' selected >--Pilih Kasie--</option>";
	$ks=mysql_query("select * from user_id where id_ukpd LIKE '%$_SESSION[id_ukpd]%' and level_user LIKE '%9%'");
	while($j=mysql_fetch_array($ks)){
	echo "<option value='$j[userid]'>$j[id_bag]</option>";
	}
	echo "</select></td>
	</tr>
	<tr>
	<td>Foto</td><td>:</td><td><input class='form-control' name='fupload' type='file' /></td>
	</tr>
	
	
	
	<tr>
	<td></td><td></td><td><input type=submit value=Simpan>
	<input type=button value=Batal onclick=self.history.back()>
	</td>
	</tr>
	</table>
	</form>
	"; 
	
	break;
	
	
	
	case "input":
	echo "<h2 class='head'>Entry Data Pegawai</h2>
	<form action='$aksi?module=pegawai&act=input' method='post' enctype='multipart/form-data' >
	<table class='tabelform tabpad'>
	<tr>
	<td>Nip</td><td>:</td><td><input name='nip' type='text'></td>
	</tr>
	<tr>
	<td>Nama Pegawai</td><td>:</td><td><input class='form-control' name='nama' type='text'></td>
	</tr>
	<tr>
	<td>Tempat Lahir</td><td>:</td><td><input class='form-control' name='tls' type='text'></td>
	</tr>
	<tr>
	<td>Tanggal Lahir</td><td>:</td><td>
	<select name='hari'>
                <option value='none' selected='selected'>Tgl*</option>";
			for($h=1; $h<=31; $h++) 
			{ 
				echo"<option value=",$h,">",$h,"</option>";
			} 
	echo"</select>
	<select name='bulan'>
            	<option value='none' selected='selected'>Bulan*</option>
				<option value='1'>Januari</option>
				<option value='2'>Februari</option>
				<option value='3'>Maret</option>
				<option value='4'>April</option>
				<option value='5'>Mei</option>
				<option value='6'>Juni</option>
				<option value='7'>Juli</option>
				<option value='8'>Agustus</option>
				<option value='9'>September</option>
				<option value='10'>Oktober</option>
				<option value='11'>November</option>
				<option value='12'>Desember</option>
			</select>
	<select name='tahun'>
            <option value='none' selected='selected'>Tahun*</option>";
			$now =  date("Y");
			$saiki = 1965;
			for($l=$saiki; $l<=$now; $l++)
			{
				echo"<option value=",$l,">",$l,"</option>";
			}	
	echo "</select>
	</td>
	</tr>
	
	<tr>
	<td>Jenis Kelamin</td><td>:</td><td><input name='jk' type='radio' value='L' />Pria <input name='jk' type='radio' value='P' />Wanita</td>
	</tr>
	
	<tr>
	<td>Alamat</td><td>:</td><td><textarea name='almt' ></textarea></td>
	</tr>
	
	<tr>
	<td>Tanggal Masuk</td><td>:</td><td>
	<select name='hm'>
                <option value='none' selected='selected'>Tgl*</option>";
			for($h=1; $h<=31; $h++) 
			{ 
				echo"<option value=",$h,">",$h,"</option>";
			} 
	echo"</select>
	<select name='bm'>
            	<option value='none' selected='selected'>Bulan*</option>
				<option value='1'>Januari</option>
				<option value='2'>Februari</option>
				<option value='3'>Maret</option>
				<option value='4'>April</option>
				<option value='5'>Mei</option>
				<option value='6'>Juni</option>
				<option value='7'>Juli</option>
				<option value='8'>Agustus</option>
				<option value='9'>September</option>
				<option value='10'>Oktober</option>
				<option value='11'>November</option>
				<option value='12'>Desember</option>
			</select>
	<select name='tm'>
            <option value='none' selected='selected'>Tahun*</option>";
			$now =  date("Y");
			$saiki = 2000;
			for($l=$saiki; $l<=$now; $l++)
			{
				echo"<option value=",$l,">",$l,"</option>";
			}	
	echo "</select>
	</td>
	</tr>
	
	<tr>
	<td>Bagian</td><td>:</td><td><select name='bagian'>
	<option value='' selected >Pilih Bagian</option>";
	$jab=mysql_query("select * from bagian");
	while($j=mysql_fetch_array($jab)){
	echo "<option value='$j[id_bag]'>$j[n_bag]</option>";
	}
	echo "</select></td>
	</tr>
	
	<tr>
	<td>Jabatan</td><td>:</td><td><select name='jabatan'>	
	<option value='' selected >Pilih Jabatan</option>";
	$jab=mysql_query("select * from jabatan");
	while($j=mysql_fetch_array($jab)){
	echo "<option value='$j[id_jab]'  >$j[n_jab]</option>";
	}
	echo "</select></td>
	</tr>
	<tr>
	<td>Level User</td><td>:</td><td><select name='Level_user'>
		<option value='none' selected='selected'>Level User</option>
				<option value='1'>1</option>
				<option value='2'>2</option>
				<option value='3'>3</option>
				<option value='4'>4</option>
				<option value='5'>5</option>
				<option value='6'>6</option>
				<option value='7'>7</option>
				</select>
	</td>
	</tr>
	<tr>
	<td>Pendidikan</td><td>:</td><td><input class='form-control' name='pdk' type='text'></td>
	</tr>
	
	<tr>
	<td>Foto</td><td>:</td><td><input name='fupload' type='file' /></td>
	</tr>
	
	<tr>
	<td>Status Pegawai</td><td>:</td><td><select name='sp'>
	<option value='' selected >Pilih Status</option>
	<option value='tetap' >Tetap</option>
	<option value='kontrak' >Kontrak</option>
	</select></td>
	</tr>
	
	<tr>
	<td></td><td></td><td><input type=submit value=Simpan>
	<input type=button value=Batal onclick=self.history.back()>
	</td>
	</tr>
	</table>
	</form>
	";
	break;
	
	case "edit":
	$ambil=mysql_query("select * from pegawai where nip='$_GET[id]'");
	$t=mysql_fetch_array($ambil);
	$user=mysql_query("select * from user_id where userid='$_GET[id]'");
	$ul=mysql_fetch_array($user);
	echo "<h2 class='head'>Edit Data Pegawai</h2>
	<form action='$aksi?module=pegawai&act=edit' method='post' enctype='multipart/form-data' >
	<table class='tabelform tabpad'>
	<tr>
	<td>Nama SKPD</td><td>:</td><td><input class='form-control' type='text' name='id_skpd' value='$_SESSION[id_skpd]' readonly></td>
	</tr>
	<tr>
	<td>Nama UKPD</td><td>:</td><td><input class='form-control' type='text' name='id_ukpd' value='$_SESSION[id_ukpd]' readonly>
	</td>
	</tr>
	<tr>
	<td>Nip</td><td>:</td><td><input name='nip' class='form-control' type='text' value='$t[nip]' readonly></td>
	</tr>
	<tr>
	<td>Nama Pegawai</td><td>:</td><td><input class='form-control' name='nama' type='text' value='$t[nama]'></td>
	</tr>
	<tr>
	<td>Tempat Lahir</td><td>:</td><td><input class='form-control' name='tls' type='text' value='$t[tmpt_lahir]'></td>
	</tr>
	<tr>
	<td>Tanggal Lahir</td><td>:</td><td>"; 
	$tg=explode("-",$t['tgl_lahir']);
	$tl=$tg[0];
	$btl=$tg[1];
	$htl=$tg[2];
	combotgl(1, 31, ttl, $htl);
	combonamabln(1,12,btl,$btl);
	combothn(1965, 2000, tl, $tl);
	echo "</td>
	</tr>
	
	<tr>
	<td>Jenis Kelamin</td><td>:</td><td>";
	echo "<input name='jk' type='radio' value='L'"; if($t['jenis_kelamin']=='L'){ echo "checked";} echo "/>Pria ";
	echo "<input name='jk' type='radio' value='P'"; if($t['jenis_kelamin']=='P'){ echo "checked";} echo "/>Wanita ";
	
	echo "</td></tr>
	
	<tr>
	<td>Alamat</td><td>:</td><td><textarea class='form-control' name='almt' >$t[alamat]</textarea></td>
	</tr>
	
	<tr>
	<td>NPWP</td><td>:</td><td><input class='form-control' name='npwp' type='text' value='$t[npwp]'></td>
	</tr>
	
	<tr>
	<td>No Rek DKI</td><td>:</td><td><input class='form-control' name='norek' type='text' value='$t[norek]'></td>
	</tr>
	
	<tr>
	<td>Tanggal Masuk</td><td>:</td><td>";
	$ta=explode("-",$t['tgl_masuk']);
	$ttm=$ta[0];
	$btm=$ta[1];
	$htm=$ta[2];
	$now =  date("Y");
			$saiki = 2000;
	$ht="ht";
	$bt="bt";
	$tt="tt";
	combotgl(1, 31, $ht, $htm);
	combonamabln(1,12, $bt,$btm);
	combothn($saiki,$now, $tt,$ttm);
	
	echo "
	</td>
	</tr>
	
	
	<tr>
	<td>Status Pernikahan</td><td>:</td><td><select class='form-control' name='id_status'>
	<option value='' selected >--Pilih Status--</option>";
	$st=mysql_query("select * from status where id_ukpd LIKE '%$_SESSION[id_ukpd]%'");
	while($j=mysql_fetch_array($st)){
	if($t['id_status']==$j['id_status']){
	echo "<option value='$j[id_status]' selected='$t[id_status]'>$j[n_status]</option>";
	} else {
	echo "<option value='$j[id_status]'>$j[n_status]</option>";
	}
	}
	echo "</select></td>
	</tr>
	<tr>
	<td>Status Pegawai</td><td>:</td><td>";
	echo "<input name='status' type='radio' value='PNS'"; if($t['status']=='PNS'){ echo "checked";} echo "/>PNS ";
	echo "<input name='status' type='radio' value='NON PNS'"; if($t['status']=='NON PNS'){ echo "checked";} echo "/>NON PNS ";
	
	echo "</td></tr>
	<tr>
	<td>Pendidikan Terakhir</td><td>:</td><td><select class='form-control' name='id_pendidikan'>
	<option value='' selected >--Pilih Pendidikan Terkahir--</option>";
	$pnd=mysql_query("select * from pendidikan_t where id_ukpd LIKE '%$_SESSION[id_ukpd]%'");
	while($j=mysql_fetch_array($pnd)){
	if($t['id_pendidikan']==$j['id_pendidikan']){
	echo "<option value='$j[id_pendidikan]' selected='$t[id_pendidikan]'>$j[n_pendidikan]</option>";
	} else {
	echo "<option value='$j[id_pendidikan]'>$j[n_pendidikan]</option>";
	}
	}
	echo "</select></td>
	</tr>
	<tr>
	<td>Rumpun Jabatan</td><td>:</td><td><select class='form-control' name='id_rumpun'>
	<option value='' selected >--Pilih Rumpun Jabatan--</option>";
	$rj=mysql_query("select * from rumpun where id_ukpd LIKE '%$_SESSION[id_ukpd]%'");
	while($j=mysql_fetch_array($rj)){
	if($t['id_rumpun']==$j['id_rumpun']){
	echo "<option value='$j[id_rumpun]' selected='$t[id_rumpun]'>$j[n_rumpun]</option>";
	} else {
	echo "<option value='$j[id_rumpun]'>$j[n_rumpun]</option>";
	}
	}
	echo "</select></td>
	</tr>
	<tr>
	<td>Bagian</td><td>:</td><td><select class='form-control' name='bagian'>
	<option value='' selected >Pilih Bagian</option>";
	$jab=mysql_query("select * from bagian where id_ukpd LIKE '%$_SESSION[id_ukpd]%'");
	while($j=mysql_fetch_array($jab)){
	if($t['id_bag']==$j['id_bag']){
	echo "<option value='$j[id_bag]' selected='$t[id_bag]'>$j[n_bag]</option>";
	} else {
	echo "<option value='$j[id_bag]'>$j[n_bag]</option>";
	}
	}
	echo "</select></td>
	</tr>
	<tr>
	<td>Jabatan</td><td>:</td><td><select class='form-control' name='jabatan'>	
	<option value='' selected >Pilih Jabatan</option>";
	$jab=mysql_query("select * from jabatan where id_ukpd LIKE '%$_SESSION[id_ukpd]%'");
	while($j=mysql_fetch_array($jab)){
	if($t['id_jab']==$j['id_jab']){
	echo "<option value='$j[id_jab]' selected='$t[id_jab]'  >$j[n_jab]</option>";
	} else {
	echo "<option value='$j[id_jab]'>$j[n_jab]</option>";
	}
	}
	echo "</select></td>
	</tr>
	<tr>
	<td>BPJS Kesehatan</td><td>:</td><td>";
	echo "<input name='bpjsks' type='checkbox' value='0.02'"; if($t['bpjsks']=='0.02'){ echo "checked";} echo "/>BPJS Kesehatan ";
	echo"
	</td>
	</tr>
	<tr>
	<td>BPJS Ketenegakerjaan</td><td>:</td><td>";
	echo "<input name='bpjsjkk' type='checkbox' value='0.0054'"; if($t['bpjsjkk']=='0.0054'){ echo "checked";} echo "/>JKK & JKM ";
	echo "<input name='bpjsijht' type='checkbox' value='0.057'"; if($t['bpjsijht']=='0.057'){ echo "checked";} echo "/>IJHT ";
	echo "<input name='bpjsjp' type='checkbox' value='0.03'"; if($t['bpjsjp']=='0.03'){ echo "checked";} echo "/>JP ";
	echo"</td>
	</tr>
	<tr>
	
	<tr>
	<td>Kasatpel</td><td>:</td><td><select class='form-control' name='kasatpel'>
	<option value='' selected >--Pilih Kasatpel--</option>";
	$rj=mysql_query("select * from user_id where id_ukpd LIKE '%$_SESSION[id_ukpd]%' and level_user LIKE '%3%'");
	while($j=mysql_fetch_array($rj)){
	if($t['kasatpel']==$j['userid']){
	echo "<option value='$j[userid]' selected='$t[userid]'>$j[nama]</option>";
	} else {
	echo "<option value='$j[userid]'>$j[nama]</option>";
	}
	}
	echo "</select></td>
	</tr>
	<tr>
	<td>Kasie</td><td>:</td><td><select class='form-control' name='kasie'>
	<option value='' selected >--Pilih Kasie--</option>";
	$ks=mysql_query("select * from user_id where id_ukpd LIKE '%$_SESSION[id_ukpd]%' and level_user LIKE '%9%'");
	while($j=mysql_fetch_array($ks)){
	if($t['kasie']==$j['userid']){
	echo "<option value='$j[userid]' selected='$t[userid]'>$j[id_bag]</option>";
	} else {
	echo "<option value='$j[userid]'>$j[id_bag]</option>";
	}
	}
	echo "</select></td>
	</tr>
	<tr>
	<td>Level User</td><td>:</td><td><select class='form-control' name='level_user'>	
	<option value='' selected >Pilih Level user</option>";
	$ls=mysql_query("select * from set_user ");
	while($lss=mysql_fetch_array($ls)){
	if($ul['level_user']==$lss['id']){
	echo "<option value='$lss[id]' selected='$ul[level_user]'>$lss[ket]</option>";
	} else {
	echo "<option value='$lss[id]'>$lss[ket]</option>";
	}
	}
	echo "</select></td>
	</tr>
	<tr>
	<td>Foto</td><td>:</td><td><img src='image_peg/small_$t[foto]' class='form-control' /></td>
	</tr>
	
	<tr>
	<td>Ganti Foto</td><td>:</td><td><input class='form-control' name='fupload' type='file' /></td>
	</tr>
	
	<tr>
	<td></td><td></td><td><input  type=submit value=Simpan>
	<input type=button value=Batal onclick=self.history.back()>
	</td>
	</tr>
	</table>
	</form>
	";
	break;
	
	case "edit1":
	$ambil=mysql_query("select * from pegawai where nip='$_GET[id]'");
	$t=mysql_fetch_array($ambil);
	$user=mysql_query("select * from user_id where userid='$_GET[id]'");
	$ul=mysql_fetch_array($user);
	echo "<h2 class='head'>Edit Data Pegawai</h2>
	<form action='$aksi?module=pegawai&act=edit1' method='post' enctype='multipart/form-data' >
	<table class='tabelform tabpad'>
	<tr>
	<td>Nama SKPD</td><td>:</td><td><input class='form-control' type='text' name='id_skpd' value='$_SESSION[id_skpd]' readonly></td>
	</tr>
	<tr>
	<td>Nama UKPD</td><td>:</td><td><input class='form-control' type='text' name='id_ukpd' value='$_SESSION[id_ukpd]' readonly>
	</td>
	</tr>
	<tr>
	<td>Nip</td><td>:</td><td><input name='nip' class='form-control' type='text' value='$t[nip]' readonly></td>
	</tr>
	<tr>
	<td>Nama Pegawai</td><td>:</td><td><input class='form-control' name='nama' type='text' value='$t[nama]'></td>
	</tr>
	<tr>
	<td>Tempat Lahir</td><td>:</td><td><input class='form-control' name='tls' type='text' value='$t[tmpt_lahir]'></td>
	</tr>
	<tr>
	<td>Tanggal Lahir</td><td>:</td><td>"; 
	$tg=explode("-",$t['tgl_lahir']);
	$tl=$tg[0];
	$btl=$tg[1];
	$htl=$tg[2];
	combotgl(1, 31, ttl, $htl);
	combonamabln(1,12,btl,$btl);
	combothn(1965, 2000, tl, $tl);
	echo "</td>
	</tr>
	
	<tr>
	<td>Jenis Kelamin</td><td>:</td><td>";
	echo "<input name='jk' type='radio' value='L'"; if($t['jenis_kelamin']=='L'){ echo "checked";} echo "/>Pria ";
	echo "<input name='jk' type='radio' value='P'"; if($t['jenis_kelamin']=='P'){ echo "checked";} echo "/>Wanita ";
	
	echo "</td></tr>
	
	<tr>
	<td>Alamat</td><td>:</td><td><textarea class='form-control' name='almt' >$t[alamat]</textarea></td>
	</tr>
	
	<tr>
	<td>NPWP</td><td>:</td><td><input class='form-control' name='npwp' type='text' value='$t[npwp]'></td>
	</tr>
	
	<tr>
	<td>No Rek DKI</td><td>:</td><td><input class='form-control' name='norek' type='text' value='$t[norek]'></td>
	</tr>
	
	<tr>
	<td>Tanggal Masuk</td><td>:</td><td>";
	$ta=explode("-",$t['tgl_masuk']);
	$ttm=$ta[0];
	$btm=$ta[1];
	$htm=$ta[2];
	$now =  date("Y");
			$saiki = 2000;
	$ht="ht";
	$bt="bt";
	$tt="tt";
	combotgl(1, 31, $ht, $htm);
	combonamabln(1,12, $bt,$btm);
	combothn($saiki,$now, $tt,$ttm);
	
	echo "
	</td>
	</tr>
	
	
	<tr>
	<td>Status</td><td>:</td><td><select class='form-control' name='id_status'>
	<option value='' selected >--Pilih Status--</option>";
	$st=mysql_query("select * from status where id_ukpd LIKE '%$_SESSION[id_ukpd]%'");
	while($j=mysql_fetch_array($st)){
	if($t['id_status']==$j['id_status']){
	echo "<option value='$j[id_status]' selected='$t[id_status]'>$j[n_status]</option>";
	} else {
	echo "<option value='$j[id_status]'>$j[n_status]</option>";
	}
	}
	echo "</select></td>
	</tr>
	<tr>
	<td>Status Pegawai</td><td>:</td><td>";
	echo "<input name='status' type='radio' value='PNS'"; if($t['status']=='PNS'){ echo "checked";} echo "/>PNS ";
	echo "<input name='status' type='radio' value='NON PNS'"; if($t['status']=='NON PNS'){ echo "checked";} echo "/>NON PNS ";
	
	echo "</td></tr>
	<tr>
	<td>Pendidikan Terakhir</td><td>:</td><td><select class='form-control' name='id_pendidikan'>
	<option value='' selected >--Pilih Pendidikan Terkahir--</option>";
	$pnd=mysql_query("select * from pendidikan_t where id_ukpd LIKE '%$_SESSION[id_ukpd]%'");
	while($j=mysql_fetch_array($pnd)){
	if($t['id_pendidikan']==$j['id_pendidikan']){
	echo "<option value='$j[id_pendidikan]' selected='$t[id_pendidikan]'>$j[n_pendidikan]</option>";
	} else {
	echo "<option value='$j[id_pendidikan]'>$j[n_pendidikan]</option>";
	}
	}
	echo "</select></td>
	</tr>
	<tr>
	<td>Rumpun Jabatan</td><td>:</td><td><select class='form-control' name='id_rumpun'>
	<option value='' selected >--Pilih Rumpun Jabatan--</option>";
	$rj=mysql_query("select * from rumpun where id_ukpd LIKE '%$_SESSION[id_ukpd]%'");
	while($j=mysql_fetch_array($rj)){
	if($t['id_rumpun']==$j['id_rumpun']){
	echo "<option value='$j[id_rumpun]' selected='$t[id_rumpun]'>$j[n_rumpun]</option>";
	} else {
	echo "<option value='$j[id_rumpun]'>$j[n_rumpun]</option>";
	}
	}
	echo "</select></td>
	</tr>
	<tr>
	<td>Bagian</td><td>:</td><td><select class='form-control' name='bagian'>
	<option value='' selected >Pilih Bagian</option>";
	$jab=mysql_query("select * from bagian where id_ukpd LIKE '%$_SESSION[id_ukpd]%'");
	while($j=mysql_fetch_array($jab)){
	if($t['id_bag']==$j['id_bag']){
	echo "<option value='$j[id_bag]' selected='$t[id_bag]'>$j[n_bag]</option>";
	} else {
	echo "<option value='$j[id_bag]'>$j[n_bag]</option>";
	}
	}
	echo "</select></td>
	</tr>
	<tr>
	<td>Jabatan</td><td>:</td><td><select class='form-control' name='jabatan'>	
	<option value='' selected >Pilih Jabatan</option>";
	$jab=mysql_query("select * from jabatan where id_ukpd LIKE '%$_SESSION[id_ukpd]%'");
	while($j=mysql_fetch_array($jab)){
	if($t['id_jab']==$j['id_jab']){
	echo "<option value='$j[id_jab]' selected='$t[id_jab]'  >$j[n_jab]</option>";
	} else {
	echo "<option value='$j[id_jab]'>$j[n_jab]</option>";
	}
	}
	echo "</select></td>
	</tr>
	<tr>
	<td>BPJS Kesehatan</td><td>:</td><td><input type='checkbox'  name='bpjsks' value='0.02'> BPJS Kesehatan </td>
	</tr>
	<tr>
	<td>BPJS Ketenegakerjaan</td><td>:</td><td><input type='checkbox' name='bpjsjkk' value='0.0054'> JKK & JKM   
	    <input type='checkbox' name='bpjsijht' value='0.057'> IJHT   
	<input type='checkbox' name='bpjsjp' value='0.03'> JP</td>
	</tr>
	<tr>
		<tr>
	<td>Kasatpel</td><td>:</td><td><select class='form-control' name='kasatpel'>
	<option value='' selected >--Pilih Kasatpel--</option>";
	$rj=mysql_query("select * from user_id where id_ukpd LIKE '%$_SESSION[id_ukpd]%' and level_user LIKE '%8%'");
	while($j=mysql_fetch_array($rj)){
	if($t['kasatpel']==$j['userid']){
	echo "<option value='$j[userid]' selected='$t[userid]'>$j[nama]</option>";
	} else {
	echo "<option value='$j[userid]'>$j[nama]</option>";
	}
	}
	echo "</select></td>
	</tr>
	<tr>
	<td>Kasie</td><td>:</td><td><select class='form-control' name='kasie'>
	<option value='' selected >--Pilih Kasie--</option>";
	$ks=mysql_query("select * from user_id where id_ukpd LIKE '%$_SESSION[id_ukpd]%' and level_user LIKE '%9%'");
	while($j=mysql_fetch_array($ks)){
	if($t['kasie']==$j['userid']){
	echo "<option value='$j[userid]' selected='$t[userid]'>$j[id_bag]</option>";
	} else {
	echo "<option value='$j[userid]'>$j[id_bag]</option>";
	}
	}
	echo "</select></td>
	</tr>
	<tr>
	<td>Level User</td><td>:</td><td><select class='form-control' name='level_user'>	
	<option value='' selected >Pilih Level user</option>";
	$ls=mysql_query("select * from set_user ");
	while($lss=mysql_fetch_array($ls)){
	if($ul['level_user']==$lss['id']){
	echo "<option value='$lss[id]' selected='$ul[level_user]'>$lss[ket]</option>";
	} else {
	echo "<option value='$lss[id]'>$lss[ket]</option>";
	}
	}
	echo "</select></td>
	</tr>
	
	<tr>
	<td>Foto</td><td>:</td><td><img src='image_peg/small_$t[foto]' class='form-control' /></td>
	</tr>
	
	<tr>
	<td>Ganti Foto</td><td>:</td><td><input class='form-control' name='fupload' type='file' /></td>
	</tr>
	
	<tr>
	<td></td><td></td><td><input  type=submit value=Simpan>
	<input type=button value=Batal onclick=self.history.back()>
	</td>
	</tr>
	</table>
	</form>
	";
	break;
	
	
	
	
	
	case "update":
	$ambil=mysql_query("select * from pegawai where nip='$_GET[id]'");
	$t=mysql_fetch_array($ambil);
	echo "<h2 class='head'>Edit Data Pegawai</h2>
	<form action='$aksi?module=pegawai&act=ubah' method='post' enctype='multipart/form-data' >
	<table class='tabelform tabpad'>
	<tr>
	<td>Nip</td><td>:</td><td><input name='nip' class='form-control' type='text' value='$t[nip]' readonly></td>
	</tr>
	<tr>
	<td>Nama Pegawai</td><td>:</td><td><input class='form-control' name='nama' type='text' value='$t[nama]'></td>
	</tr>
	<tr>
	<td>Tempat Lahir</td><td>:</td><td><input class='form-control' name='tls' type='text' value='$t[tmpt_lahir]'></td>
	</tr>
	<tr>
	<td>Tanggal Lahir</td><td>:</td><td>"; 
	$tg=explode("-",$t['tgl_lahir']);
	$tl=$tg[0];
	$btl=$tg[1];
	$htl=$tg[2];
	combotgl(1, 31, ttl, $htl);
	combonamabln(1,12,btl,$btl);
	combothn(1965, 2000, tl, $tl);
	echo "</td>
	</tr>
	
	<tr>
	<td>Jenis Kelamin</td><td>:</td><td>";
	echo "<input name='jk' type='radio' value='L'"; if($t['jenis_kelamin']=='L'){ echo "checked";} echo "/>Pria ";
	echo "<input name='jk' type='radio' value='P'"; if($t['jenis_kelamin']=='P'){ echo "checked";} echo "/>Wanita ";
	
	echo "</td></tr>
	
	<tr>
	<td>Alamat</td><td>:</td><td><textarea class='form-control' name='almt' >$t[alamat]</textarea></td>
	</tr>
		
	<tr>
	<td>NPWP</td><td>:</td><td><input class='form-control' name='npwp' type='text' value='$t[npwp]'></td>
	</tr>
	
	<tr>
	<td>No Rek DKI</td><td>:</td><td><input class='form-control' name='norek' type='text' value='$t[norek]'></td>
	</tr>
	
	<tr>
	<td>Foto</td><td>:</td><td><img src='image_peg/small_$t[foto]' class='form-control' /></td>
	</tr>
	
	<tr>
	<td>Ganti Foto</td><td>:</td><td><input class='form-control' name='fupload' type='file' /></td>
	</tr>
	
	<tr>
	<td></td><td></td><td><input  type=submit value=Simpan>
	<input type=button value=Batal onclick=self.history.back()>
	</td>
	</tr>
	</table>
	</form>
	";
	break;
	
	
	case "detail":
	$ambil=mysql_query("select * from pegawai where nip='$_GET[id]'");
	$t=mysql_fetch_array($ambil);
	echo "<h2 class='head'>Data Pegawai</h2>
	<div class='rp' >
	<div class='foto'>";
	if($t[foto]==""){
		echo "<img src='image_peg/no.jpg' width='200' height='240' />";
	} else {
	echo "<img src='image_peg/small_$t[foto]' width='200' height='240' />";
	}
	echo "</div>
	<table class='tabelform tabpad'>
	<tr>
	<td>Nip</td><td>:</td><td>$t[nip]</td>
	</tr>
	<tr>
	<td>Nama Pegawai</td><td>:</td><td>$t[nama]</td>
	</tr>
	<tr>
	<td>Tempat Lahir</td><td>:</td><td>$t[tmpt_lahir]</td>
	</tr>
	<tr>
	<td>Tanggal Lahir</td><td>:</td><td>"; 
	echo "".tgl_indo($t['tgl_lahir'])."";
	echo "</td>
	</tr>
	
	<tr>
	<td>Jenis Kelamin</td><td>:</td><td>";
	if($t['jenis_kelamin']=='L'){
	echo "Pria";
	} else {
	echo "Wanita";
	}	
	echo "</td></tr>
	
	<tr>
	<td>Status</td><td>:</td><td>";
	$st=mysql_query("select * from status where id_status='$t[id_status]'");
	$b=mysql_fetch_array($st);
	$status=$b[nilai];
	echo "$b[n_status]";	
	echo "</td>
	</tr>
	
	<tr>
	<td>Alamat</td><td>:</td><td>$t[alamat]</td>
	</tr>
	
	<tr>
	<td>Tanggal Masuk</td><td>:</td><td>";
	echo "".tgl_indo($t['tgl_masuk'])."";
	echo "
	</td>
	</tr>
	
	<tr>
	<td>Pendidikan terakhir</td><td>:</td><td>";
	$pnd=mysql_query("select * from pendidikan_t where id_pendidikan='$t[id_pendidikan]'");
	$b=mysql_fetch_array($pnd);
	$pendidikan=$b[n_pendidikan];
	echo "$b[n_pendidikan]";	
	echo "</td>
	</tr>
	
	<tr>
	<td>Rumpun Jabatan</td><td>:</td><td>";
	$rm=mysql_query("select * from rumpun where id_rumpun='$t[id_rumpun]'");
	$b=mysql_fetch_array($rm);
	$rumpun=$b[nilai];
	echo "$b[n_rumpun]";	
	echo "</td>
	</tr>
	
	<tr>
	<td>Masa Kerja</td><td>:</td><td>";
	$tmp =new datetime($t['tgl_masuk']);
	$today = new datetime();
	$masa= $today->diff($tmp);
	$tahun= $masa->y;
	$bulan= $masa->m;
	$mk=($tahun*12)+$bulan;
	echo $masa->y; echo" Tahun "; echo $masa->m; echo" Bulan ";  
	echo " 
	</td>
	</tr>
	
	<tr>
	<td>Gapok </td><td>:</td><td>";
	$gapok=''; 
	if ($pendidikan=="")
	echo "TMP Belum Di Input";
	elseif($pendidikan == 'SD' and $mk <= 24 )
	$gapok=2719298;
	elseif($pendidikan === 'SD' and $mk >= 25 and $mk <= 48)
	$gapok=2787281;
	elseif($pendidikan === 'SD' and  $mk >= 49 and $mk <= 72 )
	$gapok=2856963;
	elseif($pendidikan == 'SD' and $mk >= 73 and $mk <= 96 )
	$gapok=2928387;
	elseif($pendidikan === 'SD' and $mk >= 97 and $mk <= 120)
	$gapok=3001596;
	elseif($pendidikan === 'SD' and $mk >= 121 and $mk <= 144 )
	$gapok=3076636;
	elseif($pendidikan == 'SD' and $mk >= 145 and $mk <= 168 )
	$gapok=3153552;
	elseif($pendidikan === 'SD' and $mk >= 169 and $mk <= 192)
	$gapok=3232391;
	elseif($pendidikan === 'SD' and $mk >= 193 and $mk <= 216 )
	$gapok=33313201;
	elseif($pendidikan == 'SD' and $mk >= 217 and $mk <= 240 )
	$gapok=33396031;
	elseif($pendidikan === 'SD' and $mk >= 241 and $mk <= 264)
	$gapok=3480932;
	elseif($pendidikan === 'SD' and $mk >= 265 and $mk <= 288 )
	$gapok=3567955;
	elseif($pendidikan == 'SD' and $mk >= 289 and $mk <= 312 )
	$gapok=3657154;
	elseif($pendidikan === 'SD' and $mk >= 313 and $mk <= 336)
	$gapok=3748583;
	elseif($pendidikan === 'SD' and $mk >= 337 and $mk <= 360 )
	$gapok=3842297;
	elseif($pendidikan == 'SD' and $mk > 361 and $mk <= 384 )
	$gapok=3938355;
	elseif($pendidikan == 'SD' and $mk > 385 and $mk <= 408)
	$gapok=4036814;
	
	elseif($pendidikan == 'SMP' and $mk <= 24)
	$gapok=3263158;
	elseif($pendidikan === 'SMP' and $mk >= 25 and $mk <= 48)
	$gapok=3344737;
	elseif($pendidikan === 'SMP' and $mk >= 49 and $mk <= 72 )
	$gapok=3428355;
	elseif($pendidikan == 'SMP' and $mk >= 73 and $mk <= 96 )
	$gapok=3514064;
	elseif($pendidikan === 'SMP' and $mk >= 97 and $mk <= 120)
	$gapok=3601916;
	elseif($pendidikan === 'SMP' and $mk >= 121 and $mk <= 144 )
	$gapok=3691964;
	elseif($pendidikan == 'SMP' and $mk >= 145 and $mk <= 168 )
	$gapok=3784263;
	elseif($pendidikan === 'SMP' and $mk >= 169 and $mk <= 192)
	$gapok=3878869;
	elseif($pendidikan === 'SMP' and $mk >= 193 and $mk <= 216 )
	$gapok=3975841;
	elseif($pendidikan == 'SMP' and $mk >= 217 and $mk <= 240 )
	$gapok=4075237;
	elseif($pendidikan === 'SMP' and $mk >= 241 and $mk <= 264)
	$gapok=4177118;
	elseif($pendidikan === 'SMP' and $mk >= 265 and $mk <= 288 )
	$gapok=4281546;
	elseif($pendidikan == 'SMP' and $mk >= 289 and $mk <= 312 )
	$gapok=4388585;
	elseif($pendidikan === 'SMP' and $mk >= 313 and $mk <= 336)
	$gapok=4498299;
	elseif($pendidikan === 'SMP' and $mk >= 337 and $mk <= 360 )
	$gapok=4610757;
	elseif($pendidikan == 'SMP' and $mk >= 361 and $mk <= 384 )
	$gapok=4726026;
	elseif($pendidikan == 'SMP' and $mk >= 385 and $mk <= 408)
	$gapok=4844176;
	
	elseif($pendidikan == 'SLTA' and $mk <= 24)
	$gapok=3807018;
	elseif($pendidikan === 'SLTA' and $mk >= 25 and $mk <= 48)
	$gapok=3902193;
	elseif($pendidikan === 'SLTA' and $mk >= 49 and $mk <= 72 )
	$gapok=3999748;
	elseif($pendidikan == 'SLTA' and $mk >= 73 and $mk <= 96 )
	$gapok=4099742;
	elseif($pendidikan === 'SLTA' and $mk >= 97 and $mk <= 120)
	$gapok=4202235;
	elseif($pendidikan === 'SLTA' and $mk >= 121 and $mk <= 144 )
	$gapok=4307291;
	elseif($pendidikan == 'SLTA' and $mk >= 145 and $mk <= 168 )
	$gapok=4414973;
	elseif($pendidikan === 'SLTA' and $mk >= 169 and $mk <= 192)
	$gapok=4525348;
	elseif($pendidikan === 'SLTA' and $mk >= 193 and $mk <= 216 )
	$gapok=4638481;
	elseif($pendidikan == 'SLTA' and $mk >= 217 and $mk <= 240 )
	$gapok=4754443;
	elseif($pendidikan === 'SLTA' and $mk >= 241 and $mk <= 264)
	$gapok=4873304;
	elseif($pendidikan === 'SLTA' and $mk >= 265 and $mk <= 288 )
	$gapok=4995137;
	elseif($pendidikan == 'SLTA' and $mk >= 289 and $mk <= 312 )
	$gapok=5120015;
	elseif($pendidikan === 'SLTA' and $mk >= 313 and $mk <= 336)
	$gapok=5248016;
	elseif($pendidikan === 'SLTA' and $mk >= 337 and $mk <= 360 )
	$gapok=5379216;
	elseif($pendidikan == 'SLTA' and $mk >= 361 and $mk <= 384 )
	$gapok=5513697;
	elseif($pendidikan == 'SLTA' and $mk > 385 and $mk <= 408)
	$gapok=5651539;
	
	elseif($pendidikan == 'D III / D IV' and $mk <= 24 )
	$gapok=4078947;
	elseif($pendidikan === 'D III / D IV' and $mk >= 25 and $mk <= 48)
	$gapok=4180921;
	elseif($pendidikan === 'D III / D IV' and $mk >= 49 and $mk <= 72 )
	$gapok=4285444;
	elseif($pendidikan == 'D III / D IV' and $mk >= 73 and $mk <= 96 )
	$gapok=4392580;
	elseif($pendidikan === 'D III / D IV' and $mk >= 97 and $mk <= 120)
	$gapok=4502395;
	elseif($pendidikan === 'D III / D IV' and $mk >= 121 and $mk <= 144 )
	$gapok=4614955;
	elseif($pendidikan == 'D III / D IV' and $mk >= 145 and $mk <= 168 )
	$gapok=4730328;
	elseif($pendidikan === 'D III / D IV' and $mk >= 169 and $mk <= 192)
	$gapok=4848587;
	elseif($pendidikan === 'D III / D IV' and $mk >= 193 and $mk <= 216 )
	$gapok=4969801;
	elseif($pendidikan == 'D III / D IV' and $mk >= 217 and $mk <= 240 )
	$gapok=5094046;
	elseif($pendidikan === 'D III / D IV' and $mk >= 241 and $mk <= 264)
	$gapok=5221937;
	elseif($pendidikan === 'D III / D IV' and $mk >= 265 and $mk <= 288 )
	$gapok=5351932;
	elseif($pendidikan == 'D III / D IV' and $mk >= 289 and $mk <= 312 )
	$gapok=5485731;
	elseif($pendidikan === 'D III / D IV' and $mk >= 313 and $mk <= 336)
	$gapok=5622874;
	elseif($pendidikan === 'D III / D IV' and $mk >= 337 and $mk <= 360 )
	$gapok=5763446;
	elseif($pendidikan == 'D III / D IV' and $mk > 361 and $mk <= 384 )
	$gapok=5907532;
	elseif($pendidikan == 'D III / D IV' and $mk >= 385 and $mk <= 408)
	$gapok=6055220;
	
	elseif($pendidikan == 'S1' and $mk <= 24 )
	$gapok=4350877;
	elseif($pendidikan === 'S1' and $mk >= 25 and $mk <= 48)
	$gapok=4459649;
	elseif($pendidikan === 'S1' and $mk >= 49 and $mk <= 72 )
	$gapok=4571140;
	elseif($pendidikan == 'S1' and $mk >= 73 and $mk <= 96 )
	$gapok=4685419;
	elseif($pendidikan === 'S1' and $mk >= 97 and $mk <= 120)
	$gapok=4802554;
	elseif($pendidikan === 'S1' and $mk >= 121 and $mk <= 144 )
	$gapok=4922618;
	elseif($pendidikan == 'S1' and $mk >= 145 and $mk <= 168 )
	$gapok=5045684;
	elseif($pendidikan === 'S1' and $mk >= 169 and $mk <= 192)
	$gapok=5171826;
	elseif($pendidikan === 'S1' and $mk >= 193 and $mk <= 216 )
	$gapok=5301121;
	elseif($pendidikan == 'S1' and $mk >= 217 and $mk <= 240 )
	$gapok=5433649;
	elseif($pendidikan === 'S1' and $mk >= 241 and $mk <= 264)
	$gapok=5569491;
	elseif($pendidikan === 'S1' and $mk >= 265 and $mk <= 288 )
	$gapok=5708728;
	elseif($pendidikan == 'S1' and $mk >= 289 and $mk <= 312 )
	$gapok=5851446;
	elseif($pendidikan === 'S1' and $mk >= 313 and $mk <= 336)
	$gapok=5997732;
	elseif($pendidikan === 'S1' and $mk >= 337 and $mk <= 360 )
	$gapok=6147676;
	elseif($pendidikan == 'S1' and $mk >= 361 and $mk <= 384 )
	$gapok=6301367;
	elseif($pendidikan == 'S1' and $mk >= 385 and $mk <= 408)
	$gapok=6458902;
	
	elseif($pendidikan == 'S2 / dr./ drg./ Apoteker/ Ners' and $mk <= 24 )
	$gapok=4622807;
	elseif($pendidikan === 'S2 / dr./ drg./ Apoteker/ Ners' and $mk >= 25 and $mk <= 48)
	$gapok=4738377;
	elseif($pendidikan === 'S2 / dr./ drg./ Apoteker/ Ners' and $mk >= 49 and $mk <= 72 )
	$gapok=4856837;
	elseif($pendidikan == 'S2 / dr./ drg./ Apoteker/ Ners' and $mk >= 73 and $mk <= 96 )
	$gapok=4978258;
	elseif($pendidikan === 'S2 / dr./ drg./ Apoteker/ Ners' and $mk >= 97 and $mk <= 120)
	$gapok=5102714;
	elseif($pendidikan === 'S2 / dr./ drg./ Apoteker/ Ners' and $mk >= 121 and $mk <= 144 )
	$gapok=5230282;
	elseif($pendidikan == 'S2 / dr./ drg./ Apoteker/ Ners' and $mk >= 145 and $mk <= 168 )
	$gapok=5361039;
	elseif($pendidikan === 'S2 / dr./ drg./ Apoteker/ Ners' and $mk >= 169 and $mk <= 192)
	$gapok=5495065;
	elseif($pendidikan === 'S2 / dr./ drg./ Apoteker/ Ners' and $mk >= 193 and $mk <= 216 )
	$gapok=5632441;
	elseif($pendidikan == 'S2 / dr./ drg./ Apoteker/ Ners' and $mk >= 217 and $mk <= 240 )
	$gapok=5773253;
	elseif($pendidikan === 'S2 / dr./ drg./ Apoteker/ Ners' and $mk >= 241 and $mk <= 264)
	$gapok=5917584;
	elseif($pendidikan === 'S2 / dr./ drg./ Apoteker/ Ners' and $mk >= 265 and $mk <= 288 )
	$gapok=6065523;
	elseif($pendidikan == 'S2 / dr./ drg./ Apoteker/ Ners' and $mk >= 289 and $mk <= 312 )
	$gapok=6217161;
	elseif($pendidikan === 'S2 / dr./ drg./ Apoteker/ Ners' and $mk >= 313 and $mk <= 336)
	$gapok=6372591;
	elseif($pendidikan === 'S2 / dr./ drg./ Apoteker/ Ners' and $mk >= 337 and $mk <= 360 )
	$gapok=6531905;
	elseif($pendidikan == 'S2 / dr./ drg./ Apoteker/ Ners' and $mk >= 361 and $mk <= 384 )
	$gapok=6695203;
	elseif($pendidikan == 'S2 / dr./ drg./ Apoteker/ Ners' and $mk >= 385 and $mk <= 408)
	$gapok=6862583;
	
	elseif($pendidikan == 'S3 / dr. Spesialis' and $mk <= 24)
	$gapok=4894737;
	elseif($pendidikan === 'S3 / dr. Spesialis' and $mk >= 25 and $mk <= 48)
	$gapok=5017105;
	elseif($pendidikan === 'S3 / dr. Spesialis' and $mk >= 49 and $mk <= 72 )
	$gapok=5142533;
	elseif($pendidikan == 'S3 / dr. Spesialis' and $mk >= 73 and $mk <= 96 )
	$gapok=5271096;
	elseif($pendidikan === 'S3 / dr. Spesialis' and $mk >= 97 and $mk <= 120)
	$gapok=5402874;
	elseif($pendidikan === 'S3 / dr. Spesialis' and $mk >= 121 and $mk <= 144 )
	$gapok=5537945;
	elseif($pendidikan == 'S3 / dr. Spesialis' and $mk >= 145 and $mk <= 168 )
	$gapok=5676394;
	elseif($pendidikan === 'S3 / dr. Spesialis' and $mk >= 169 and $mk <= 192)
	$gapok=5818304;
	elseif($pendidikan === 'S3 / dr. Spesialis' and $mk >= 193 and $mk <= 216 )
	$gapok=5963762;
	elseif($pendidikan == 'S3 / dr. Spesialis' and $mk >= 217 and $mk <= 240 )
	$gapok=6112856;
	elseif($pendidikan === 'S3 / dr. Spesialis' and $mk >= 241 and $mk <= 264)
	$gapok=6265677;
	elseif($pendidikan === 'S3 / dr. Spesialis' and $mk >= 265 and $mk <= 288 )
	$gapok=6422319;
	elseif($pendidikan == 'S3 / dr. Spesialis' and $mk >= 289 and $mk <= 312 )
	$gapok=6582877;
	elseif($pendidikan === 'S3 / dr. Spesialis' and $mk >= 313 and $mk <= 336)
	$gapok=6747449;
	elseif($pendidikan === 'S3 / dr. Spesialis' and $mk >= 337 and $mk <= 360 )
	$gapok=6916135;
	elseif($pendidikan == 'S3 / dr. Spesialis' and $mk >= 361 and $mk <= 384 )
	$gapok=7089038;
	elseif($pendidikan == 'S3 / dr. Spesialis' and $mk >= 385 and $mk <= 408)
	$gapok=7266264;
	else
	echo"";
	$gaji=number_format($gapok,0);
	echo" Rp.$gaji
	</td>
	</tr>

	<tr>
	<td>Bruto </td><td>:</td><td>";
	$bruto=$gapok*$status;
	$hasil33=number_format($bruto,0);
	echo "Rp.$hasil33"; 
	
	echo" 
	</td>
	</tr>
	
	<tr>
	<td>Tunjangan </td><td>:</td><td>";
	$tunjangan=$gapok*$rumpun;
	$hasil34=number_format($tunjangan,0);
	echo "Rp.$hasil34"; 
	
	echo" 
	</td>
	</tr>
	
	<tr>
	<td>Gaji Di Terima </td><td>:</td><td>";
	$diterima=$bruto+$tunjangan;
	$hasil35=number_format($diterima,0);
	echo "Rp.$hasil35 (PERKIRAAN)"; 
	
	echo" 
	</td>
	</tr>
	
	<tr>
	<td>Bagian</td><td>:</td><td>";
	$bag=mysql_query("select * from bagian where id_bag='$t[id_bag]'");
	$b=mysql_fetch_array($bag);
	echo "$b[n_bag]";	
	echo "</td>
	</tr>
	
	<tr>
	<td>Jabatan</td><td>:</td><td>";
	$jab=mysql_query("select * from jabatan where id_jab='$t[id_jab]'");
	$j=mysql_fetch_array($jab);
	echo "$j[n_jab]";
	echo "</td>
	</tr>
	
	<tr>
	<td colspan='3'>[ <a href='?module=pegawai&act=update&id=$t[nip]'> Edit Profil </a>] [ <a href='?module=pegawai&act=pwd&id=$t[nip]'> Ganti Password </a>]</td>
	</tr>
	
	</table>
	<div style='clear:both'></div>
	<h2 class='head'>Riwayat pendidikan</h2>
	<table class='table table-bordered table-hover table-striped'>
	<thead>
	<tr>
	<td>Tahun</td>
	<td>Detail Pendidikan</td>
	</tr>
	</thead>";
	$nip=$_SESSION['namauser'];
	$ri=mysql_query("select * from pendidikan where nip='$_GET[id]' order by idp ASC");
	if(mysql_num_rows($ri)==0){
	echo "<tr>
	<td colspan='2'>*Tidak Ada Data*</td>
	</tr>";
	} else {
	while($p=mysql_fetch_array($ri)){
	echo "
	<tr>
	<td>$p[t_pdk]</td>
	<td>".nl2br($p['d_pdk'] )."</br>[ <a href='?module=pegawai&act=rpedit&id=$p[idp]'>edit</a> | 
	<a href='$aksi?module=pegawai&act=rpdel&id=$p[idp]&nip=$p[nip]'>hapus</a>]</td>
	</tr>";
	}
	}
	echo "
	<tr><td colspan='2'><a href='?module=pegawai&act=rp&id=$_GET[id]'>Tambah Data</a></td></td>
	</table>
	</div>
	
	
	<div class='rp2'>
	<h2 class='head'>PENGALAMAN KERJA</h2>
	<table class='table table-bordered table-hover table-striped'>	
	<thead>
	<tr>
	<td>Nama Pekerjaan</td>
	<td>Detail Pekerjaan</td>
	</tr>	
	</thead>";
	$nip=$_SESSION['namauser'];
	$ri=mysql_query("select * from pengalaman_kerja where nip='$_GET[id]' order by id_peker ASC");
	if(mysql_num_rows($ri)==0){
	echo "<tr>
	<td colspan='2'>*Tidak Ada Data*</td>
	</tr>";
	} else {
	while($p=mysql_fetch_array($ri)){
	echo "
	<tr>
	<td>$p[nm_pekerjaan]</td>
	<td>".nl2br($p['d_pekerjaan'])." </br>[ <a href='?module=pegawai&act=pkedit&id=$p[id_peker]'>edit</a> | 
	<a href='$aksi?module=pegawai&act=pkdel&id=$p[id_peker]&nip=$p[nip]'>hapus</a>]</td>
	</tr>";
	}
	}
	echo "
	<tr><td colspan='2'><a href='?module=pegawai&act=pk&id=$_GET[id]'>Tambah Data</a></td></td>
	</table>
	</div>
		<div style='clear:both'></div>
	";	
	break;
	
	case "rp":
	echo "<h2 class='head'>TAMBAH RIWAYAT PENDIDIKAN</h2>
	<form action='$aksi?module=pegawai&act=rp' method='post' enctype='multipart/form-data' >
	<table class='tabelform tabpad'>
	<tr>
	<td></td><td></td><td><input name='nip' type='hidden' value='$_GET[id]' readonly></td>
	</tr>
	<tr>
	<td>Tahun</td><td>:</td><td><input class='form-control' name='tahun' type='text'><span> format: 2000-2006</span></td>
	</tr>
	<tr>
	<td>Detail Pendidikan</td><td>:</td><td><textarea class='form-control' name='dp' rows='5'></textarea></td>
	</tr>
	<tr>
	<td></td><td></td><td><input type=submit value=Simpan>
	<input type=button value=Batal onclick=self.history.back()>
	</td>
	</tr>
	</table>
	</form>
	";
	break;
	
	case "rpedit":
	$edit=mysql_query("select * from pendidikan where idp='$_GET[id]' ");
	$e=mysql_fetch_array($edit);
	echo "<h2 class='head'>EDIT RIWAYAT PENDIDIKAN</h2>
	<form action='$aksi?module=pegawai&act=rpedit' method='post' enctype='multipart/form-data' >
	<table class='tabelform tabpad'>
	<tr>
	<td></td><td></td><td>
	<input name='nip' type='hidden' value='$e[nip]' readonly>
	<input name='idp' type='hidden' value='$_GET[id]' readonly></td>
	</tr>
	<tr>
	<td>Tahun</td><td>:</td><td><input class='form-control' name='tahun' type='text' value='$e[t_pdk]'><span> format: 2000-2006</span></td>
	</tr>
	<tr>
	<td>Detail Pendidikan</td><td>:</td><td><textarea class='form-control' name='dp' rows='5'>$e[d_pdk]</textarea></td>
	</tr>
	<tr>
	<td></td><td></td><td><input type=submit value=Simpan>
	<input type=button value=Batal onclick=self.history.back()>
	</td>
	</tr>
	</table>
	</form>
	";
	break;
	
	case "pk":
	echo "<h2 class='head'>TAMBAH DATA PENGALAMAN KERJA</h2>
	<form action='$aksi?module=pegawai&act=pk' method='post' enctype='multipart/form-data' >
	<table class='tabelform tabpad'>
	<tr>
	<td></td><td></td><td><input name='nip' type='hidden' value='$_GET[id]' readonly></td>
	</tr>
	<tr>
	<td>Nama Pekerjaan</td><td>:</td><td><input class='form-control' name='np' type='text'><span> </span></td>
	</tr>
	<tr>
	<td>Detail Pekerjaan</td><td>:</td><td><textarea class='form-control' name='dp' rows='5'></textarea></td>
	</tr>
	<tr>
	<td></td><td></td><td><input type=submit value=Simpan>
	<input type=button value=Batal onclick=self.history.back()>
	</td>
	</tr>
	</table>
	</form>
	";
	break;
	
	case "pkedit":
	$edit=mysql_query("select * from pengalaman_kerja where id_peker='$_GET[id]' ");
	$e=mysql_fetch_array($edit);
	echo "<h2 class='head'>EDIT DATA RIWAYAT PENDIDIKAN</h2>
	<form action='$aksi?module=pegawai&act=pkedit' method='post' enctype='multipart/form-data' >
	<table class='tabelform tabpad'>
	<tr>
	<td></td><td></td><td><input name='nip' type='hidden' value='$e[nip]' readonly>
	<input name='idp' type='hidden' value='$_GET[id]' readonly></td>
	</tr>
	<tr>
	<td>Nama Pekerjaan</td><td>:</td><td><input class='form-control' name='np' type='text' value='$e[nm_pekerjaan]'><span> </span></td>
	</tr>
	<tr>
	<td>Detail Pekerjaan</td><td>:</td><td><textarea class='form-control' name='dp' rows='5'>$e[d_pekerjaan]</textarea></td>
	</tr>
	<tr>
	<td></td><td></td><td><input type=submit value=Simpan>
	<input type=button value=Batal onclick=self.history.back()>
	</td>
	</tr>
	</table>
	</form>
	";
	break;
	
	case "pwd":
	echo "<h2 class='head'>GANTI PASSWORD</h2>
	<form action='$aksi?module=pegawai&act=pwd' method='post' enctype='multipart/form-data' >
	<table class='tabelform tabpad'>
	<tr>
	<td></td><td></td><td><input name='nip' type='hidden' value='$_GET[id]' readonly>
	</td>
	</tr>
	<tr>
	<td>Password Lama</td><td>:</td><td><input class='form-control' name='pl' type='password'><span> </span></td>
	</tr>
	<tr>
	<td>Password Baru</td><td>:</td><td><input class='form-control' name='pb' type='password'><span> </span></td>
	</tr>
	<td></td><td></td><td><input type=submit value=Simpan>
	<input type=button value=Batal onclick=self.history.back()>
	</td>
	</tr>
	</table>
	</form>
	";
	break;
	
	case "cari":
	$cek=$_POST['cek'];
	$t2=$_POST['t2'];
	echo"Pencariaan anda = $cek";
	$q = "SELECT * from pegawai where nama like '%$cek%' and id_ukpd LIKE '%$_SESSION[id_ukpd]%' ";
	$tampil=mysql_query($q);
    
	echo "<div>
	<input type=button value=Kembali onclick=self.history.back()>
	</div>
	<h2 class='head'>DATA PEGAWAI</h2>
	<table class='table table-bordered table-hover table-striped'>
	<thead>
  <tr>
    <td>No</td>
    <td>Nip</td>
    <td>Nama</td>
	<td>Tgl Masuk</td>
	<td>Bagian</td>
	<td>Pendidikan Terakhir</td>
	<td>Status</td>
	<td>Rumpun</td>
	<td>Kasie</td>
	<td>Level User</td>
	<td>Control</td>
  </tr>
  </thead>";
  $no=1;
  if (mysql_num_rows($tampil) == 0) {  
    echo '<p></p><p>Pencarian tidak ditemukan</p>';  
   } else {  
    echo '<p></p>';   
  while($dt=mysql_fetch_array($tampil)){
  	$pimpinan=mysql_query("select * from user_id where userid='$dt[kasie]'");
	$b=mysql_fetch_array($pimpinan);
	$pp=$b[nama];
	$st=mysql_query("select * from status where id_status='$dt[id_status]'");
	$s=mysql_fetch_array($st);
	$sts=$s[n_status];
	$pndd=mysql_query("select * from pendidikan_t where id_pendidikan='$dt[id_pendidikan]'");
	$pndk=mysql_fetch_array($pndd);
	$pndkn=$pndk[n_pendidikan];
	$rmp=mysql_query("select * from rumpun where id_rumpun='$dt[id_rumpun]'");
	$rmpn=mysql_fetch_array($rmp);
	$rmpnn=$rmpn[n_rumpun];
  echo "<tr>
    <td>$no</td>
    <td>$dt[nip]</td>
    <td>$dt[nama]</td>
	<td>".tgl_indo($dt['tgl_masuk'])."</td>
    <td>";
	$bag=mysql_query("select * from bagian where id_bag='$dt[id_bag]'");
	$b=mysql_fetch_array($bag);
	echo "$b[n_bag]";	
	echo "</td>
	<td>$pndkn</td>
	<td>$sts</td>
	<td>$rmpnn</td>
	<td>$pp</td>
	<td>";
	$lv=mysql_query("select * from user_id where userid='$dt[nip]'");
	$b=mysql_fetch_array($lv);
	echo "$b[level_user]";	
	echo "</td>
	<td><span><a href='?module=pegawai&act=edit1&id=$dt[nip]'>Edit</a></span><span>
	<a href=\"$aksi?module=pegawai&act=hapus&id=$dt[nip]\" onClick=\"return confirm('Apakah Anda benar-benar mau menghapusnya?')\">Hapus</a></span>
	<span><a href='?module=pegawai&act=detail&id=$dt[nip]'>Detail</a></span></td>
  </tr>";
  $no++;
  }}
echo "  
</table>
	";
	
	
break;

case "cariunit":
	$cek=$_POST['cek'];
	$t2=$_POST['t2'];
	$q = "SELECT * from pegawai,jabatan where 
	pegawai.id_jab=jabatan.id_jab  and id_bag like '%$cek%' ";
	$tampil=mysql_query($q);
    
	echo "<div>
	<input type=button value=Kembali onclick=self.history.back()>
	</div>
	<h2 class='head'>DATA PEGAWAI</h2>
	<table class='table table-bordered table-hover table-striped'>
	<thead>
  <tr>
    <td>No</td>
    <td>Nip</td>
    <td>Nama</td>
	<td>Tgl Masuk</td>
	<td>Pendidikan Terakhir</td>
	<td>Status</td>
	<td>Rumpun</td>
	<td>Kasie</td>
	<td>Level User</td>
	<td>Control</td>
  </tr>
  </thead>";
  $no=1;
  if (mysql_num_rows($tampil) == 0) {  
    echo '<p></p><p>Pencarian tidak ditemukan</p>';  
   } else {  
    echo '<p></p>';   
  while($dt=mysql_fetch_array($tampil)){
  	$pimpinan=mysql_query("select * from user_id where userid='$dt[kasie]'");
	$b=mysql_fetch_array($pimpinan);
	$pp=$b[nama];
	$st=mysql_query("select * from status where id_status='$dt[id_status]'");
	$s=mysql_fetch_array($st);
	$sts=$s[n_status];
	$pndd=mysql_query("select * from pendidikan_t where id_pendidikan='$dt[id_pendidikan]'");
	$pndk=mysql_fetch_array($pndd);
	$pndkn=$pndk[n_pendidikan];
	$rmp=mysql_query("select * from rumpun where id_rumpun='$dt[id_rumpun]'");
	$rmpn=mysql_fetch_array($rmp);
	$rmpnn=$rmpn[n_rumpun];
  echo "<tr>
    <td>$no</td>
    <td>$dt[nip]</td>
    <td>$dt[nama]</td>
	<td>".tgl_indo($dt['tgl_masuk'])."</td>
	<td>$pndkn</td>
	<td>$sts</td>
	<td>$rmpnn</td>
	<td>$pp</td>
	<td>$dt[level_user] $dt[n_jab]</td>
	<td><span><a href='?module=pegawai&act=edit1&id=$dt[nip]'>Edit</a></span><span>
	<a href=\"$aksi?module=pegawai&act=hapus&id=$dt[nip]\" onClick=\"return confirm('Apakah Anda benar-benar mau menghapusnya?')\">Hapus</a></span>
	<span><a href='?module=pegawai&act=detail&id=$dt[nip]'>Detail</a></span></td>
  </tr>";
  $no++;
  }}
echo "  
</table>
	";
	
	
break;

	
}


?>