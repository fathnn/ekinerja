<script>
    function validasi(){
        var nilai 			= input.nilai.value;
        var pesan = '';
         
        if (nilai == '') {
            nilai = '-Nilai tidak boleh kosong\n';
        }
         
        if (kd_skp == '') {
            pesan += '-SKP harus dipilih\n';
        }
         
        if (jam_mulai == '') {
            pesan += '-Jam Mulai tidak boleh kosong\n';
        }
         
       if (jam_akhir == '') {
            pesan += '-Jam Akhir tidak boleh kosong\n';
        }
         
        if (pesan != '') {
            alert('Maaf, ada kesalahan pengisian Formulir : \n'+pesan);
            return false;
        }
    return true
    }
</script>
<?php
error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
$aksi="modul/nilai/aksi_nilai.php";
$nip=$_SESSION['namauser'];
switch($_GET[act]){
	default:
	echo"
<a href='?module=waktu&act=awalan&nip=$_SESSION[namauser]'>Data Sudah Selesai Di Proses lanjutkan</a>";
	break;
	
	case "awalan":	
	$nip=$_SESSION['namauser'];
	$tampil1=mysql_query("select * from pegawai where nip='$_GET[nip]' ");
	while($dt=mysql_fetch_array($tampil1)){
    $nip1=$dt['nip']; 
	$nama=$dt['nama'];
	$foto=$t['foto'];
	}
  	$tm="$_POST[tahun]-$_POST[bulan]-28";
	$tgl=$tm;
	$per=explode('-',$tgl);
	$bln=$per[1];
	$thn=$per[0];
	$waktu= date ('H:i:s');
		$telat=mysql_query("select * from waktu_k where 
						 Month(waktu_k.tanggal)='$bln' 
						 and Year(waktu_k.tanggal)='$thn' and nip='$_GET[nip]'
						 order by id_waktu_k ASC  ");
	$a=mysql_fetch_array($telat);
	$wkt_tlt = $a['telat'];
	$pengukuran=mysql_query("select * from pengukuran where 
						 Month(pengukuran.tanggal)='$bln' 
						 and Year(pengukuran.tanggal)='$thn' and nip='$_GET[nip]'
						 order by id_pengukuran ASC  ");
	while($dt1=mysql_fetch_array($pengukuran)){
	$n_pengukuran=$dt1['point'] - $wkt_tlt;
	$h_pengukuran=number_format($n_pengukuran*0.7,2);
	$h_anggaran=15;
	}
	$penyerapan=mysql_query("select * from penyerapan where 
						 Month(penyerapan.tanggal)='$bln' 
						 and Year(penyerapan.tanggal)='$thn' and id_ukpd LIKE '%$_SESSION[id_ukpd]%'");
	while($dt1=mysql_fetch_array($penyerapan)){
	$n_penyerapan=$dt1['nilai'];
	}
	$disiplin=mysql_query("select * from disiplin where 
						 Month(disiplin.tanggal)='$bln' 
						 and Year(disiplin.tanggal)='$thn' and nip='$_GET[nip]'
						 order by id_disiplin ASC  ");
	while($dt2=mysql_fetch_array($disiplin)){
	$n_disiplin=$dt2['point'];
	}
	$kompetensi=mysql_query("select * from kompetensi where 
						 Month(kompetensi.tanggal)='$bln' 
						 and Year(kompetensi.tanggal)='$thn' and nip='$_GET[nip]'
						 order by id_kompetensi ASC  ");					 
	while($dt3=mysql_fetch_array($kompetensi)){
	$n_kompetensi=$dt3['point'];
	}					 					 
	$nilai1=$n_disiplin+$n_kompetensi;
	$hasil1=$nilai1*0.1;
	$anggaran=$n_penyerapan*0.2;
	$hasil2=number_format($anggaran+$h_pengukuran+$hasil1,2);					 
	echo "<h2 class='head'>PERHITUNGAN PENILAIAN</h2>
	<table class='table table-bordered table-hover table-striped'>
	<tr>
	<td>NIP <input class='form-control' name='nip' type='text' value='$nip1' readonly> NAMA <input class='form-control' name='nama' type='text' value='$nama' readonly>TANGGAL<input class='form-control' name='tanggal' type='text' value='$tgl' readonly></td>
	<td colspan='5'>
	<div class='foto'>";
	if($foto==""){
		echo "<img src='image_peg/no.jpg' width='200' height='200' />";
	} else {
	echo "<img src='image_peg/small_$foto' width='200' height='200' />";
	}
	echo "</div></td>
	<tr>
	<td colspan='5'>UNSUR YANG DI NILAI </td><td>JUMLAH</td>
	</tr>
	<tr>
	<td colspan='2'>a. Nilai Kinerja</td><td>$n_pengukuran</td><td>X</td><td>70%</td><td>$h_pengukuran</td>
	</tr>
	<tr>
	<td colspan='2'>b. Nilai Penyerapan Anggaran</td><td>$n_penyerapan</td><td>X</td><td>20%</td><td>$anggaran</td>
	</tr>
	<tr>
	<td>c. Perilaku Kerja</td><td>1. Disiplin</td><td>$n_disiplin</td><td colspan='3'></td>
	</tr>
	<tr>
	<td></td><td>2. Kompetensi</td><td>$n_kompetensi</td><td colspan='3'></td>
	</tr>
	<tr>
	<td colspan='2'>Nilai Prilaku Kerja</td><td>$nilai1</td><td>X</td><td>10%</td><td>$hasil1</td>
	</tr>
	<tr>
	<td colspan='5'>NILAI PRESTASI KERJA</td><td><bold>$hasil2</bold></td>
	</tr>
	</table>
	
	";

	break;
	
	case "cekvalidasipj";
	$tahun =  date("Y");
	$bulan = date("M");
	$tampil1=mysql_query("select * from pegawai where nip='$_GET[nip]' ");
	while($dt=mysql_fetch_array($tampil1)){
    $nip1=$dt['nip']; 
	$nama=$dt['nama'];
	$foto=$dt['foto'];
	}
  	echo"<h2 class='head'>CEK VALIDASI</h2>
	<form action='?module=nilai&act=awalan&nip=$nip1&nama=$nama' name='input' method='post' enctype='multipart/form-data' >
	<table class='table table-bordered table-hover table-striped'>
	<tr>
	<td><div class='foto'>";
	if($foto==""){
		echo "<img src='image_peg/no.jpg' width='200' height='240' />";
	} else {
	echo "<img src='image_peg/small_$foto' width='200' height='240' />";
	}
	echo "</div>NIP <input class='form-control' name='nip' type='text' value='$nip1' readonly> </td>
	</tr>
	<tr>
	<td>NAMA <input class='form-control' name='nama' type='text' value='$nama' readonly></td>
	</tr>
	<tr>
	<td>Periode<select  name='bulan'>
            	<option value='' selected='selected'>--Pilih bulan--</option>
				<option value='1'>Januari</option>
				<option value='2'>Februari</option>
				<option value='3'>Maret</option>
				<option value='4'>April</option>
				<option value='5'>Mei</option>
				<option value='6'>Juni</option>
				<option value='7'>Juli</option>
				<option value='8'>Agustus</option>
				<option value='9'>September</option>
				<option value='10'>Oktober</option>
				<option value='11'>November</option>
				<option value='12'>Desember</option>
			</select>
	<select name='tahun'>
            <option value='$tahun' class='form-control' selected='selected'>$tahun</option>";
			$saiki = 2021;
			for($l=$saiki; $l<=$saiki; $l++)
			{
				echo"<option value=",$l,">",$l,"</option>";
			}	
	echo "</select></td>
	</tr>
	<tr>
	<td colspan='6'><input type=submit value=Tampilkan></td>
	</tr>
	</table>
	</form>";
	break;
	
	case "cekvalidasimanagement";
	$tahun =  date("Y");
	$bulan = date("M");
	$tampil1=mysql_query("select * from pegawai where nip='$_GET[nip]' ");
	while($dt=mysql_fetch_array($tampil1)){
    $nip1=$dt['nip']; 
	$nama=$dt['nama'];
	$foto=$dt['foto'];
	}
  	echo"<h2 class='head'>CEK VALIDASI</h2>
	<form action='?module=nilai&act=awalanm&nip=$nip1&nama=$nama' name='input' method='post' enctype='multipart/form-data' >
	<table class='table table-bordered table-hover table-striped'>
	<tr>
	<td><div class='foto'>";
	if($foto==""){
		echo "<img src='image_peg/no.jpg' width='200' height='240' />";
	} else {
	echo "<img src='image_peg/small_$foto' width='200' height='240' />";
	}
	echo "</div>NIP <input class='form-control' name='nip' type='text' value='$nip1' readonly> </td>
	</tr>
	<tr>
	<td>NAMA <input class='form-control' name='nama' type='text' value='$nama' readonly></td>
	</tr>
	<tr>
	<td>Periode<select  name='bulan'>
            	<option value='' selected='selected'>--Pilih bulan--</option>
				<option value='1'>Januari</option>
				<option value='2'>Februari</option>
				<option value='3'>Maret</option>
				<option value='4'>April</option>
				<option value='5'>Mei</option>
				<option value='6'>Juni</option>
				<option value='7'>Juli</option>
				<option value='8'>Agustus</option>
				<option value='9'>September</option>
				<option value='10'>Oktober</option>
				<option value='11'>November</option>
				<option value='12'>Desember</option>
			</select>
	<select name='tahun'>
            <option value='$tahun' class='form-control' selected='selected'>$tahun</option>";
			$saiki = 2018;
			for($l=$saiki; $l<=2030; $l++)
			{
				echo"<option value=",$l,">",$l,"</option>";
			}	
	echo "</select></td>
	</tr>
	<tr>
	<td colspan='6'><input type=submit value=Tampilkan></td>
	</tr>
	</table>
	</form>";
	break;
	
	case "awalanm":	
	$nip=$_SESSION['namauser'];
	$ambil=mysql_query("select * from pegawai where nip='$_GET[nip]'");
	$t=mysql_fetch_array($ambil);
	
    $nip1=$t['nip']; 
	$nama=$t['nama'];
	$foto=$t['foto'];
	$bagian=$t['id_bag'];
	$jabatan=$t['id_jab'];
	$skpd=$t['id_skpd'];
	$ukpd=$t['id_ukpd'];
  	$tm="$_POST[tahun]-$_POST[bulan]-28";
	$tgl=$tm;
	$per=explode('-',$tgl);
	$bln=$per[1];
	$thn=$per[0];
	$waktu= date ('H:i:s');					 
	$pengukuran=mysql_query("select * from pengukuran where 
						 Month(pengukuran.tanggal)='$bln' 
						 and Year(pengukuran.tanggal)='$thn' and nip='$_GET[nip]'
						 order by id_pengukuran ASC  ");
	while($dt1=mysql_fetch_array($pengukuran)){
	$n_pengukuran=$dt1['point'];
	$h_pengukuran=number_format($n_pengukuran*0.7,2);
	$h_anggaran=15;
	}
	$penyerapan=mysql_query("select * from penyerapan where 
						 Month(penyerapan.tanggal)='$bln' 
						 and Year(penyerapan.tanggal)='$thn' and id_ukpd LIKE '%$_SESSION[id_ukpd]%'");
	while($dt1=mysql_fetch_array($penyerapan)){
	$n_penyerapan=$dt1['nilai'];
	$id_penyerapan=$dt1['id_penyerapan'];
	}
	$disiplin=mysql_query("select * from disiplin where 
						 Month(disiplin.tanggal)='$bln' 
						 and Year(disiplin.tanggal)='$thn' and nip='$_GET[nip]'
						 order by id_disiplin ASC  ");
	while($dt2=mysql_fetch_array($disiplin)){
	$n_disiplin=$dt2['point'];
	}
	$kompetensi=mysql_query("select * from kompetensi where 
						 Month(kompetensi.tanggal)='$bln' 
						 and Year(kompetensi.tanggal)='$thn' and nip='$_GET[nip]'
						 order by id_kompetensi ASC  ");					 
	while($dt3=mysql_fetch_array($kompetensi)){
	$n_kompetensi=$dt3['point'];
	}	
	$waktu=mysql_query("select * from waktu_k where 
						 Month(waktu_k.tanggal)='$bln' 
						 and Year(waktu_k.tanggal)='$thn' and nip='$_GET[nip]'
						 order by id_waktu_k ASC  ");
	while($wkt=mysql_fetch_array($waktu)){
	$alpha=$wkt['alpha'];
	$sakit=$wkt['sakit'];
	$telat=$wkt['telat'];
	$h_pengukuran=number_format($n_pengukuran*0.7,2);
	$h_anggaran=15;
	}					 
	$nilai1=$n_disiplin+$n_kompetensi;
	$hasil1=$nilai1*0.1;
	$anggaran=$n_penyerapan*0.2;
	$maks=$anggaran+70+10;
	$hasil2=number_format($anggaran+$h_pengukuran+$hasil1,2);
	$pnd=mysql_query("select * from pendidikan_t where id_pendidikan='$t[id_pendidikan]'");
	$b=mysql_fetch_array($pnd);
	$pendidikan=$b['n_pendidikan'];
	$rm=mysql_query("select * from rumpun where id_rumpun='$t[id_rumpun]'");
	$b=mysql_fetch_array($rm);
	$rumpun=$b['nilai'];
	$rumpun_j=$b['n_rumpun'];
	$st=mysql_query("select * from status where id_status='$t[id_status]'");
	$b=mysql_fetch_array($st);
	$status=$b['nilai'];
	$id_status=$b['id_status'];
	$tmp =new datetime($t['tgl_masuk']);
	$today = new datetime($tgl);
	$masa= $today->diff($tmp);
	$tahun= $masa->y;
	$bulan= $masa->m;
	$mk=($tahun*12)+$bulan; 
	$gapok=''; 
	if ($pendidikan=="")
	echo "TMP Belum Di Input";
	elseif($pendidikan == 'SD' and $mk <= 24 )
	$gapok=2719298;
	elseif($pendidikan === 'SD' and $mk >= 25 and $mk <= 48)
	$gapok=2787281;
	elseif($pendidikan === 'SD' and  $mk >= 49 and $mk <= 72 )
	$gapok=2856963;
	elseif($pendidikan == 'SD' and $mk >= 73 and $mk <= 96 )
	$gapok=2928387;
	elseif($pendidikan === 'SD' and $mk >= 97 and $mk <= 120)
	$gapok=3001596;
	elseif($pendidikan === 'SD' and $mk >= 121 and $mk <= 144 )
	$gapok=3076636;
	elseif($pendidikan == 'SD' and $mk >= 145 and $mk <= 168 )
	$gapok=3153552;
	elseif($pendidikan === 'SD' and $mk >= 169 and $mk <= 192)
	$gapok=3232391;
	elseif($pendidikan === 'SD' and $mk >= 193 and $mk <= 216 )
	$gapok=33313201;
	elseif($pendidikan == 'SD' and $mk >= 217 and $mk <= 240 )
	$gapok=33396031;
	elseif($pendidikan === 'SD' and $mk >= 241 and $mk <= 264)
	$gapok=3480932;
	elseif($pendidikan === 'SD' and $mk >= 265 and $mk <= 288 )
	$gapok=3567955;
	elseif($pendidikan == 'SD' and $mk >= 289 and $mk <= 312 )
	$gapok=3657154;
	elseif($pendidikan === 'SD' and $mk >= 313 and $mk <= 336)
	$gapok=3748583;
	elseif($pendidikan === 'SD' and $mk >= 337 and $mk <= 360 )
	$gapok=3842297;
	elseif($pendidikan == 'SD' and $mk > 361 and $mk <= 384 )
	$gapok=3938355;
	elseif($pendidikan == 'SD' and $mk > 385 and $mk <= 408)
	$gapok=4036814;
	
	elseif($pendidikan == 'SMP' and $mk <= 24)
	$gapok=3263158;
	elseif($pendidikan === 'SMP' and $mk >= 25 and $mk <= 48)
	$gapok=3344737;
	elseif($pendidikan === 'SMP' and $mk >= 49 and $mk <= 72 )
	$gapok=3428355;
	elseif($pendidikan == 'SMP' and $mk >= 73 and $mk <= 96 )
	$gapok=3514064;
	elseif($pendidikan === 'SMP' and $mk >= 97 and $mk <= 120)
	$gapok=3601916;
	elseif($pendidikan === 'SMP' and $mk >= 121 and $mk <= 144 )
	$gapok=3691964;
	elseif($pendidikan == 'SMP' and $mk >= 145 and $mk <= 168 )
	$gapok=3784263;
	elseif($pendidikan === 'SMP' and $mk >= 169 and $mk <= 192)
	$gapok=3878869;
	elseif($pendidikan === 'SMP' and $mk >= 193 and $mk <= 216 )
	$gapok=3975841;
	elseif($pendidikan == 'SMP' and $mk >= 217 and $mk <= 240 )
	$gapok=4075237;
	elseif($pendidikan === 'SMP' and $mk >= 241 and $mk <= 264)
	$gapok=4177118;
	elseif($pendidikan === 'SMP' and $mk >= 265 and $mk <= 288 )
	$gapok=4281546;
	elseif($pendidikan == 'SMP' and $mk >= 289 and $mk <= 312 )
	$gapok=4388585;
	elseif($pendidikan === 'SMP' and $mk >= 313 and $mk <= 336)
	$gapok=4498299;
	elseif($pendidikan === 'SMP' and $mk >= 337 and $mk <= 360 )
	$gapok=4610757;
	elseif($pendidikan == 'SMP' and $mk >= 361 and $mk <= 384 )
	$gapok=4726026;
	elseif($pendidikan == 'SMP' and $mk >= 385 and $mk <= 408)
	$gapok=4844176;
	
	elseif($pendidikan == 'SLTA' and $mk <= 24)
	$gapok=3807018;
	elseif($pendidikan === 'SLTA' and $mk >= 25 and $mk <= 48)
	$gapok=3902193;
	elseif($pendidikan === 'SLTA' and $mk >= 49 and $mk <= 72 )
	$gapok=3999748;
	elseif($pendidikan == 'SLTA' and $mk >= 73 and $mk <= 96 )
	$gapok=4099742;
	elseif($pendidikan === 'SLTA' and $mk >= 97 and $mk <= 120)
	$gapok=4202235;
	elseif($pendidikan === 'SLTA' and $mk >= 121 and $mk <= 144 )
	$gapok=4307291;
	elseif($pendidikan == 'SLTA' and $mk >= 145 and $mk <= 168 )
	$gapok=4414973;
	elseif($pendidikan === 'SLTA' and $mk >= 169 and $mk <= 192)
	$gapok=4525348;
	elseif($pendidikan === 'SLTA' and $mk >= 193 and $mk <= 216 )
	$gapok=4638481;
	elseif($pendidikan == 'SLTA' and $mk >= 217 and $mk <= 240 )
	$gapok=4754443;
	elseif($pendidikan === 'SLTA' and $mk >= 241 and $mk <= 264)
	$gapok=4873304;
	elseif($pendidikan === 'SLTA' and $mk >= 265 and $mk <= 288 )
	$gapok=4995137;
	elseif($pendidikan == 'SLTA' and $mk >= 289 and $mk <= 312 )
	$gapok=5120015;
	elseif($pendidikan === 'SLTA' and $mk >= 313 and $mk <= 336)
	$gapok=5248016;
	elseif($pendidikan === 'SLTA' and $mk >= 337 and $mk <= 360 )
	$gapok=5379216;
	elseif($pendidikan == 'SLTA' and $mk >= 361 and $mk <= 384 )
	$gapok=5513697;
	elseif($pendidikan == 'SLTA' and $mk > 385 and $mk <= 408)
	$gapok=5651539;
	
	elseif($pendidikan == 'D III / D IV' and $mk <= 24 )
	$gapok=4078947;
	elseif($pendidikan === 'D III / D IV' and $mk >= 25 and $mk <= 48)
	$gapok=4180921;
	elseif($pendidikan === 'D III / D IV' and $mk >= 49 and $mk <= 72 )
	$gapok=4285444;
	elseif($pendidikan == 'D III / D IV' and $mk >= 73 and $mk <= 96 )
	$gapok=4392580;
	elseif($pendidikan === 'D III / D IV' and $mk >= 97 and $mk <= 120)
	$gapok=4502395;
	elseif($pendidikan === 'D III / D IV' and $mk >= 121 and $mk <= 144 )
	$gapok=4614955;
	elseif($pendidikan == 'D III / D IV' and $mk >= 145 and $mk <= 168 )
	$gapok=4730328;
	elseif($pendidikan === 'D III / D IV' and $mk >= 169 and $mk <= 192)
	$gapok=4848587;
	elseif($pendidikan === 'D III / D IV' and $mk >= 193 and $mk <= 216 )
	$gapok=4969801;
	elseif($pendidikan == 'D III / D IV' and $mk >= 217 and $mk <= 240 )
	$gapok=5094046;
	elseif($pendidikan === 'D III / D IV' and $mk >= 241 and $mk <= 264)
	$gapok=5221937;
	elseif($pendidikan === 'D III / D IV' and $mk >= 265 and $mk <= 288 )
	$gapok=5351932;
	elseif($pendidikan == 'D III / D IV' and $mk >= 289 and $mk <= 312 )
	$gapok=5485731;
	elseif($pendidikan === 'D III / D IV' and $mk >= 313 and $mk <= 336)
	$gapok=5622874;
	elseif($pendidikan === 'D III / D IV' and $mk >= 337 and $mk <= 360 )
	$gapok=5763446;
	elseif($pendidikan == 'D III / D IV' and $mk > 361 and $mk <= 384 )
	$gapok=5907532;
	elseif($pendidikan == 'D III / D IV' and $mk >= 385 and $mk <= 408)
	$gapok=6055220;
	
	elseif($pendidikan == 'S1' and $mk <= 24 )
	$gapok=4350877;
	elseif($pendidikan === 'S1' and $mk >= 25 and $mk <= 48)
	$gapok=4459649;
	elseif($pendidikan === 'S1' and $mk >= 49 and $mk <= 72 )
	$gapok=4571140;
	elseif($pendidikan == 'S1' and $mk >= 73 and $mk <= 96 )
	$gapok=4685419;
	elseif($pendidikan === 'S1' and $mk >= 97 and $mk <= 120)
	$gapok=4802554;
	elseif($pendidikan === 'S1' and $mk >= 121 and $mk <= 144 )
	$gapok=4922618;
	elseif($pendidikan == 'S1' and $mk >= 145 and $mk <= 168 )
	$gapok=5045684;
	elseif($pendidikan === 'S1' and $mk >= 169 and $mk <= 192)
	$gapok=5171826;
	elseif($pendidikan === 'S1' and $mk >= 193 and $mk <= 216 )
	$gapok=5301121;
	elseif($pendidikan == 'S1' and $mk >= 217 and $mk <= 240 )
	$gapok=5433649;
	elseif($pendidikan === 'S1' and $mk >= 241 and $mk <= 264)
	$gapok=5569491;
	elseif($pendidikan === 'S1' and $mk >= 265 and $mk <= 288 )
	$gapok=5708728;
	elseif($pendidikan == 'S1' and $mk >= 289 and $mk <= 312 )
	$gapok=5851446;
	elseif($pendidikan === 'S1' and $mk >= 313 and $mk <= 336)
	$gapok=5997732;
	elseif($pendidikan === 'S1' and $mk >= 337 and $mk <= 360 )
	$gapok=6147676;
	elseif($pendidikan == 'S1' and $mk >= 361 and $mk <= 384 )
	$gapok=6301367;
	elseif($pendidikan == 'S1' and $mk >= 385 and $mk <= 408)
	$gapok=6458902;
	
	elseif($pendidikan == 'S2 / dr./ drg./ Apoteker/ Ners' and $mk <= 24 )
	$gapok=4622807;
	elseif($pendidikan === 'S2 / dr./ drg./ Apoteker/ Ners' and $mk >= 25 and $mk <= 48)
	$gapok=4738377;
	elseif($pendidikan === 'S2 / dr./ drg./ Apoteker/ Ners' and $mk >= 49 and $mk <= 72 )
	$gapok=4856837;
	elseif($pendidikan == 'S2 / dr./ drg./ Apoteker/ Ners' and $mk >= 73 and $mk <= 96 )
	$gapok=4978258;
	elseif($pendidikan === 'S2 / dr./ drg./ Apoteker/ Ners' and $mk >= 97 and $mk <= 120)
	$gapok=5102714;
	elseif($pendidikan === 'S2 / dr./ drg./ Apoteker/ Ners' and $mk >= 121 and $mk <= 144 )
	$gapok=5230282;
	elseif($pendidikan == 'S2 / dr./ drg./ Apoteker/ Ners' and $mk >= 145 and $mk <= 168 )
	$gapok=5361039;
	elseif($pendidikan === 'S2 / dr./ drg./ Apoteker/ Ners' and $mk >= 169 and $mk <= 192)
	$gapok=5495065;
	elseif($pendidikan === 'S2 / dr./ drg./ Apoteker/ Ners' and $mk >= 193 and $mk <= 216 )
	$gapok=5632441;
	elseif($pendidikan == 'S2 / dr./ drg./ Apoteker/ Ners' and $mk >= 217 and $mk <= 240 )
	$gapok=5773253;
	elseif($pendidikan === 'S2 / dr./ drg./ Apoteker/ Ners' and $mk >= 241 and $mk <= 264)
	$gapok=5917584;
	elseif($pendidikan === 'S2 / dr./ drg./ Apoteker/ Ners' and $mk >= 265 and $mk <= 288 )
	$gapok=6065523;
	elseif($pendidikan == 'S2 / dr./ drg./ Apoteker/ Ners' and $mk >= 289 and $mk <= 312 )
	$gapok=6217161;
	elseif($pendidikan === 'S2 / dr./ drg./ Apoteker/ Ners' and $mk >= 313 and $mk <= 336)
	$gapok=6372591;
	elseif($pendidikan === 'S2 / dr./ drg./ Apoteker/ Ners' and $mk >= 337 and $mk <= 360 )
	$gapok=6531905;
	elseif($pendidikan == 'S2 / dr./ drg./ Apoteker/ Ners' and $mk >= 361 and $mk <= 384 )
	$gapok=6695203;
	elseif($pendidikan == 'S2 / dr./ drg./ Apoteker/ Ners' and $mk >= 385 and $mk <= 408)
	$gapok=6862583;
	
	elseif($pendidikan == 'S3 / dr. Spesialis' and $mk <= 24)
	$gapok=4894737;
	elseif($pendidikan === 'S3 / dr. Spesialis' and $mk >= 25 and $mk <= 48)
	$gapok=5017105;
	elseif($pendidikan === 'S3 / dr. Spesialis' and $mk >= 49 and $mk <= 72 )
	$gapok=5142533;
	elseif($pendidikan == 'S3 / dr. Spesialis' and $mk >= 73 and $mk <= 96 )
	$gapok=5271096;
	elseif($pendidikan === 'S3 / dr. Spesialis' and $mk >= 97 and $mk <= 120)
	$gapok=5402874;
	elseif($pendidikan === 'S3 / dr. Spesialis' and $mk >= 121 and $mk <= 144 )
	$gapok=5537945;
	elseif($pendidikan == 'S3 / dr. Spesialis' and $mk >= 145 and $mk <= 168 )
	$gapok=5676394;
	elseif($pendidikan === 'S3 / dr. Spesialis' and $mk >= 169 and $mk <= 192)
	$gapok=5818304;
	elseif($pendidikan === 'S3 / dr. Spesialis' and $mk >= 193 and $mk <= 216 )
	$gapok=5963762;
	elseif($pendidikan == 'S3 / dr. Spesialis' and $mk >= 217 and $mk <= 240 )
	$gapok=6112856;
	elseif($pendidikan === 'S3 / dr. Spesialis' and $mk >= 241 and $mk <= 264)
	$gapok=6265677;
	elseif($pendidikan === 'S3 / dr. Spesialis' and $mk >= 265 and $mk <= 288 )
	$gapok=6422319;
	elseif($pendidikan == 'S3 / dr. Spesialis' and $mk >= 289 and $mk <= 312 )
	$gapok=6582877;
	elseif($pendidikan === 'S3 / dr. Spesialis' and $mk >= 313 and $mk <= 336)
	$gapok=6747449;
	elseif($pendidikan === 'S3 / dr. Spesialis' and $mk >= 337 and $mk <= 360 )
	$gapok=6916135;
	elseif($pendidikan == 'S3 / dr. Spesialis' and $mk >= 361 and $mk <= 384 )
	$gapok=7089038;
	elseif($pendidikan == 'S3 / dr. Spesialis' and $mk >= 385 and $mk <= 408)
	$gapok=7266264;
	else
	
	$gaji=number_format($gapok,0);
	$bruto=$gapok*$status;
	$bruto1=number_format($bruto,0);
	$tunjangan=$gapok*$rumpun;
	$tunjangan1=number_format($tunjangan,0);
	$tunjanganprolehan=$tunjangan*$jumlahx/100;
	$tun_pendapatan=number_format($tunjanganprolehan,0);
	$diterima=$bruto+$tunjangan;
	$pendapatan=number_format($diterima,0);					 
	echo "<h2 class='head'>PERHITUNGAN PENILAIAN</h2>
	<form action='$aksi?module=nilai&act=inputm' name='input' method='post' enctype='multipart/form-data' >
	<table class='table table-bordered table-hover table-striped'>
	<tr>
	<td >NIP <input class='form-control' name='nip' type='text' value='$nip1' readonly>
	<input class='form-control' name='bagian' type='hidden' value='$bagian' >
	<input class='form-control' name='jabatan' type='hidden' value='$jabatan' > 
	NAMA <input class='form-control' name='nama' type='text' value='$nama' readonly>
	TANGGAL<input class='form-control' name='tanggal' type='text' value='$tgl' readonly>
	Masa Kerja<input class='form-control' name='masa_kerja' type='text' value='$tahun Tahun $bulan Bulan' readonly>
	<input class='form-control' name='id_skpd' type='hidden' value='$skpd' >
	<input class='form-control' name='id_ukpd' type='hidden' value='$ukpd' >
	Rumpun Jabatan<input class='form-control' name='rumpun' type='text' value='$rumpun_j' readonly>
	<input class='form-control' name='jabatan' type='hidden' value='$jabatan' >
	Gaji Bruto<input class='form-control' type='text' value='Rp.$bruto1' readonly>
	<input class='form-control' name='bruto' type='hidden' value='$bruto' >
	<input class='form-control' name='bagian' type='hidden' value='$bagian' >
	Tunjangan<input class='form-control' type='text' value='Rp.$tunjangan1' readonly>
	<input class='form-control' name='tunjangan' type='hidden' value='$tunjangan' >
	<input class='form-control' name='alpha' type='hidden' value='$alpha'>
	<input class='form-control' name='gapok' type='hidden' value='$gapok' >
	<input class='form-control' name='id_status' type='hidden' value='$id_status' >
	<input class='form-control' name='id_penyerapan' type='hidden' value='$id_penyerapan' ></td>
	<td colspan='6'>
	<div class='foto'>";
	if($foto==""){
		echo "<img src='image_peg/no.jpg' width='250' height='340' />";
	} else {
	echo "<img src='image_peg/small_$foto' width='250' height='340' />";
	}
	echo "</div>
	</td>
	<tr>
	<td colspan='5'>UNSUR YANG DI NILAI </td><td>JUMLAH</td><td>Validasi</td>
	</tr>
	<tr>
	<td colspan='2'>a. Sasaran Kerja Pegawai (SKP)</td><td>$n_pengukuran</td><td>X</td><td>70%</td><td>$h_pengukuran</td><td> <input class='form-control' name='nskp' required type='text'>Nilai Maksimum <font color='red'><strong>70</strong></font></td>
	</tr>
	<tr>
	<td colspan='2'>b. Nilai Penyerapan Anggaran</td><td>$n_penyerapan</td><td>X</td><td>20%</td><td colspan='2'>$anggaran</td>
	</tr>
	<tr>
	<td>c. Perilaku Kerja</td><td>1. Disiplin</td><td>$n_disiplin</td><td colspan='4'></td>
	</tr>
	<tr>
	<td></td><td>2. Kompetensi</td><td>$n_kompetensi</td><td colspan='4'></td>
	</tr>
	<tr>
	<td colspan='2'>Nilai Prilaku Kerja</td><td>$nilai1</td><td>X</td><td>10%</td><td>$hasil1 </td><td><input class='form-control' name='nprilaku' required type='text'> Nilai Maksimum <font color='red'><strong>10</strong></font></td>
	</tr>
	<tr>
	<td colspan='5'>NILAI PRESTASI KERJA</td><td colspan='2'><h4>$hasil2</h4> Nilai Maksimal Bulan Ini <font color='red'><strong>$maks%</strong></td>
	</tr>
	<tr>
	<td colspan='5'></td><td colspan='2'><input class='form-control' name='penilai' value='$nip' type='hidden'>
	</font></td>
	</tr>
	<tr>
	<td colspan='7'><input type=submit value=Simpan></td>
	</tr>
	</table>
	</form>
	<hr>";
	echo"
	<table class='table table-bordered table-hover table-striped'>
	<thead>
  <tr>
  <td>Tanggal</td>
    <td>Nip</td>
    <td>Nama Pegawai</td>
	<td>Nilai</td>
	<td>Tunjangan Validasi</td>
	<td>Control</td>
  </tr>
  </thead>";
  $no=1;
  	$nilai=mysql_query("select * from pencapaian where 
						 Month(pencapaian.tanggal)='$bln' 
						 and Year(pencapaian.tanggal)='$thn' and nip='$_GET[nip]'");
  while($dt=mysql_fetch_array($nilai)){
  $nilaiv=$dt['nskp']+$dt['nprilaku']+$anggaran;
  $tun_validasi=$dt['tunjangan']*$nilaiv/100;
  $tun_finish=number_format($tun_validasi,0);
  echo "<tr>
  <td>$dt[tanggal]</td>
    <td>$dt[nip]</td>
    <td>$dt[nama]</td>
	 <td>$nilaiv</td>
	 <td>Rp.$tun_finish</td>
	<td><span>
	<a href=\"$aksi?module=nilai&act=hapus&id_pencapaian=$dt[id_pencapaian]\" onClick=\"return confirm('Apakah Anda benar-benar mau menghapusnya?')\">Hapus</a></span>
	</td>
  </tr>";
  $no++;
  }
echo "  
</table>
	";
	

	break;
	
	
	
	case "penambahan":
	$tampil1=mysql_query("select * from pegawai where nip='$_GET[nip]' ");
	while($dt=mysql_fetch_array($tampil)){
	$nip1=$dt['nip'];
	}
	$tgl= date('Y-m-d');
	echo "<h2 class='head'>Entry Penambahan Waktu Efektif</h2>
	<form action='$aksi?module=waktu&act=input_t' method='post' enctype='multipart/form-data' >
	<table class='tabelform tabpad'>
	
	<tr>
	<td>Nip</td>
	<td>:</td>
	<td><input class='form-control' name='nip' type='text' value='$_GET[nip]' readonly > </td>
	<td></td>
	</tr>
	
	<tr>
	<td>Tanggal</td>
	<td>:</td>
	<td><input class='form-control' name='tanggal' type='text' value='$tgl' readonly></td>
	<td></td>
	</tr>
	
	<tr>
	<td>Cuti Sakit</td>
	<td>:</td>
	<td><input class='form-control' name='c_sakit_t' type='text'></td>
	<td>Hari</td>
	</tr>
	
	<tr>
	<td>Cuti Alasan Penting < 6 hari</td>
	<td>:</td>
	<td><input class='form-control' name='c_alasan_t' type='text'></td>
	<td>Hari</td>
	</tr>
	
	<tr>
	<td>Cuti Tahunan</td>
	<td>:</td>
	<td><input class='form-control' name='c_tahunan_t' type='text'></td>
	<td>Hari</td>
	</tr>
	
	<tr>
	<td>Diklat</td>
	<td>:</td>
	<td><input class='form-control' name='diklat' type='text'></td>
	<td>Hari</td>
	</tr>
	
	<tr>
	<td>SPD</td>
	<td>:</td>
	<td><input class='form-control' name='spd' type='text'></td>
	<td>Hari</td>
	</tr>
	
	<tr>
	<td>Haji</td>
	<td>:</td>
	<td><input class='form-control' name='haji' type='text'></td>
	<td>Hari</td>
	</tr>
	
	<tr>
	<td></td>
	<td></td>
	<td><input type=submit value=Simpan>
	<input type=button value=Batal onclick=self.history.back()>
	</td>
	</tr>
	
	</table>
	</form>
	";
	break;
	
	
	case "pengurangan":
	$tampil1=mysql_query("select * from pegawai where nip='$_GET[nip]' ");
	while($dt=mysql_fetch_array($tampil)){
	$nip1=$dt['nip'];
	}
	$tgl= date('Y-m-d');
	echo "<h2 class='head'>Entry Pengurangan Waktu Efektif</h2>
	<form action='$aksi?module=waktu&act=input_k' method='post' enctype='multipart/form-data' >
	<table class='tabelform tabpad'>
	
	<tr>
	<td>Nip</td>
	<td>:</td>
	<td><input class='form-control' name='nip' type='text' value='$_GET[nip]' readonly > </td>
	<td></td>
	</tr>
	
    <tr>
	<td>Tanggal</td>
	<td>:</td>
	<td><input class='form-control' name='tanggal' type='text' value='$tgl' readonly></td>
	<td></td>
	</tr>
	
	<tr>
	<td>Sakit</td>
	<td>:</td>
	<td><input class='form-control' name='sakit' type='text'> </td>
	<td>Hari</td>
	</tr>
	
	<tr>
	<td>Alpha</td>
	<td>:</td>
	<td><input class='form-control' name='alpha' type='text'> </td>
	<td>Hari</td>
	</tr>
	
		
	<tr>
	<td>Izin</td>
	<td>:</td>
	<td><input class='form-control' name='izin' type='text'></td>
	<td>Hari</td>
	</tr>
	
	<tr>
	<td>Izin Setengah Hari</td>
	<td>:</td>
	<td><input class='form-control' name='izin_s' type='text'></td>
	<td>Hari</td>
	</tr>
	
	<tr>
	<td>Meninggal</td>
	<td>:</td>
	<td><input class='form-control' name='meninggal' type='text'></td>
	<td>Hari</td>
	</tr>
	
	<tr>
	<td>Telat</td>
	<td>:</td>
	<td><input class='form-control' name='telat' type='text'> </td>
	<td>Menit</td>
	</tr>
	
	<tr>
	<td>Cuti Sakit</td>
	<td>:</td>
	<td><input class='form-control' name='c_sakit_k' type='text'></td>
	<td>Hari</td>
	</tr>
	
	<tr>
	<td>Cuti Alasan Penting >= 6 hari</td>
	<td>:</td>
	<td><input class='form-control' name='c_alasan_k' type='text'></td>
	<td>Hari</td>
	</tr>
	
	<tr>
	<td>Cuti Pesalinan</td>
	<td>:</td>
	<td><input class='form-control' name='c_persalinan_k' type='text'></td>
	<td>Hari</td>
	</tr>
	
	<tr>
	<td>Cuti Besar</td>
	<td>:</td>
	<td><input class='form-control' name='c_besar_k' type='text'></td>
	<td>Hari</td>
	</tr>
	
	<tr>
	<td></td>
	<td></td>
	<td><input type=submit value=Simpan>
	<input type=button value=Batal onclick=self.history.back()>
	</td>
	</tr>
	
	</table>
	</form>
	";
	break;
	
	
	case "pengukuran":
	echo"<h2 class='head'>Pengukuran</h2>";
	$tampil1=mysql_query("select * from pegawai where nip='$_GET[nip]' ");
	while($dt=mysql_fetch_array($tampil)){
	$nip1=$dt['nip'];
	$nama=$dt['nama'];
	}
	$sa=$nama;
  $tgl= date('Y-m-d');
	$per=explode('-',$tgl);
	$bln=$per[1];
	$thn=$per[0];
	$waktu= date ('H:i:s');
	$tampil=mysql_query("select * from pengukuran where 
						 Month(pengukuran.tanggal)='$bln' 
						 and Year(pengukuran.tanggal)='$thn' and nip='$_GET[nip]'
						 order by id_pengukuran ASC  ");
						 
	$kinerja_utama=mysql_query("select SUM(point) from kinerja where 
						 Month(kinerja.tanggal)='$bln' 
						 and Year(kinerja.tanggal)='$thn' and nip='$_GET[nip]'
						 order by id_kinerja ASC ");
        $point_kinerja=mysql_fetch_array($kinerja_utama);
        $point_utama=$point_kinerja[0];
		
		$kinerja_tambahan=mysql_query("select SUM(point) from kinerja_t where 
						 Month(kinerja_t.tanggal)='$bln' 
						 and Year(kinerja_t.tanggal)='$thn' and nip='$_GET[nip]'
						 order by id_kinerja_t ASC ");
		$point_kinerja=mysql_fetch_array($kinerja_tambahan);
        $point_tambahan=$point_kinerja[0];
		
		$kreatifitas=mysql_query("select SUM(point) from kreatifitas where 
						 Month(kreatifitas.tanggal)='$bln' 
						 and Year(kreatifitas.tanggal)='$thn' and nip='$_GET[nip]'
						 order by id_kreatifitas ASC ");
		$point_kinerja=mysql_fetch_array($kreatifitas);
        $point_kreatifitas=$point_kinerja[0];
		$jumlah_point=$point_utama+$point_tambahan+$point_kreatifitas;
		$jh=300;
		$maksimal=$waktu1*$jh;
		$nilai=$waktu1;
		$we=min($jumlah_point,$nilai)/$nilai*100;
        $s=number_format($we,2);
	echo"
	<form action='$aksi?module=waktu&act=score' method='post' enctype='multipart/form-data' >
	<table class=''>
	<tr>
	<td>NIP</td>
	<td>:</td>
	<td> $_GET[nip]<input class='form-control' name='nip' type='text' value='$_GET[nip]' hidden > </td>
	<td></td>
	</tr>
	<tr>
	<td>CAPAIAN WAKTU EFEKTIVITAS UTAMA</td>
	<td>:</td>
	<td> $point_utama<input class='form-control' name='nilai_utama' type='text' value='$point_utama' hidden > </td>
	<td></td>
	</tr>
	<tr>
	<td>CAPAIAN WAKTU EFEKTIVITAS TAMBAHAN</td>
	<td>:</td>
	<td> $point_tambahan<input class='form-control' name='nilai_tambahan' type='text' value='$point_tambahan' hidden > <input class='form-control' name='tanggal' type='text' value='$tgl' hidden > </td>
	<td></td>
	</tr>
	<tr>
	<td>CAPAIAN WAKTU KREATIVITAS</td>
	<td>:</td>
	<td> $point_kreatifitas<input class='form-control' name='nilai_kreatifitas' type='text' value='$point_kreatifitas' hidden > </td>
	<td></td>
	</tr>
	<tr>
	<td>TOTAL CAPAIAN WAKTU EFEKTIVITAS</td>
	<td>:</td>
	<td> $jumlah_point<input class='form-control' name='jumlah' type='text' value='$jumlah_point' hidden > </td>
	<td></td>
	</tr>
	<tr>
	<td colspan='4'><hr></td>
	</tr>
	<tr>
	<td>Jumlah Hari Kerja</td>
	<td>:</td>
	<td><input class='form-control' name='hari' type='text' > </td>
	<td></td>
	</tr>
	<tr>
	<td>Jam Kerja</td>
	<td>:</td>
	<td>$jh Menit/Hari <input type=submit value=Simpan> </td>
	<td></td>
	</tr>
	</table>
	</form>
	
	<table class='table table-bordered table-hover table-striped'>
	<thead>
  <tr>
  <td>No</td>
  <td>ID Pengukuran</td>
  <td>Tanggal</td>
    <td>Nip</td>
	<td>Nilai Kinerja Utama</td>
	<td>Nilai kinerja Tambahan</td>
	<td>Nilai Kreatifitas</td>
	<td>Total Kinerja</td>
	<td>Hari Kerja</td>
	<td>Maximal Waktu</td>
	<td>Point</td>
  </tr>
  </thead>";
  $no=1;
  while($dt=mysql_fetch_array($tampil)){
  $vol=$dt['jumlah']/$time;
  echo "<tr>
  <td>$no</td>
  <td>$dt[id_pengukuran]</td>
  <td>$dt[tanggal]</td>
    <td>$dt[nip]</td>
	 <td>$dt[nilai_utama]</td>
	 <td>$dt[nilai_tambahan]</td>
	<td>$dt[nilai_kreatifitas]</td>
	<td>$dt[jumlah]</td>
	<td>$dt[hari]</td>
	<td>$dt[max_waktu]</td>
	<td>$dt[point]</td>
  </tr>";
  $no++;
  }
echo "  
</table>
	
	";
  
		
	break;
	
	case "lihat":
	echo"Tanggal : 
	<form action='?module=kinerja&act=cari' method='POST' ><table border='0'>
	<tr>
	<td>
	<input class='form-control' name='t1' width='60' type='date' ></td><td> s/d <input class='form-control'  width='60' name='t2' type='date' > <input type=submit value='Tampilkan' > </td>
	</tr>
	</table>
	</form>"; 	
	$nip=$_SESSION['namauser'];
	$tgl= date('Y-m-d');
	$per=explode('-',$tgl);
	$bln=$per[1];
	$thn=$per[0];
	$waktu= date ('H:i:s');
	$tampil=mysql_query("select * from kinerja where 
						 Month(kinerja.tanggal)='$bln' 
						 and Year(kinerja.tanggal)='$thn' and nip='$_GET[nip]'
						 order by id_kinerja ASC  ");
	echo "<h2 class='head'>DATA KINERJA UNIT USER</h2>
	<div>
	<input type=button value=Kembali onclick=self.history.back()>
	</div>
	
	<table class='table table-bordered table-hover table-striped'>
	<thead>
  <tr>
  <td>No</td>
  <td>ID Kinerja</td>
  <td>Tanggal</td>
    <td>Nip</td>
	<td>Nama kp</td>
	<td>Uraian</td>
	<td>Jam Mulai</td>
	<td>Jam Selesai</td>
	<td>Durasi Pekerjaan</td>
	<td>Validasi</td>
	<td>Point</td>
  </tr>
  </thead>";
  $no=1;
  while($dt=mysql_fetch_array($tampil)){
  $nilai=$dt['jumlah']*1;
  echo "<tr>
  <td>$no</td>
  <td>$dt[id_kinerja]</td>
  <td>$dt[tanggal]</td>
    <td>$dt[nip]</td>
	 <td>$dt[kd_skp]</td>
	 <td>$dt[uraian]</td>
	<td>$dt[jam_mulai]</td>
	<td>$dt[jam_akhir]</td>
	<td>$dt[jumlah] Menit </td>
	<td>
	
	<input type='text' name='id_kinerja' value='$dt[id_kinerja]' hidden>
	<input type='text' name='kd_skp' value='$dt[kd_skp]' hidden>
	<input type='text' name='tanggal' value='$dt[tanggal]' hidden>
	<input type='text' name='nip' value='$dt[nip]' hidden>
	<input type='text' name='uraian' value='$dt[uraian]' hidden>
	<input type='text' name='jam_mulai' value='$dt[jam_mulai]' hidden>
	<input type='text' name='jam_akhir' value='$dt[jam_akhir]' hidden>
	<input type='text' name='jumlah' value='$dt[jumlah]' hidden>
	<input type='text' name='point' value='$dt[jumlah]' hidden>
	<a href='?module=kinerja&act=validasi&id_kinerja=$dt[id_kinerja]'><input type=submit value='Validasi' name='validas'></s><a href='?module=kinerja&act=batal&id_kinerja=$dt[id_kinerja]'><input type=submit value='Batal Validasi' name='validas'></s></td>
    <td>$dt[point] </td>
  </tr>
  ";
  $no++;
  }echo"
  </tr>
  <tr>
  <td colspan=10 > NILAI
  </td>
  <td>"; 
  $tgl= date('Y-m-d');
	$per=explode('-',$tgl);
	$bln=$per[1];
	$thn=$per[0];
	$waktu= date ('H:i:s');
	
  $qry_jumlah_b=mysql_query("select SUM(point) from kinerja where 
						 Month(kinerja.tanggal)='$bln' 
						 and Year(kinerja.tanggal)='$thn' and nip='$_GET[nip]'
						 order by id_kinerja ASC ");
        $data_b=mysql_fetch_array($qry_jumlah_b);
        $nilai=$data_b[0];
        echo $nilai;
		echo"</td>
  </tr>";
echo "  
</table>

	";
	
	break;
	
	case "validasi":
	$ambil=mysql_query("select * from kinerja where id_kinerja='$_GET[id_kinerja]'");
	$ed=mysql_fetch_array($ambil);
	echo "Yakin anda Ingin Menyetujui Validasi Ini  ??
	<form action='$aksi?module=kinerja&act=val' method='post' enctype='multipart/form-data' >
	<input type='hidden' name='id_kinerja' readonly value='$ed[id_kinerja]' >
	<table class='tabelform tabpad'>
	<tr>
	<td><input class='form-control' name='id_kinerja' type='text' value='$ed[id_kinerja]' readonly ></td>
	</tr>
	<tr>
	<td> <input type='text' name='nip' readonly value='$ed[nip]' readonly>
	</td>
	</tr>	
	<tr>
	<td><input class='form-control' name='tanggal' type='date' value='$ed[tanggal]' readonly ></td>
	</tr>
	
	<tr>
	<td><input class='form-control' name='kd_skp' type='text' value='$ed[kd_skp]' readonly></td>
	</tr>
	
	<tr>
	<td><input class='�nput' name='uraian' value='$ed[uraian]' readonly></td>
	</tr>
	
	<tr>
	<td><input class='form-control' name='jam_mulai' type='time' value='$ed[jam_mulai]' readonly></td>
	</tr>
	
	<tr>
	<td><input class='form-control' name='jam_akhir' type='time' value='$ed[jam_akhir]' readonly></td>
	</tr>
	<tr>
	<td><input class='form-control' name='point' type='text' value='$ed[jumlah]' readonly></td>
	</tr>
	<tr>
	<td><input type=submit value=Iya>
	<input type=button value=Batal onclick=self.history.back()>
	</td>
	</tr>
	</table>
	</form>
	";
	break;
	
	case "batal":
	$ambil=mysql_query("select * from kinerja where id_kinerja='$_GET[id_kinerja]'");
	$ed=mysql_fetch_array($ambil);
	echo "Yakin anda Ingin Membatalkan Validasi Ini  ??
	<form action='$aksi?module=kinerja&act=val' method='post' enctype='multipart/form-data' >
	<input type='hidden' name='id_kinerja' readonly value='$ed[id_kinerja]' >
	<table class='tabelform tabpad'>
	<tr>
	<td><input class='form-control' name='id_kinerja' type='text' value='$ed[id_kinerja]' readonly ></td>
	</tr>
	<tr>
	<td> <input type='text' name='nip' readonly value='$ed[nip]' readonly>
	</td>
	</tr>	
	<tr>
	<td><input class='form-control' name='tanggal' type='date' value='$ed[tanggal]' readonly ></td>
	</tr>
	
	<tr>
	<td><input class='form-control' name='kd_skp' type='text' value='$ed[kd_skp]' readonly></td>
	</tr>
	
	<tr>
	<td><input class='�nput' name='uraian' value='$ed[uraian]' readonly></td>
	</tr>
	
	<tr>
	<td><input class='form-control' name='jam_mulai' type='time' value='$ed[jam_mulai]' readonly></td>
	</tr>
	
	<tr>
	<td><input class='form-control' name='jam_akhir' type='time' value='$ed[jam_akhir]' readonly></td>
	</tr>
	<tr>
	<td><input class='form-control' name='' type='text' value='$ed[jumlah]' readonly><input class='form-control' name='point' type='text' value='0' hidden></td>
	</tr>
	<tr>
	<td><input type=submit value=Iya>
	<input type=button value=Batal onclick=self.history.back()>
	</td>
	</tr>
	</table>
	</form>
	";
	break;
	
	
	case "edit":
	$ambil=mysql_query("select * from kinerja where id_kinerja='$_GET[id_kinerja]'");
	$ed=mysql_fetch_array($ambil);
	echo "<h2 class='head'>Edit Data Kinerja</h2>
	<form action='$aksi?module=kinerja&act=edit' method='post' enctype='multipart/form-data' >
	<input type='hidden' name='id_kinerja' readonly value='$ed[id_kinerja]' >
	<table class='tabelform tabpad'>
	<tr>
	<td>Id Kinerja</td><td>:</td><td><input class='form-control' name='id_kinerja' type='text' value='$ed[id_kinerja]' readonly ></td>
	</tr>
	<tr>
	<td>Nip</td><td>:</td><td> <input type='text' name='nip' readonly value='$ed[nip]' >"; 
	echo "</td>
	</tr>	
	<tr>
	<td>Tanggal</td><td>:</td><td><input class='form-control' name='tanggal' type='date' value='$ed[tanggal]' ></td>
	</tr>
	
	<tr>
	<td>Pilih SKP</td><td>:</td><td>
	<select name='kd_skp'> 
	<option value='$ed[kd_skp]' selected='selected'>$ed[kd_skp]</option>";
	$sql = mysql_query("select *FROM skptahunan WHERE nip LIKE '%$_SESSION[namauser]%' ");
    if(mysql_num_rows($sql) != 0){
        while($data = mysql_fetch_assoc($sql)){
            echo '<option>'.$data['kd_skp'].'</option>';
        }
    } echo"
</td>
	</tr>
	
	<tr>
	<td>Uraian</td><td>:</td><td><textarea name='uraian'  cols='100' rows='10' tabindex='4'>$ed[uraian]</textarea></td>
	</tr>
	
	<tr>
	<td>Jam Mulai</td><td>:</td><td><input class='form-control' name='jam_mulai' type='time' value='$ed[jam_mulai]'></td>
	</tr>
	
	<tr>
	<td>Jam Akhir</td><td>:</td><td><input class='form-control' name='jam_akhir' type='time' value='$ed[jam_akhir]'></td>
	</tr>
	
	<tr>
	<td></td><td></td><td><input type=submit value=Simpan>
	<input type=button value=Batal onclick=self.history.back()>
	</td>
	</tr>
	</table>
	</form>
	";
	break;
	
	
	
	
	case "cari":
	$t1=$_POST['t1'];
	$t2=$_POST['t2'];
	echo"yang di cari tanggal $t1 sampai $t2";
	$tampil=mysql_query("select * from kinerja where tanggal between '$t1' and '$t2'  ");
    
	echo "<div>
	<input type=button value=Kembali onclick=self.history.back()>
	</div>
	<h2 class='head'>DATA KINERJA PEGAWAI</h2>
	<table class='table table-bordered table-hover table-striped'>
	<thead>
  <tr>
  <td>No</td>
  <td>ID Kinerja</td>
  <td>Tanggal</td>
    <td>Nip</td>
	<td>kd_skp</td>
	<td>Uraian</td>
	<td>Jam Mulai</td>
	<td>Jam Selesai</td>
	<td>Durasi Pekerjaan</td>
	<td>Control</td>
	<td>Point</td>
  </tr>
  </thead>";
  $no=1;
  while($dt=mysql_fetch_array($tampil)){
  echo "<tr>
  <td>$no</td>
  <td>$dt[id_kinerja]</td>
  <td>$dt[tanggal]</td>
    <td>$dt[nip]</td>
	 <td>$dt[kd_skp]</td>
	 <td>$dt[uraian]</td>
	<td>$dt[jam_mulai]</td>
	<td>$dt[jam_akhir]</td>
	<td>$dt[jumlah] Menit</td>
	<td><span><a href='?module=kinerja&act=validasi&id_kinerja=$dt[id_kinerja]'><input type=submit value='Validasi' name='validas'></s><a href='?module=kinerja&act=batal&id_kinerja=$dt[id_kinerja]'><input type=submit value='Batal Validasi' name='validas'></s></span><span>
	</span>
	<td>$dt[point] </td>
	</td>
  </tr>";
  $no++;
  }
echo " 
<tr>
  <td colspan=10 > NILAI
  </td>
  <td>"; 
  $tgl= date('Y-m-d');
	$per=explode('-',$tgl);
	$bln=$per[1];
	$thn=$per[0];
	$waktu= date ('H:i:s');
	
  $qry_jumlah_b=mysql_query("select SUM(point) from kinerja where tanggal between '$t1' and '$t2' ");
        $data_b=mysql_fetch_array($qry_jumlah_b);
        $nilai=$data_b[0];
        echo $nilai;
		echo"</td>
  </tr> 
</table>
	";
	
}


?>