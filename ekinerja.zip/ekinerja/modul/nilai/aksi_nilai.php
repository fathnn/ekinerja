<?php 
include "../../config/koneksi.php";
include "../../config/fungsi_indotgl.php";
include "../../config/class_paging.php";
include "../../config/kode_auto.php";

$module=$_GET['module'];
$act=$_GET['act'];


if($module=='nilai' AND $act=='input' ){
	$id=kdauto(pencapaian,PNY);
	mysql_query("insert into pencapaian set id_pencapaian='$id', nip='$_POST[nip]', nama='$_POST[nama]', tanggal='$_POST[tanggal]', nilai='$_POST[nilai]'");
	echo "<script>alert('Data Sudah Tersimpah, Lanjut Ke Menu Validasi'); window.location = 'javascript:history.go(-1)'</script>";
}
elseif($module=='nilai' AND $act=='inputm' ){
	$id=kdauto(pencapaian,PNY);
	mysql_query("insert into pencapaian set id_pencapaian='$id', nip='$_POST[nip]', nama='$_POST[nama]', id_skpd='$_POST[id_skpd]', nskp='$_POST[nskp]',nprilaku='$_POST[nprilaku]', id_ukpd='$_POST[id_ukpd]', penilai='$_POST[penilai]', tanggal='$_POST[tanggal]', 
				masa_kerja='$_POST[masa_kerja]', rumpun='$_POST[rumpun]', tunjangan='$_POST[tunjangan]', bruto='$_POST[bruto]', id_bag='$_POST[bagian]',id_penyerapan='$_POST[id_penyerapan]', 
				id_jab='$_POST[jabatan]', gapok='$_POST[gapok]', id_status='$_POST[id_status]' ");
	echo "<script>alert('Data Sudah Tersimpah, Lanjut Ke Menu Validasi'); window.location = 'javascript:history.go(-2)'</script>";
}
elseif($module=='nilai' AND $act=='edit' ){
	mysql_query("update bagian set n_bag='$_POST[nama]' where id_bag='$_POST[id]'");
	header('location:../../media.php?module='.$module);
}

elseif($module=='nilai' AND $act=='hapus' ){
	mysql_query("delete from pencapaian where id_pencapaian='$_GET[id_pencapaian]'");
	echo "<script>alert('Data Sudah Tersimpah, Lanjut Ke Menu Validasi'); window.location = 'javascript:history.go(-2)'</script>";
}
elseif($module=='nilai' AND $act=='hapusm' ){
	mysql_query("delete from pencapaian where id_pencapaian='$_GET[id_pencapaian]'");
	echo "<script>alert('Data Sudah Tersimpah, Lanjut Ke Menu Validasi'); window.location = 'javascript:history.go(-2)'</script>";
}


?>