<?php
error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
$aksi="modul/bagian/aksi_bagian.php";

switch($_GET[act]){
	default:
	$tahun =  date("Y");
	$bulan = date("M");
	echo "<h2 class='head'>LAPORAN GAJI INDEX</h2>
	<form action='pencarian.php' method='POST' target='_blank' rel='dofollow' >
	<table border='0' class='tabelform tabpad'>
	<tr>
	<td>
	</td><td> </td>
	</tr>
	<tr>
	<tr>
	<td>TANGGAL</td><td>:</td><td><select  name='bulan'>
            	<option value='' selected='selected'>--Pilih bulan--</option>
				<option value='1'>Januari</option>
				<option value='2'>Februari</option>
				<option value='3'>Maret</option>
				<option value='4'>April</option>
				<option value='5'>Mei</option>
				<option value='6'>Juni</option>
				<option value='7'>Juli</option>
				<option value='8'>Agustus</option>
				<option value='9'>September</option>
				<option value='10'>Oktober</option>
				<option value='11'>November</option>
				<option value='12'>Desember</option>
			</select>
	<select name='tahun'>
            <option value='$tahun' class='form-control' selected='selected'>$tahun</option>";
			$saiki = 2018;
			for($l=$saiki; $l<=2030; $l++)
			{
				echo"<option value=",$l,">",$l,"</option>";
			}	
	echo "</select>
	<input class='form-control' name='ukpd' width='60' type='hidden' value='$_SESSION[id_ukpd]'></td>
	<td><input type=submit value='Tampilkan' > </td>
	</tr>
	</table>";
	break;
	
	case "gaji":
	$tahun =  date("Y");
	$bulan = date("M");
	echo "<h2 class='head'>LAPORAN GAJI BRUTO</h2>
	<form action='laporan_gaji.php' method='POST' target='_blank' rel='dofollow' >
	<table border='0' class='tabelform tabpad'>
	<tr>
	<td>
	</td><td> </td>
	</tr>
	<tr>
	<td>
	<td>TANGGAL</td><td>:</td><td><select  name='bulan'>
            	<option value='' selected='selected'>--Pilih bulan--</option>
				<option value='1'>Januari</option>
				<option value='2'>Februari</option>
				<option value='3'>Maret</option>
				<option value='4'>April</option>
				<option value='5'>Mei</option>
				<option value='6'>Juni</option>
				<option value='7'>Juli</option>
				<option value='8'>Agustus</option>
				<option value='9'>September</option>
				<option value='10'>Oktober</option>
				<option value='11'>November</option>
				<option value='12'>Desember</option>
			</select>
	<select name='tahun'>
            <option value='$tahun' class='form-control' selected='selected'>$tahun</option>";
			$saiki = 2018;
			for($l=$saiki; $l<=$tahun; $l++)
			{
				echo"<option value=",$l,">",$l,"</option>";
			}	
	echo "</select>
	<input class='form-control' name='ukpd' width='60' type='hidden' value='$_SESSION[id_ukpd]'></td>
	<td><input type=submit value='Tampilkan' > </td>
	</tr>
	</table>";
	break;
	
	
	case "cari":
	$tgl=$_POST['tanggal'];
	$per=explode('-',$tgl);
	$bln=$per[1];
	$thn=$per[0];
	$waktu= date ('H:i:s');
	$tampil=mysql_query("select * from pencapaian where 
						 Month(pencapaian.tanggal)='$bln' 
						 and Year(pencapaian.tanggal)='$thn' 
						 order by id_pencapaian ASC  ");
	
	echo "<div>
	<input type=button value=Kembali onclick=self.history.back()>
	</div>
	<h2 class='head'>DATA PENCAPAIAN PEGAWAI</h2>
	<table class='table table-bordered table-hover table-striped'>
	<thead>
  <tr>
  <td>No</td>
  <td>Tanggal</td>
  <td>Nip</td>
  <td>Nama</td>
	<td>Bagian</td>
	<td>Tunjangan Murni</td>
	<td>Alpha</td>
	<td>Sakit 1 s/d 2 Hari</td>
	<td>Sakit > 2 Hari</td>
	<td>Izin</td>
	<td>Telat</td>
	<td>BPJS Kesehatan</td>
	<td>BPJS Ketenaga Kerjaan</td>
	<td>Penilaian Management</td>
	<td>Tunjangan Validasi</td>
	<td>Potongan Kehadiran</td>
	<td>Tunjangan Bersih</td>
  </tr>
  </thead>";
  $no=1;
  while($dt=mysql_fetch_array($tampil)){;
  
  	$bag=mysql_query("select * from bagian where id_bag='$dt[id_bag]'");
	$bagian=mysql_fetch_array($bag);
	$nbag=$bagian[n_bag];
	
	$jab=mysql_query("select * from jabatan where id_jab='$dt[id_jab]'");
	$jabatan=mysql_fetch_array($jab);
	$njab=$jabatan[n_jab];
	
		$waktu_k=mysql_query("select * from waktu_k where 
						 Month(waktu_k.tanggal)='$bln' 
						 and Year(waktu_k.tanggal)='$thn' and nip='$dt[nip]'
						 order by id_waktu_k ASC ");
        $wk=mysql_fetch_array($waktu_k);
        $alpha=$wk[alpha];
		$sakit1=$wk[sakit1];
		$sakit2=$wk[sakit2];
		$izin=$wk[izin];
		$telat=$wk[telat];
		$tun_val=$dt[tunjangan]*$dt[nilai]/100;
		$tun_val1=number_format($tun_val,0);
		$hsakit1=($sakit1*0.01)*$tun_val;
		$hsakit1t=number_format($hsakit1,0);
		$hsakit2=($sakit2*0.02)*$tun_val;
		$hsakit2t=number_format($hsakit2,0);
		$htelat=(($telat/450)*0.025)*$tun_val;
		$htelat_t=number_format($htelat,0);
		$hizin=($izin*0.025)*$tun_val;
		$hizint=number_format($hizin,0);
		$halpha=($alpha*0.05)*$tun_val;
		$halphat=number_format($halpha,0);
		$potongan_tun=$htelat+$hsakit1+$hsakit2+$hizin+$halpha;
		$potongan=number_format($potongan_tun,0);
		$bpjskesehatan=$dt[gapok]*0.02;
		$bpjskes=number_format($bpjskesehatan,0);
		$bpjstenagakerja=$dt[gapok]*0.0054;
		$bpjstenag=number_format($bpjstenagakerja,0);
		$tunjangan_bersih=$tun_val-$potongan_tun-$bpjskesehatan-$bpjstenagakerja;
		$tun_pendapatan=number_format($tunjangan_bersih,0);
		$tunjangan=number_format($dt[tunjangan],0);
	$st=mysql_query("select * from status where id_status='$t[id_status]'");
	$b=mysql_fetch_array($st);
	$status=$b[nilai];
	echo "$b[n_status]";	
  echo "<tr>
  <td>$no</td>
  <td>$dt[tanggal]</td>
  <td>$dt[nip]</td>
    <td>$dt[nama]</td>
	 <td>$nbag</td>
	<td>$tunjangan</td>
	<td>$halphat</td>
	<td>$hsakit1t</td>
	<td>$hsakit2t</td>
	<td>$hizint</td>
	<td>$htelat_t</td>
	<td>$bpjskes</td>
	<td>$bpjstenag</td>
	<td>$dt[nilai]%</td>
	<td>$tun_val1</td>
	<td>$potongan</td>
	<td>$tun_pendapatan</td>
  </tr>";
  $no++;
  }
echo " 
</table>
	<form action='pencarian.php' method='POST' ><table border='0'>
	<tr>
	<td>
	<input class='input' name='tanggal' width='60' type='hidden' value='$tanggal' ></td><td> <button>Export Data ke Excel</button> </td>
	</tr>
	</table>";

break;
	
	case "download":
	$tgl=$_POST['tanggal'];
	$per=explode('-',$tgl);
	$bln=$per[1];
	$thn=$per[0];
	$waktu= date ('H:i:s');
	$tampil=mysql_query("select * from pencapaian where 
						 Month(pencapaian.tanggal)='$bln' 
						 and Year(pencapaian.tanggal)='$thn' 
						 order by id_pencapaian ASC  ");
	$nama_file = "namafilekita.xls";
	header("Content-type: application/octet-stream");
	header("Content-Disposition: attachment; filename=".$nama_file);
	header("Pragma: no-cache");
	header("Expires: 0");
	echo "<div>
	<input type=button value=Kembali onclick=self.history.back()>
	</div>
	<h2 class='head'>DATA PENCAPAIAN PEGAWAI</h2>
	<table class='table table-bordered table-hover table-striped'>
	<thead>
  <tr>
  <td>No</td>
  <td>Tanggal</td>
  <td>Nip</td>
  <td>Nama</td>
	<td>Bagian</td>
	<td>Jabatan</td>
	<td>Tunjangan Murni</td>
	<td>Alpha</td>
	<td>Sakit 1 s/d 2 Hari</td>
	<td>Sakit > 2 Hari</td>
	<td>Izin</td>
	<td>Telat</td>
	<td>Penilaian Management</td>
	<td>Tunjangan Validasi</td>
	<td>BPJS</td>
  </tr>
  </thead>";
  $no=1;
  while($dt=mysql_fetch_array($tampil)){;
  
  	$bag=mysql_query("select * from bagian where id_bag='$dt[id_bag]'");
	$bagian=mysql_fetch_array($bag);
	$nbag=$bagian[n_bag];
	
	$jab=mysql_query("select * from jabatan where id_jab='$dt[id_jab]'");
	$jabatan=mysql_fetch_array($jab);
	$njab=$jabatan[n_jab];
	
		$waktu_k=mysql_query("select * from waktu_k where 
						 Month(waktu_k.tanggal)='$bln' 
						 and Year(waktu_k.tanggal)='$thn' and nip='$dt[nip]'
						 order by id_waktu_k ASC ");
        $wk=mysql_fetch_array($waktu_k);
        $alpha=$wk[alpha];
		$sakit1=$wk[sakit1];
		$sakit2=$wk[sakit2];
		$izin=$wk[izin];
		$telat=$wk[telat];
		$tun_val=$dt[tunjangan]*$dt[nilai]/100;
		$tun_val1=number_format($tun_val,0);
		$bpjs=$tun_val*0.5;
		$hsakit1=($sakit1*0.01)*$tun_val;
		$hsakit2=($sakit2*0.02)*$tun_val;
		$tunjangan=number_format($dt[tunjangan],0);
	$st=mysql_query("select * from status where id_status='$t[id_status]'");
	$b=mysql_fetch_array($st);
	$status=$b[nilai];
	echo "$b[n_status]";	
  echo "<tr>
  <td>$no</td>
  <td>$dt[tanggal]</td>
  <td>$dt[nip]</td>
    <td>$dt[nama]</td>
	 <td>$nbag</td>
	 <td>$njab</td>
	<td>$tunjangan</td>
	<td>$alpha</td>
	<td>$sakit1</td>
	<td>$sakit2</td>
	<td>$izin</td>
	<td>$telat</td>
	<td>$dt[nilai]%</td>
	<td>$tun_val1</td>
	<td>$bpjs</td>
  </tr>";
  $no++;
  }
echo " 
</table>
	<form action='pencarian.php' method='POST' ><table border='0'>
	<tr>
	<td>
	<input class='input' name='tanggal' width='60' value='$tgl' ></td> <button>Export Data ke Excel</button> </td>
	</tr>
</table>
	";

break;
	
	case "cetak.xls":
	// Fungsi header dengan mengirimkan raw data excel
header("Content-type: application/vnd-ms-excel");
 
// Mendefinisikan nama file ekspor "hasil-export.xls"
header("Content-Disposition: attachment; filename=tutorialweb-export.xls");
 
// Tambahkan table
include '?module=laporan&act=cari';
	break;
	
	
	case "hapus":
	
	break;
}


?>