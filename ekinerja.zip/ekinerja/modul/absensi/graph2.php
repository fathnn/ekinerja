﻿<?  
$aksi="modul/kinerja/aksi_kinerja.php";
$nip=$_SESSION['namauser'];
switch($_GET[act]){
	default:
	$nip=$_SESSION['namauser'];
	$dat=mktime(0, 0, 0, date("m")-1, date("d"), date("Y"));
	$tgl= date('Y-m-28',$dat);
	$per=explode('-',$tgl);
	$bln=$per[1];
	$thn=$per[0];
	$waktu= date ('H:i:s');
	$tampil=mysql_query("select * from kinerja where 
						 Month(kinerja.tanggal)='$bln' 
						 and Year(kinerja.tanggal)='$thn' and nip='$_GET[nip]'
						 order by tanggal asc  ");
	$tampil1=mysql_query("select * from pegawai where nip='$_GET[nip]' ");
	while($dt=mysql_fetch_array($tampil1)){
    $nip1=$dt['nip']; 
	$nama=$dt['nama'];
	}
	echo "<h2 class='head'>DATA KINERJA UNIT USER</h2>
	<div>
	<input type=button value=Kembali onclick=self.history.back()>
	</div>
	<table class='table table-bordered table-hover table-striped'>
	<thead>
  <tr>
  <td>No</td>
  <td>ID Kinerja</td>
  <td>Tanggal</td>
    <td>Nip</td>
	<td>Nama kp</td>
	<td>Uraian</td>
	<td>Jam Mulai</td>
	<td>Jam Selesai</td>
	<td>Durasi Pekerjaan</td>
	<td>Validasi</td>
	<td>Point</td>
  </tr>
  </thead>";
  $no=1;
  while($dt=mysql_fetch_array($tampil)){
  $nilai=$dt['jumlah']*1;
  echo "<tr>
  <td>$no</td>
  <td>$dt[id_kinerja]</td>
  <td>$dt[tanggal]</td>
    <td>$dt[nip]</td>
	 <td>$dt[kd_skp]</td>
	 <td>$dt[uraian]</td>
	<td>$dt[jam_mulai]</td>
	<td>$dt[jam_akhir]</td>
	<td>$dt[jumlah] Menit </td>
	<td>
	
	<input type='text' name='id_kinerja' value='$dt[id_kinerja]' hidden>
	<input type='text' name='kd_skp' value='$dt[kd_skp]' hidden>
	<input type='text' name='tanggal' value='$dt[tanggal]' hidden>
	<input type='text' name='nip' value='$dt[nip]' hidden>
	<input type='text' name='uraian' value='$dt[uraian]' hidden>
	<input type='text' name='jam_mulai' value='$dt[jam_mulai]' hidden>
	<input type='text' name='jam_akhir' value='$dt[jam_akhir]' hidden>
	<input type='text' name='jumlah' value='$dt[jumlah]' hidden>
	<input type='text' name='point' value='$dt[jumlah]' hidden>
	<a href='?module=kinerja&act=validasi&id_kinerja=$dt[id_kinerja]'><input type=submit value='Validasi' name='validas'></s><a href='?module=kinerja&act=batal&id_kinerja=$dt[id_kinerja]'><input type=submit value='Batal Validasi' name='validas'></s></td>
    <td>$dt[point] </td>
  </tr>
  ";
  $no++;
  }echo"
  </tr>
  <tr>
  <td colspan=10 > NILAI
  </td>
  <td>"; 
 $dat=mktime(0, 0, 0, date("m")-1, date("d"), date("Y"));
	$tgl= date('Y-m-28',$dat);
	$per=explode('-',$tgl);
	$bln=$per[1];
	$thn=$per[0];
	$waktu= date ('H:i:s');
	
  $qry_jumlah_b=mysql_query("select SUM(point) from kinerja where 
						 Month(kinerja.tanggal)='$bln' 
						 and Year(kinerja.tanggal)='$thn' and nip='$_GET[nip]'
						 order by tanggal DESC ");
        $data_b=mysql_fetch_array($qry_jumlah_b);
        $nilai=$data_b[0];
        echo $nilai;
		echo"</td>
  </tr>";
echo "  
</table>

	";
	
	break;
	?>