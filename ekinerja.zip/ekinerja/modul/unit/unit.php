
<?php
error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
$aksi="modul/unit/aksi_unit.php";
$bagian=$_SESSION['id_bag'];
switch($_GET[act]){
	default:
	$set=mysql_query("select * from setting ");
	$st=mysql_fetch_array($set);
	$pj=$st['pj'];
	if($pj=="1"){
	$bagian=$_SESSION['id_bag'];
	$ambil=mysql_query("select * from pegawai WHERE id_bag LIKE '%$_SESSION[id_bag]%'  ");
	echo "<h2 class='head'>DATA LIST PEGAWAI</h2>
	<div>
	<input type=hidden value='><input type=button value='Tampilkan' onclick=\"window.location.href='?module=skp&act=input';\">
	</div>
	<table class='table table-bordered table-hover table-striped'>
	<thead>
  <tr>
    <td>No </td>
    <td>Nip </td>
    <td>Nama</td>
	<td>Bagian</td>
	<td>Jabatan</td>
	<td>Validasi Kinerja</td>
	<td colspan='4' align='center'>Penilaian</td>
	<td>Hasil</td>
  </tr>
  </thead>";
  $no=1;
  while($dt=mysql_fetch_array($ambil)){
  echo "<tr>
    <td width='25'>$no</td>
    <td>$dt[nip]</td>
    <td>$dt[nama]</td>
	 <td>";
	$bag=mysql_query("select * from bagian where id_bag='$dt[id_bag]'");
	$b=mysql_fetch_array($bag);
	echo "$b[n_bag]";	
	echo "</td>
	 <td>";
	$jab=mysql_query("select * from jabatan where id_jab='$dt[id_jab]'");
	$b=mysql_fetch_array($jab);
	echo "$b[n_jab]";	
	echo "</td>
	<td width='110'><span><a href='?module=kinerja&act=lihat&nip=$dt[nip]&nama=$dt[nama]'><img src='modul/icon/validasi.png' width='20' height='20' title='Aktifitas Utama'></a></span> || 
		<!--<span><a href='?module=aktifitas&act=lihat&nip=$dt[nip]&nama=$dt[nama]'><img src='modul/icon/tambahan.png' width='20' height='20' title='Aktifitas Tambahan'></a></span>--> ||
		<span><a href='?module=kreatifitas&act=lihat&nip=$dt[nip]&nama=$dt[nama]'><img src='modul/icon/kreatifitas.png' width='20' height='20' title='Kreatifitas'></a></span>
	<!--<td width='30'><span><a href='?module=waktu&act=awalan&nip=$dt[nip]'><img src='modul/icon/waktu.png' width='20' height='20' title='Waktu Efektif'></a></span> </td> 
	<td width='30'><span><a href='?module=waktu&act=pengukuran&nip=$dt[nip]&nama=$dt[nama]'><img src='modul/icon/pengukuran.png' width='20' height='20' title='Pengukuran'></a></span> </td>-->
	<td width='30'><span><a href='?module=disiplin&act=detail&nip=$dt[nip]&nama=$dt[nama]'><img src='modul/icon/disiplin.png' width='20' height='20' title='Disiplin'></a></span> </td>
	<td width='30'><span><a href='?module=kompetensi&act=detail&nip=$dt[nip]&nama=$dt[nama]''><img src='modul/icon/kompetensi.png' width='20' height='20' title='Kompetensi'></a></span>
	<td width='30'><span><a href='?module=nilai&act=cekvalidasipj&nip=$dt[nip]&nama=$dt[nama]'><img src='modul/icon/nilai.png' width='20' height='20' title='Hasil validasi PJ'></a></span></td>
	</tr>
  </tr>";
  $no++;
  }
echo "  
</table>
	";
	}
	else
	echo "<h2 align='center'>Ma'af Belum Waktunya Untuk Memvalidasi </h2>";
	
	break;

	case"kasatpel";
$set=mysql_query("select * from setting ");
	$st=mysql_fetch_array($set);
	$pj=$st['pj'];
	if($pj=="1"){
	$bagian=$_SESSION['id_bag'];
	$ambil=mysql_query("select * from pegawai WHERE kasatpel LIKE '%$_SESSION[namauser]%' order by nama ASC ");
	echo "<h2 class='head'>DATA LIST PEGAWAI ( Batas Validasi tanggal 4 - 7 setiap bulan nya ) </h2>
	<div>
	<input type=hidden value='><input type=button value='Tampilkan' onclick=\"window.location.href='?module=skp&act=input';\">
	</div>
	<table class='table table-bordered table-hover table-striped'>
	<thead>
  <tr>
    <td>No </td>
    <td>Nip </td>
    <td>Nama</td>
	<td>Bagian</td>
	<td>Jabatan</td>
	<td>Validasi Kinerja</td>
	<td colspan='2' align='center'>Penilaian</td>
	<td>Hasil</td>
  </tr>
  </thead>";
  $no=1;
  while($dt=mysql_fetch_array($ambil)){
  echo "<tr>
    <td width='25'>$no</td>
    <td>$dt[nip]</td>
    <td>$dt[nama]</td>
	 <td>";
	$bag=mysql_query("select * from bagian where id_bag='$dt[id_bag]'");
	$b=mysql_fetch_array($bag);
	echo "$b[n_bag]";	
	echo "</td>
	 <td>";
	$jab=mysql_query("select * from jabatan where id_jab='$dt[id_jab]'");
	$b=mysql_fetch_array($jab);
	echo "$b[n_jab]";	
	echo "</td>
	<td width='110'><span><a href='?module=kinerja&act=lihat&nip=$dt[nip]&nama=$dt[nama]'><img src='modul/icon/validasi.png' width='20' height='20' title='Aktifitas Utama'></a></span>
		<!--<span><a href='?module=aktifitas&act=lihat&nip=$dt[nip]&nama=$dt[nama]'><img src='modul/icon/tambahan.png' width='20' height='20' title='Aktifitas Tambahan'></a></span>-->
		<span><a href='?module=kreatifitas&act=lihat&nip=$dt[nip]&nama=$dt[nama]'><!--<img src='modul/icon/kreatifitas.png' width='20' height='20' title='Kreatifitas'>--></a></span>
	<!--<td width='30'><span><a href='?module=waktu&act=awalan&nip=$dt[nip]'><img src='modul/icon/waktu.png' width='20' height='20' title='Waktu Efektif'></a></span> </td> 
	<td width='30'><span><a href='?module=waktu&act=pengukuran&nip=$dt[nip]&nama=$dt[nama]'><img src='modul/icon/pengukuran.png' width='20' height='20' title='Pengukuran'></a></span> </td>>-->
	<td width='30'><span><a href='?module=disiplin&act=detail&nip=$dt[nip]&nama=$dt[nama]'><img src='modul/icon/disiplin.png' width='20' height='20' title='Disiplin'></a></span> </td>
	<td width='30'><span><a href='?module=kompetensi&act=detail&nip=$dt[nip]&nama=$dt[nama]''><img src='modul/icon/kompetensi.png' width='20' height='20' title='Kompetensi'></a></span>
	<td width='30'><span><a href='?module=nilai&act=cekvalidasipj&nip=$dt[nip]&nama=$dt[nama]'><img src='modul/icon/nilai.png' width='20' height='20' title='Hasil validasi PJ'></a></span></td>
	</tr>
  </tr>";
  $no++;
  }
echo "  
</table>
	";
	}
	else
	echo "<h2 align='center'>Ma'af Belum Waktunya Untuk Memvalidasi </h2>";
	
	break;
	
	
	case "management1":
	$bagian=$_SESSION['namauser'];
	$set=mysql_query("select * from setting ");
	$st=mysql_fetch_array($set);
	$mg=$st['management'];
	if($mg=="1"){
	$ambil=mysql_query("select * from pegawai,jabatan,bagian WHERE pegawai.id_jab=jabatan.id_jab and pegawai.id_bag=bagian.id_bag and kasie LIKE '%$_SESSION[namauser]%' order by nama asc ");	
	echo "<h2 class='head'>DATA LIST PEGAWAI</h2>
	<form action='?module=unit&act=cari' method='POST' ><table border='0' align='right'>
	<tr>
	<td>
	</td>
	</tr>
	</table>
	</form>
	<form action='?module=unit&act=carinama' method='POST' ><table border='0' align='left'>
	<tr>
	<!--<td><input class='input'  width='60' name='cek' type='' placeholder='Cari Nama Pegawai'><input type=submit value='Search' > </td>-->
	</tr>
	</table>
	</form>
	<table class='table table-bordered table-hover table-striped'>
	<thead>
  <tr>
    <td>No</td>
    <td>Nip</td>
    <td>Nama</td>
	<td>Jabatan</td>
	<td>Bagian</td>
	<td>SKP</td>
	<td>Validasi Kinerja</td>
	<td colspan='4' align='center'>Penilaian</td>
	<td>Hasil</td>
	<td>Keterangan</td>
  </tr>
  </thead>";
  $no=1;
  while($dt=mysql_fetch_array($ambil)){
  echo "<tr>
    <td width='25'>$no</td>
    <td>$dt[nip]</td>
    <td>$dt[nama]</td>
	<td>$dt[n_jab]</td>
	<td>$dt[n_bag]</td>
	<td width='30'><span><a href='?module=skptahunan&act=detailm1&nip=$dt[nip]&nama=$dt[nama]'><img src='modul/icon/skp.png' width='20' height='20' title='SKP Tahunan'></a></span></td>
	<td width='110'>
	<span><a href='?module=kinerja&act=lihat&nip=$dt[nip]&nama=$dt[nama]'><img src='modul/icon/validasi.png' width='20' height='20' title='Aktifitas Utama'></a></span> 
	<!--<span><a href='?module=aktifitas&act=lihat&nip=$dt[nip]&nama=$dt[nama]'><img src='modul/icon/tambahan.png' width='20' height='20' title='Aktifitas Tambahan'></a></span>-->
	<!--<span><a href='?module=kreatifitas&act=lihat&nip=$dt[nip]&nama=$dt[nama]'><img src='modul/icon/kreatifitas.png' width='20' height='20' title='Kreatifitas'></a></span>-->
	<td width='30'><span><a href='?module=waktu&act=awalan&nip=$dt[nip]'><img src='modul/icon/waktu.png' width='20' height='20' title='Waktu Efektif'></a></span> </td> 
	<td width='30'><span><a href='?module=waktu&act=pengukuran&nip=$dt[nip]&nama=$dt[nama]'><img src='modul/icon/pengukuran.png' width='20' height='20' title='Pengukuran'></a></span> </td>
	<td width='30'><span><a href='?module=disiplin&act=detail&nip=$dt[nip]&nama=$dt[nama]'><img src='modul/icon/disiplin.png' width='20' height='20' title='Disiplin'></a></span> </td>
	<td width='30'><span><a href='?module=kompetensi&act=detail&nip=$dt[nip]&nama=$dt[nama]''><img src='modul/icon/kompetensi.png' width='20' height='20' title='Kompetensi'></a></span>
	<td width='30'><span><a href='?module=nilai&act=cekvalidasimanagement&nip=$dt[nip]&nama=$dt[nama]'><img src='modul/icon/nilai.png' width='20' height='20' title='Hasil validasi PJ'></a></span></td>
	<td width='30'>"; 
	$dat=mktime(0, 0, 0, date("m")-1, date("d"), date("Y"));
	$tgl= date('Y-m-28',$dat);
	$per=explode('-',$tgl);
	$bln=$per[1];
	$thn=$per[0];
	$waktu= date ('H:i:s');
	$pnc=mysql_query("select * from pencapaian where 
						 Month(pencapaian.tanggal)='$bln' 
						 and Year(pencapaian.tanggal)='$thn' and nip='$dt[nip]'");
	$ket=mysql_fetch_array($pnc);
	$n1=$ket['nskp'];
	$n2=$ket['nprilaku'];
	$nilai=$n1+$n2;
	if ($n1 > 0 or $n2 > 0)
	echo"<font color='green'>Sudah Di Validasi</font>";
	else
	echo"<font color='red'>Belum Di Validasi<font>";
	echo"</td>
	</tr>
  </tr>";
  $no++;
  }
echo "  
</table>
	";
	}
	else
	echo "<h2 align='center'> Ma'af Belum Waktunya Untuk Memvalidasi </h2>";
	break;
	
	
	
	case "data":
	$bagian=$_SESSION['id_bag'];
	$ambil=mysql_query("select * from pegawai,bagian where pegawai.id_bag=bagian.id_bag  order by nip DESC");
	echo "<h2 class='head'>VALIDASI PEGAWAI</h2>
	<div>
	<input type=hidden value='><input type=button value='Tammpilkan' onclick=\"window.location.href='?module=skp&act=input';\">
	</div>
	<table class='table table-bordered table-hover table-striped'>
	<thead>
  <tr>
    <td>No</td>
    <td>Nip</td>
    <td>Nama</td>
	<td>Unit</td>
	<td colspan='3'>Validasi Kinerja</td>
	<td colspan='4' align='center'>Penilaian</td>
	<td>Hasil</td>
  </tr>
  </thead>";
  $no=1;
  while($dt=mysql_fetch_array($ambil)){
  echo "<tr>
    <td width='25'>$no</td>
    <td>$dt[nip]</td>
    <td>$dt[nama]</td>
	<td>$dt[n_bag]</td>
	<td width='20'><span><a href='?module=kinerja&act=lihat&nip=$dt[nip]&nama=$dt[nama]'><img src='modul/icon/validasi.png' width='20' height='20' title='Aktifitas Utama'></a></span> </td>
	<td width='20'><span><a href='?module=aktifitas&act=lihat&nip=$dt[nip]&nama=$dt[nama]'><img src='modul/icon/tambahan.png' width='20' height='20' title='Aktifitas Tambahan'></a></span> </td>
	<td width='20'><span><a href='?module=kreatifitas&act=lihat&nip=$dt[nip]&nama=$dt[nama]'><img src='modul/icon/kreatifitas.png' width='20' height='20' title='Kreatifitas'></a></span> </td>
	<td width='20'><span><a href='?module=waktu&act=awalan&nip=$dt[nip]'><img src='modul/icon/waktu.png' width='20' height='20' title='Waktu Efektif'></a></span> </td> 
	<td width='20'><span><a href='?module=waktu&act=pengukuran&nip=$dt[nip]&nama=$dt[nama]'><img src='modul/icon/pengukuran.png' width='20' height='20' title='Pengukuran'></a></span> </td>
	<td width='20'><span><a href='?module=disiplin&act=detail&nip=$dt[nip]&nama=$dt[nama]'><img src='modul/icon/disiplin.png' width='20' height='20' title='Disiplin'></a></span> </td>
	<td width='20'><span><a href='?module=kompetensi&act=detail&nip=$dt[nip]&nama=$dt[nama]''><img src='modul/icon/kompetensi.png' width='20' height='20' title='Kompetensi'></a></span>
	<td width='20'><span><a href='?module=nilai&act=awalan&nip=$dt[nip]&nama=$dt[nama]'><img src='modul/icon/nilai.png' width='20' height='20' title='Hasil validasi PJ'></a></span></td>
	</tr>
  </tr>";
  $no++;
  }
echo "  
</table>
	";
	break;
	
	case "kepegawaian":
	$bagian=$_SESSION['id_bag'];
	$ambil=mysql_query("select * from pegawai where id_ukpd LIKE '%$_SESSION[id_ukpd]%' order by nama asc ");
	echo "<h2 class='head'>VALIDASI PEGAWAI </h2>
	<div>
	<input type=hidden value='><input type=button value='Tammpilkan' onclick=\"window.location.href='?module=skp&act=input';\">
	</div>
	<table class='table table-bordered table-hover table-striped'>
	<thead>
  <tr>
    <td>No</td>
    <td>Nip</td>
    <td>Nama</td>
	<td>Unit</td>
	<td>Absen</td>
	<td>Sakit</td>
	<!--<td>Sakit > 2 Hr</td>-->
	<td>Cuti Tahunan</td>
	<td>Izin</td>
	<td>Telat</td>
	<td colspan='2'>Absensi</td>
  </tr>
  </thead>";
  $no=1;
  $dat=mktime(0, 0, 0, date("m")-1, date("d"), date("Y"));
	$tgl= date('Y-m-28',$dat);
	$per=explode('-',$tgl);
	$bln=$per[1];
	$thn=$per[0];
	$waktu= date ('H:i:s');

  while($dt=mysql_fetch_array($ambil)){
  echo "<tr>
    <td width='25'>$no</td>
    <td>$dt[nip]</td>
    <td>$dt[nama]</td>
	<td>";
	$bag=mysql_query("select * from bagian where id_bag='$dt[id_bag]'");
	$b=mysql_fetch_array($bag);
	echo "$b[n_bag]";	
	echo "</td>
	<td>";
	$dat=mktime(0, 0, 0, date("m")-1, date("d"), date("Y"));
	$tgl= date('Y-m-28',$dat);
	$per=explode('-',$tgl);
	$bln=$per[1];
	$thn=$per[0];
	$waktu= date ('H:i:s');
	$tampil=mysql_query("select * from waktu_k where 
						 Month(waktu_k.tanggal)='$bln' 
						 and Year(waktu_k.tanggal)='$thn' and nip='$dt[nip]'
						 order by id_waktu_k ASC  ");
						 
	$tampil2=mysql_query("select * from waktu_t where 
						 Month(tanggal)='$bln' 
						 and Year(tanggal)='$thn' and nip='$dt[nip]'
						 order by id_waktu_t ASC  ");
	$b=mysql_fetch_array($tampil2);
	$a=mysql_fetch_array($tampil);
	echo "$a[alpha]";	
	echo "</td>
	<td>$a[sakit1]</td>
	<!--<td>$a[sakit2]</td>-->
	<td>$b[c_tahunan_t]</td>
	<td>$a[izin]</td>
	<td>$a[telat]</td>
	<td width='20'><span><a href='?module=waktu&act=awalan&nip=$dt[nip]'><img src='modul/icon/waktu.png' width='20' height='20' title='Waktu Efektif'></a></span> </td> 
	<td width='20'><span><a href='?module=waktu&act=pengukuran&nip=$dt[nip]&nama=$dt[nama]'><img src='modul/icon/pengukuran.png' width='20' height='20' title='Pengukuran'></a></span> </td>
	</tr>
  </tr>";
  $no++;
  }
echo "  
</table>
	";
	break;
	
	
	case "cari":
	$bagian=$_SESSION['id_bag'];
	$cek=$_POST['cek'];
	$ambil=mysql_query("select * from pegawai,jabatan where 
	pegawai.id_jab=jabatan.id_jab  and id_bag like '%$cek%' ");
	echo "<h2 class='head'>DATA LIST PEGAWAI</h2>
	<table class='table table-bordered table-hover table-striped'>
	<thead>
  <tr>
    <td>No</td>
    <td>Nip</td>
    <td>Nama</td>
	<td>Jabatan</td>
	<td>Validasi Kinerja</td>
	<td colspan='4' align='center'>Penilaian</td>
	<td>Hasil</td>
  </tr>
  </thead>";
  $no=1;
  if (mysql_num_rows($ambil) == 0) {  
    echo '<p></p><p>Pencarian tidak ditemukan</p>';  
   } else {  
    echo '<p></p>';   
  while($dt=mysql_fetch_array($ambil)){
  echo "<tr>
    <td width='25'>$no</td>
    <td>$dt[nip]</td>
    <td>$dt[nama]</td>
	<td>$dt[n_jab]</td>
	<td width='110'><span><a href='?module=kinerja&act=lihat&nip=$dt[nip]&nama=$dt[nama]'><img src='modul/icon/validasi.png' width='20' height='20' title='Aktifitas Utama'></a></span> || 
		<span><a href='?module=aktifitas&act=lihatm&nip=$dt[nip]&nama=$dt[nama]'><img src='modul/icon/tambahan.png' width='20' height='20' title='Aktifitas Tambahan'></a></span> ||
		<span><a href='?module=kreatifitas&act=lihatm&nip=$dt[nip]&nama=$dt[nama]'><img src='modul/icon/kreatifitas.png' width='20' height='20' title='Kreatifitas'></a></span>
	<td width='30'><span><a href='?module=waktu&act=awalanm&nip=$dt[nip]'><img src='modul/icon/waktu.png' width='20' height='20' title='Waktu Efektif'></a></span> </td> 
	<td width='30'><span><a href='?module=waktu&act=pengukuranm&nip=$dt[nip]&nama=$dt[nama]'><img src='modul/icon/pengukuran.png' width='20' height='20' title='Pengukuran'></a></span> </td>
	<td width='30'><span><a href='?module=disiplin&act=detailm&nip=$dt[nip]&nama=$dt[nama]'><img src='modul/icon/disiplin.png' width='20' height='20' title='Disiplin'></a></span> </td>
	<td width='30'><span><a href='?module=kompetensi&act=detailm&nip=$dt[nip]&nama=$dt[nama]''><img src='modul/icon/kompetensi.png' width='20' height='20' title='Kompetensi'></a></span>
	<td width='30'><span><a href='?module=nilai&act=cekvalidasimanagement&nip=$dt[nip]&nama=$dt[nama]'><img src='modul/icon/nilai.png' width='20' height='20' title='Hasil validasi PJ'></a></span></td>
	</tr>
  </tr>";
  $no++;
  }}
echo "  
</table>
	";
	break;
	
		case "carinama":
	$bagian=$_SESSION['id_bag'];
	$cek=$_POST['cek'];
	$ambil=mysql_query("select * from pegawai,jabatan where 
	pegawai.id_jab=jabatan.id_jab  and nama like '%$cek%' ");
	echo "<h2 class='head'>DATA LIST PEGAWAI</h2>
	<table class='table table-bordered table-hover table-striped'>
	<thead>
  <tr>
    <td>No</td>
    <td>Nip</td>
    <td>Nama</td>
	<td>Jabatan</td>
	<td>Validasi Kinerja</td>
	<td colspan='4' align='center'>Penilaian</td>
	<td>Hasil</td>
  </tr>
  </thead>";
  $no=1;
  if (mysql_num_rows($ambil) == 0) {  
    echo '<p></p><p>Pencarian tidak ditemukan</p>';  
   } else {  
    echo '<p></p>';   
  while($dt=mysql_fetch_array($ambil)){
  echo "<tr>
    <td width='25'>$no</td>
    <td>$dt[nip]</td>
    <td>$dt[nama]</td>
	<td>$dt[n_jab]</td>
	<td width='110'><span><a href='?module=kinerja&act=lihat&nip=$dt[nip]&nama=$dt[nama]'><img src='modul/icon/validasi.png' width='20' height='20' title='Aktifitas Utama'></a></span> || 
		<span><a href='?module=aktifitas&act=lihatm&nip=$dt[nip]&nama=$dt[nama]'><img src='modul/icon/tambahan.png' width='20' height='20' title='Aktifitas Tambahan'></a></span> ||
		<span><a href='?module=kreatifitas&act=lihatm&nip=$dt[nip]&nama=$dt[nama]'><img src='modul/icon/kreatifitas.png' width='20' height='20' title='Kreatifitas'></a></span>
	<td width='30'><span><a href='?module=waktu&act=awalanm&nip=$dt[nip]'><img src='modul/icon/waktu.png' width='20' height='20' title='Waktu Efektif'></a></span> </td> 
	<td width='30'><span><a href='?module=waktu&act=pengukuranm&nip=$dt[nip]&nama=$dt[nama]'><img src='modul/icon/pengukuran.png' width='20' height='20' title='Pengukuran'></a></span> </td>
	<td width='30'><span><a href='?module=disiplin&act=detailm&nip=$dt[nip]&nama=$dt[nama]'><img src='modul/icon/disiplin.png' width='20' height='20' title='Disiplin'></a></span> </td>
	<td width='30'><span><a href='?module=kompetensi&act=detailm&nip=$dt[nip]&nama=$dt[nama]''><img src='modul/icon/kompetensi.png' width='20' height='20' title='Kompetensi'></a></span>
	<td width='30'><span><a href='?module=nilai&act=cekvalidasimanagement&nip=$dt[nip]&nama=$dt[nama]'><img src='modul/icon/nilai.png' width='20' height='20' title='Hasil validasi PJ'></a></span></td>
	</tr>
  </tr>";
  $no++;
  }}
echo "  
</table>
	";
	break;
	
	case "input":
	echo "<h2 class='head'>Entry Data SKP</h2>
	<form action='$aksi?module=skp&act=input' method='post'>
	<table class='tabelform'>
	<tr>
	<td>Kode SKP</td><td>:</td><td><input class='form-control' name='kd_skp' type='text' value=".kdauto(skp,SKP)."></td>
	</tr>
	<tr>
	<td>NAMA SKP</td><td>:</td><td><input class='form-control' name='skp' type='text'></td>
	</tr>
	<tr>
	<tr>
	<td>WAKTU EFEKTIF<td>:</td><td><input class='form-control' name='waktu' type='text'></td>
	</tr>
	<tr>
	<td></td><td></td><td><input type=submit value=Simpan>
	<input type=button value=Batal onclick=self.history.back()>
	</td>
	</tr>
	</table>
	</form>
	";
	break;
	
	case "edit":
	$edit=mysql_query("select * from skp where kd_skp='$_GET[kd_skp]'");
	$data=mysql_fetch_array($edit);
	echo "<h2>Entry Data Bagian</h2>
	<form action='$aksi?module=skp&act=edit' method='post'>
	<table>
	<tr>
	<td>Kode SKP</td><td>:</td><td><input class='form-control' name='kd_skp' type='text' value='$data[kd_skp]'></td>
	</tr>
	<tr>
	<td>NAMA SKP</td><td>:</td><td><input class='form-control' name='skp' type='text' value='$data[skp]'></td>
	</tr>
	<tr>
	<tr>
	<td>WAKTU EFEKTIF</td><td>:</td><td><input class='form-control' name='waktu' type='text' value='$data[waktu]'></td>
	</tr>
	<tr>
	<td></td><td></td><td><input type=submit value=Update>
	<input type=button value=Batal onclick=self.history.back()>
	</td>
	</tr>
	</table>
	</form>";
	break;
	
	case "hapus":
	
	break;
}


?>