<script type="text/javascript">
function validasi_input(form){
  if (form.hari.value == ""){
    alert("hari masih kosong!");
    form.hari.focus();
    return (false);
  }
  if (form.c_sakit_t.value == ""){
    alert("cuti sakit masih kosong!");
    form.c_sakit_t.focus();
    return (false);
  }
   if (form.c_alasan_t.value == ""){
    alert("cuti alasan penting masih kosong!");
    form.c_alasan_t.focus();
    return (false);
  }
   if (form.c_tahunan_t.value == ""){
    alert("cuti tahunan masih kosong!");
    form.c_tahunan_t.focus();
    return (false);
  }
   if (form.diklat.value == ""){
    alert("diklat masih kosong!");
    form.diklat.focus();
    return (false);
  }
   if (form.spd.value == ""){
    alert("spd  masih kosong!");
    form.spd.focus();
    return (false);
  }
   if (form.haji.value == ""){
    alert("haji masih kosong!");
    form.haji.focus();
    return (false);
  }
   if (form.sakit1.value == ""){
    alert("sakit masih kosong!");
    form.sakit1.focus();
    return (false);
  }
  if (form.sakit2.value == ""){
    alert("sakit masih kosong!");
    form.sakit2.focus();
    return (false);
  }
  if (form.alpha.value == ""){
    alert("alpha masih kosong!");
    form.alpha.focus();
    return (false);
  }
  if (form.telat.value == ""){
    alert("telat masih kosong!");
    form.telat.focus();
    return (false);
  }
  if (form.c_sakit_k.value == ""){
    alert("cuti sakit masih kosong!");
    form.c_sakit_k.focus();
    return (false);
  }
  if (form.c_alasan_k.value == ""){
    alert("cuti alasan penting masih kosong!");
    form.c_alasan_k.focus();
    return (false);
  }
  if (form.c_persalinan_k.value == ""){
    alert("cuti persalinan penting masih kosong!");
    form.c_persalinan_k.focus();
    return (false);
  }
  if (form.c_besar_k.value == ""){
    alert("scuti besar penting masih kosong!");
    form.c_besar_k.focus();
    return (false);
  }
  if (form.izin.value == ""){
    alert("izin penting masih kosong!");
    form.izin.focus();
    return (false);
  }
  if (form.izin_s.value == ""){
    alert("izin sakit masih kosong!");
    form.izin_s.focus();
    return (false);
  }
   if (form.meninggal.value == ""){
    alert("meninggal masih kosong!");
    form.meninggal.focus();
    return (false);
  }
 return (true);
}
</script>
<?php
error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
$aksi="modul/waktu/aksi_waktu.php";
$nip=$_SESSION['namauser'];
switch($_GET[act]){
	default:
	echo"
<a href='?module=waktu&act=awalan&nip=$_SESSION[namauser]'>Data Sudah Selesai Di Proses lanjutkan</a>";
	break;
	
	case "awalan":
	$nip=$_SESSION['namauser'];
	$nama=$_SESSION['nama'];
	$tampil1=mysql_query("select * from pegawai where nip='$_GET[nip]' ");
	while($dt=mysql_fetch_array($tampil1)){
    $nip1=$dt['nip'];
    $nama=$dt['nama']; }
    $dat=mktime(0, 0, 0, date("m")-1, date("d"), date("Y"));
	$tgl= date('Y-m-28',$dat);
	$per=explode('-',$tgl);
	$bln=$per[1];
	$thn=$per[0];
	$waktu= date ('H:i:s');
	//Query Penambahan	
	$set=mysql_query("select * from waktu_t where 
						 Month(waktu_t.tanggal)='$bln' 
						 and Year(waktu_t.tanggal)='$thn' and nip='$_GET[nip]'");
						 $st=mysql_fetch_array($set);
	$stat=$st['nip'];
	$tampil_waktu_t=mysql_query("select * from waktu_t where 
						 Month(waktu_t.tanggal)='$bln' 
						 and Year(waktu_t.tanggal)='$thn' and nip='$_GET[nip]'
						 order by id_waktu_t ASC  ");
	$qry_jumlah_a=mysql_query("select SUM(t_waktu_t) from waktu_t where 
						 Month(waktu_t.tanggal)='$bln' 
						 and Year(waktu_t.tanggal)='$thn' and nip='$_GET[nip]'
						 order by id_waktu_t ASC ");
    $data_a=mysql_fetch_array($qry_jumlah_a);
    $nilai1=$data_a[0];
	
	//Query Pengurangan
	$tampil_waktu_k=mysql_query("select * from waktu_k where 
						 Month(waktu_k.tanggal)='$bln' 
						 and Year(waktu_k.tanggal)='$thn' and nip='$_GET[nip]'
						 order by id_waktu_k ASC  ");
						 					 
	$qry_jumlah_b=mysql_query("select SUM(t_waktu_k) from waktu_k where 
						 Month(waktu_k.tanggal)='$bln' 
						 and Year(waktu_k.tanggal)='$thn' and nip='$_GET[nip]'
						 order by id_waktu_k ASC ");
    $data_b=mysql_fetch_array($qry_jumlah_b);
    $nilai=$data_b[0];					 
	
	echo "<h2 class='head'>WAKTU PENAMBAHAN EFEKTIF</h2>
	
	<div>
	<input type=button value='Penambahan' onclick=\"window.location.href='?module=waktu&act=penambahan&nip=$nip1&nama=$nama';\">
	
	<!--<input type=button value=Kembali onclick=self.history.back()>-->
	</div>
	<table class='table table-bordered table-hover table-striped'>
	<thead>
  <tr>
  <td>No</td>
  <td>ID Waktu</td>
  <td>Tanggal</td>
    <td>Nip</td>
	<!--<td>Cuti Sakit</td>-->
	<td>Cuti Alasan Penting</td>
	<td>Cuti Tahunan</td>
	<td>Peningkatan Kompetensi</td>
	<!--<td>SPD</td>
	<td>Petugas Haji</td>-->
	<td>Point</td>
	<td>Action</td>
  </tr>
  </thead>";
  $no=1;
  while($dt=mysql_fetch_array($tampil_waktu_t)){
   echo "<tr>
  <td>$no</td>
  <td>$dt[id_waktu_t]</td>
  <td>$dt[tanggal]</td>
    <td>$nip1</td>
	 <!--<td>$dt[c_sakit_t]</td>-->
	 <td>$dt[c_alasan_t]</td>
	<td>$dt[c_tahunan_t]</td>
	<td>$dt[diklat]</td>
	<!--<td>$dt[spd]</td>-->
    <!--<td>$dt[haji] </td>-->
	<td>$dt[t_waktu_t] </td>
	<td><a href=\"$aksi?module=waktu&act=hapus_wt&id_waktu_t=$dt[id_waktu_t]\" onClick=\"return confirm('Apakah Anda benar-benar mau menghapusnya?')\">Hapus</a></span></td>
  </tr>
  ";
  $no++;
}
  echo"
  </tr>
  <tr>
  <td colspan=10 > NILAI
  </td>
  <td>"; 
        echo $nilai1;
		echo"</td>
  </tr>";
echo "  
</table>

	";
	echo"<hr>";
	
						 
	echo "<h2 class='head'>WAKTU PENGURANGAN EFEKTIF</h2>
	<div>
	<input type=button value='Pengurangan' onclick=\"window.location.href='?module=waktu&act=pengurangan&nip=$nip1&nama=$nama';\">
	</div>
	<table class='table table-bordered table-hover table-striped'>
	<thead>
  <tr>
  <td>No</td>
  <td>ID Waktu</td>
  <td>Tanggal</td>
    <td>Nip</td>
	<td>Sakit</td>
	<!--<td>Sakit > 2 Hr</td>-->
	<td>Alpha</td>
	<td>Telat</td>
	<!--<td>Cuti Sakit</td>-->
	<td>Cuti Alasan Penting</td>
	<td>Cuti Bersalin</td>
	<!--<td>Cuti Besar</td>-->
	<td>Izin</td>
	<!--<td>Meninggal</td>-->
	<td>Point</td>
	<td>Action</td>
  </tr>
  </thead>";
  $no=1;
  while($dt=mysql_fetch_array($tampil_waktu_k)){
   echo "<tr>
  <td>$no</td>
  <td>$dt[id_waktu_k]</td>
  <td>$dt[tanggal]</td>
    <td>$nip1</td>
	<td>$dt[sakit1]</td>
	<!--<td>$dt[sakit2]</td>-->
	<td>$dt[alpha]</td>
	<td>$dt[telat]</td>
	 <!--<td>$dt[c_sakit_k]</td>-->
	 <td>$dt[c_alasan_k]</td>
	<td>$dt[c_persalinan_k]</td>
	<!--<td>$dt[c_besar_k]</td>-->
	<td>$dt[izin]</td>
	<!--<td>$dt[meninggal]</td>-->
	<td>$dt[t_waktu_k] </td>
	<td><a href=\"$aksi?module=waktu&act=hapus_wk&id_waktu_k=$dt[id_waktu_k]\" onClick=\"return confirm('Apakah Anda benar-benar mau menghapusnya?')\">Hapus</a></span></td>
  </tr>
  ";
  $no++;
}
  echo"
  </tr>
  <tr>
  <td colspan=14 > NILAI
  </td>
  <td>";
        echo $nilai;
		echo"
  </td>
  </tr>";
echo "  
</table>

	";
	
	break;
	
	case "awalanm":	
	$nip=$_SESSION['namauser'];
	$nama=$_SESSION['nama'];
	$tampil1=mysql_query("select * from pegawai where nip='$_GET[nip]' ");
	while($dt=mysql_fetch_array($tampil1)){
  $nip1=$dt['nip'];
  $nama=$dt['nama']; }
  	$tgl= date('Y-m-d');
	$per=explode('-',$tgl);
	$bln=$per[1];
	$thn=$per[0];
	$waktu= date ('H:i:s');
	$tampil=mysql_query("select * from waktu_t where 
						 Month(waktu_t.tanggal)='$bln' 
						 and Year(waktu_t.tanggal)='$thn' and nip='$_GET[nip]'
						 order by id_waktu_t ASC  ");
	echo "<h2 class='head'>WAKTU PENAMBAHAN EFEKTIF</h2>
	
	<div>
	<input type=button value='Penambahan' onclick=\"window.location.href='?module=waktu&act=penambahan&nip=$nip1&nama=$nama';\">
	<input type=button value='Pengurangan' onclick=\"window.location.href='?module=waktu&act=pengurangan&nip=$nip1&nama=$nama';\">
	<input type=button value=Kembali onclick=self.history.go(-2)>
	</div>
	<table class='table table-bordered table-hover table-striped'>
	<thead>
  <tr>
  <td>No</td>
  <td>ID Waktu</td>
  <td>Tanggal</td>
    <td>Nip</td>
	<td>Cuti Sakit</td>
	<td>Cuti Alasan</td>
	<td>Cuti Tahunan</td>
	<td>DIKLAT</td>
	<td>SPD</td>
	<td>Petugas Haji</td>
	<td>Point</td>
  </tr>
  </thead>";
  $no=1;
  while($dt=mysql_fetch_array($tampil)){
   echo "<tr>
  <td>$no</td>
  <td>$dt[id_waktu_t]</td>
  <td>$dt[tanggal]</td>
    <td>$nip1</td>
	 <td>$dt[c_sakit_t]</td>
	 <td>$dt[c_alasan_t]</td>
	<td>$dt[c_tahunan_t]</td>
	<td>$dt[diklat]</td>
	<td>$dt[spd]</td>
    <td>$dt[haji] </td>
	<td>$dt[t_waktu_t] </td>
  </tr>
  ";
  $no++;
}
  echo"
  </tr>
  <tr>
  <td colspan=10 > NILAI
  </td>
  <td>"; $tgl= date('Y-m-d');
	$per=explode('-',$tgl);
	$bln=$per[1];
	$thn=$per[0];
	$waktu= date ('H:i:s');
	
  $qry_jumlah_b=mysql_query("select SUM(t_waktu_t) from waktu_t where 
						 Month(waktu_t.tanggal)='$bln' 
						 and Year(waktu_t.tanggal)='$thn' and nip='$_GET[nip]'
						 order by id_waktu_t ASC ");
        $data_b=mysql_fetch_array($qry_jumlah_b);
        $nilai=$data_b[0];
        echo $nilai;
  
		echo"</td>
  </tr>";
echo "  
</table>

	";
	echo"<hr>";
	$nip=$_SESSION['namauser'];
	$tampil1=mysql_query("select * from pegawai where nip='$_GET[nip]' ");
	while($dt=mysql_fetch_array($tampil1)){
  $nip1=$dt['nip']; }
  	$tgl= date('Y-m-d');
	$per=explode('-',$tgl);
	$bln=$per[1];
	$thn=$per[0];
	$waktu= date ('H:i:s');
	$tampil=mysql_query("select * from waktu_k where 
						 Month(waktu_k.tanggal)='$bln' 
						 and Year(waktu_k.tanggal)='$thn' and nip='$_GET[nip]'
						 order by id_waktu_k ASC  ");
	echo "<h2 class='head'>WAKTU PENGURANGAN EFEKTIF</h2>
	<table class='table table-bordered table-hover table-striped'>
	<thead>
  <tr>
  <td>No</td>
  <td>ID Waktu</td>
  <td>Tanggal</td>
    <td>Nip</td>
	<td>Sakit</td>
	<!--<td>Sakit > 2 Hr</td>-->
	<td>Alpha</td>
	<td>Telat</td>
	<!--<td>Cuti Sakit</td>-->
	<td>Cuti Alasan Penting</td>
	<td>Cuti Bersalin</td>
	<!--<td>Cuti Besar</td>-->
	<td>Izin</td>
	<!--<td>Meninggal</td>-->
	<td>Point</td>
  </tr>
  </thead>";
  $no=1;
  while($dt=mysql_fetch_array($tampil)){
   echo "<tr>
  <td>$no</td>
  <td>$dt[id_waktu_k]</td>
  <td>$dt[tanggal]</td>
    <td>$nip1</td>
	<td>$dt[sakit1]</td>
<!--<td>$dt[sakit2]</td>-->
	<td>$dt[alpha]</td>
	<td>$dt[telat]</td>
	 <!--<td>$dt[c_sakit_k]</td>-->
	 <td>$dt[c_alasan_k]</td>
	<td>$dt[c_persalinan_k]</td>
	<!--<td>$dt[c_besar_k]</td>-->
	<td>$dt[izin]</td>
	<!--<td>$dt[meninggal]</td>-->
	<td>$dt[t_waktu_k] </td>
  </tr>
  ";
  $no++;
}
  echo"
  </tr>
  <tr>
  <td colspan=14 > NILAI
  </td>
  <td>";
  $tgl= date('Y-m-d');
	$per=explode('-',$tgl);
	$bln=$per[1];
	$thn=$per[0];
	$waktu= date ('H:i:s');
	
  $qry_jumlah_b=mysql_query("select SUM(t_waktu_k) from waktu_k where 
						 Month(waktu_k.tanggal)='$bln' 
						 and Year(waktu_k.tanggal)='$thn' and nip='$_GET[nip]'
						 order by id_waktu_k ASC ");
        $data_b=mysql_fetch_array($qry_jumlah_b);
        $nilai=$data_b[0];
        echo $nilai;
		echo"
  </td>
  </tr>";
echo "  
</table>

	";
	
	break;
	
	case "penambahan":
	$tampil1=mysql_query("select * from pegawai where nip='$_GET[nip] ");
	while($dt=mysql_fetch_array($tampil)){
	$nip1=$dt['nip'];
	$nama=$dt['nama'];
	}
	$dat=mktime(0, 0, 0, date("m")-1, date("d"), date("Y"));
	$tgl= date('Y-m-d',$dat);
	echo "<h2 class='head'>Entry Penambahan Waktu Efektif</h2>
	<form action='$aksi?module=waktu&act=input_t' onsubmit='return validasi_input(this)' method='post' enctype='multipart/form-data' >
	<table class='tabelform tabpad'>
	
	<tr>
	<td colspan='3'>Di Nilai</td>
	</tr
	
	<tr>
	<td>Nip</td>
	<td>:</td>
	<td><input class='form-control' name='nip' type='text' value='$_GET[nip]' readonly > </td>
	<td></td>
	</tr>
	
	<tr>
	<td>Nama</td>
	<td>:</td>
	<td><input class='form-control' name='nama' type='text' value='$_GET[nama]' readonly > </td>
	<td></td>
	</tr>
	
	<tr>
	<td colspan='3''><hr></td>
	
	</tr>
	
	<tr>
	<td>Tanggal</td>
	<td>:</td>
	<td><input class='form-control' name='tanggal' type='text' value='$tgl' readonly></td>
	<td></td>
	</tr>
	
	<tr>
	<!--<td>Cuti Sakit</td>
	<td>:</td>
	<td><input class='form-control' name='c_sakit_t' type='text'></td>
	<td>Hari</td>
	</tr>-->
	
	<tr>
	<td>Cuti Alasan Penting</td>
	<td>:</td>
	<td><input class='form-control' name='c_alasan_t' type='text'></td>
	<td>Hari</td>
	</tr>
	
	<tr>
	<td>Cuti Tahunan</td>
	<td>:</td>
	<td><input class='form-control' name='c_tahunan_t' type='text'></td>
	<td>Hari</td>
	</tr>
	
	<tr>
	<td>Peningkatan Kompetensi</td>
	<td>:</td>
	<td><input class='form-control' name='diklat' type='text'></td>
	<td>Hari</td>
	</tr>
	
	<!--<tr>
	<td>SPD</td>
	<td>:</td>
	<td><input class='form-control' name='spd' type='text'></td>
	<td>Hari</td>
	</tr>-->
	
	<!--<tr>
	<td>Haji</td>
	<td>:</td>
	<td><input class='form-control' name='haji' type='text'></td>
	<td>Hari</td>
	</tr>-->
	
	<tr>
	<td></td>
	<td></td>
	<td><input type='submit' value='Simpan'>
	<input type='button' value='Batal' onclick='self.history.back()'>
	</td>
	</tr>
	
	</table>
	</form>
	";
	break;
	
	
	case "pengurangan":
	$tampil1=mysql_query("select * from pegawai where nip='$_GET[nip]' ");
	while($dt=mysql_fetch_array($tampil)){
	$nip1=$dt['nip'];
	}
	$dat=mktime(0, 0, 0, date("m")-1, date("d"), date("Y"));
	$tgl= date('Y-m-d',$dat);
	echo "<h2 class='head'>Entry Pengurangan Waktu Efektif</h2>
	<form action='$aksi?module=waktu&act=input_k' onsubmit='return validasi_input(this)' method='post' enctype='multipart/form-data' >
	<table class='tabelform tabpad'>
	
	<tr>
	<td colspan='3'>
	Di Nilai</td>
	</tr>
	
	<tr>
	<td>Nip</td>
	<td>:</td>
	<td><input class='form-control' name='nip' type='text' value='$_GET[nip]' readonly > </td>
	<td></td>
	</tr>
	
	<tr>
	<td>Nama</td>
	<td>:</td>
	<td><input class='form-control' name='nama' type='text' value='$_GET[nama]' readonly > </td>
	<td></td>
	</tr>
	
	<tr>
	<td colspan='3''><hr></td>
	
	</tr>
    <tr>
	<td>Tanggal</td>
	<td>:</td>
	<td><input class='form-control' name='tanggal' type='text' value='$tgl' readonly></td>
	<td></td>
	</tr>
	
	<tr>
	<td>Sakit</td>
	<td>:</td>
	<td><input class='form-control' name='sakit1' type='text'> </td>
	<td>Hari</td>
	</tr>
	
	<!--<tr>
	<td>Sakit > 2 Hari</td>
	<td>:</td>
	<td><input class='form-control' name='sakit2' type='text'> </td>
	<td>Hari</td>
	</tr>-->
	
	<tr>
	<td>Alpha</td>
	<td>:</td>
	<td><input class='form-control' name='alpha' type='text'> </td>
	<td>Hari</td>
	</tr>
	
		
	<tr>
	<td>Izin</td>
	<td>:</td>
	<td><input class='form-control' name='izin' type='text'></td>
	<td>Hari</td>
	</tr>
	
	<!--<tr>
	<td>Izin Setengah Hari</td>
	<td>:</td>
	<td><input class='form-control' name='izin_s' type='text'></td>
	<td>Hari</td>
	</tr>-->
	
	<!--<tr>
	<td>Meninggal</td>
	<td>:</td>
	<td><input class='form-control' name='meninggal' type='text'></td>
	<td>Hari</td>
	</tr>-->
	
	<tr>
	<td>Telat</td>
	<td>:</td>
	<td><input class='form-control' name='telat' type='text'> </td>
	<td>Menit</td>
	</tr>
	
	<!--<tr>
	<td>Cuti Sakit</td>
	<td>:</td>
	<td><input class='form-control' name='c_sakit_k' type='text'></td>
	<td>Hari</td>
	</tr>-->
	
	<tr>
	<td>Cuti Alasan Penting</td>
	<td>:</td>
	<td><input class='form-control' name='c_alasan_k' type='text'></td>
	<td>Hari</td>
	</tr>
	
	<tr>
	<td>Cuti Bersalin</td>
	<td>:</td>
	<td><input class='form-control' name='c_persalinan_k' type='text'></td>
	<td>Hari</td>
	</tr>
	
	<!--<tr>
	<td>Cuti Besar</td>
	<td>:</td>
	<td><input class='form-control' name='c_besar_k' type='text'></td>
	<td>Hari</td>
	</tr>-->
	
	<tr>
	<td></td>
	<td></td>
	<td><input type='submit' value='Simpan'>
	<input type='button' value='Batal' onclick='self.history.back()'>
	</td>
	</tr>
	
	</table>
	</form>
	";
	break;
	
	
	case "pengukuran":
	echo"<h2 class='head'>Pengukuran</h2>";
	$tampil1=mysql_query("select * from pegawai where nip='$_GET[nip]' ");
	while($dt=mysql_fetch_array($tampil1)){
	$nip1=$dt['nip'];
	$nama=$dt['nama'];
	}
	$sa=$nama;
    $dat=mktime(0, 0, 0, date("m")-1, date("d"), date("Y"));
	$tgl= date('Y-m-d',$dat);
	$per=explode('-',$tgl);
	$bln=$per[1];
	$thn=$per[0];
	$waktu= date ('H:i:s');
	//Month(pengukuran.tanggal)='$bln'  and Year(pengukuran.tanggal)='$thn' and
	$tampil=mysql_query("select * from pengukuran where  nip='$_GET[nip]'
						 order by id_pengukuran ASC  ");
						 
						 
	$waktukerja=mysql_query("select * from waktu_kerja where 
						 Month(waktu_kerja.tanggal)='$bln' 
						 and Year(waktu_kerja.tanggal)='$thn' ");	
		$waktu=mysql_fetch_array($waktukerja);
        $w_kerja=$waktu[2];
		
		 $waktu_k=mysql_query("select * from waktu_k where 
						 Month(waktu_k.tanggal)='$bln' 
						 and Year(waktu_k.tanggal)='$thn' and nip='$_GET[nip]'
						 order by id_waktu_k ASC ");
        $wk=mysql_fetch_array($waktu_k);
        $point_waktu_k=$wk['t_waktu_k'];
	
		 $waktu_t=mysql_query("select * from waktu_t where 
						 Month(waktu_t.tanggal)='$bln' 
						 and Year(waktu_t.tanggal)='$thn' and nip='$_GET[nip]'
						 order by id_waktu_t ASC ");
        $wt=mysql_fetch_array($waktu_t);
        $point_waktu_t=$wt['t_waktu_t'];
				 
	    $kinerja_utama=mysql_query("select SUM(point) from kinerja where nip='$_GET[nip]'
						 order by id_kinerja ASC ");
        $point_kinerja=mysql_fetch_array($kinerja_utama);
        $point_utama=$point_kinerja[0];
		
		$kinerja_tambahan=mysql_query("select SUM(point) from kinerja_t where 
						 Month(kinerja_t.tanggal)='$bln' 
						 and Year(kinerja_t.tanggal)='$thn' and nip='$_GET[nip]'
						 order by id_kinerja_t ASC ");
		$point_kinerja=mysql_fetch_array($kinerja_tambahan);
        $point_tambahan=$point_kinerja[0];
		
		$kreatifitas=mysql_query("select SUM(point) from kreatifitas where 
						 Month(kreatifitas.tanggal)='$bln' 
						 and Year(kreatifitas.tanggal)='$thn' and nip='$_GET[nip]'
						 order by id_kreatifitas ASC ");
		$point_kinerja=mysql_fetch_array($kreatifitas);
        $point_kreatifitas=$point_kinerja[0];
		$jumlah_point=$point_utama+$point_tambahan+$point_kreatifitas+$point_waktu_t;
		$jh=300;
		$maksimal=($waktu1*$jh)-$point_waktu_k;
		$nilai=$waktu1;
		$we=min($jumlah_point,$nilai)/$nilai*100;
        $s=number_format($we,2);
	echo"
	<form action='$aksi?module=waktu&act=score' onsubmit='return validasi_input(this)' method='post' enctype='multipart/form-data' >
	<table class='table-bordered'>
	<tr>
	<td>NIP</td>
	<td> $_GET[nip] $nilai<input  name='nip' type='text' value='$_GET[nip]' hidden > </td>
	<td></td>
	</tr>
	<tr>
	<td>Nama</td>
	<td>  $_GET[nama]<input  name='nama' type='text' value='$_GET[nama]' hidden > </td>
	<td></td>
	</tr>
	<tr>
	<td>Tanggal</td>
	<td> $tgl </td>
	<td></td>
	</tr>
	<tr>
	<td>CAPAIAN WAKTU EFEKTIVITAS UTAMA DAN TAMBAHAN</td>
	<td> $point_utama<input  name='nilai_utama' type='text' value='$point_utama' hidden> </td>
	<td></td>
	</tr>
	<!--<tr>
	<td>CAPAIAN WAKTU EFEKTIVITAS TAMBAHAN</td>
	<td> $point_tambahan<input  name='nilai_tambahan' type='text' value='$point_tambahan' hidden >  </td>
	<td></td>
	</tr>
	<tr>
	<td>CAPAIAN WAKTU KREATIVITAS</td>
	<td> $point_kreatifitas<input name='nilai_kreatifitas' type='text' value='$point_kreatifitas' hidden > </td>
	<td></td>
	</tr>-->
	<tr>
	<td>TOTAL CAPAIAN WAKTU EFEKTIVITAS</td>
	<td> $jumlah_point<input  name='jumlah' type='text' value='$jumlah_point' hidden> <input  name='wk' type='text' value='$point_waktu_k' hidden >  </td>
	<td></td>
	</tr>
	
	</tr>
	<tr>
	<td>Jumlah Hari Kerja</td>
	<td><input class='form-control' name='hari' value='$w_kerja' type='text' ><input  name='tanggal' type='text' value='$tgl' hidden > </td>
	<td></td>
	</tr>
	<tr>
	<td>Jam Kerja</td>
	<td>$jh Menit/Hari</td>
	</tr>
	</table>

	
	<input type=submit value=Simpan><input type=button value=Batal onclick=self.history.back()></td>
		</form>
	<table class='table table-bordered table-hover table-striped'>
	<thead>
  <tr>
  <td></td>
  <td>ID Pengukuran</td>
  <td>Tanggal</td>
    <td>Nip</td>
	<!--<td>Nilai Kinerja Utama</td>
	<td>Nilai kinerja Tambahan</td>-->
	<!--<td>Nilai Kreatifitas</td>-->
	<td>Total Kinerja</td>
	<td>Hari Kerja</td>
	<td>Maximal Waktu</td>
	<td>Point</td>
	<td>Action</td>
  </tr>
  </thead>";
  $no=1;
  while($dt=mysql_fetch_array($tampil)){
  $vol=$dt['jumlah']/$time;
  echo "<tr>
  <td>$no</td>
  <td>$dt[id_pengukuran]</td>
  <td>$dt[tanggal]</td>
    <td>$dt[nip]</td>
	 <!--<td>$dt[nilai_utama]</td>
	 <td>$dt[nilai_tambahan]</td>-->
	<!--<td>$dt[nilai_kreatifitas]</td>-->
	<td>$dt[nilai_utama]</td>
	<td>$dt[hari]</td>
	<td>$dt[max_waktu]</td>
	<td>$dt[point]</td>
	<td><a href=\"$aksi?module=waktu&act=hapus_p&id_pengukuran=$dt[id_pengukuran]\" onClick=\"return confirm('Apakah Anda benar-benar mau menghapusnya?')\">Hapus</a></span></td>
  </tr>";
  $no++;
  }
echo "  
</table>
	
	";
  
		
	break;
	
	case "pengukuranm":
	echo"<h2 class='head'>Pengukuran</h2>";
	$tampil1=mysql_query("select * from pegawai where nip='$_GET[nip]' ");
	while($dt=mysql_fetch_array($tampil1)){
	$nip1=$dt['nip'];
	$nama=$dt['nama'];
	}
	$sa=$nama;
  $dat=mktime(0, 0, 0, date("m")-1, date("d"), date("Y"));
	$tgl= date('Y-m-28',$dat);
	$bln=$per[1];
	$thn=$per[0];
	$waktu= date ('H:i:s');
	$tampil=mysql_query("select * from pengukuran where 
						 Month(pengukuran.tanggal)='$bln' 
						 and Year(pengukuran.tanggal)='$thn' and nip='$_GET[nip]'
						 order by id_pengukuran ASC  ");
						 
	$kinerja_utama=mysql_query("select SUM(point) from kinerja where 
						 Month(kinerja.tanggal)='$bln' 
						 and Year(kinerja.tanggal)='$thn' and nip='$_GET[nip]'
						 order by id_kinerja ASC ");
        $point_kinerja=mysql_fetch_array($kinerja_utama);
        $point_utama=$point_kinerja[0];
		
		$kinerja_tambahan=mysql_query("select SUM(point) from kinerja_t where 
						 Month(kinerja_t.tanggal)='$bln' 
						 and Year(kinerja_t.tanggal)='$thn' and nip='$_GET[nip]'
						 order by id_kinerja_t ASC ");
		$point_kinerja=mysql_fetch_array($kinerja_tambahan);
        $point_tambahan=$point_kinerja[0];
		
		$kreatifitas=mysql_query("select SUM(point) from kreatifitas where 
						 Month(kreatifitas.tanggal)='$bln' 
						 and Year(kreatifitas.tanggal)='$thn' and nip='$_GET[nip]'
						 order by id_kreatifitas ASC ");
		$point_kinerja=mysql_fetch_array($kreatifitas);
        $point_kreatifitas=$point_kinerja[0];
		$jumlah_point=$point_utama+$point_tambahan+$point_kreatifitas;
		$jh=300;
		$maksimal=$waktu1*$jh;
		$nilai=$waktu1;
		$we=min($jumlah_point,$nilai)/$nilai*100;
        $s=number_format($we,2);
	echo"
	<form action='$aksi?module=waktu&act=score' method='post' enctype='multipart/form-data' >
	<table class=''>
	<tr>
	<td>NIP</td>
	<td>:</td>
	<td> $_GET[nip]<input  name='nip' type='text' value='$_GET[nip]' hidden > </td>
	<td></td>
	</tr>
	<tr>
	<td>Nama</td>
	<td>:</td>
	<td>  $_GET[nama]<input  name='nama' type='text' value='$_GET[nama]' hidden > </td>
	<td></td>
	</tr>
	<tr>
	<td>Tanggal</td>
	<td>:</td>
	<td> $tgl </td>
	<td></td>
	</tr>
	<tr>
	<td>CAPAIAN WAKTU EFEKTIVITAS UTAMA</td>
	<td>:</td>
	<td> $point_utama<input  name='nilai_utama' type='text' value='$point_utama' hidden > </td>
	<td></td>
	</tr>
	<tr>
	<td>CAPAIAN WAKTU EFEKTIVITAS TAMBAHAN</td>
	<td>:</td>
	<td> $point_tambahan<input  name='nilai_tambahan' type='text' value='$point_tambahan' hidden > <input  name='tanggal' type='text' value='$tgl' hidden > </td>
	<td></td>
	</tr>
	<tr>
	<td>CAPAIAN WAKTU KREATIVITAS</td>
	<td>:</td>
	<td> $point_kreatifitas<input name='nilai_kreatifitas' type='text' value='$point_kreatifitas' hidden > </td>
	<td></td>
	</tr>
	<tr>
	<td>TOTAL CAPAIAN WAKTU EFEKTIVITAS</td>
	<td>:</td>
	<td> $jumlah_point<input  name='jumlah' type='text' value='$jumlah_point' hidden > </td>
	<td></td>
	</tr>
	<tr>
	<td colspan='4'><hr></td>
	</tr>
	<tr>
	<td>Jumlah Hari Kerja</td>
	<td>:</td>
	<td><input class='form-control' name='hari' type='text' > </td>
	<td></td>
	</tr>
	<tr>
	<td>Jam Kerja</td>
	<td>:</td>
	<td>$jh Menit/Hari <input type=submit value=Simpan>||<input type=button value=Batal onclick=self.history.go(-2)></td>
	<td></td>
	</tr>
	</table>
	</form>
	
	<table class='table table-bordered table-hover table-striped'>
	<thead>
  <tr>
  <td>No</td>
  <td>ID Pengukuran</td>
  <td>Tanggal</td>
    <td>Nip</td>
	<td>Nilai Kinerja Utama</td>
	<td>Nilai kinerja Tambahan</td>
	<td>Nilai Kreatifitas</td>
	<td>Total Kinerja</td>
	<td>Hari Kerja</td>
	<td>Maximal Waktu</td>
	<td>Point</td>
  </tr>
  </thead>";
  $no=1;
  while($dt=mysql_fetch_array($tampil)){
  $vol=$dt[jumlah]/$time;
  echo "<tr>
  <td>$no</td>
  <td>$dt[id_pengukuran]</td>
  <td>$dt[tanggal]</td>
    <td>$dt[nip]</td>
	 <td>$dt[nilai_utama]</td>
	 <td>$dt[nilai_tambahan]</td>
	<td>$dt[nilai_kreatifitas]</td>
	<td>$dt[jumlah]</td>
	<td>$dt[hari]</td>
	<td>$dt[max_waktu]</td>
	<td>$dt[point]</td>
  </tr>";
  $no++;
  }
echo "  
</table>
	
	";
  
		
	break;
	
	case "lihat":
	echo"Tanggal : 
	<form action='?module=kinerja&act=cari' method='POST' ><table border='0'>
	<tr>
	<td>
	<input class='form-control' name='t1' width='60' type='date' ></td><td> s/d <input class='form-control'  width='60' name='t2' type='date' > <input type=submit value='Tampilkan' > </td>
	</tr>
	</table>
	</form>"; 	
	$nip=$_SESSION['namauser'];
	$dat=mktime(0, 0, 0, date("m")-1, date("d"), date("Y"));
	$tgl= date('Y-m-28',$dat);
	$per=explode('-',$tgl);
	$bln=$per[1];
	$thn=$per[0];
	$waktu= date ('H:i:s');
	$tampil=mysql_query("select * from kinerja where 
						 Month(kinerja.tanggal)='$bln' 
						 and Year(kinerja.tanggal)='$thn' and nip='$_GET[nip]'
						 order by id_kinerja ASC  ");
	echo "<h2 class='head'>DATA KINERJA UNIT USER</h2>
	<div>
	<input type=button value=Kembali onclick=self.history.back()>
	</div>
	
	<table class='table table-bordered table-hover table-striped'>
	<thead>
  <tr>
  <td>No</td>
  <td>ID Kinerja</td>
  <td>Tanggal</td>
    <td>Nip</td>
	<td>Nama kp</td>
	<td>Uraian</td>
	<td>Jam Mulai</td>
	<td>Jam Selesai</td>
	<td>Durasi Pekerjaan</td>
	<td>Validasi</td>
	<td>Point</td>
  </tr>
  </thead>";
  $no=1;
  while($dt=mysql_fetch_array($tampil)){
  $nilai=$dt['jumlah']*1;
  echo "<tr>
  <td>$no</td>
  <td>$dt[id_kinerja]</td>
  <td>$dt[tanggal]</td>
    <td>$dt[nip]</td>
	 <td>$dt[kd_skp]</td>
	 <td>$dt[uraian]</td>
	<td>$dt[jam_mulai]</td>
	<td>$dt[jam_akhir]</td>
	<td>$dt[jumlah] Menit </td>
	<td>
	
	<input type='text' name='id_kinerja' value='$dt[id_kinerja]' hidden>
	<input type='text' name='kd_skp' value='$dt[kd_skp]' hidden>
	<input type='text' name='tanggal' value='$dt[tanggal]' hidden>
	<input type='text' name='nip' value='$dt[nip]' hidden>
	<input type='text' name='uraian' value='$dt[uraian]' hidden>
	<input type='text' name='jam_mulai' value='$dt[jam_mulai]' hidden>
	<input type='text' name='jam_akhir' value='$dt[jam_akhir]' hidden>
	<input type='text' name='jumlah' value='$dt[jumlah]' hidden>
	<input type='text' name='point' value='$dt[jumlah]' hidden>
	<a href='?module=kinerja&act=validasi&id_kinerja=$dt[id_kinerja]'><input type=submit value='Validasi' name='validas'></s><a href='?module=kinerja&act=batal&id_kinerja=$dt[id_kinerja]'><input type=submit value='Batal Validasi' name='validas'></s></td>
    <td>$dt[point] </td>
  </tr>
  ";
  $no++;
  }echo"
  </tr>
  <tr>
  <td colspan=10 > NILAI
  </td>
  <td>"; 
 $dat=mktime(0, 0, 0, date("m")-1, date("d"), date("Y"));
	$tgl= date('Y-m-28',$dat);
	$per=explode('-',$tgl);
	$bln=$per[1];
	$thn=$per[0];
	$waktu= date ('H:i:s');
	
  $qry_jumlah_b=mysql_query("select SUM(point) from kinerja where 
						 Month(kinerja.tanggal)='$bln' 
						 and Year(kinerja.tanggal)='$thn' and nip='$_GET[nip]'
						 order by id_kinerja ASC ");
        $data_b=mysql_fetch_array($qry_jumlah_b);
        $nilai=$data_b[0];
        echo $nilai;
		echo"</td>
  </tr>";
echo "  
</table>

	";
	
	break;
	
	case "validasi":
	$ambil=mysql_query("select * from kinerja where id_kinerja='$_GET[id_kinerja]'");
	$ed=mysql_fetch_array($ambil);
	echo "Yakin anda Ingin Menyetujui Validasi Ini  ??
	<form action='$aksi?module=kinerja&act=val' method='post' enctype='multipart/form-data' >
	<input type='hidden' name='id_kinerja' readonly value='$ed[id_kinerja]' >
	<table class='tabelform tabpad'>
	<tr>
	<td><input class='form-control' name='id_kinerja' type='text' value='$ed[id_kinerja]' readonly ></td>
	</tr>
	<tr>
	<td> <input type='text' name='nip' readonly value='$ed[nip]' readonly>
	</td>
	</tr>	
	<tr>
	<td><input class='form-control' name='tanggal' type='date' value='$ed[tanggal]' readonly ></td>
	</tr>
	
	<tr>
	<td><input class='form-control' name='kd_skp' type='text' value='$ed[kd_skp]' readonly></td>
	</tr>
	
	<tr>
	<td><input class='�nput' name='uraian' value='$ed[uraian]' readonly></td>
	</tr>
	
	<tr>
	<td><input class='form-control' name='jam_mulai' type='time' value='$ed[jam_mulai]' readonly></td>
	</tr>
	
	<tr>
	<td><input class='form-control' name='jam_akhir' type='time' value='$ed[jam_akhir]' readonly></td>
	</tr>
	<tr>
	<td><input class='form-control' name='point' type='text' value='$ed[jumlah]' readonly></td>
	</tr>
	<tr>
	<td><input type=submit value=Iya>
	<input type=button value=Batal onclick=self.history.back()>
	</td>
	</tr>
	</table>
	</form>
	";
	break;
	
	case "batal":
	$ambil=mysql_query("select * from kinerja where id_kinerja='$_GET[id_kinerja]'");
	$ed=mysql_fetch_array($ambil);
	echo "Yakin anda Ingin Membatalkan Validasi Ini  ??
	<form action='$aksi?module=kinerja&act=val' method='post' enctype='multipart/form-data' >
	<input type='hidden' name='id_kinerja' readonly value='$ed[id_kinerja]' >
	<table class='tabelform tabpad'>
	<tr>
	<td><input class='form-control' name='id_kinerja' type='text' value='$ed[id_kinerja]' readonly ></td>
	</tr>
	<tr>
	<td> <input type='text' name='nip' readonly value='$ed[nip]' readonly>
	</td>
	</tr>	
	<tr>
	<td><input class='form-control' name='tanggal' type='date' value='$ed[tanggal]' readonly ></td>
	</tr>
	
	<tr>
	<td><input class='form-control' name='kd_skp' type='text' value='$ed[kd_skp]' readonly></td>
	</tr>
	
	<tr>
	<td><input class='�nput' name='uraian' value='$ed[uraian]' readonly></td>
	</tr>
	
	<tr>
	<td><input class='form-control' name='jam_mulai' type='time' value='$ed[jam_mulai]' readonly></td>
	</tr>
	
	<tr>
	<td><input class='form-control' name='jam_akhir' type='time' value='$ed[jam_akhir]' readonly></td>
	</tr>
	<tr>
	<td><input class='form-control' name='' type='text' value='$ed[jumlah]' readonly><input class='form-control' name='point' type='text' value='0' hidden></td>
	</tr>
	<tr>
	<td><input type=submit value=Iya>
	<input type=button value=Batal onclick=self.history.back()>
	</td>
	</tr>
	</table>
	</form>
	";
	break;
	
	
	case "edit":
	$ambil=mysql_query("select * from kinerja where id_kinerja='$_GET[id_kinerja]'");
	$ed=mysql_fetch_array($ambil);
	echo "<h2 class='head'>Edit Data Kinerja</h2>
	<form action='$aksi?module=kinerja&act=edit' method='post' enctype='multipart/form-data' >
	<input type='hidden' name='id_kinerja' readonly value='$ed[id_kinerja]' >
	<table class='tabelform tabpad'>
	<tr>
	<td>Id Kinerja</td><td>:</td><td><input class='form-control' name='id_kinerja' type='text' value='$ed[id_kinerja]' readonly ></td>
	</tr>
	<tr>
	<td>Nip</td><td>:</td><td> <input type='text' name='nip' readonly value='$ed[nip]' >"; 
	echo "</td>
	</tr>	
	<tr>
	<td>Tanggal</td><td>:</td><td><input class='form-control' name='tanggal' type='date' value='$ed[tanggal]' ></td>
	</tr>
	
	<tr>
	<td>Pilih SKP</td><td>:</td><td>
	<select name='kd_skp'> 
	<option value='$ed[kd_skp]' selected='selected'>$ed[kd_skp]</option>";
	$sql = mysql_query("select *FROM skptahunan WHERE nip LIKE '%$_SESSION[namauser]%' ");
    if(mysql_num_rows($sql) != 0){
        while($data = mysql_fetch_assoc($sql)){
            echo '<option>'.$data['kd_skp'].'</option>';
        }
    } echo"
</td>
	</tr>
	
	<tr>
	<td>Uraian</td><td>:</td><td><textarea name='uraian'  cols='100' rows='10' tabindex='4'>$ed[uraian]</textarea></td>
	</tr>
	
	<tr>
	<td>Jam Mulai</td><td>:</td><td><input class='form-control' name='jam_mulai' type='time' value='$ed[jam_mulai]'></td>
	</tr>
	
	<tr>
	<td>Jam Akhir</td><td>:</td><td><input class='form-control' name='jam_akhir' type='time' value='$ed[jam_akhir]'></td>
	</tr>
	
	<tr>
	<td></td><td></td><td><input type=submit value=Simpan>
	<input type=button value=Batal onclick=self.history.back()>
	</td>
	</tr>
	</table>
	</form>
	";
	break;
	
	
	
	
	case "cari":
	$t1=$_POST['t1'];
	$t2=$_POST['t2'];
	echo"yang di cari tanggal $t1 sampai $t2";
	$tampil=mysql_query("select * from kinerja where tanggal between '$t1' and '$t2'  ");
    
	echo "<div>
	<input type=button value=Kembali onclick=self.history.back()>
	</div>
	<h2 class='head'>DATA KINERJA PEGAWAI</h2>
	<table class='table table-bordered table-hover table-striped'>
	<thead>
  <tr>
  <td>No</td>
  <td>ID Kinerja</td>
  <td>Tanggal</td>
    <td>Nip</td>
	<td>kd_skp</td>
	<td>Uraian</td>
	<td>Jam Mulai</td>
	<td>Jam Selesai</td>
	<td>Durasi Pekerjaan</td>
	<td>Control</td>
	<td>Point</td>
  </tr>
  </thead>";
  $no=1;
  while($dt=mysql_fetch_array($tampil)){
  echo "<tr>
  <td>$no</td>
  <td>$dt[id_kinerja]</td>
  <td>$dt[tanggal]</td>
    <td>$dt[nip]</td>
	 <td>$dt[kd_skp]</td>
	 <td>$dt[uraian]</td>
	<td>$dt[jam_mulai]</td>
	<td>$dt[jam_akhir]</td>
	<td>$dt[jumlah] Menit</td>
	<td><span><a href='?module=kinerja&act=validasi&id_kinerja=$dt[id_kinerja]'><input type=submit value='Validasi' name='validas'></s><a href='?module=kinerja&act=batal&id_kinerja=$dt[id_kinerja]'><input type=submit value='Batal Validasi' name='validas'></s></span><span>
	</span>
	<td>$dt[point] </td>
	</td>
  </tr>";
  $no++;
  }
echo " 
<tr>
  <td colspan=10 > NILAI
  </td>
  <td>"; 
  $dat=mktime(0, 0, 0, date("m")-1, date("d"), date("Y"));
	$tgl= date('Y-m-28',$dat);
	$per=explode('-',$tgl);
	$bln=$per[1];
	$thn=$per[0];
	$waktu= date ('H:i:s');
	
  $qry_jumlah_b=mysql_query("select SUM(point) from kinerja where tanggal between '$t1' and '$t2' ");
        $data_b=mysql_fetch_array($qry_jumlah_b);
        $nilai=$data_b[0];
        echo $nilai;
		echo"</td>
  </tr> 
</table>
	";
	
}


?>