<?php 
include "../../config/koneksi.php";
include "../../config/fungsi_indotgl.php";
include "../../config/class_paging.php";
include "../../config/kode_auto.php";
include "../../config/fungsi_thumb.php";
error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
$module=$_GET['module'];
$act=$_GET['act'];

if($module=='kinerja' AND $act=='hapus' ){ 
	mysql_query("delete from kinerja where id_kinerja='$_GET[id_kinerja]'");
	header('location:../../media.php?module='.$module);
}

$mulai="$_POST[jam_mulai]"; //jam dalam format STRING
$selesai="$_POST[jam_akhir]"; //jam dalam format DATE real itme

$mulai_time=(is_string($mulai)?strtotime($mulai):$mulai);// memaksa mebentuk format time untuk string
$selesai_time=(is_string($selesai)?strtotime($selesai):$selesai);

$detik=$selesai_time-$mulai_time; //hitung selisih dalam detik
$menit=floor($detik/60); //hiutng menit
$sisa_detik=$detik%$menit; //hitung sisa detik

if($module=='waktu' AND $act=='input_t' ){
$tl="$menit";
$id=kdauto(waktu_t,WKT);
$cst=$_POST["c_sakit_t"]*60;
$cat=$_POST["c_alasan_t"]*300;
$ctt=$_POST["c_tahunan_t"]*300;
$diklat=$_POST["diklat"]*300;
$spd=$_POST["spd"]*300;
$haji=$_POST["haji"]*300;
$t_waktu_t=$cst+$cat+$ctt+$diklat+$spd+$haji;
	mysql_query("insert into waktu_t set id_waktu_t='$id',nip='$_POST[nip]',c_sakit_t='$_POST[c_sakit_t]',c_alasan_t='$_POST[c_alasan_t]',
										   c_tahunan_t='$_POST[c_tahunan_t]', diklat='$_POST[diklat]',
										   spd='$_POST[spd]', haji='$_POST[haji]', tanggal='$_POST[tanggal]', t_waktu_t='$t_waktu_t'
										   ");
	echo "<script>alert('Lanjutkan Memvalidasi'); window.location = 'javascript:history.go(-2)'</script>";
}

elseif($module=='waktu' AND $act=='input_k' ){
$tl="$menit";
$id=kdauto(waktu_k,WKT);
$sakit1=$_POST["sakit1"]*30;
$sakit2=$_POST["sakit2"]*300;
$alpha=$_POST["alpha"]*600;
$izin=$_POST["izin"]*300;
$izin_s=$_POST["izin_s"]*150;
$telat=$_POST["telat"]*1;
$csk=$_POST["c_sakit_k"]*240;
$cak=$_POST["c_alasan_k"]*300;
$cpk=$_POST["c_persalinan_k"]*300;
$cbk=$_POST["c_besar_k"]*300;
$meninggal=$_POST["meninggal"]*300;
$t_waktu_k=$sakit1+$sakit2+$alpha+$izin+$telat+$csk+$cak+$cpk+$cbk+$meninggal;
	mysql_query("insert into waktu_k set id_waktu_k='$id',nip='$_POST[nip]',sakit1='$_POST[sakit1]', sakit2='$_POST[sakit2]', alpha='$_POST[alpha]',tanggal='$_POST[tanggal]',
										   izin='$_POST[izin]', izin_s='$_POST[izin_s]',
										   telat='$_POST[telat]', c_sakit_k='$_POST[c_sakit_k]', c_alasan_k='$_POST[c_alasan_k]',
										   c_persalinan_k='$_POST[c_persalinan_k]',c_besar_k='$_POST[c_besar_k]',meninggal='$_POST[meninggal]',
										    t_waktu_k='$t_waktu_k'
										   ");
	echo "<script>alert('Lanjutkan Memvalidasi'); window.location = 'javascript:history.go(-2)'</script>";
}

elseif($module=='kinerja' AND $act=='edit' ){
$tl="$menit";
	mysql_query("update kinerja set 	   kd_skp='$_POST[kd_skp]',
										   uraian='$_POST[uraian]',
										   jam_mulai='$_POST[jam_mulai]',
										   jam_akhir='$_POST[jam_akhir]',
										   jumlah='$tl',tanggal='$_POST[tanggal]'
										   where id_kinerja='$_POST[id_kinerja]'
										   ");
	header('location:../../media.php?module='.$module);
}
elseif($module=='kinerja' AND $act=='val' ){
$tl="$menit";
mysql_query("update kinerja set 	   kd_skp='$_POST[kd_skp]',
										   uraian='$_POST[uraian]',
										   jam_mulai='$_POST[jam_mulai]',
										   jam_akhir='$_POST[jam_akhir]',
										   jumlah='$tl',tanggal='$_POST[tanggal]',point='$_POST[point]'
										   where id_kinerja='$_POST[id_kinerja]'
										   ");
										   $bagian=$_SESSION['id_bag'];
										    echo "<script>alert('Lanjutkan Memvalidasi'); window.location = 'javascript:history.go(-2)'</script>";
}

elseif($module=='waktu' AND $act=='hapus_p' ){
	mysql_query("delete from pengukuran where id_pengukuran = '$_GET[id_pengukuran]'");
	echo "<script>alert('Lanjutkan Memvalidasi Ulang'); window.location = 'javascript:history.go(-1)'</script>";
}
elseif($module=='waktu' AND $act=='hapus_wt' ){
	mysql_query("delete from waktu_t where id_waktu_t = '$_GET[id_waktu_t]'");
echo "<script>alert('Lanjutkan Memvalidasi Ulang'); window.location = 'javascript:history.go(-2)'</script>";
}
elseif($module=='waktu' AND $act=='hapus_wk' ){
	mysql_query("delete from waktu_k where id_waktu_k = '$_GET[id_waktu_k]'");
echo "<script>alert('Lanjutkan Memvalidasi Ulang'); window.location = 'javascript:history.go(-2)'</script>";
}
elseif($module=='waktu' AND $act=='score' ){
$tl="$menit";
$hari=$_POST["hari"];
$jumlah=$_POST["jumlah"];
$waktu_k=$_POST["wk"];
$max=$hari*300;
$nilai=($max-$waktu_k)/$max*100;
$point=number_format($nilai,2);
$id=kdauto('pengukuran','PNK');
	mysql_query("insert into pengukuran set id_pengukuran='$id',nip='$_POST[nip]',nilai_utama='$_POST[nilai_utama]',nilai_tambahan='$_POST[nilai_tambahan]',nilai_kreatifitas='$_POST[nilai_kreatifitas]',
										   jumlah='$_POST[jumlah]',hari='$_POST[hari]',max_waktu='$max',
										   tanggal='$_POST[tanggal]', point='$point'
										   ");
echo "<script>alert('Lanjutkan Memvalidasi'); window.location = 'javascript:history.go(-1)'</script>";
}

?>