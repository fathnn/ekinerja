<?php
error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
$aksi="modul/setting/aksi_setting.php";

switch($_GET[act]){
	default:
	$tampil=mysql_query("select * from setting");
	echo "<h2 class='head'>SETTING VALIDASI</h2>
	<form action='$aksi?module=setting&act=update' method='post' enctype='multipart/form-data' >
	<table class='table table-bordered table-hover table-striped'>
	<thead>
  <tr>
    <td>No</td>
    <td>Akses Penanggung Jawab/Kasatpel</td>
    <td>akses Management</td>
	<td>Izinkan Input Ekinerja Di Bulan Sebelumnya</td>
  </tr>
  </thead>";
  $no=1;
  while($dt=mysql_fetch_array($tampil)){
  echo "<tr>
    <td>$no</td>
    <td>";
	echo "<input name='pj' type='radio' value='0'"; if($dt['pj']=='0'){ echo "checked";} echo "/>Akses Di Tutup <p>";
	echo "<input name='pj' type='radio' value='1'"; if($dt['pj']=='1'){ echo "checked";} echo "/>Akses Di Buka ";
	echo"</td>
    <td>";
	echo "<input name='management' type='radio' value='0'"; if($dt['management']=='0'){ echo "checked";} echo "/>Akses Di Tutup <p> ";
	echo "<input name='management' type='radio' value='1'"; if($dt['management']=='1'){ echo "checked";} echo "/>Akses Di Buka ";
	echo"</td>
	<td>";
	echo "<input name='kinerja' type='radio' value='0'"; if($dt['kinerja']=='0'){ echo "checked";} echo "/>Akses Di Tutup <p> ";
	echo "<input name='kinerja' type='radio' value='1'"; if($dt['kinerja']=='1'){ echo "checked";} echo "/>Akses Di Buka ";
	echo"</td>
  </tr>
  <tr>
  <td colspan='4'><input class='form-control' name='id_setting' type='hidden' value='$dt[id_setting]'><input type='submit' value='Update'></td>
  </tr>
  ";
  $no++;
  }
echo "  
</table>
</form>
	";
	
	break;

	
	case "hapus":
	
	break;
}


?>