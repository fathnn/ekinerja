<?php 
include "../../config/koneksi.php";
include "../../config/fungsi_indotgl.php";
include "../../config/class_paging.php";
include "../../config/kode_auto.php";
include "../../config/fungsi_thumb.php";
error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
$module=$_GET['module'];
$act=$_GET['act'];

if($module=='disiplin' AND $act=='hapus' ){ 
	mysql_query("delete from disiplin where id_disiplin='$_GET[id_disiplin]'");
	echo "<script>alert('Data Sudah Di Hapus, Lanjutkan Memvalidasi Ulang'); window.location = 'javascript:history.go(-1)'</script>";
}

$mulai="$_POST[wm_k]"; //jam dalam format STRING
$selesai="$_POST[wa_k]"; //jam dalam format DATE real itme

$mulai_time=(is_string($mulai)?strtotime($mulai):$mulai);// memaksa mebentuk format time untuk string
$selesai_time=(is_string($selesai)?strtotime($selesai):$selesai);

$detik=$selesai_time-$mulai_time; //hitung selisih dalam detik
$menit=floor($detik/60); //hiutng menit
$sisa_detik=$detik%$menit; //hitung sisa detik

if($module=='disiplin' AND $act=='input' ){
$penampilan=($_POST["k_diri"]+$_POST["k_penampilan"]+$_POST["k_seragam"])/3;
$kerapihan=($_POST["k_alat"]+$_POST["k_ruangan"]+$_POST["k_sarana"])/3;
$nilai1=$penampilan*0.15;
$nilai2=$kerapihan*0.15;
$point=($nilai1+$nilai2)*10;
$id=kdauto(disiplin,DSP);
	mysql_query("insert into disiplin set id_disiplin='$id',nip='$_POST[nip]',k_penampilan='$_POST[k_penampilan]',k_diri='$_POST[k_diri]',k_seragam='$_POST[k_seragam]',
										   k_alat='$_POST[k_alat]', k_ruangan='$_POST[k_ruangan]',
										   k_sarana='$_POST[k_sarana]', tanggal='$_POST[tanggal]', point='$point'
										   ");
	echo "<script>alert('Lanjutkan Memvalidasi'); window.location = 'javascript:history.go(-2)'</script>";
}


?>