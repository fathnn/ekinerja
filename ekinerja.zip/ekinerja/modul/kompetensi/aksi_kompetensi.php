<?php 
include "../../config/koneksi.php";
include "../../config/fungsi_indotgl.php";
include "../../config/class_paging.php";
include "../../config/kode_auto.php";
include "../../config/fungsi_thumb.php";

$module=$_GET['module'];
$act=$_GET['act'];

if($module=='kompetensi' AND $act=='hapus' ){ 
	mysql_query("delete from kompetensi where id_kompetensi='$_GET[id_kompetensi]'");
	echo "<script>alert('Data Sudah Di Hapus, Lanjut Validasi Ulang'); window.location = 'javascript:history.go(-1)'</script>";
}

$mulai="$_POST[wm_k]"; //jam dalam format STRING
$selesai="$_POST[wa_k]"; //jam dalam format DATE real itme

$mulai_time=(is_string($mulai)?strtotime($mulai):$mulai);// memaksa mebentuk format time untuk string
$selesai_time=(is_string($selesai)?strtotime($selesai):$selesai);

$detik=$selesai_time-$mulai_time; //hitung selisih dalam detik
$menit=floor($detik/60); //hiutng menit
$sisa_detik=$detik%$menit; //hitung sisa detik

if($module=='kompetensi' AND $act=='score' ){
$penampilan=($_POST["k_diri"]+$_POST["k_penampilan"]+$_POST["k_seragam"])/3;

  $s1=number_format(($_POST['menganalisa1']+$_POST['menganalisa2'])/2,1);
  $s2=number_format(($_POST['komunikasi1']+$_POST['komunikasi2'])/2,1);
  $s3=number_format(($_POST['kerjasama1']+$_POST['kerjasama2'])/2,1);
  $s4=number_format(($_POST['kecerdasan1']+$_POST['kecerdasan2']+$_POST['kecerdasan3'])/3,1);
  $s5=number_format(($_POST['fokus1']+$_POST['fokus2'])/2,1);
  $s6=number_format(($_POST['tanggung1']+$_POST['tanggung2']+$_POST['tanggung3']+$_POST['tanggung4'])/4,1);
  $s7=number_format(($_POST['orientasi_k1']+$_POST['orientasi_k2'])/2,1);
  $s8=number_format(($_POST['inisiatif1']+$_POST['inisiatif2'])/2,1);
  $s9=number_format(($_POST['disiplin1']+$_POST['disiplin2']+$_POST['disiplin3'])/3,1);
  $s10=number_format(($_POST['orientasi_p1']+$_POST['orientasi_p2']+$_POST['orientasi_p3'])/3,1);
  $point=number_format(($s1+$s2+$s3+$s4+$s5+$s6+$s7+$s8+$s9+$s10)*0.7,2);
$id=kdauto(kompetensi,KMP);
	mysql_query("insert into kompetensi set id_kompetensi='$id',nip='$_POST[nip]',menganalisa1='$_POST[menganalisa1]',menganalisa2='$_POST[menganalisa2]',komunikasi1='$_POST[komunikasi1]',
										   komunikasi2='$_POST[komunikasi2]', kerjasama1='$_POST[kerjasama1]',kerjasama2='$_POST[kerjasama2]',kecerdasan1='$_POST[kecerdasan1]',kecerdasan2='$_POST[kecerdasan2]',kecerdasan3='$_POST[kecerdasan3]',
										   fokus1='$_POST[fokus1]',fokus2='$_POST[fokus2]',fokus3='$_POST[fokus3]',tanggung1='$_POST[tanggung1]',tanggung2='$_POST[tanggung2]',tanggung3='$_POST[tanggung3]',tanggung4='$_POST[tanggung4]',orientasi_k1='$_POST[orientasi_k1]',
										   orientasi_k2='$_POST[orientasi_k2]',inisiatif1='$_POST[inisiatif1]',inisiatif2='$_POST[inisiatif2]',disiplin1='$_POST[disiplin1]',disiplin2='$_POST[disiplin2]',disiplin3='$_POST[disiplin3]',
										   orientasi_p1='$_POST[orientasi_p1]',orientasi_p2='$_POST[orientasi_p2]',orientasi_p3='$_POST[orientasi_p3]', tanggal='$_POST[tanggal]', point='$point'
										   ");
	echo "<script>alert('Data Sudah Tersimpan, Lanjut Ke Menu Validasi'); window.location = 'javascript:history.go(-1)'</script>";
}



elseif($module=='kreatifitas' AND $act=='edit' ){
$tl="$menit";
	mysql_query("update kreatifitas set kreatifitas='$_POST[kreatifitas]',
										   uraian='$_POST[uraian]',
										   wm_k='$_POST[wm_k]',
										   wa_k='$_POST[wa_k]',
										   jumlah='$tl',tanggal='$_POST[tanggal]'
										   where id_kreatifitas='$_POST[id_kreatifitas]'
										   ");
	header('location:../../media.php?module='.$module);
}
elseif($module=='kreatifitas' AND $act=='val' ){
$tl="$menit";
mysql_query("update kreatifitas set 	   kreatifitas='$_POST[kreatifitas]',
										   uraian='$_POST[uraian]',
										   wm_k='$_POST[wm_k]',
										   wa_k='$_POST[wa_k]',
										   jumlah='$tl',tanggal='$_POST[tanggal]',point='$_POST[point]'
										   where id_kreatifitas='$_POST[id_kreatifitas]'
										   ");
										   $bagian=$_SESSION['id_bag'];
										    echo "<script>alert('Lanjutkan Memvalidasi'); window.location = 'javascript:history.go(-2)'</script>";
}

elseif($module=='kreatifitas' AND $act=='hapus' ){
	mysql_query("delete from kreatifitas where id_kreatifitas = '$_GET[id_kreatifitas]'");
	header('location:../../media.php?module='.$module);
}


?>