<script type="text/javascript">
function validasi_input(form){
  if (form.menganalisa1.value == ""){
    alert("menganalisa masih ada yg kosong!");
    form.menganalisa1.focus();
    return (false);
  }
   if (form.menganalisa2.value == ""){
    alert("menganalisa masih ada yg kosong!");
    form.menganalisa2.focus();
    return (false); 
  }
  if (form.komunikasi1.value == ""){
    alert("komunikasi masih ada yg kosong!");
    form.komunikasi1.focus();
    return (false); komunikasi1
  }
  if (form.komunikasi2.value == ""){
    alert("komunikasi masih ada yg kosong!");
    form.komunikasi2.focus();
    return (false); komunikasi1
  }
  if (form.kerjasama1.value == ""){
    alert("kerjasama masih ada yg kosong!");
    form.kerjasama1.focus();
    return (false);
  }
  if (form.kerjasama2.value == ""){
    alert("kerjasama masih ada yg kosong!");
    form.kerjasama2.focus();
    return (false);
  }
  if (form.kecerdasan1.value == ""){
    alert("kecerdasan masih ada yg kosong!");
    form.kecerdasan1.focus();
    return (false);
  }
  if (form.kecerdasan2.value == ""){
    alert("kecerdasan masih ada yg kosong!");
    form.kecerdasan2.focus();
    return (false);
  }
  if (form.kecerdasan3.value == ""){
    alert("kecerdasan masih ada yg kosong!");
    form.kecerdasan3.focus();
    return (false);
  }
  if (form.fokus1.value == ""){
    alert("fokus masih ada yg kosong!");
    form.fokus1.focus();
    return (false);
  }
  if (form.fokus2.value == ""){
    alert("fokus masih ada yg kosong!");
    form.fokus2.focus();
    return (false);
  }
  if (form.fokus3.value == ""){
    alert("fokus masih ada yg kosong!");
    form.fokus3.focus();
    return (false);
  }
  if (form.tanggung1.value == ""){
    alert("tanggung jawab masih ada yg kosong!");
    form.tanggung1.focus();
    return (false);
  }
  if (form.tanggung2.value == ""){
    alert("tanggung jawab masih ada yg kosong!");
    form.tanggung2.focus();
    return (false);
  }
  if (form.tanggung3.value == ""){
    alert("tanggung jawab masih ada yg kosong!");
    form.tanggung3.focus();
    return (false);
  }
  if (form.tanggung4.value == ""){
    alert("tanggung jawab masih ada yg kosong!");
    form.tanggung4.focus();
    return (false);
  }
  if (form.orientasi_k1.value == ""){
    alert("orientasi kualitas masih ada yg kosong!");
    form.orientasi_k1.focus();
    return (false);
  }
   if (form.orientasi_k2.value == ""){
    alert("orientasi kualitas masih ada yg kosong!");
    form.orientasi_k2.focus();
    return (false);
  }
   if (form.inisiatif1.value == ""){
    alert("inisiatif masih ada yg kosong!");
    form.inisiatif1.focus();
    return (false);
  }
  if (form.inisiatif2.value == ""){
    alert("inisiatif masih ada yg kosong!");
    form.inisiatif2.focus();
    return (false);
  }
  if (form.disiplin1.value == ""){
    alert("disiplin masih ada yg kosong!");
    form.disiplin1.focus();
    return (false);
  }
  if (form.disiplin2.value == ""){
    alert("disiplin masih ada yg kosong!");
    form.disiplin2.focus();
    return (false);
  }
  if (form.disiplin3.value == ""){
    alert("disiplin masih ada yg kosong!");
    form.disiplin3.focus();
    return (false);
  }
  if (form.orientasi_p1.value == ""){
    alert("orientasi pelanggan masih ada yg kosong!");
    form.orientasi_p1.focus();
    return (false);
  }
   if (form.orientasi_p2.value == ""){
    alert("orientasi pelanggan masih ada yg kosong!");
    form.orientasi_p2.focus();
    return (false);
  }
   if (form.orientasi_p3.value == ""){
    alert("orientasi pelanggan masih ada yg kosong!");
    form.orientasi_p3.focus();
    return (false);
  }
return (true);
}
</script>
<?php
error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
$aksi="modul/kompetensi/aksi_kompetensi.php";
$nip=$_SESSION['namauser'];
switch($_GET[act]){
	default:
	echo"
<a href='?module=kreatifitas&act=detail&nip=$_SESSION[namauser]'>Data Sudah Selesai Di Proses lanjutkan</a>";
	break;
	
	
	
	case "detail":
	echo"<h2 class='head'>Kompetensi (70%)</h2>";
	$tampil1=mysql_query("select * from pegawai where nip='$_GET[nip]' ");
	while($dt=mysql_fetch_array($tampil)){
	$nip1=$dt['nip'];
	$nama=$dt['nama'];
	}
	$sa=$nama;
   $dat=mktime(0, 0, 0, date("m")-1, date("d"), date("Y"));
	$tgl= date('Y-m-d',$dat);
	$per=explode('-',$tgl);
	$bln=$per[1];
	$thn=$per[0];
	$waktu= date ('H:i:s');
	$tampil=mysql_query("select * from kompetensi where 
						 Month(kompetensi.tanggal)='$bln' 
						 and Year(kompetensi.tanggal)='$thn' and nip='$_GET[nip]'
						 order by id_kompetensi ASC  ");
						 
	echo"
	<form action='$aksi?module=kompetensi&act=score' onsubmit='return validasi_input(this)' method='post' enctype='multipart/form-data' >
	<table class='tabelform tabpad table-bordered table-hover table-striped' style='width: 100% !important;'>
	<tr>
	<td colspan='3'>Petunjuk Pengisian:</td>
	</tr>
	<tr>
	<td>1.</td>
	<td colspan='2'>Beri nilai kepada setiap indikator kompetensi dan Pilihan nilai adalah 1 sampai dengan 10, sesuai kategori di bawah. Jangan mengisi dengan angka lain</td>
	</tr>
	<tr>
	<td>2.</td>
	<td colspan='2'>Nilai dari tiap point dirata-rata dan dikalikan bobot, untuk mendapatkan score untuk setiap kompetensi</td>
	</tr>
	<tr>
	<td>3.</td>
	<td colspan='2'>Seluruh Score kompetensi dijumlahkan untuk mendapatkan score Competency</td>
	</tr>
	<tr>
	<td colspan='2'>Kategori</td><td>score</td>
	</tr>
	<tr>
	<td colspan='2'>Develop / Perlu Dikembangkan</td><td>1 - 4</td>
	</tr>
	<tr>
	<td colspan='2'>Meets / Sesuai</td><td>5 - 9</td>
	</tr>
	<tr>
	<td colspan='2'>Exceeds / Melebihi</td><td>10</td>
	</tr>
	<tr>
	<td colspan='3'><hr></td>
	</tr>
	<tr>
	<td>Nip</td><td>$_GET[nip]<input  name='nip' value='$_GET[nip]' type='text' hidden><td></td>
	<tr>
	<tr>
	<td>Nama</td><td>$_GET[nama]<input  name='nama' value='$_GET[nama]' type='text' hidden><td></td>
	<tr>
	<tr>
	<td>Tanggal</td><td>_$tgl<input  name='tanggal' value='$tgl' type='text' hidden><td></td>
	</tr>
	<tr>
	<td colspan='3'><hr></td>
	</tr>
	<tr>
	<td colspan='3'>KOMPETENSI</td>
	</tr>
	<tr>
	<td>No</td>
	<td colspan='2'>KEMAMPUAN MENGANALISA</td>
	</tr>
	<tr>
	<td>1.</td>
	<td>Mampu melakukan pemecahan masalah secara sistematis</td>
	<td><input class='form-control' name='menganalisa1' type='text'></td>
	</tr>
	<tr>
	<td>2.</td>
	<td>Mampu membuat beberapa analisis dan solusi pemecahan permasalahan</td>
	<td><input class='form-control' name='menganalisa2' type='text'></td>
	</tr>
	
	<tr>
	<td>No</td>
	<td colspan='2'>KOMUNIKASI</td>
	</tr>
	<tr>
	<td>1.</td>
	<td>Mampu memberikan pendapat/masukan kepada atasan, rekan kerja atau bawahan  secara sistematis dan akurat secara lisan dan tulisan</td>
	<td><input class='form-control' name='komunikasi1' type='text'></td>
	</tr>
	<tr>
	<td>2.</td>
	<td>Mampu memahami keadaan situasi dan kondisi pada saat berkomunikasi (menyampaikan  pesan, ide dan gagasan)</td>
	<td><input class='form-control' name='komunikasi2' type='text'></td>
	</tr>
	
	<tr>
	<td>No</td>
	<td colspan='2'>KERJASAMA</td>
	</tr>
	<tr>
	<td>1.</td>
	<td>Mampu bekerjasama dengan unit-unit terkait</td>
	<td><input class='form-control' name='kerjasama1' type='text'></td>
	</tr>
	<tr>
	<td>2.</td>
	<td>Tetap mendukung keputusan team sekalipun keputusan yang diambil tidak sesuai dengan keputusan pribadi</td>
	<td><input class='form-control' name='kerjasama2' type='text'></td>
	</tr>
	
	<tr>
	<td>No</td>
	<td colspan='2'>KECERDASAN EMOSIONAL</td>
	</tr>
	<tr>
	<td>1.</td>
	<td>Menunjukkan emosional yang stabil pada saat mendapat tekanan pekerjaan yang tinggi</td>
	<td><input class='form-control' name='kecerdasan1' type='text'></td>
	</tr>
	<tr>
	<td>2.</td>
	<td>Peka terdahap perasaan orang lain</td>
	<td><input class='form-control' name='kecerdasan2' type='text'></td>
	</tr>
	<tr>
	<td>3.</td>
	<td>Mampu menjaga situasi dan hubungan kerja yang baik dengan atasan, rekan kerja atau bawahan</td>
	<td><input class='form-control' name='kecerdasan3' type='text'></td>
	</tr>
	
	<tr>
	<td>No</td>
	<td colspan='2'>FOKUS PADA HASIL KERJA</td>
	</tr>
	<tr>
	<td>1.</td>
	<td>Mampu mencapai target kerja sesuai dengan tenggat waktu</td>
	<td><input class='form-control' name='fokus1' type='text'></td>
	</tr>
	<tr>
	<td>2.</td>
	<td>Mampu merencanakan dan mengelola sumber daya untuk mencapai hasil yang memuaskan</td>
	<td><input class='form-control' name='fokus2' type='text'></td>
	</tr>
	<tr>
	<td>3.</td>
	<td>Dapat mengatasi kendala dengan supervisi minimum</td>
	<td><input class='form-control' name='fokus3' type='text'></td>
	</tr>
	
	<tr>
	<td>No</td>
	<td colspan='2'>TANGGUNG JAWAB</td>
	</tr>
	<tr>
	<td>1.</td>
	<td>Berkomitmen menyelesaikan pekerjaan tanpa perlu dimonitor oleh atasan</td>
	<td><input class='form-control' name='tanggung1' type='text'></td>
	</tr>
	<tr>
	<td>2.</td>
	<td>Dapat diandalkan menyelesaikan pekerjaan dengan mandiri dan tepat waktu</td>
	<td><input class='form-control' name='tanggung2' type='text'></td>
	</tr>
	<tr>
	<td>3.</td>
	<td>Dapat terus melaksanakan  tugas  dalam situasi  tekanan</td>
	<td><input class='form-control' name='tanggung3' type='text'></td>
	</tr>
	<tr>
	<td>4.</td>
	<td>Tidak mengelak dari tugas dan wewenang yang diberikan dan bersedia menerima konsekuensi yang timbul dari pekerjaannya</td>
	<td><input class='form-control' name='tanggung4' type='text'></td>
	</tr>
	
	<tr>
	<td>No</td>
	<td colspan='2'>ORIENTASI TERHADAP KUALITAS</td>
	</tr>
	<tr>
	<td>1.</td>
	<td>Memperhatikan standar kerja yang ditetapkan maupun sistem dan prosedur</td>
	<td><input class='form-control' name='orientasi_k1' type='text'></td>
	</tr>
	<tr>
	<td>2.</td>
	<td>Selalu berusahan meningkatkan kualitas kerja dan mengembangkan sistem kerja yang baik(Continuous improvment)</td>
	<td><input class='form-control' name='orientasi_k2' type='text'></td>
	</tr>
	
	<tr>
	<td>No</td>
	<td colspan='2'>INISIATIF</td>
	</tr>
	<tr>
	<td>1.</td>
	<td>Mampu memberikan ide-ide yang secara langsung dapat diterapkan untuk perbaikan kualitas kerja</td>
	<td><input class='form-control' name='inisiatif1' type='text'></td>
	</tr>
	<tr>
	<td>2.</td>
	<td>Mengambil tindakan proaktif secara mandiri bila ada masalah/situasi tertentu sesuai dengan kebutuhan dan aturan yang berlaku</td>
	<td><input class='form-control' name='inisiatif2' type='text'></td>
	</tr>
	
	<tr>
	<td>No</td>
	<td colspan='2'>DISIPLIN</td>
	</tr>
	<tr>
	<td>1.</td>
	<td>Melaksanakan dan mematuhi aturan yang sudah ditetapkan</td>
	<td><input class='form-control' name='disiplin1' type='text'></td>
	</tr>
	<tr>
	<td>2.</td>
	<td>Tidak absen untuk alasan yang dibuat-buat</td>
	<td><input class='form-control' name='disiplin2' type='text'></td>
	</tr>
	<tr>
	<td>3.</td>
	<td>Tidak suka terlambat</td>
	<td><input class='form-control' name='disiplin3' type='text'></td>
	</tr>
	
	<tr>
	<td>No</td>
	<td colspan='2'>ORIENTASI PELANGGAN</td>
	</tr>
	<tr>
	<td>1.</td>
	<td>Dapat memahami kebutuhan pelanggan</td>
	<td><input class='form-control' name='orientasi_p1' type='text'></td>
	</tr>
	<tr>
	<td>2.</td>
	<td>Responsif terhadap permintaan dan keluhan pelanggan</td>
	<td><input class='form-control' name='orientasi_p2' type='text'></td>
	</tr>
	<tr>
	<td>3.</td>
	<td>Membangun dan memelihara hubungan yang efektif dengan pelanggan</td>
	<td><input class='form-control' name='orientasi_p3' type='text'></td>
	</tr>
	<td colspan='3'><input type='submit' value='Simpan'>
	<input type=button value='Batal' onclick=self.history.back()> 
	</td>
	</table>
	</form>
	
	

	
	<table class='table table-bordered table-hover table-striped'>
	<thead>
  <tr>
  <td>Tanggal</td>
    <td>Nip</td>
	<td colspan='3'>Kemampuan Menganalisa</td>
	<td colspan='3'>Komunikasi</td>
	<td colspan='3'>Kerjasama</td>
	<td colspan='4'>Kecerdasan Emosional</td>
	<td colspan='4'>Fokus pada Hasil Kerja</td>
	<td colspan='5'>tanggung jawab</td>
	<td colspan='3'>Orientasi terhadap kualitas</td>
	<td colspan='3'>Inisiatif</td>
	<td colspan='4'>Disiplin</td>
	<td colspan='4'>Orientasi Pelanggan</td>
	<td>Point</td>
	<td>Action</td>
  </tr>
  </thead>";
  $no=1;
  while($dt=mysql_fetch_array($tampil)){
  $s1=number_format(($dt[menganalisa1]+$dt[menganalisa2])/2,1);
  $s2=number_format(($dt[komunikasi1]+$dt[komunikasi2])/2,1);
  $s3=number_format(($dt[kerjasama1]+$dt[kerjasama2])/2,1);
  $s4=number_format(($dt[kecerdasan1]+$dt[kecerdasan2]+$dt[kecerdasan3])/3,1);
  $s5=number_format(($dt[fokus1]+$dt[fokus2])/2,1);
  $s6=number_format(($dt[tanggung1]+$dt[tanggung2]+$dt[tanggung3]+$dt[tanggung4])/4,1);
  $s7=number_format(($dt[orientasi_k1]+$dt[orientasi_k2])/2,1);
  $s8=number_format(($dt[inisiatif1]+$dt[inisiatif2])/2,1);
  $s9=number_format(($dt[disiplin1]+$dt[disiplin2]+$dt[disiplin3])/3,1);
  $s10=number_format(($dt[orientasi_p1]+$dt[orientasi_p2]+$dt[orientasi_p3])/3,1);
  echo "<tr>
  <td>$dt[tanggal]</td>
    <td>$dt[nip]</td>
	 <td>$dt[menganalisa1]</td>
	 <td>$dt[menganalisa2]</td>
	 <td>$s1</td>
	 <td>$dt[komunikasi1]</td>
	 <td>$dt[komunikasi2]</td>
	 <td>$s2</td>
	 <td>$dt[kerjasama1]</td>
	 <td>$dt[kerjasama2]</td>
	 <td>$s3</td>
	 <td>$dt[kecerdasan1]</td>
	 <td>$dt[kecerdasan2]</td>
	 <td>$dt[kecerdasan3]</td>
	 <td>$s4</td>
	 <td>$dt[fokus1]</td>
	 <td>$dt[fokus2]</td>
	 <td>$dt[fokus3]</td>
	 <td>$s5</td>
	 <td>$dt[tanggung1]</td>
	 <td>$dt[tanggung2]</td>
	 <td>$dt[tanggung3]</td>
	 <td>$dt[tanggung4]</td>
	 <td>$s6</td>
	 <td>$dt[orientasi_k1]</td>
	 <td>$dt[orientasi_k2]</td>
	 <td>$s7</td>
	 <td>$dt[inisiatif1]</td>
	 <td>$dt[inisiatif2]</td>
	 <td>$s8</td>
	 <td>$dt[disiplin1]</td>
	 <td>$dt[disiplin2]</td>
	 <td>$dt[disiplin3]</td>
	 <td>$s9</td>
	 <td>$dt[orientasi_p1]</td>
	 <td>$dt[orientasi_p2]</td>
	 <td>$dt[orientasi_p3]</td>
	 <td>$s10</td>
	 <td>$dt[point]</td>
	 <td><a href=\"$aksi?module=kompetensi&act=hapus&id_kompetensi=$dt[id_kompetensi]\" onClick=\"return confirm('Apakah Anda benar-benar mau menghapusnya?')\">Hapus</a></span></td>
	 </tr>";
  $no++;
  }
echo "  
</table>
	
	";
  
		
	break;
	
	case "detailm":
	echo"<h2 class='head'>Kompetensi (70%)</h2>";
	$tampil1=mysql_query("select * from pegawai where nip='$_GET[nip]' ");
	while($dt=mysql_fetch_array($tampil)){
	$nip1=$dt['nip'];
	$nama=$dt['nama'];
	}
	$sa=$nama;
  $tgl= date('Y-m-d');
	$per=explode('-',$tgl);
	$bln=$per[1];
	$thn=$per[0];
	$waktu= date ('H:i:s');
	$tampil=mysql_query("select * from kompetensi where 
						 Month(kompetensi.tanggal)='$bln' 
						 and Year(kompetensi.tanggal)='$thn' and nip='$_GET[nip]'
						 order by id_kompetensi ASC  ");
						 
	echo"
	<form action='$aksi?module=kompetensi&act=score' onsubmit='return validasi_input(this)' method='post' enctype='multipart/form-data' >
	<table class='tabelform tabpad'>
	<tr>
	<td colspan='3'>Petunjuk Pengisian:</td>
	</tr>
	<tr>
	<td>1.</td>
	<td colspan='2'>Beri nilai kepada setiap indikator kompetensi dan Pilihan nilai adalah 1 sampai dengan 10, sesuai kategori di bawah. Jangan mengisi dengan angka lain</td>
	</tr>
	<tr>
	<td>2.</td>
	<td colspan='2'>Nilai dari tiap point dirata-rata dan dikalikan bobot, untuk mendapatkan score untuk setiap kompetensi</td>
	</tr>
	<tr>
	<td>3.</td>
	<td colspan='2'>Seluruh Score kompetensi dijumlahkan untuk mendapatkan score Competency</td>
	</tr>
	<tr>
	<td colspan='2'>Kategori</td><td>score</td>
	</tr>
	<tr>
	<td colspan='2'>Develop / Perlu Dikembangkan</td><td>1 - 4</td>
	</tr>
	<tr>
	<td colspan='2'>Meets / Sesuai</td><td>5 - 9</td>
	</tr>
	<tr>
	<td colspan='2'>Exceeds / Melebihi</td><td>10</td>
	</tr>
	<tr>
	<td colspan='3'><hr></td>
	</tr>
	<tr>
	<td>Nip</td><td>$_GET[nip]<input  name='nip' value='$_GET[nip]' type='text' hidden><td></td>
	<tr>
	<tr>
	<td>Nama</td><td>$_GET[nama]<input  name='nama' value='$_GET[nama]' type='text' hidden><td></td>
	<tr>
	<tr>
	<td>Tanggal</td><td>_$tgl<input  name='tanggal' value='$tgl' type='text' hidden><td></td>
	</tr>
	<tr>
	<td colspan='3'><hr></td>
	</tr>
	<tr>
	<td colspan='3'>KOMPETENSI</td>
	</tr>
	<tr>
	<td>No</td>
	<td colspan='2'>KEMAMPUAN MENGANALISA</td>
	</tr>
	<tr>
	<td>1.</td>
	<td>Mampu melakukan pemecahan masalah secara sistematis</td>
	<td><input class='form-control' name='menganalisa1' type='text'></td>
	</tr>
	<tr>
	<td>2.</td>
	<td>Mampu membuat beberapa analisis dan solusi pemecahan permasalahan</td>
	<td><input class='form-control' name='menganalisa2' type='text'></td>
	</tr>
	
	<tr>
	<td>No</td>
	<td colspan='2'>KOMUNIKASI</td>
	</tr>
	<tr>
	<td>1.</td>
	<td>Mampu memberikan pendapat/masukan kepada atasan, rekan kerja atau bawahan  secara sistematis dan akurat secara lisan dan tulisan</td>
	<td><input class='form-control' name='komunikasi1' type='text'></td>
	</tr>
	<tr>
	<td>2.</td>
	<td>Mampu memahami keadaan situasi dan kondisi pada saat berkomunikasi (menyampaikan  pesan, ide dan gagasan)</td>
	<td><input class='form-control' name='komunikasi2' type='text'></td>
	</tr>
	
	<tr>
	<td>No</td>
	<td colspan='2'>KERJASAMA</td>
	</tr>
	<tr>
	<td>1.</td>
	<td>Mampu bekerjasama dengan unit-unit terkait</td>
	<td><input class='form-control' name='kerjasama1' type='text'></td>
	</tr>
	<tr>
	<td>2.</td>
	<td>Tetap mendukung keputusan team sekalipun keputusan yang diambil tidak sesuai dengan keputusan pribadi</td>
	<td><input class='form-control' name='kerjasama2' type='text'></td>
	</tr>
	
	<tr>
	<td>No</td>
	<td colspan='2'>KECERDASAN EMOSIONAL</td>
	</tr>
	<tr>
	<td>1.</td>
	<td>Menunjukkan emosional yang stabil pada saat mendapat tekanan pekerjaan yang tinggi</td>
	<td><input class='form-control' name='kecerdasan1' type='text'></td>
	</tr>
	<tr>
	<td>2.</td>
	<td>Peka terdahap perasaan orang lain</td>
	<td><input class='form-control' name='kecerdasan2' type='text'></td>
	</tr>
	<tr>
	<td>3.</td>
	<td>Mampu menjaga situasi dan hubungan kerja yang baik dengan atasan, rekan kerja atau bawahan</td>
	<td><input class='form-control' name='kecerdasan3' type='text'></td>
	</tr>
	
	<tr>
	<td>No</td>
	<td colspan='2'>FOKUS PADA HASIL KERJA</td>
	</tr>
	<tr>
	<td>1.</td>
	<td>Mampu mencapai target kerja sesuai dengan tenggat waktu</td>
	<td><input class='form-control' name='fokus1' type='text'></td>
	</tr>
	<tr>
	<td>2.</td>
	<td>Mampu merencanakan dan mengelola sumber daya untuk mencapai hasil yang memuaskan</td>
	<td><input class='form-control' name='fokus2' type='text'></td>
	</tr>
	<tr>
	<td>3.</td>
	<td>Dapat mengatasi kendala dengan supervisi minimum</td>
	<td><input class='form-control' name='fokus3' type='text'></td>
	</tr>
	
	<tr>
	<td>No</td>
	<td colspan='2'>TANGGUNG JAWAB</td>
	</tr>
	<tr>
	<td>1.</td>
	<td>Berkomitmen menyelesaikan pekerjaan tanpa perlu dimonitor oleh atasan</td>
	<td><input class='form-control' name='tanggung1' type='text'></td>
	</tr>
	<tr>
	<td>2.</td>
	<td>Dapat diandalkan menyelesaikan pekerjaan dengan mandiri dan tepat waktu</td>
	<td><input class='form-control' name='tanggung2' type='text'></td>
	</tr>
	<tr>
	<td>3.</td>
	<td>Dapat terus melaksanakan  tugas  dalam situasi  tekanan</td>
	<td><input class='form-control' name='tanggung3' type='text'></td>
	</tr>
	<tr>
	<td>4.</td>
	<td>Tidak mengelak dari tugas dan wewenang yang diberikan dan bersedia menerima konsekuensi yang timbul dari pekerjaannya</td>
	<td><input class='form-control' name='tanggung4' type='text'></td>
	</tr>
	
	<tr>
	<td>No</td>
	<td colspan='2'>ORIENTASI TERHADAP KUALITAS</td>
	</tr>
	<tr>
	<td>1.</td>
	<td>Memperhatikan standar kerja yang ditetapkan maupun sistem dan prosedur</td>
	<td><input class='form-control' name='orientasi_k1' type='text'></td>
	</tr>
	<tr>
	<td>2.</td>
	<td>Selalu berusahan meningkatkan kualitas kerja dan mengembangkan sistem kerja yang baik(Continuous improvment)</td>
	<td><input class='form-control' name='orientasi_k2' type='text'></td>
	</tr>
	
	<tr>
	<td>No</td>
	<td colspan='2'>INISIATIF</td>
	</tr>
	<tr>
	<td>1.</td>
	<td>Mampu memberikan ide-ide yang secara langsung dapat diterapkan untuk perbaikan kualitas kerja</td>
	<td><input class='form-control' name='inisiatif1' type='text'></td>
	</tr>
	<tr>
	<td>2.</td>
	<td>Mengambil tindakan proaktif secara mandiri bila ada masalah/situasi tertentu sesuai dengan kebutuhan dan aturan yang berlaku</td>
	<td><input class='form-control' name='inisiatif2' type='text'></td>
	</tr>
	
	<tr>
	<td>No</td>
	<td colspan='2'>DISIPLIN</td>
	</tr>
	<tr>
	<td>1.</td>
	<td>Melaksanakan dan mematuhi aturan yang sudah ditetapkan</td>
	<td><input class='form-control' name='disiplin1' type='text'></td>
	</tr>
	<tr>
	<td>2.</td>
	<td>Tidak absen untuk alasan yang dibuat-buat</td>
	<td><input class='form-control' name='disiplin2' type='text'></td>
	</tr>
	<tr>
	<td>3.</td>
	<td>Tidak suka terlambat</td>
	<td><input class='form-control' name='disiplin3' type='text'></td>
	</tr>
	
	<tr>
	<td>No</td>
	<td colspan='2'>ORIENTASI PELANGGAN</td>
	</tr>
	<tr>
	<td>1.</td>
	<td>Dapat memahami kebutuhan pelanggan</td>
	<td><input class='form-control' name='orientasi_p1' type='text'></td>
	</tr>
	<tr>
	<td>2.</td>
	<td>Responsif terhadap permintaan dan keluhan pelanggan</td>
	<td><input class='form-control' name='orientasi_p2' type='text'></td>
	</tr>
	<tr>
	<td>3.</td>
	<td>Membangun dan memelihara hubungan yang efektif dengan pelanggan</td>
	<td><input class='form-control' name='orientasi_p3' type='text'></td>
	</tr>
	<td colspan='3'><input type='submit' value='Simpan'>
	<input type=button value='Batal' onclick=self.history.go(-2)> 
	</td>
	</table>
	</form>
	
	

	
	<table class='table table-bordered table-hover table-striped'>
	<thead>
  <tr>
  <td>Tanggal</td>
    <td>Nip</td>
	<td colspan='3'>Kemampuan Menganalisa</td>
	<td colspan='3'>Komunikasi</td>
	<td colspan='3'>Kerjasama</td>
	<td colspan='4'>Kecerdasan Emosional</td>
	<td colspan='4'>Fokus pada Hasil Kerja</td>
	<td colspan='5'>tanggung jawab</td>
	<td colspan='3'>Orientasi terhadap kualitas</td>
	<td colspan='3'>Inisiatif</td>
	<td colspan='4'>Disiplin</td>
	<td colspan='4'>Orientasi Pelanggan</td>
	<td>Point</td>
  </tr>
  </thead>";
  $no=1;
  while($dt=mysql_fetch_array($tampil)){

  $s1=number_format(($dt[menganalisa1]+$dt[menganalisa2])/2,1);
  $s2=number_format(($dt[komunikasi1]+$dt[komunikasi2])/2,1);
  $s3=number_format(($dt[kerjasama1]+$dt[kerjasama2])/2,1);
  $s4=number_format(($dt[kecerdasan1]+$dt[kecerdasan2]+$dt[kecerdasan3])/3,1);
  $s5=number_format(($dt[fokus1]+$dt[fokus2])/2,1);
  $s6=number_format(($dt[tanggung1]+$dt[tanggung2]+$dt[tanggung3]+$dt[tanggung4])/4,1);
  $s7=number_format(($dt[orientasi_k1]+$dt[orientasi_k2])/2,1);
  $s8=number_format(($dt[inisiatif1]+$dt[inisiatif2])/2,1);
  $s9=number_format(($dt[disiplin1]+$dt[disiplin2]+$dt[disiplin3])/3,1);
  $s10=number_format(($dt[orientasi_p1]+$dt[orientasi_p2]+$dt[orientasi_p3])/3,1);
  echo "<tr>
  <td>$dt[tanggal]</td>
    <td>$dt[nip]</td>
	 <td>$dt[menganalisa1]</td>
	 <td>$dt[menganalisa2]</td>
	 <td>$s1</td>
	 <td>$dt[komunikasi1]</td>
	 <td>$dt[komunikasi2]</td>
	 <td>$s2</td>
	 <td>$dt[kerjasama1]</td>
	 <td>$dt[kerjasama2]</td>
	 <td>$s3</td>
	 <td>$dt[kecerdasan1]</td>
	 <td>$dt[kecerdasan2]</td>
	 <td>$dt[kecerdasan3]</td>
	 <td>$s4</td>
	 <td>$dt[fokus1]</td>
	 <td>$dt[fokus2]</td>
	 <td>$dt[fokus3]</td>
	 <td>$s5</td>
	 <td>$dt[tanggung1]</td>
	 <td>$dt[tanggung2]</td>
	 <td>$dt[tanggung3]</td>
	 <td>$dt[tanggung4]</td>
	 <td>$s6</td>
	 <td>$dt[orientasi_k1]</td>
	 <td>$dt[orientasi_k2]</td>
	 <td>$s7</td>
	 <td>$dt[inisiatif1]</td>
	 <td>$dt[inisiatif2]</td>
	 <td>$s8</td>
	 <td>$dt[disiplin1]</td>
	 <td>$dt[disiplin2]</td>
	 <td>$dt[disiplin3]</td>
	 <td>$s9</td>
	 <td>$dt[orientasi_p1]</td>
	 <td>$dt[orientasi_p2]</td>
	 <td>$dt[orientasi_p3]</td>
	 <td>$s10</td>
	 <td>$dt[point]</td>
	 </tr>";
  $no++;
  }
echo "  
</table>
	
	";
  
		
	break;
	
	case "cari":
	$t1=$_POST['t1'];
	$t2=$_POST['t2'];
	echo"yang di cari tanggal $t1 sampai $t2";
	$tampil=mysql_query("select * from kreatifitas where tanggal between '$t1' and '$t2'  ");
    
	echo "<div>
	<input type=button value=Kembali onclick=self.history.back()>
	</div>
	<h2 class='head'>DATA KREATIFITAS PEGAWAI</h2>
	<table class='table table-bordered table-hover table-striped'>
	<thead>
  <tr>
  <td>No</td>
  <td>ID Kinerja</td>
  <td>Tanggal</td>
    <td>Nip</td>
	<td>Kreatifitas</td>
	<td>Uraian</td>
	<td>Jam Mulai</td>
	<td>Jam Selesai</td>
	<td>Durasi Pekerjaan</td>
	<td>Control</td>
	<td>Point</td>
  </tr>
  </thead>";
  $no=1;
  while($dt=mysql_fetch_array($tampil)){
  echo "<tr>
  <td>$no</td>
  <td>$dt[id_kinerja_t]</td>
  <td>$dt[tanggal]</td>
    <td>$dt[nip]</td>
	 <td>$dt[kreatifitas]</td>
	 <td>$dt[uraian]</td>
	<td>$dt[wm_k]</td>
	<td>$dt[wa_k]</td>
	<td>$dt[jumlah] Menit</td>
	<td><span><a href='?module=kreatifitas&act=validasi&id_kreatifitas=$dt[id_kreatifitas]'><input type=submit value='Validasi' name='validas'></s><a href='?module=kreatifitas&act=batal&id_kreatifitas=$dt[id_kreatifitas]'><input type=submit value='Batal Validasi' name='validas'></s></span><span>
	</span>
	<td>$dt[point] </td>
	</td>
  </tr>";
  $no++;
  }
echo " 
<tr>
  <td colspan=10 > NILAI
  </td>
  <td>"; 
  $tgl= date('Y-m-d');
	$per=explode('-',$tgl);
	$bln=$per[1];
	$thn=$per[0];
	$waktu= date ('H:i:s');
	
  $qry_jumlah_b=mysql_query("select SUM(point) from kreatifitas where tanggal between '$t1' and '$t2' ");
        $data_b=mysql_fetch_array($qry_jumlah_b);
        $nilai=$data_b[0];
        echo $nilai;
		echo"</td>
  </tr> 
</table>
	";
	
}


?>