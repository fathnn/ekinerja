<script type="text/javascript">
function validasi_input(form){
  if (form.tanggal.value == ""){
    alert("tanggal masih kosong!");
    form.tanggal.focus();
    return (false);
  }
  if (form.aktifitas.value == ""){
    alert("aktifitas masih kosong!");
    form.aktifitas.focus();
    return (false);
  }
  if (form.uraian.value == ""){
    alert("uraian masih kosong!");
    form.uraian.focus();
    return (false);
  }
  if (form.wm.value == ""){
    alert("jam mulai belum di pilih!");
    form.wm.focus();
    return (false);
  }
  if (form.wa.value == ""){
    alert("jam selesai belum di pilih!");
    form.wa.focus();
    return (false);
  }
  if (form.waktu_e.value == ""){
    alert("ada kesalahan di waktu efektif!");
    form.kd_skp.focus();
    return (false);
  }
return (true);
}
</script>

<?php
error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
$aksi="modul/aktifitas/aksi_aktifitas.php";
$nip=$_SESSION['namauser'];
$keterangan=date("d/m/Y H:i:s");
switch($_GET[act]){
	default:
	echo"
<a href='?module=aktifitas&act=detail&nip=$_SESSION[namauser]'>Data Sudah Selesai Di Proses lanjutkan</a>";
	break;
	
	case "awalan":
	$tampil=mysql_query("select * from kinerja_t,pegawai where kinerja_t.nip=pegawai.nip  order by id_kinerja_t");
	echo "<h2 class='head'>DATA AKTIFITAS TAMBAHAN</h2>
	<div>
	<input type=button value='Tambah Data' onclick=\"window.location.href='?module=aktifitas&act=input';\">
	</div>
	<table class='table table-bordered table-hover table-striped'>
	<thead>
  <tr>
  <td>No</td>
  <td>Tanggal</td>
    <td>Nip</td>
    <td>Nama Pegawai</td>
	<td>Aktifitas</td>
	<td>Uraian</td>
	<td>Jam Mulai</td>
	<td>Jam Selesai</td>
	<td>Durasi Pekerjaan</td>
	<td>Control</td>
  </tr>
  </thead>";
  $no=1;
  while($dt=mysql_fetch_array($tampil)){
  $vol=$dt['jumlah']/$dt['waktu'];
  echo "<tr>
  <td>$no</td>
  <td>$dt[tanggal]</td>
    <td>$dt[nip]</td>
    <td>$dt[nama]</td>
	 <td>$dt[aktifitas]</td>
	 <td>$dt[uraian]</td>
	<td>$dt[wm]</td>
	<td>$dt[wa]</td>
	<td>$dt[jumlah] Menit</td>
	 <td><span><a href='?module=aktifitas&act=edit&id_kinerja_t=$dt[id_kinerja_t]'>Edit</a></span> <span>
	<a href=\"$aksi?module=aktifitas&act=hapus&id_kinerja_t=$dt[id_kinerja_t]\" onClick=\"return confirm('Apakah Anda benar-benar mau menghapusnya?')\">Hapus</a></span>
	</td>
  </tr>";
  $no++;
  }
echo "  
</table>
	";
	break;
	
	case "penambahan":
	$tampil1=mysql_query("select * from pegawai where nip='$_GET[nip]' ");
	while($dt=mysql_fetch_array($tampil)){
	$nip1=$dt['nip'];
	}
	$tgl= date('Y-m-d');
	echo "<h2 class='head'>Entry Penambahan Waktu Efektif</h2>
	<form action='$aksi?module=waktu&act=input_t' method='post' enctype='multipart/form-data' >
	<table class='tabelform tabpad'>
	
	<tr>
	<td class='form-group'>Nip</td>
	<td>:</td>
	<td class='form-group'><input class='form-control' name='nip' type='text' value='$_GET[nip]' readonly > </td>
	<td></td>
	</tr>
	
	<tr>
	<td class='form-group'>Tanggal</td>
	<td>:</td>
	<td class='form-group'><input class='form-control' name='tanggal' type='text' value='$tgl' readonly></td>
	<td></td>
	</tr>
	
	<tr>
	<td class='form-group'>Cuti Sakit</td>
	<td>:</td>
	<td class='form-group'><input class='form-control' name='c_sakit_t' type='text'></td>
	<td class='form-group'>Hari</td>
	</tr>
	
	<tr>
	<td class='form-group'>Cuti Alasan Penting < 6 hari</td>
	<td>:</td>
	<td class='form-group'><input class='form-control' name='c_alasan_t' type='text'></td>
	<td class='form-group'>Hari</td>
	</tr>
	
	<tr>
	<td class='form-group'>Cuti Tahunan</td>
	<td>:</td>
	<td class='form-group'><input class='form-control' name='c_tahunan_t' type='text'></td>
	<td class='form-group'>Hari</td>
	</tr>
	
	<tr>
	<td class='form-group'>Diklat</td>
	<td>:</td>
	<td class='form-group'><input class='form-control' name='diklat' type='text'></td>
	<td class='form-group'>Hari</td>
	</tr>
	
	<tr>
	<td class='form-group'>SPD</td>
	<td>:</td>
	<td class='form-group'><input class='form-control' name='spd' type='text'></td>
	<td class='form-group'>Hari</td>
	</tr>
	
	<tr>
	<td class='form-group'>Haji</td>
	<td>:</td>
	<td class='form-group'><input class='form-control' name='haji' type='text'></td>
	<td class='form-group'>Hari</td>
	</tr>
	
	<tr>
	<td></td>
	<td></td>
	<td><input type=submit value=Simpan>
	<input type=button value=Batal onclick=self.history.back()>
	</td>
	</tr>
	
	</table>
	</form>
	";
	break;
	
	
	case "pengurangan":
	$tampil1=mysql_query("select * from pegawai where nip='$_GET[nip]' ");
	while($dt=mysql_fetch_array($tampil)){
	$nip1=$dt['nip'];
	}
	$tgl= date('Y-m-d');
	echo "<h2 class='head'>Entry Pengurangan Waktu Efektif</h2>
	<form action='$aksi?module=waktu&act=input_k' method='post' enctype='multipart/form-data' >
	<table class='tabelform tabpad'>
	
	<tr>
	<td>Nip</td>
	<td>:</td>
	<td><input class='form-control' name='nip' type='text' value='$_GET[nip]' readonly > </td>
	<td></td>
	</tr>
	
    <tr>
	<td class='form-group'>Tanggal</td>
	<td>:</td>
	<td class='form-group'><input class='form-control' name='tanggal' type='text' value='$tgl' readonly></td>
	<td class='form-group'></td>
	</tr>
	
	<tr>
	<td class='form-group'>Sakit</td>
	<td>:</td>
	<td class='form-group'><input class='form-control' name='sakit' type='text'> </td>
	<td class='form-group'>Hari</td>
	</tr>
	
	<tr>
	<td class='form-group'>Alpha</td>
	<td>:</td>
	<td class='form-group'><input class='form-control' name='alpha' type='text'> </td>
	<td class='form-group'>Hari</td>
	</tr>
	
		
	<tr>
	<td class='form-group'>Izin</td>
	<td>:</td>
	<td><input class='form-control' name='izin' type='text'></td>
	<td>Hari</td>
	</tr>
	
	<tr>
	<td class='form-group'>Izin Setengah Hari</td>
	<td>:</td>
	<td class='form-group'><input class='form-control' name='izin_s' type='text'></td>
	<td class='form-group'>Hari</td>
	</tr>
	
	<tr>
	<td class='form-group'>Meninggal</td>
	<td>:</td>
	<tdclass='form-group'> <input class='form-control' name='meninggal' type='text'></td>
	<td>Hari</td>
	</tr>
	
	<tr>
	<td class='form-group'>Telat</td>
	<td>:</td>
	<td class='form-group'><input class='form-control' name='telat' type='text'> </td>
	<td>Menit</td>
	</tr>
	
	<tr>
	<td class='form-group'>Cuti Sakit</td>
	<td>:</td>
	<td class='form-group'><input class='form-control' name='c_sakit_k' type='text'></td>
	<td>Hari</td>
	</tr>
	
	<tr>
	<td class='form-group'>Cuti Alasan Penting >= 6 hari</td>
	<td>:</td>
	<td class='form-group'><input class='form-control' name='c_alasan_k' type='text'></td>
	<td>Hari</td>
	</tr>
	
	<tr>
	<td class='form-group'>Cuti Pesalinan</td>
	<td>:</td>
	<td><input class='form-control' name='c_persalinan_k' type='text'></td>
	<td>Hari</td>
	</tr>
	
	<tr>
	<td class='form-group'>Cuti Besar</td>
	<td>:</td>
	<td><input class='form-control' name='c_besar_k' type='text'></td>
	<td>Hari</td>
	</tr>
	
	<tr>
	<td></td>
	<td></td>
	<td><input type=submit value=Simpan>
	<input type=button value=Batal onclick=self.history.back()>
	</td>
	</tr>
	
	</table>
	</form>
	";
	break;
	
	
	case "pengukuran":
	echo"<h2 class='head'>Pengukuran</h2>";
	$tampil1=mysql_query("select * from pegawai where nip='$_GET[nip]' ");
	while($dt=mysql_fetch_array($tampil)){
	$nip1=$dt['nip'];
	}
  $tgl= date('Y-m-d');
	$per=explode('-',$tgl);
	$bln=$per[1];
	$thn=$per[0];
	$waktu= date ('H:i:s');
	$kinerja=mysql_query("select SUM(point) from kinerja where 
						 Month(kinerja.tanggal)='$bln' 
						 and Year(kinerja.tanggal)='$thn' and nip='$_GET[nip]'
						 order by id_kinerja ASC ");
        $point_kinerja=mysql_fetch_array($kinerja);
        $point=$point_kinerja[0];
		$we=min(5000,6300)/6300*100;
        $s=number_format($we,2);
	echo"<table class='tabelform tabpad'>
	<tr>
	<td class='form-group'>NIP</td>
	<td>:</td>
	<td>$_GET[nip]<input class='form-control' name='nip' type='text' value='$_GET[nip]' hidden > </td>
	<td></td>
	</tr>
	<tr>
	<td class='form-group'>CAPAIAN WAKTU EFEKTIVITAS UTAMA</td>
	<td>:</td>
	<td class='form-group'>$point<input class='form-control' name='nip' type='text' value='$point' hidden > </td>
	<td></td>
	</tr>
	<tr>
	<td class='form-group'>CAPAIAN WAKTU EFEKTIVITAS TAMBAHAN</td>
	<td>:</td>
	<td class='form-group'>$point<input class='form-control' name='nip' type='text' value='$point' hidden > </td>
	<td></td>
	</tr>
	<tr>
	<td class='form-group'>CAPAIAN WAKTU KREATIVITAS</td>
	<td>:</td>
	<td class='form-group'>$point<input class='form-control' name='nip' type='text' value='$point' hidden > </td>
	<td></td>
	</tr>
	<tr>
	<td class='form-group'>TOTAL CAPAIAN WAKTU EFEKTIVITAS</td>
	<td>:</td>
	<td class='form-group'>$point<input class='form-control' name='nip' type='text' value='$point' hidden > </td>
	<td></td>
	</tr>
	<tr>
	<td colspan='4'><hr></td>
	</tr>
	<tr>
	<td class='form-group'>Jumlah Waktu Kerja</td>
	<td>:</td>
	<td class='form-group'><input class='form-control' name='nip' type='text' value='21' readonly > </td>
	<td></td>
	</tr>
	<tr>
	<td class='form-group'>Jam Kerja</td>
	<td>:</td>
	<td class='form-group'>300<input class='form-control' name='jk' type='text' value='300' hidden > </td>
	<td></td>
	</tr>
	<tr>
	<td class='form-group'>Maksimal Waktu Efektif</td>
	<td>:</td>
	<td class='form-group'>6300<input class='form-control' name='jk' type='text' value='$we' hidden > </td>
	<td></td>
	</tr>
	<tr>
	<td class='form-group'>Point Aktivitas</td>
	<td>:</td>
	<td class='form-group'>$s<input class='form-control' name='jk' type='text' value='$we' hidden > </td>
	<td></td>
	</tr>
	<table>
	";
  
		
	break;
	
	case "lihat":	
	$nip=$_SESSION['namauser'];
	$dat=mktime(0, 0, 0, date("m")-1, date("d"), date("Y"));
	$tgl= date('Y-m-30',$dat);
	$per=explode('-',$tgl);
	$bln=$per[1];
	$thn=$per[0];
	$waktu= date ('H:i:s');
	$tampil=mysql_query("select * from kinerja_t where 
						 Month(kinerja_t.tanggal)='$bln' 
						 and Year(kinerja_t.tanggal)='$thn' and nip='$_GET[nip]'
						 order by id_kinerja_t DESC  ");
	$tampil1=mysql_query("select * from pegawai where nip='$_GET[nip]' ");
	while($dt=mysql_fetch_array($tampil1)){
    $nip1=$dt['nip']; 
	$nama=$dt['nama'];
	}
	echo "<h2 class='head'>DATA AKTIFITAS TAMBAHAN</h2>
	<div>
	<input type=button value=Kembali onclick=self.history.back()>
	</div>
	<table class='table table-bordered table-hover table-striped'>
	<thead>
  <tr>
  <td>No</td>
  <td>ID Kinerja</td>
  <td>Tanggal</td>
    <td>Nip</td>
	<td>aktifitas</td>
	<td>Uraian</td>
	<td>Jam Mulai</td>
	<td>Jam Selesai</td>
	<td>Durasi Pekerjaan</td>
	<td>Validasi</td>
	<td>Point</td>
  </tr>
  </thead>";
  $no=1;
  while($dt=mysql_fetch_array($tampil)){
  $nilai=$dt['jumlah']*1;
  echo "<tr>
  <td>$no</td>
  <td>$dt[id_kinerja_t]</td>
  <td>$dt[tanggal]</td>
    <td>$dt[nip]</td>
	 <td>$dt[aktifitas]</td>
	 <td>$dt[uraian]</td>
	<td>$dt[wm]</td>
	<td>$dt[wa]</td>
	<td>$dt[jumlah] Menit </td>
	<td>
	<a href='?module=aktifitas&act=validasi&id_kinerja_t=$dt[id_kinerja_t]'><input type=submit value='Validasi' name='validas'></s><a href='?module=aktifitas&act=batal&id_kinerja_t=$dt[id_kinerja_t]'><input type=submit value='Batal Validasi' name='validas'></s></td>
    <td>$dt[point] </td>
  </tr>
  ";
  $no++;
  }echo"
  </tr>
  <tr>
  <td colspan=10 > NILAI
  </td>
  <td>"; 
  $dat=mktime(0, 0, 0, date("m")-1, date("d"), date("Y"));
	$tgl= date('Y-m-30',$dat);
	$per=explode('-',$tgl);
	$bln=$per[1];
	$thn=$per[0];
	$waktu= date ('H:i:s');
	
  $qry_jumlah_b=mysql_query("select SUM(point) from kinerja_t where 
						 Month(kinerja_t.tanggal)='$bln' 
						 and Year(kinerja_t.tanggal)='$thn' and nip='$_GET[nip]'
						 order by id_kinerja_t ASC ");
        $data_b=mysql_fetch_array($qry_jumlah_b);
        $nilai=$data_b[0];
        echo $nilai;
		echo"</td>
  </tr>";
echo "  
</table>

	";
	
	break;
	
	case "lihatpj":	
	$nip=$_SESSION['namauser'];
	$tgl=$_POST['tanggal'];
	$per=explode('-',$tgl);
	$bln=$per[1];
	$thn=$per[0];
	$waktu= date ('H:i:s');
	$tampil=mysql_query("select * from kinerja_t where 
						 Month(kinerja_t.tanggal)='$bln' 
						 and Year(kinerja_t.tanggal)='$thn' and nip='$_GET[nip]'
						 order by tanggal DESC  ");
	echo "<h2 class='head'>DATA AKTIFITAS TAMBAHAN</h2>
	<div>
	<input type=button value=Kembali onclick=self.history.back()>
	</div>

	<table class='table table-bordered table-hover table-striped'>
	<thead>
  <tr>
  <td>No</td>
  <td>ID Kinerja</td>
  <td>Tanggal</td>
    <td>Nip</td>
	<td>aktifitas</td>
	<td>Uraian</td>
	<td>Jam Mulai</td>
	<td>Jam Selesai</td>
	<td>Durasi Pekerjaan</td>
	<td>Validasi</td>
	<td>Point</td>
  </tr>
  </thead>";
  $no=1;
  while($dt=mysql_fetch_array($tampil)){
  $nilai=$dt['jumlah']*1;
  echo "<tr>
  <td>$no</td>
  <td>$dt[id_kinerja_t]</td>
  <td>$dt[tanggal]</td>
    <td>$dt[nip]</td>
	 <td>$dt[aktifitas]</td>
	 <td>$dt[uraian]</td>
	<td>$dt[wm]</td>
	<td>$dt[wa]</td>
	<td>$dt[jumlah] Menit </td>
	<td>
	<a href='?module=aktifitas&act=validasipj&id_kinerja_t=$dt[id_kinerja_t]'><input type=submit value='Validasi' name='validas'></s><a href='?module=aktifitas&act=batalpj&id_kinerja_t=$dt[id_kinerja_t]'><input type=submit value='Batal Validasi' name='validas'></s></td>
    <td>$dt[point] </td>
  </tr>
  ";
  $no++;
  }echo"
  </tr>
  <tr>
  <td colspan=10 > NILAI
  </td>
  <td>"; 
  $tgl=$_POST['tanggal'];
	$per=explode('-',$tgl);
	$bln=$per[1];
	$thn=$per[0];
	$waktu= date ('H:i:s');
	
  $qry_jumlah_b=mysql_query("select SUM(point) from kinerja_t where 
						 Month(kinerja_t.tanggal)='$bln' 
						 and Year(kinerja_t.tanggal)='$thn' and nip='$_GET[nip]'
						 order by id_kinerja_t ASC ");
        $data_b=mysql_fetch_array($qry_jumlah_b);
        $nilai=$data_b[0];
        echo $nilai;
		echo"</td>
  </tr>";
echo "  
</table>

	";
	
	break;
	
	case "lihatm":	
	$nip=$_SESSION['namauser'];
	$tgl= date('Y-m-d');
	$per=explode('-',$tgl);
	$bln=$per[1];
	$thn=$per[0];
	$waktu= date ('H:i:s');
	$tampil=mysql_query("select * from kinerja_t where 
						 Month(kinerja_t.tanggal)='$bln' 
						 and Year(kinerja_t.tanggal)='$thn' and nip='$_GET[nip]'
						 order by tanggal DESC   ");
	echo "<h2 class='head'>DATA AKTIFITAS TAMBAHAN</h2>
	<div>
	<input type=button value=Kembali onclick=self.history.go(-2)>
	</div>
	
	<table class='table table-bordered table-hover table-striped'>
	<thead>
  <tr>
  <td>No</td>
  <td>ID Kinerja</td>
  <td>Tanggal</td>
    <td>Nip</td>
	<td>aktifitas</td>
	<td>Uraian</td>
	<td>Jam Mulai</td>
	<td>Jam Selesai</td>
	<td>Durasi Pekerjaan</td>
	<td>Validasi</td>
	<td>Point</td>
  </tr>
  </thead>";
  $no=1;
  while($dt=mysql_fetch_array($tampil)){
  $nilai=$dt['jumlah']*1;
  echo "<tr>
  <td>$no</td>
  <td>$dt[id_kinerja_t]</td>
  <td>$dt[tanggal]</td>
    <td>$dt[nip]</td>
	 <td>$dt[aktifitas]</td>
	 <td>$dt[uraian]</td>
	<td>$dt[wm]</td>
	<td>$dt[wa]</td>
	<td>$dt[jumlah] Menit </td>
	<td>
	<a href='?module=aktifitas&act=validasi&id_kinerja_t=$dt[id_kinerja_t]'><input type=submit value='Validasi' name='validas'></s><a href='?module=aktifitas&act=batal&id_kinerja_t=$dt[id_kinerja_t]'><input type=submit value='Batal Validasi' name='validas'></s></td>
    <td>$dt[point] </td>
  </tr>
  ";
  $no++;
  }echo"
  </tr>
  <tr>
  <td colspan=10 > NILAI
  </td>
  <td>"; 
  $tgl= date('Y-m-d');
	$per=explode('-',$tgl);
	$bln=$per[1];
	$thn=$per[0];
	$waktu= date ('H:i:s');
	
  $qry_jumlah_b=mysql_query("select SUM(point) from kinerja_t where 
						 Month(kinerja_t.tanggal)='$bln' 
						 and Year(kinerja_t.tanggal)='$thn' and nip='$_GET[nip]'
						 order by id_kinerja_t ASC ");
        $data_b=mysql_fetch_array($qry_jumlah_b);
        $nilai=$data_b[0];
        echo $nilai;
		echo"</td>
  </tr>";
echo "  
</table>

	";
	
	break;
	
	case "validasi":
	$ambil=mysql_query("select * from kinerja_t where id_kinerja_t='$_GET[id_kinerja_t]'");
	$ed=mysql_fetch_array($ambil);
	echo "Yakin anda Ingin Menyetujui Validasi Ini  ??
	<form action='$aksi?module=aktifitas&act=val' method='post' enctype='multipart/form-data' >
	<input type='hidden' name='id_kinerja_t' readonly value='$ed[id_kinerja_t]' >
	<table class='tabelform tabpad'>
	<tr>
	<td class='form-group'><input class='form-control' name='id_kinerja_t' type='text' value='$ed[id_kinerja_t]' readonly ></td>
	</tr>
	<tr>
	<td class='form-group'> <input type='text' name='nip' readonly value='$ed[nip]' readonly>
	</td>
	</tr>	
	<tr>
	<td class='form-group'><input class='form-control' name='tanggal' type='date' value='$ed[tanggal]' readonly ></td>
	</tr>
	
	<tr>
	<td class='form-group'><input class='form-control' name='aktifitas' type='text' value='$ed[aktifitas]' readonly></td>
	</tr>
	
	<tr>
	<td class='form-group'><input class='�nput' name='uraian' value='$ed[uraian]' readonly></td>
	</tr>
	
	<tr>
	<td class='form-group'><input class='form-control' name='wm' type='time' value='$ed[wm]' readonly></td>
	</tr>
	
	<tr>
	<td class='form-group'><input class='form-control' name='wa' type='time' value='$ed[wa]' readonly></td>
	</tr>
	<tr>
	<td class='form-group'><input class='form-control' name='point' type='text' value='$ed[jumlah]' readonly></td>
	</tr>
	<tr>
	<td class='form-group'><input type=submit value=Iya>
	<input type=button value=Batal onclick=self.history.back()>
	</td>
	</tr>
	</table>
	</form>
	";
	break;
	
	case "validasipj":
	$ambil=mysql_query("select * from kinerja_t where id_kinerja_t='$_GET[id_kinerja_t]'");
	$ed=mysql_fetch_array($ambil);
	echo "Yakin anda Ingin Menyetujui Validasi Ini  ??
	<form action='$aksi?module=aktifitas&act=valpj' method='post' enctype='multipart/form-data' >
	<input type='hidden' name='id_kinerja_t' readonly value='$ed[id_kinerja_t]' >
	<table class='tabelform tabpad'>
	<tr>
	<td class='form-group'><input class='form-control' name='id_kinerja_t' type='text' value='$ed[id_kinerja_t]' readonly ></td>
	</tr>
	<tr>
	<td class='form-group'> <input type='text' name='nip' readonly value='$ed[nip]' readonly>
	</td>
	</tr>	
	<tr>
	<td class='form-group'><input class='form-control' name='tanggal' type='date' value='$ed[tanggal]' readonly ></td>
	</tr>
	
	<tr>
	<td class='form-group'><input class='form-control' name='aktifitas' type='text' value='$ed[aktifitas]' readonly></td>
	</tr>
	
	<tr>
	<td class='form-group'><input class='�nput' name='uraian' value='$ed[uraian]' readonly></td>
	</tr>
	
	<tr>
	<td class='form-group'><input class='form-control' name='wm' type='time' value='$ed[wm]' readonly></td>
	</tr>
	
	<tr>
	<td class='form-group'><input class='form-control' name='wa' type='time' value='$ed[wa]' readonly></td>
	</tr>
	<tr>
	<td class='form-group'><input class='form-control' name='point' type='text' value='$ed[jumlah]' readonly></td>
	</tr>
	<tr>
	<td class='form-group'><input type=submit value=Iya>
	<input type=button value=Batal onclick=self.history.go(-2)>
	</td>
	</tr>
	</table>
	</form>
	";
	break;
	
	case "input":
	echo "<h2 class='head'>Entry Data Kinerja Tambahan</h2>
	<form action='$aksi?module=aktifitas&act=input' onsubmit='return validasi_input(this)' name='input' method='post' enctype='multipart/form-data' >
	<table class='tabelform tabpad'>
	<tr>
	<td class='form-group'>Nip</td><td>:</td><td><input class='form-control' name='nip' type='text' value='$_SESSION[namauser]' readonly > </td>
	</tr>
	<tr>
	<td class='form-group'>Tanggal</td><td>:</td><td><input class='form-control' name='tanggal' id='calende' type='text'>
	<input class='form-control' name='keterangan' type='hidden' value='$keterangan'></td>
	</tr>
	<tr>
	<td class='form-group'>Aktifitas</td><td>:</td><td><textarea class='form-control' name='aktifitas'></textarea></td>
	</tr>
	<tr>
	<td class='form-group'>uraian</td><td>:</td><td><textarea class='form-control' name='uraian'></textarea></td>
	</tr>
	<tr>
	<td class='form-group'>Jam Mulai</td><td>:</td><td>
	<div class='input-group clockpicker pull-center' data-placement='right' data-align='top' data-autoclose='true'>
	<input class='form-control' name='wm' type='text' value='' readonly>
	<span class='input-group-addon'>
					<span class='glyphicon glyphicon-time'></span>
				</span>
			</div></td>
	</tr>
	<tr>
	<td class='form-group'>Jam Selesai</td><td>:</td><td>
	<div class='input-group clockpicker pull-center' data-placement='right' data-align='top' data-autoclose='true'>
	<input class='form-control' name='wa' type='text' value='' readonly>
	<span class='input-group-addon'>
					<span class='glyphicon glyphicon-time'></span>
				</span>
			</div></td>
	</tr>
	<tr>
	<td class='form-group'></td><td></td><td><input type=submit value=Simpan>
	<input type=button value=Batal onclick=self.history.back()>
	</td>
	</tr>
	</table>
	</form>
	";
	break;
	
	case "batal":
	$ambil=mysql_query("select * from kinerja_t where id_kinerja_t='$_GET[id_kinerja_t]'");
	$ed=mysql_fetch_array($ambil);
	echo "Yakin anda Ingin Membatalkan Validasi Ini  ??
	<form action='$aksi?module=aktifitas&act=val' method='post' enctype='multipart/form-data' >
	<input type='hidden' name='id_kinerja_t' readonly value='$ed[id_kinerja_t]' >
	<table class='tabelform tabpad'>
	<tr>
	<td class='form-group'><input class='form-control' name='id_kinerja_t' type='text' value='$ed[id_kinerja_t]' readonly ></td>
	</tr>
	<tr>
	<td class='form-group'> <input type='text' name='nip' readonly value='$ed[nip]' readonly>
	</td>
	</tr>	
	<tr>
	<td class='form-group'><input class='form-control' name='tanggal' type='date' value='$ed[tanggal]' readonly ></td>
	</tr>
	
	<tr>
	<td class='form-group'><input class='form-control' name='aktifitas' type='text' value='$ed[aktifitas]' readonly></td>
	</tr>
	
	<tr>
	<td class='form-group'><input class='�nput' name='uraian' value='$ed[uraian]' readonly></td>
	</tr>
	
	<tr>
	<td class='form-group'><input class='form-control' name='wm' type='time' value='$ed[wm]' readonly></td>
	</tr>
	
	<tr>
	<td class='form-group'><input class='form-control' name='wa' type='time' value='$ed[wa]' readonly></td>
	</tr>
	<tr>
	<td class='form-group'><input class='form-control' name='' type='text' value='$ed[jumlah]' readonly><input class='form-control' name='point' type='text' value='0' hidden></td>
	</tr>
	<tr>
	<td class='form-group'><input type=submit value=Iya>
	<input type=button value=Batal onclick=self.history.back()>
	</td>
	</tr>
	</table>
	</form>
	";
	break;
	
	case "batalpj":
	$ambil=mysql_query("select * from kinerja_t where id_kinerja_t='$_GET[id_kinerja_t]'");
	$ed=mysql_fetch_array($ambil);
	echo "Yakin anda Ingin Membatalkan Validasi Ini  ??
	<form action='$aksi?module=aktifitas&act=valpj' method='post' enctype='multipart/form-data' >
	<input type='hidden' name='id_kinerja_t' readonly value='$ed[id_kinerja_t]' >
	<table class='tabelform tabpad'>
	<tr>
	<td class='form-group'><input class='form-control' name='id_kinerja_t' type='text' value='$ed[id_kinerja_t]' readonly ></td>
	</tr>
	<tr>
	<td class='form-group'> <input type='text' name='nip' readonly value='$ed[nip]' readonly>
	</td>
	</tr>	
	<tr>
	<td class='form-group'><input class='form-control' name='tanggal' type='date' value='$ed[tanggal]' readonly ></td>
	</tr>
	
	<tr>
	<td class='form-group'><input class='form-control' name='aktifitas' type='text' value='$ed[aktifitas]' readonly></td>
	</tr>
	
	<tr>
	<td class='form-group'><input class='�nput' name='uraian' value='$ed[uraian]' readonly></td>
	</tr>
	
	<tr>
	<td class='form-group'><input class='form-control' name='wm' type='time' value='$ed[wm]' readonly></td>
	</tr>
	
	<tr>
	<td class='form-group'><input class='form-control' name='wa' type='time' value='$ed[wa]' readonly></td>
	</tr>
	<tr>
	<td class='form-group'><input class='form-control' name='' type='text' value='$ed[jumlah]' readonly><input class='form-control' name='point' type='text' value='0' hidden></td>
	</tr>
	<tr>
	<td class='form-group'><input type=submit value=Iya>
	<input type=button value=Batal onclick=self.history.go(-2)>
	</td>
	</tr>
	</table>
	</form>
	";
	break;
	
	case "edit":
	$ambil=mysql_query("select * from kinerja_t where id_kinerja_t='$_GET[id_kinerja_t]'");
	$ed=mysql_fetch_array($ambil);
	$date=$ed['tanggal'];
	$tanggal=date("m/d/Y",strtotime($date));
	echo "<h2 class='head'>Edit Data AKtifitas Tambahan</h2>
	<form action='$aksi?module=aktifitas&act=edit' method='post' onsubmit='return validasi_input(this)' enctype='multipart/form-data' >
	<input type='hidden' name='id_kinerja_t' readonly value='$ed[id_kinerja_t]' >
	<table >
	<tr>
	<td class='form-group'>Id Kinerja</td><td>:</td><td><input class='form-control' name='id_kinerja_t' type='text' value='$ed[id_kinerja_t]' readonly ></td>
	</tr>
	<tr>
	<td class='form-group'>Nip</td><td>:</td><td> <input class='form-control' type='text' name='nip' readonly value='$ed[nip]' >
	<input class='form-control' name='keterangan' type='hidden' value='$keterangan'>"; 
	echo "</td>
	</tr>	
	<tr>
	<td class='form-group'>Tanggal</td><td>:</td><td><input class='form-control' id='calender' name='tanggal' type='text' value='$tanggal' ></td>
	</tr>
	
	<tr>
	<td class='form-group'>Aktifitas</td><td>:</td><td><textarea name='aktifitas' class='form-control' >$ed[aktifitas]</textarea></td>
	</tr>
	
	<tr>
	<td class='form-group'>Uraian</td><td>:</td><td><textarea name='uraian' class='form-control' >$ed[uraian]</textarea></td>
	</tr>
	
	<tr>
	<td class='form-group'>Jam Mulai</td><td>:</td><td>
	<div class='input-group clockpicker pull-center' data-placement='right' data-align='top' data-autoclose='true'>
	<input class='form-control' name='wm' type='text' value='$ed[wm]'>
	<span class='input-group-addon'>
					<span class='glyphicon glyphicon-time'></span>
				</span>
			</div>
	</td>
	</tr>
	
	<tr>
	<td class='form-group'>Jam Akhir</td><td>:</td><td>
	<div class='input-group clockpicker pull-center' data-placement='right' data-align='top' data-autoclose='true'>
	<input class='form-control' name='wa' type='text' value='$ed[wa]'>
	<span class='input-group-addon'>
					<span class='glyphicon glyphicon-time'></span>
				</span>
			</div>
	</td>
	</tr>
	
	<tr>
	<td class='form-group'></td><td></td><td><input type=submit value=Simpan>
	<input type=button value=Batal onclick=self.history.back()>
	</td>
	</tr>
	</table>
	</form>
	";
	break;
	
	case "detail":
	$nip=$_SESSION['namauser'];
	$tgl= date('Y-m-d');
	$per=explode('-',$tgl);
	$bln=$per[1];
	$thn=$per[0];
	$waktu= date ('H:i:s');
	$dat=mktime(0, 0, 0, date("m")-1, date("d"), date("Y"));
	$tgl1= date('Y-m-28',$dat);
	$per1=explode('-',$tgl1);
	$bln1=$per1[1];
	$thn1=$per1[0];
	
	$dat=mktime(0, 0, 0, date("m")-1, date("d"), date("Y"));
	$tgl1= date('Y-m-28',$dat);
	$per1=explode('-',$tgl1);
	$bln1=$per1[1];
	$thn1=$per1[0];
	$tahun =  date("Y");
	$set=mysql_query("select * from setting ");
	$knj=mysql_fetch_array($set);
	$ekin=$knj['kinerja'];
	if($ekin=="1"){
	$tampil=mysql_query("select * from kinerja where 
						 Month(kinerja.tanggal)='$bln' 
						 and Year(kinerja.tanggal)='$thn' and nip='$nip'
						 order by tanggal,wm DESC  ");
	$tam=mysql_query("select * from skp  ");
	}
	else
	$tampil=mysql_query("select * from kinerja where 
						 Month(kinerja.tanggal)='$bln1' 
						 and Year(kinerja.tanggal)='$thn' and nip='$nip'
						 order by tanggal.wm DESC  ");
	$tam=mysql_query("select * from skp  ");
	echo ("select * from kinerja_t where 
						 Month(kinerja_t.tanggal)='$bln1' 
						 and Year(kinerja_t.tanggal)='$thn' and nip='$nip'
						 order by tanggal.wm DESC  ");
	echo "<h2 class='head'>DATA AKTIFITAS TAMBAHAN</h2>
	<div>
	<input type=button value='Tambah Data' onclick=\"window.location.href='?module=aktifitas&act=input';\">
	</div>
	<div align='right'><form action='?module=aktifitas&act=c_aktifitas' method='POST' >
	TANGGAL <select  name='bulan'>
            	<option value='' selected='selected'>--Pilih bulan--</option>
				<option value='1'>Januari</option>
				<option value='2'>Februari</option>
				<option value='3'>Maret</option>
				<option value='4'>April</option>
				<option value='5'>Mei</option>
				<option value='6'>Juni</option>
				<option value='7'>Juli</option>
				<option value='8'>Agustus</option>
				<option value='9'>September</option>
				<option value='10'>Oktober</option>
				<option value='11'>November</option>
				<option value='12'>Desember</option>
			</select>
			<select name='tahun'>
            <option value='$tahun' class='form-control' selected='selected'>Pilih Tahun</option>";
			$saiki = 2015;
			for($l=$saiki; $l<=$tahun; $l++)
			{
				echo"<option value=",$l,">",$l,"</option>";
			}	
	echo "</select> 
	<input type='submit' value='Tampilkan'>
			 </div>
	<table class='table table-bordered table-hover table-striped'>
	<thead>
  <tr>
  <td>No</td>
  <td>ID Kinerja</td>
  <td>Tanggal</td>
    <td>Nip</td>
	<td>Aktifitas</td>
	<td>Uraian</td>
	<td>Jam Mulai</td>
	<td>Jam Selesai</td>
	<td>Durasi Pekerjaan</td>
	<td>Penginputan</td>
	<td>Control</td>
  </tr>
  </thead>";
  $no=1;
  while($dt=mysql_fetch_array($tam)){
  $time=$dt['waktu'];
  }
  while($dt=mysql_fetch_array($tampil)){
  $vol=$dt['jumlah']/$time;
  echo "<tr>
  <td>$no</td>
  <td>$dt[id_kinerja_t]</td>
  <td>$dt[tanggal]</td>
    <td>$dt[nip]</td>
	 <td>$dt[aktifitas]</td>
	 <td>$dt[uraian]</td>
	<td>$dt[wm]</td>
	<td>$dt[wa]</td>
	<td>$dt[jumlah] Menit</td>
	<td>$dt[keterangan] WIB</td>
	<td> <span><a href='?module=aktifitas&act=edit&id_kinerja_t=$dt[id_kinerja_t]'>Edit</a></span> <span>
	<a href=\"$aksi?module=aktifitas&act=hapus&id_kinerja_t=$dt[id_kinerja_t]\" onClick=\"return confirm('Apakah Anda benar-benar mau menghapusnya?')\">Hapus</a></span>
	</td>
  </tr>";
  $no++;
  }
echo "  
</table>
	";
	break;
	
	case "c_aktifitas":
	$nip=$_SESSION['namauser'];
	$tm="$_POST[tahun]-$_POST[bulan]-28";
	$tgl=$tm;
	$periode=$_POST['bulan']-$_POST['tahun'];
	$day = date('F Y', strtotime($tgl));
	$per=explode('-',$tgl);
	$bln=$per[1];
	$thn=$per[0];
	$waktu= date ('H:i:s');
	$tampil=mysql_query("select * from kinerja_t where 
						 Month(kinerja_t.tanggal)='$bln' 
						 and Year(kinerja_t.tanggal)='$thn' and nip='$nip'
						 order by tanggal,wm DESC  ");
	$tahun =$_POST['tahun'];
	?>
	<h2 class='head'>DATA KINERJA TAMBAHAN </h2>
      
	
	<? echo"Periode : $day
	<div align='right'><form action='?module=aktifitas&act=c_aktifitas' method='POST' >
	TANGGAL <select  name='bulan'>
            	<option value='' selected='selected'>--Pilih bulan--</option>
				<option value='1'>Januari</option>
				<option value='2'>Februari</option>
				<option value='3'>Maret</option>
				<option value='4'>April</option>
				<option value='5'>Mei</option>
				<option value='6'>Juni</option>
				<option value='7'>Juli</option>
				<option value='8'>Agustus</option>
				<option value='9'>September</option>
				<option value='10'>Oktober</option>
				<option value='11'>November</option>
				<option value='12'>Desember</option>
			</select>
			<select name='tahun'>
            <option value='$tahun' class='form-control' selected='selected'>$tahun</option>";
			$saiki = 2015;
			for($l=$saiki; $l<=$now; $l++)
			{
				echo"<option value=",$l,">",$l,"</option>";
			}	
	echo "</select> 
	<input type='submit' value='Tampilkan'>
			 </div>
	<table class='table table-bordered table-hover table-striped'>
	<thead>
  <tr>
  <td>No</td>
  <td>ID Kinerja</td>
  <td>Tanggal</td>
    <td>Nip</td>
	<td>kegiatan</td>
	<td>Uraian</td>
	<td>Jam Mulai</td>
	<td>Jam Selesai</td>
	<td>Durasi Pekerjaan</td>
	<td>Peninputan</td>
	<td>Status</td>
  </tr>
  </thead>";
  $no=1;
  while($dt=mysql_fetch_array($tampil)){
  $n1=$dt['point'];
  echo "<tr>
  <td>$no</td>
  <td>$dt[id_kinerja_t]</td>
  <td>$dt[tanggal]</td>
    <td>$dt[nip]</td>
	 <td>$dt[aktifitas]</td>
	 <td>$dt[uraian]</td>
	<td>$dt[wm]</td>
	<td>$dt[wa]</td>
	<td>$dt[jumlah] Menit</td>
	<td>$dt[keterangan] WIB</td>
	<td>";
	if ($n1 > 0 )
	echo"<font color='green'>Tevalidasi</font>";
	else
	echo"<font color='red'>Pending/Tidak di Validasi $n1<font>";
	echo"
	</td>
  </tr>";
  $no++;
  } 
echo "  
</table> 
<div style='text-align:center;padding:20px;'>
	<input class='noPrint' type='button' value='Cetak Halaman' onclick='window.print()'>
	";
	break;
	
	
	case "cari":
	$t1=$_POST['t1'];
	$t2=$_POST['t2'];
	echo"yang di cari tanggal $t1 sampai $t2";
	$tampil=mysql_query("select * from kinerja_t where tanggal between '$t1' and '$t2'  ");
    
	echo "<div>
	<input type=button value=Kembali onclick=self.history.back()>
	</div>
	<h2 class='head'>DATA AKTIFITAS TAMBAHAN</h2>
	<table class='table table-bordered table-hover table-striped'>
	<thead>
  <tr>
  <td>No</td>
  <td>ID Kinerja</td>
  <td>Tanggal</td>
    <td>Nip</td>
	<td>Aktifitas</td>
	<td>Uraian</td>
	<td>Jam Mulai</td>
	<td>Jam Selesai</td>
	<td>Durasi Pekerjaan</td>
	<td>Control</td>
	<td>Point</td>
  </tr>
  </thead>";
  $no=1;
  while($dt=mysql_fetch_array($tampil)){
  echo "<tr>
  <td>$no</td>
  <td>$dt[id_kinerja_t]</td>
  <td>$dt[tanggal]</td>
    <td>$dt[nip]</td>
	 <td>$dt[aktifitas]</td>
	 <td>$dt[uraian]</td>
	<td>$dt[jam_mulai]</td>
	<td>$dt[jam_akhir]</td>
	<td>$dt[jumlah] Menit</td>
	<td><span><a href='?module=kinerja_t&act=validasi&id_kinerja_t=$dt[id_kinerja_t]'><input type=submit value='Validasi' name='validas'></s><a href='?module=kinerja_t&act=batal&id_kinerja_t=$dt[id_kinerja_t]'><input type=submit value='Batal Validasi' name='validas'></s></span><span>
	</span>
	<td>$dt[point] </td>
	</td>
  </tr>";
  $no++;
  }
echo " 
<tr>
  <td colspan=10 > NILAI
  </td>
  <td>"; 
  $tgl= date('Y-m-d');
	$per=explode('-',$tgl);
	$bln=$per[1];
	$thn=$per[0];
	$waktu= date ('H:i:s');
	
  $qry_jumlah_b=mysql_query("select SUM(point) from kinerja_t where tanggal between '$t1' and '$t2' ");
        $data_b=mysql_fetch_array($qry_jumlah_b);
        $nilai=$data_b[0];
        echo $nilai;
		echo"</td>
  </tr> 
</table>
	";
	
}


?>