<?php 
error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
include "../../config/koneksi.php";
include "../../config/fungsi_indotgl.php";
include "../../config/class_paging.php";
include "../../config/kode_auto.php";
include "../../config/fungsi_thumb.php";

$module=$_GET['module'];
$act=$_GET['act'];

if($module=='kinerja' AND $act=='hapus' ){ 
	mysql_query("delete from kinerja where id_kinerja='$_GET[id_kinerja]'");
	header('location:../../media.php?module='.$module);
}

$mulai="$_POST[wm]"; //jam dalam format STRING
$selesai="$_POST[wa]"; //jam dalam format DATE real itme
$date="$_POST[tanggal]";
$tanggal=date("y-m-d",strtotime($date));
$mulai_time=(is_string($mulai)?strtotime($mulai):$mulai);// memaksa mebentuk format time untuk string
$selesai_time=(is_string($selesai)?strtotime($selesai):$selesai);

$detik=$selesai_time-$mulai_time; //hitung selisih dalam detik
$menit=floor($detik/60); //hiutng menit
$sisa_detik=$detik%$menit; //hitung sisa detik

if($module=='waktu' AND $act=='input_t' ){
$tl="$menit";
$id=kdauto('waktu_t','WKT');
$cst=$_POST["c_sakit_t"]*60;
$cat=$_POST["c_alasan_t"]*300;
$ctt=$_POST["c_tahunan_t"]*300;
$diklat=$_POST["diklat"]*300;
$spd=$_POST["spd"]*300;
$haji=$_POST["haji"]*300;
$t_waktu_t=$cst+$cat+$ctt+$diklat+$spd+$haji;
	mysql_query("insert into waktu_t set id_waktu_t='$id',nip='$_POST[nip]',c_sakit_t='$_POST[c_sakit_t]',c_alasan_t='$_POST[c_alasan_t]',
										   c_tahunan_t='$_POST[c_tahunan_t]', diklat='$_POST[diklat]',
										   spd='$_POST[spd]', haji='$_POST[haji]', tanggal='$tanggal', t_waktu_t='$t_waktu_t'
										   ");
	echo "<script>alert('Lanjutkan Memvalidasi'); window.location = 'javascript:history.go(-2)'</script>";
}

elseif($module=='aktifitas' AND $act=='input' ){
$tl="$menit";
$date=$_POST['tanggal'];
$tanggal=date("y-m-d",strtotime($date));
$id=kdauto('kinerja_t','KNT');
	mysql_query("insert into kinerja_t set id_kinerja_t='$id',nip='$_POST[nip]',aktifitas='$_POST[aktifitas]',uraian='$_POST[uraian]',
										   wm='$_POST[wm]', wa='$_POST[wa]',keterangan='$_POST[keterangan]',
										   jumlah='$tl', tanggal='$tanggal', point='$_POST[point]'
										   ");
	header('location:../../media.php?module='.$module);
}

elseif($module=='waktu' AND $act=='input_k' ){
$tl="$menit";
$id=kdauto('waktu_k','WKT');
$sakit=$_POST["sakit"]*300;
$alpha=$_POST["alpha"]*600;
$izin=$_POST["izin"]*150;
$izin_s=$_POST["izin_s"]*150;
$telat=$_POST["telat"]*1;
$csk=$_POST["c_sakit_k"]*240;
$cak=$_POST["c_alasan_k"]*300;
$cpk=$_POST["c_persalinan_k"]*300;
$cbk=$_POST["c_besar_k"]*300;
$meninggal=$_POST["meninggal"]*300;
$t_waktu_k=$sakit+$alpha+$izin+$izin_s+$telat+$csk+$cak+$cpk+$cbk+$meninggal;
	mysql_query("insert into waktu_k set id_waktu_k='$id',nip='$_POST[nip]',sakit='$_POST[sakit]',alpha='$_POST[alpha]',tanggal='$_POST[tanggal]',
										   izin='$_POST[izin]', izin_s='$_POST[izin_s]',
										   telat='$_POST[telat]', c_sakit_k='$_POST[c_sakit_k]', c_alasan_k='$_POST[c_alasan_k]',c_persalinan_k='$_POST[c_persalinan_k]',c_besar_k='$_POST[c_besar_k]',meninggal='$_POST[meninggal]', t_waktu_k='$t_waktu_k'
										   ");
	echo "<script>alert('Lanjutkan Memvalidasi'); window.location = 'javascript:history.go(-2)'</script>";
}

elseif($module=='aktifitas' AND $act=='edit' ){
$date=$_POST['tanggal'];
$tanggal=date("y-m-d",strtotime($date));
$tl="$menit";
	mysql_query("update kinerja_t set 	   aktifitas='$_POST[aktifitas]',
										   uraian='$_POST[uraian]',
										   wm='$_POST[wm]',
										   wa='$_POST[wa]',keterangan='$_POST[keterangan]',
										   jumlah='$tl',tanggal='$tanggal'
										   where id_kinerja_t='$_POST[id_kinerja_t]'
										   ");
	header('location:../../media.php?module='.$module);
}
elseif($module=='aktifitas' AND $act=='val' ){
$tl="$menit";
mysql_query("update kinerja_t set 	   aktifitas='$_POST[aktifitas]',
										   uraian='$_POST[uraian]',
										   wm='$_POST[wm]',
										   wa='$_POST[wa]',
										   jumlah='$tl',tanggal='$_POST[tanggal]',point='$_POST[point]'
										   where id_kinerja_t='$_POST[id_kinerja_t]'
										   ");
										   $bagian=$_SESSION['id_bag'];
										    echo "<script>alert('Lanjutkan Memvalidasi'); window.location = 'javascript:history.go(-2)'</script>";
}
elseif($module=='aktifitas' AND $act=='valpj' ){
$tl="$menit";
mysql_query("update kinerja_t set 	   aktifitas='$_POST[aktifitas]',
										   uraian='$_POST[uraian]',
										   wm='$_POST[wm]',
										   wa='$_POST[wa]',
										   jumlah='$tl',tanggal='$_POST[tanggal]',point='$_POST[point]'
										   where id_kinerja_t='$_POST[id_kinerja_t]'
										   ");
										   $bagian=$_SESSION['id_bag'];
										    echo "<script>alert('Lanjutkan Memvalidasi'); window.location = 'javascript:history.go(-3)'</script>";
}
elseif($module=='aktifitas' AND $act=='hapus' ){
	mysql_query("delete from kinerja_t where id_kinerja_t = '$_GET[id_kinerja_t]'");
	header('location:../../media.php?module='.$module);
}


?>