<?php
error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
$aksi="modul/pendidikan/aksi_pendidikan.php";

switch($_GET[act]){
	default:
	$tampil=mysql_query("select * from pendidikan_t where id_ukpd LIKE '%$_SESSION[id_ukpd]%' order by id_pendidikan DESC");
	echo "<h2 class='head'>DATA MASTER PENDIDIKAN</h2>
	<div>
	<input type=button value='Tambah Data' onclick=\"window.location.href='?module=pendidikan&act=input';\">
	</div>
	<table class='table table-bordered table-hover table-striped'>
	<thead>
  <tr>
    <td>No</td>
    <td>Id Pendidikan</td>
    <td>Nama Pendidikan</td>
	<td>Control</td>
  </tr>
  </thead>";
  $no=1;
  while($dt=mysql_fetch_array($tampil)){
  echo "<tr>
    <td>$no</td>
    <td>$dt[id_pendidikan]</td>
    <td>$dt[n_pendidikan]</td>
	<td><span><a href='?module=pendidikan&act=edit&id_pendidikan=$dt[id_pendidikan]'>Edit</a></span><span>
	<a href=\"$aksi?module=pendidikan&act=hapus&id_pendidikan=$dt[id_pendidikan]\" onClick=\"return confirm('Apakah Anda benar-benar mau menghapusnya?')\">Hapus</a></span></td>
  </tr>";
  $no++;
  }
echo "  
</table>
	";
	
	break;
	
	
	case "input":
	echo "<h2 class='head'>Entry Data Master Pendidikan</h2>
	<form action='$aksi?module=pendidikan&act=input' method='post'>
	<div class='panel-body'> 
            <div class='table-responsive'> 
	<table>
	<tr>
	<td>ID STATUS</td><td>:</td><td><input class='form-control' name='id_pendidikan' type='text' value=".kdauto('pendidikan_t','PND')." readonly>
	<input class='form-control' type='hidden' name='id_skpd' value='$_SESSION[id_skpd]' ><input class='form-control' type='hidden' name='id_ukpd' value='$_SESSION[id_ukpd]' ></td>
	</tr>
	<tr>
	<td>NAMA PENDIDIKAN</td><td>:</td><td>
	<select class='form-control' name='n_pendidikan'>
		<option value='none' selected='selected'>-Pilih-</option>
				<option value='SD'>SD</option>
				<option value='SMP'>SMP</option>
				<option value='SLTA'>SLTA</option>
				<option value='D III / D IV'>D III / D IV</option>
				<option value='S1'>S1</option>
				<option value='S2 / dr./ drg./ Apoteker/ Ners'>S2 / dr./ drg./ Apoteker/ Ners</option>
				<option value='S3 / dr. Spesialis'>S3 / dr. Spesialis</option>
				</select>
	</tr>
	<td></td><td></td><td><input type=submit value=Simpan>
	<input type=button value=Batal onclick=self.history.back()>
	</td>
	</tr>
	</table>
	</form>
	";
	break;
	
	
	case "edit":
	$edit=mysql_query("select * from pendidikan_t where id_pendidikan='$_GET[id_pendidikan]'");
	$data=mysql_fetch_array($edit);
	echo "<h2>Entry Data Master Status</h2>
	<form action='$aksi?module=pendidikan&act=edit' method='post'>
	<table>
	<tr>
	<td>ID STATUS</td><td>:</td><td><input class='form-control' name='id_pendidikan' type='text' value='$data[id_pendidikan]' Readonly>
	<input class='form-control' type='hidden' name='id_skpd' value='$_SESSION[id_skpd]' ><input class='form-control' type='hidden' name='id_ukpd' value='$_SESSION[id_ukpd]' ></td>
	</tr>
	<tr>
	<td>NAMA PENDIDIKAN</td><td>:</td><td>
	<select class='form-control' name='n_pendidikan'>
		<option value='none' selected='selected'>-Pilih-</option>
				<option value='SD'>SD</option>
				<option value='SMP'>SMP</option>
				<option value='SLTA'>SLTA</option>
				<option value='D III / D IV'>D III / D IV</option>
				<option value='S1'>S1</option>
				<option value='S2 / dr./ drg./ Apoteker/ Ners'>S2 / dr./ drg./ Apoteker/ Ners</option>
				<option value='S3 / dr. Spesialis'>S3 / dr. Spesialis</option>
				</select>
	</tr>
	<td></td><td></td><td><input type=submit value=Update>
	<input type=button value=Batal onclick=self.history.back()>
	</td>
	</tr>
	</table>
	</form>";
	break;
	
	case "hapus":
	
	break;
}


?>