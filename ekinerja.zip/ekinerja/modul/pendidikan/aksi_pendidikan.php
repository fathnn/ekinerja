<?php 
include "../../config/koneksi.php";
include "../../config/fungsi_indotgl.php";
include "../../config/class_paging.php";
include "../../config/kode_auto.php";

$module=$_GET['module'];
$act=$_GET['act'];


if($module=='pendidikan' AND $act=='input' ){
	mysql_query("insert into pendidikan_t set id_pendidikan='$_POST[id_pendidikan]',id_skpd='$_POST[id_skpd]',id_ukpd='$_POST[id_ukpd]', n_pendidikan='$_POST[n_pendidikan]'");
	header('location:../../media.php?module='.$module);
}


elseif($module=='pendidikan' AND $act=='edit' ){
	mysql_query("update pendidikan_t set n_pendidikan='$_POST[n_pendidikan]',id_skpd='$_POST[id_skpd]',id_ukpd='$_POST[id_ukpd]' where id_pendidikan='$_POST[id_pendidikan]'");
	header('location:../../media.php?module='.$module);
}
elseif($module=='pendidikan' AND $act=='hapus' ){
	mysql_query("delete from pendidikan_t where id_pendidikan='$_GET[id_pendidikan]'");
	header('location:../../media.php?module='.$module);
}

?>