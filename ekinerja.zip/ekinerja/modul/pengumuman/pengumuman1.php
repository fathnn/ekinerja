<!DOCTYPE html>
<html>
<head>
   <title>e Kinerja Pasar Minggu</title>
</head>
<body>
    <br>
    <br>
    <br>
   <center><h1>  </h1></center>
  <center> <img src="sopekin.png" height="600" width="1800" /> </center>
    <br>
    <br>
    <br>
   <center> <h2> </h2> </center>
   <center> <img src="validasiekin.png" height="600" width="1800" /> </center>
     <br>
    <br>
    <br>
   <center> <h3> </h3> </center>
   <center> <img src="headerekin.png" height="250" width="1800" /></center>
     <br>
    <br>
    <br>
      <center> <img src="ekin1.png" height="800" width="1800" /></center>
      <br>
    <br>
    <br>
      <center> <img src="ekin2.png" height="800" width="1800" /></center>
      <br>
    <br>
    <br>
      <center> <img src="ekin3.png" height="800" width="1800" /></center>
      <br>
    <br>
    <br>
      <center> <img src="ekin4.png" height="800" width="1800" /></center>
      <br>
    <br>
    <br>
      <center> <img src="ekin5.png" height="800" width="1800" /></center>
      <br>
    <br>
    <br>
      <center> <img src="ekin6.png" height="800" width="1800" /></center>
      <br>
    <br>
    <br>
      <center> <img src="ekin7.png" height="800" width="1800" /></center>
      <br>
    <br>
    <br>
      <center> <img src="ekin8.png" height="800" width="1800" /></center>
  
</body>

</html>