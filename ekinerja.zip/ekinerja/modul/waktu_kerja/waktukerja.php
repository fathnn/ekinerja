<script>
    function validasi(){
        var tanggal        = input.tanggal.value;
        var kd_skp 			= input.kd_skp.value;
        var jam_mulai       = input.jam_mulai.value;
		 var jam_akhir       = input.jam_akhir.value;
        var pesan = '';
         
        if (tanggal == '') {
            tanggal = '-Nama tidak boleh kosong\n';
        }
         
        if (tanggal!= '' && !tanggal.match(tanggalValid)) {
            pesan += '-nama tidak valid\n';
        }
         
        if (kd_skp == '') {
            pesan += '-SKP harus dipilih\n';
        }
         
        if (jam_mulai == '') {
            pesan += '-Jam Mulai tidak boleh kosong\n';
        }
         
       if (jam_akhir == '') {
            pesan += '-Jam Akhir tidak boleh kosong\n';
        }
         
        if (pesan != '') {
            alert('Maaf, ada kesalahan pengisian Formulir : \n'+pesan);
            return false;
        }
    return true
    }
</script>

<?php
error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
$aksi="modul/waktu_kerja/aksi_waktukerja.php";

switch($_GET[act]){
	default:
	$tampil=mysql_query("select * from waktu_kerja where id_ukpd LIKE '%$_SESSION[id_ukpd]%' order by id_waktu DESC");
	echo "<h2 class='head'>DATA HARI KERJA SELURUH KARYAWAN</h2>
	<div>
	<input type=button value='Tambah Data' onclick=\"window.location.href='?module=waktu_kerja&act=input';\">
	</div>
	<table class='table table-bordered table-hover table-striped'>
	<thead>
  <tr>
    <td>No</td>
    <td>Id Waktu</td>
    <td>Tanggal</td>
	<td>Hari Kerja</td>
	<td>Control</td>
  </tr>
  </thead>";
  $no=1;
  while($dt=mysql_fetch_array($tampil)){
  $day = date('F Y', strtotime($dt['tanggal']));
  echo "<tr>
    <td>$no</td>
    <td>$dt[id_waktu]</td>
    <td>$day</td>
	<td>$dt[hari]</td>
	<td><span><a href='?module=waktu_kerja&act=edit&id_waktu=$dt[id_waktu]'>Edit</a></span><span>
	<a href=\"$aksi?module=penyerapan&act=hapus&id_waktu=$dt[id_waktu]\" onClick=\"return confirm('Apakah Anda benar-benar mau menghapusnya?')\">Hapus</a></span></td>
  </tr>";
  $no++;
  }
echo "  
</table>
	";
	
	break;
	
	case "input":
	$tahun =  date("Y");
	$bulan = date("M");
	echo "<h2 class='head'>Entry Data Hari Kerja Karyawan</h2>
	<form action='$aksi?module=waktu_kerja&act=input' name='input' method='post'>
	<div class='panel-body'> 
            <div class='table-responsive'> 
	<table>
	<tr>
	<td>ID WAKTU</td><td>:</td><td><input class='form-control' name='id_waktu' type='text' value=".kdauto(waktu_kerja,WKK)." readonly>
	<input class='form-control' type='hidden' name='id_skpd' value='$_SESSION[id_skpd]' ><input class='form-control' type='hidden' name='id_ukpd' value='$_SESSION[id_ukpd]' ></td>
	</tr>
	<tr>
	<td>TANGGAL</td><td>:</td><td><select  name='bulan'>
            	<option value='' selected='selected'>--Pilih bulan--</option>
				<option value='1'>Januari</option>
				<option value='2'>Februari</option>
				<option value='3'>Maret</option>
				<option value='4'>April</option>
				<option value='5'>Mei</option>
				<option value='6'>Juni</option>
				<option value='7'>Juli</option>
				<option value='8'>Agustus</option>
				<option value='9'>September</option>
				<option value='10'>Oktober</option>
				<option value='11'>November</option>
				<option value='12'>Desember</option>
			</select>
	<select name='tahun'>";
	for ($x = $tahun; $x <= $tahun+10-1; $x++) {
	    
        echo "<option value='$x' class='form-control' ";
        if ($x == $tahun){echo "selected='selected'";} 
	    echo "readonly>$x</option>";
    }
				
	echo "</select></td>
	</tr>
	<tr>
	<tr>
	<td>HARI KERJA</td><td>:</td><td><input class='form-control' name='hari' type='text'></td>
	</tr>
	<tr>
	<td></td><td></td><td><input type=submit value=Simpan>
	<input type=button value=Batal onclick=self.history.back()>
	</td>
	</tr>
	</table>
	</form>
	";
	break;
	
	case "edit":
	$edit=mysql_query("select * from waktu_kerja where id_waktu='$_GET[id_waktu]'");
	$data=mysql_fetch_array($edit);
	$date=$data['tanggal'];
	$tanggal=date("m/d/Y",strtotime($date));
	echo "<h2>Entry Data Hari Kerja</h2>
	<form action='$aksi?module=waktu_kerja&act=edit' name='input' method='post'>
	<table>
	<tr>
	<td>ID WAKTU</td><td>:</td><td><input class='form-control' name='id_waktu' type='text' value='$data[id_waktu]' Readonly>
	<input class='form-control' type='hidden' name='id_skpd' value='$_SESSION[id_skpd]' ><input class='form-control' type='hidden' name='id_ukpd' value='$_SESSION[id_ukpd]' ></td>
	</tr>
	<tr>
	<td>TANGGAL</td><td>:</td><td><input class='form-control' name='tanggal' type='text' value='$tanggal' id='calender'></td>
	</tr>
	<tr>
	<td>HARI KERJA</td><td>:</td><td><input class='form-control' name='hari' type='text' value='$data[hari]'></td>
	</tr>
	<tr>
	<td></td><td></td><td><input type=submit value=Update>
	<input type=button value=Batal onclick=self.history.back()>
	</td>
	</tr>
	</table>
	</form>";
	break;
	
	case "hapus":
	
	break;
}


?>