<?php 
include "../../config/koneksi.php";
include "../../config/fungsi_indotgl.php";
include "../../config/class_paging.php";
include "../../config/kode_auto.php";

$module=$_GET['module'];
$act=$_GET['act'];
$date="$_POST[tanggal]";
$tanggal=date("y-m-d",strtotime($date));
if($module=='waktu_kerja' AND $act=='input' ){
$tm="$_POST[tahun]-$_POST[bulan]-28]";
	mysql_query("insert into waktu_kerja set id_waktu='$_POST[id_waktu]', hari='$_POST[hari]',id_skpd='$_POST[id_skpd]',id_ukpd='$_POST[id_ukpd]', tanggal='$tm'");
	header('location:../../media.php?module='.$module);
}

elseif($module=='waktu_kerja' AND $act=='edit' ){
	mysql_query("update waktu_kerja set tanggal='$tanggal', hari='$_POST[hari]',id_skpd='$_POST[id_skpd]',id_ukpd='$_POST[id_ukpd]' where id_waktu='$_POST[id_waktu]'");
	header('location:../../media.php?module='.$module);
}

elseif($module=='waktu_kerja' AND $act=='hapus' ){
	mysql_query("delete from waktu_kerja where id_waktu='$_GET[id_waktu]'");
	header('location:../../media.php?module='.$module);
}


?>