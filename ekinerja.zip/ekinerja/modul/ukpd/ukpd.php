<?php

$aksi="modul/ukpd/aksi_ukpd.php";

switch($_GET[act]){
	default:
	$tampil=mysql_query("select * from ukpd order by id_ukpd DESC");
	echo "<h2 class='head'>DATA UKPD</h2>
	<div>
	<input type=button value='Tambah Data' onclick=\"window.location.href='?module=ukpd&act=input';\">
	</div>
	<table class='table table-bordered table-hover table-striped'>
	<thead>
  <tr>
    <td>No</td>
    <td>Id UKPD</td>
    <td>Nama UKPD</td>
	<td>Control</td>
  </tr>
  </thead>";
  $no=1;
  while($dt=mysql_fetch_array($tampil)){
  echo "<tr>
    <td>$no</td>
    <td>$dt[id_ukpd]</td>
    <td>$dt[n_ukpd]</td>
	<td><span><a href='?module=ukpd&act=edit&id_ukpd=$dt[id_ukpd]'>Edit</a></span><span>
	<a href=\"$aksi?module=ukpd&act=hapus&id_ukpd=$dt[id_ukpd]\" onClick=\"return confirm('Apakah Anda benar-benar mau menghapusnya?')\">Hapus</a></span></td>
  </tr>";
  $no++;
  }
echo "  
</table>
	";
	
	break;
	
	case "input":
	echo "<h2 class='head'>Entry Data UKPD</h2>
	<form action='$aksi?module=ukpd&act=input' method='post'>
	<div class='panel-body'> 
            <div class='table-responsive'> 
	<table>
	<tr>
	<td>ID UKPD</td><td>:</td><td><input class='form-control' name='id_ukpd' type='text' ></td>
	</tr>
	<tr>
	<td>NAMA UKPD</td><td>:</td><td><input class='form-control' name='n_ukpd' type='text' value='$data[n_skpd]'></td>
	</tr>
	<tr>
	<td></td><td></td><td><input type=submit value=Simpan>
	<input type=button value=Batal onclick=self.history.back()>
	</td>
	</tr>
	</table>
	</form>
	";
	break;
	
	case "edit":
	$edit=mysql_query("select * from ukpd where id_ukpd='$_GET[id_ukpd]'");
	$data=mysql_fetch_array($edit);
	echo "<h2>Entry Data UKPD</h2>
	<form action='$aksi?module=ukpd&act=edit' method='post'>
	<table>
	<tr>
	<td>ID UKPD</td><td>:</td><td><input class='form-control' name='id_ukpd' type='text' value='$data[id_ukpd]' Readonly></td>
	</tr>
	<tr>
	<td>NAMA UKPD</td><td>:</td><td><input class='form-control' name='n_ukpd' type='text' value='$data[n_ukpd]'></td>
	</tr>
	<tr>
	<td></td><td></td><td><input type=submit value=Update>
	<input type=button value=Batal onclick=self.history.back()>
	</td>
	</tr>
	</table>
	</form>";
	break;
	
	case "hapus":
	
	break;
}


?>