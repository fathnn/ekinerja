<?php 
include "../../config/koneksi.php";
include "../../config/fungsi_indotgl.php";
include "../../config/class_paging.php";
include "../../config/kode_auto.php";

$module=$_GET['module'];
$act=$_GET['act'];


if($module=='ukpd' AND $act=='input' ){
	mysql_query("insert into ukpd set id_ukpd='$_POST[id_ukpd]', n_ukpd='$_POST[n_ukpd]'");
	header('location:../../media.php?module='.$module);
}

elseif($module=='ukpd' AND $act=='edit' ){
	mysql_query("update ukpd set n_ukpd='$_POST[n_ukpd]' where id_ukpd='$_POST[id_ukpd]'");
	header('location:../../media.php?module='.$module);
}

elseif($module=='ukpd' AND $act=='hapus' ){
	mysql_query("delete from ukpd where id_ukpd='$_GET[id_ukpd]'");
	header('location:../../media.php?module='.$module);
}

?>