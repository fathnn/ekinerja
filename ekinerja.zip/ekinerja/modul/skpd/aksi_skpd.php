<?php 
include "../../config/koneksi.php";
include "../../config/fungsi_indotgl.php";
include "../../config/class_paging.php";
include "../../config/kode_auto.php";

$module=$_GET['module'];
$act=$_GET['act'];


if($module=='skpd' AND $act=='input' ){
	mysql_query("insert into skpd set id_skpd='$_POST[id_skpd]', n_skpd='$_POST[n_skpd]'");
	header('location:../../media.php?module='.$module);
}

elseif($module=='skpd' AND $act=='edit' ){
	mysql_query("update skpd set n_skpd='$_POST[n_skpd]' where id_skpd='$_POST[id_skpd]'");
	header('location:../../media.php?module='.$module);
}

elseif($module=='skpd' AND $act=='hapus' ){
	mysql_query("delete from skpd where id_skpd='$_GET[id_skpd]'");
	header('location:../../media.php?module='.$module);
}


?>