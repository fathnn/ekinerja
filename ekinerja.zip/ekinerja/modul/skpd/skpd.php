<?php

$aksi="modul/skpd/aksi_skpd.php";

switch($_GET[act]){
	default:
	$tampil=mysql_query("select * from skpd order by id_skpd DESC");
	echo "<h2 class='head'>DATA SKPD</h2>
	<div>
	<input type=button value='Tambah Data' onclick=\"window.location.href='?module=skpd&act=input';\">
	</div>
	<table class='table table-bordered table-hover table-striped'>
	<thead>
  <tr>
    <td>No</td>
    <td>Id SKPD</td>
    <td>Nama SKPD</td>
	<td>Control</td>
  </tr>
  </thead>";
  $no=1;
  while($dt=mysql_fetch_array($tampil)){
  echo "<tr>
    <td>$no</td>
    <td>$dt[id_skpd]</td>
    <td>$dt[n_skpd]</td>
	<td><span><a href='?module=skpd&act=edit&id_skpd=$dt[id_skpd]'>Edit</a></span><span>
	<a href=\"$aksi?module=skpd&act=hapus&id=$dt[id_skpd]\" onClick=\"return confirm('Apakah Anda benar-benar mau menghapusnya?')\">Hapus</a></span></td>
  </tr>";
  $no++;
  }
echo "  
</table>
	";
	
	break;
	
	case "input":
	echo "<h2 class='head'>Entry Data SKPD</h2>
	<form action='$aksi?module=skpd&act=input' method='post'>
	<div class='panel-body'> 
            <div class='table-responsive'> 
	<table>
	<tr>
	<td>ID SKPD</td><td>:</td><td><input class='form-control' name='id_skpd' type='text' ></td>
	</tr>
	<tr>
	<td>NAMA SKPD</td><td>:</td><td><input class='form-control' name='n_skpd' type='text' ></td>
	</tr>
	<tr>
	<td></td><td></td><td><input type=submit value=Simpan>
	<input type=button value=Batal onclick=self.history.back()>
	</td>
	</tr>
	</table>
	</form>
	";
	break;
	
	case "edit":
	$edit=mysql_query("select * from skpd where id_skpd='$_GET[id_skpd]'");
	$data=mysql_fetch_array($edit);
	echo "<h2>Entry Data SKPD</h2>
	<form action='$aksi?module=skpd&act=edit' method='post'>
	<table>
	<tr>
	<td>ID SKPD</td><td>:</td><td><input class='form-control' name='id_skpd' type='text' value='$data[id_skpd]' Readonly></td>
	</tr>
	<tr>
	<td>NAMA SKPD</td><td>:</td><td><input class='form-control' name='n_skpd' type='text' value='$data[n_skpd]'></td>
	</tr>
	<tr>
	<td></td><td></td><td><input type=submit value=Update>
	<input type=button value=Batal onclick=self.history.back()>
	</td>
	</tr>
	</table>
	</form>";
	break;
	
	case "hapus":
	
	break;
}


?>