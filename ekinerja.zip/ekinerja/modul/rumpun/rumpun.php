<?php
error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
$aksi="modul/rumpun/aksi_rumpun.php";

switch($_GET[act]){
	default:
	$tampil=mysql_query("select * from rumpun where id_ukpd LIKE '%$_SESSION[id_ukpd]%' order by id_rumpun DESC");
	echo "<h2 class='head'>DATA RUMPUN JABATAN</h2>
	<div>
	<input type=button value='Tambah Data' onclick=\"window.location.href='?module=rumpun&act=input';\">
	</div>
	<table class='table table-bordered table-hover table-striped'>
	<thead>
  <tr>
    <td>No</td>
    <td>Id Rumpun</td>
    <td>Nama Rumpun</td>
	<td>Nilai</td>
	<td>Control</td>
  </tr>
  </thead>";
  $no=1;
  while($dt=mysql_fetch_array($tampil)){
  echo "<tr>
    <td>$no</td>
    <td>$dt[id_rumpun]</td>
    <td>$dt[n_rumpun]</td>
	<td>$dt[nilai]</td>
	<td><span><a href='?module=rumpun&act=edit&id_rumpun=$dt[id_rumpun]'>Edit</a></span><span>
	<a href=\"$aksi?module=rumpun&act=hapus&id_rumpun=$dt[id_rumpun]\" onClick=\"return confirm('Apakah Anda benar-benar mau menghapusnya?')\">Hapus</a></span></td>
  </tr>";
  $no++;
  }
echo "  
</table>
	";
	
	break;
	
	case "input":
	echo "<h2 class='head'>Entry Data Rumpun Jabatan</h2>
	<form action='$aksi?module=rumpun&act=input' method='post'>
	<div class='panel-body'> 
            <div class='table-responsive'> 
	<table>
	<tr>
	<td>ID RUMPUN</td><td>:</td><td><input class='form-control' name='id_rumpun' type='text' value=".kdauto('rumpun','R')." readonly>
	<input class='form-control' type='hidden' name='id_skpd' value='$_SESSION[id_skpd]' ><input class='form-control' type='hidden' name='id_ukpd' value='$_SESSION[id_ukpd]' ></td>
	</tr>
	<tr>
	<td>Nama Rumpun</td><td>:</td><td>
	<select class='form-control' name='n_rumpun'>
		<option value='none' selected='selected'>-Pilih-</option>
				<option value='Dokter Spesialis Bedah'>JFT Dokter Spesialis Bedah</option>
				<option value='Dokter Spesialis Non Bedah'>JFT Dokter Spesialis Non Bedah</option>
				<option value='Dokter Spesialis Penunjang'>JFT Dokter Spesialis Penunjang</option>
				<option value='Dokter Umum / Dokter Gigi'>JFT Dokter Umum / Dokter Gigi</option>
				<option value='Apoteker / Ners'>JFT Apoteker / Ners</option>
				<option value='Radiologi/Analis/DIV/DIII Kes'>JFT Radiologi/Analis/DIV/DIII Kes</option>
				<option value='Teknis Tingkat Ahli'>JFT Teknis Tingkat Ahli</option>
				<option value='Teknis Tingkat Terampil'>JFT Teknis Tingkat Terampil</option>
				
				<option value='Administrasi Tingkat Ahli'>JFU Administrasi Tingkat Ahli</option>
				<option value='Administrasi Tingkat Terampil'>JFU Administrasi Tingkat Terampil</option>
				<option value='Operasional Tingkat Ahli'>JFU Operasional Tingkat Ahli</option>
				<option value='Operasional Tingkat Terampil'>JFU Operasional Tingkat Terampil</option>
				<option value='Pelayanan Tingkat Ahli'>JFU Pelayanan Tingkat Ahli</option>
				<option value='Pelayanan Tingkat Terampil'>JFU Pelayanan Tingkat Terampil</option>
				</select>
	</tr>
	<tr>
	<td>NILAI PERKALIAN</td><td>:</td><td><input class='form-control' name='nilai' type='text'></td>
	</tr>
	<tr>
	<td></td><td></td><td><input type=submit value=Simpan>
	<input type=button value=Batal onclick=self.history.back()>
	</td>
	</tr>
	</table>
	</form>
	";
	break;
	
	case "edit":
	$edit=mysql_query("select * from rumpun where id_rumpun='$_GET[id_rumpun]'");
	$data=mysql_fetch_array($edit);
	echo "<h2>Entry Data Rumpun Jabatan</h2>
	<form action='$aksi?module=rumpun&act=edit' method='post'>
	<table>
	<tr>
	<td>ID RUMPUN</td><td>:</td><td><input class='form-control' name='id_rumpun' type='text' value='$data[id_rumpun]' Readonly>
	<input class='form-control' type='hidden' name='id_skpd' value='$_SESSION[id_skpd]' ><input class='form-control' type='hidden' name='id_ukpd' value='$_SESSION[id_ukpd]' ></td>
	</tr>
	<tr>
	<td>Nama Rumpun</td><td>:</td><td>
	<select class='form-control' name='n_rumpun'>
		<option value='none' selected='selected'>-Pilih-</option>
				<option value='Dokter Spesialis Bedah'>JFT Dokter Spesialis Bedah</option>
				<option value='Dokter Spesialis Non Bedah'>JFT Dokter Spesialis Non Bedah</option>
				<option value='Dokter Spesialis Penunjang'>JFT Dokter Spesialis Penunjang</option>
				<option value='Dokter Umum / Dokter Gigi'>JFT Dokter Umum / Dokter Gigi</option>
				<option value='Apoteker / Ners'>JFT Apoteker / Ners</option>
				<option value='Radiologi/Analis/DIV/DIII Kes'>JFT Radiologi/Analis/DIV/DIII Kes</option>
				<option value='Teknis Tingkat Ahli'>JFT Teknis Tingkat Ahli</option>
				<option value='Teknis Tingkat Terampil'>JFT Teknis Tingkat Terampil</option>
				
				<option value='Administrasi Tingkat Ahli'>JFU Administrasi Tingkat Ahli</option>
				<option value='Administrasi Tingkat Terampil'>JFU Administrasi Tingkat Terampil</option>
				<option value='Operasional Tingkat Ahli'>JFU Operasional Tingkat Ahli</option>
				<option value='Operasional Tingkat Terampil'>JFU Operasional Tingkat Terampil</option>
				<option value='Pelayanan Tingkat Ahli'>JFU Pelayanan Tingkat Ahli</option>
				<option value='Pelayanan Tingkat Terampil'>JFU Pelayanan Tingkat Terampil</option>
				</select>
	</tr>
	<tr>
	<td>NILAI</td><td>:</td><td><input class='form-control' name='nilai' type='text' value='$data[nilai]'></td>
	</tr>
	<tr>
	<td></td><td></td><td><input type=submit value=Update>
	<input type=button value=Batal onclick=self.history.back()>
	</td>
	</tr>
	</table>
	</form>";
	break;
	
	case "hapus":
	
	break;
}


?>