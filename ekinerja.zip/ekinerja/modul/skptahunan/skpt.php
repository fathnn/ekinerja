<script>
    function validasi(){
        var kuant        = input.kuant.value;
        var kual 			= input.kual.value;
        var waktu       = input.waktu.value;
		 var jam_akhir       = input.jam_akhir.value;
        var pesan = '';
         
        if (kuant == '') {
            kuant = '-Nama tidak boleh kosong\n';
        }
         
        
         
        if (kual == '') {
            pesan += '-SKP harus dipilih\n';
        }
         
        if (waktu == '') {
            pesan += '-Jam Mulai tidak boleh kosong\n';
        }
         
       if (jam_akhir == '') {
            pesan += '-Jam Akhir tidak boleh kosong\n';
        }
         
        if (pesan != '') {
            alert('Maaf, ada kesalahan pengisian Formulir : \n'+pesan);
            return false;
        }
    return true
    }
</script>

<?php  

error_reporting(0);
$aksi="modul/skptahunan/aksi_skpt.php";
$nip=trim($_SESSION['nip']);
switch($_GET[act]){
	default:
	echo"
<a href='?module=skptahunan&act=detail&nip=$_SESSION[nip]'>Data Sudah Selesai Di Proses lanjutkan</a>";
	
	break;
	
	case "detail";
		$tampil=mysql_query("select * from skptahunan where nip='$_GET[nip]' order by id_skptahunan desc");
	echo "<h2 class='head'>Entry Aktifitas</h2>
	<div>
	 <input type=button value='Tambah Data' onclick=\"window.location.href='?module=skptahunan&act=input';\"> 
	</div>
	<table class='table table-bordered table-hover table-striped'>
	<thead>
  <tr>
  <td>No</td>
  <td>ID SKP Tahunan</td>
    <td>Nama</td>
    <td>Nama SKP</td>
    <td>Nama Bagian</td>
	<!--<td>Kuant</td>
	<td>Kual</td>	
    <td>Waktu</td>--->		
    <td>Tanggal Buat</td>
	<td>Tanggal Edit</td>
	<td>Control</td>
  </tr>
  </thead>";
  $no=1;
  while($dt=mysql_fetch_array($tampil)){
  echo "<tr>
  <td>$no</td>
  	 <td>$dt[id_skptahunan]</td>
    <td>$dt[nip]</td>
    <td>$dt[kd_skp]</td>
    <td>$dt[id_bag]</td>
	 <!--<td>$dt[kuant]</td>
	  <td>$dt[kual]%</td>
	   <td>$dt[waktu] Menit</td>-->
	    <td>$dt[t_buat]</td>
	   <td>$dt[t_edit] </td>
	<td><!--<span><a href='?module=skptahunan&act=edit&id_skptahunan=$dt[id_skptahunan]'>Edit</a></span>--><span>
	<a href=\"$aksi?module=skptahunan&act=hapus&id_skptahunan=$dt[id_skptahunan]\" onClick=\"return confirm('Apakah Anda benar-benar mau menghapusnya?')\">Hapus</a></span></td>
  </tr>";
  $no++;
  }
echo "  
</table>
	";
	
	break;
	
	case "detailm1";
		$tampil=mysql_query("select * from skptahunan where nip='$_GET[nip]' ");
	echo "<h2 class='head'>DATA SKP TAHUNAN</h2>
	<table class='table table-bordered table-hover table-striped'>
	<thead>
  <tr>
  <td>No</td>
  <td>ID SKP Tahunan</td>
    <td>Nama</td>
    <td>Nama SKP</td>
	<td>Kuant</td>
	<td>Kual</td>
	<td>Waktu</td>
	<td>Tanggal Buat</td>
	<td>Tanggal Edit</td>
  </tr>
  </thead>";
  $no=1;
  while($dt=mysql_fetch_array($tampil)){
  	$bag=mysql_query("select * from bagian where id_bag='$dt[id_bag]'");
	$bg=mysql_fetch_array($bag);
	$nbag=$bg[n_bag];
	$pg=mysql_query("select * from user_id where userid='$dt[nip]'");
	$pgw=mysql_fetch_array($pg);
	$npg=$pgw[nama];
  echo "<tr>
  <td>$no</td>
  	 <td>$dt[id_skptahunan]</td>
    <td>$npg</td>
    <td>$dt[kd_skp]</td>
	 <td>$dt[kuant]</td>
	  <td>$dt[kual]%</td>
	   <td>$dt[waktu] Menit</td>
	    <td>$dt[t_buat]</td>
	   <td>$dt[t_edit] </td>
  </tr>";
  $no++;
  }
echo "  
</table>
	";
	
	break;
	
	case "input":
	$wakt=date('d-m-y');
	echo "<h2 class='head'>Entry Aktifitas</h2>
	<form action='$aksi?module=skptahunan&act=input' name='input' method='post'>
	<table class='tabelform'>
	<tr>
	<td>Tanggal </td><td>:</td><td colspan='2'><input class='form-control' name='t_buat' readonly value='$wakt'><input type='hidden' class='form-control' name='t_edit' readonly value=''></td>
	</tr>
	<tr>
	<td>ID SKP Tahunan</td><td>:</td><td colspan='2'><input class='form-control' name='id_skptahunan' readonly value=".kdauto('skptahunan','SKPT')."></td>
	</tr>
	<tr>
	<td>NIP</td><td>:</td><td colspan='2'><input class='form-control' name='nip' type='text' value='$_SESSION[nip]' readonly ></td>
	</tr>
	<tr>
	<td>ID Bagian</td><td>:</td><td colspan='2'><input class='form-control' name='id_bag' value='$_SESSION[id_bag]' type='text' readonly></td>
	</tr>

    <tr>
	<td class='form-group'>Nama Aktifitas</td><td>:</td><td colspan='2'>
	<input class='form-control' id='src' name='kd_skp' type='text' onkeypress='suggest(this.value);' placeholder='Search Aktifitas.. 'autocomplete='off'><div id='suggest'></div></td></tr>
	<tr>
	<!--<td class='form-group'>Waktu Efektif</td><td>:</td><td colspan='2'>
	<input class='form-control' name='waktu_e' id='nilai' type='text'  value='' readonly>";
	echo '</td></tr>';
	
	//<tr>
	//<td >Efektif</td><td>:</td><td>
	//<input class="form-control" type="text" width="30" name="waktu_e" id="prd_name" title="Menit" readonly/>
	//<script type="text/javascript">
	//<? echo $jsArray; 
	//<\script>
	//<? echo"</td>
	//</tr>
	echo"<tr>
	<td>Kuant</td><td>:</td><td colspan='2'><input class='form-control' name='kuant' type='number' placeholder='Jumlah Setahun'></td>-->
	</tr>
	<tr>
	<td></td><td></td><td align='right'><input type=submit value=Simpan></td><td>
	<input type=button value=Batal onclick=self.history.back()>
	</td>
	</tr>
	</table>
	</form>
	";
	break;
	
	case "edit":
	$wakt=date('d-m-y');
	$edit=mysql_query("select * from skptahunan where id_skptahunan='$_GET[id_skptahunan]'");
	$data=mysql_fetch_array($edit);
	echo "<h2>Entry Data SKP Tahunan</h2>
	<form action='$aksi?module=skptahunan&act=edit' method='post'>
	<table class='tabelform'>
	<td>tanggal</td><td>:</td><td colspan='2' class='form-group'><input class='form-control' name='t_edit' type='text' value='$wakt' readonly ><input class='form-control' name='t_buat' type='hidden' value='$data[t_buat]' readonly ></td>
	</tr>
	<tr>
	<td>ID SKP Tahunan</td><td>:</td><td colspan='2'><input class='form-control' name='id_skptahunan' type='text' value='$data[id_skptahunan]' readonly ></td>
	</tr>
	<tr>
	<td>NIP</td><td>:</td><td colspan='2'><input class='form-control' name='nip' type='text' value='$data[nip]' readonly ></td>
	</tr>
	<tr>
	<td>ID BAGIAN</td><td>:</td><td colspan='2'><input class='form-control' name='id_bag' type='text' value='$data[id_bag]' readonly ><input class='form-control' name='waktu_e' type='hidden' value='$data[waktu_e]' readonly ></td>
	</tr>
	<tr>
	<td class='form-group'>Nama SKP</td><td>:</td><td colspan='2'>
	<input class='form-control' id='src' name='kd_skp' value='$data[kd_skp]' type='text' onkeypress='suggest(this.value);' placeholder='Search SKP.. '><div id='suggest'></div></td></tr>
	<tr>
	<td class='form-group'>Waktu Efektif</td><td>:</td><td colspan='2'>
	<input class='form-control' name='waktu_e' id='nilai' value='$data[waktu_e]' type='text'  value='' readonly>";
	echo '</td></tr>';
	//<tr>
	//<td class='form-group'>Nama SKP</td><td>:</td><td>";
	//$result = mysql_query("select * FROM skp");
	//$jsArray = "var prdName = new Array();\n";
	//echo '<select class="form-control" name="kd_skp" onchange="document.getElementById(\'prd_name\').value = prdName[this.value]">';
	//echo '<option>--SKP--</option>';
	//while ($row = mysql_fetch_array($result)) {
    //echo '<option value="' . $row['skp'] . '">' . $row['skp'] . '</option>';
    //$jsArray .= "prdName['" . $row['skp'] . "'] = '" . addslashes($row['waktu']) . "';\n";
	//}
	//echo '</select></td></tr>';
	//
	//<tr>
	//<td >Efektif</td><td>:</td><td>
	//<input class="form-control" type="text" width="30" name="waktu_e" id="prd_name" title="Menit" readonly/>
	//<script type="text/javascript">
	//<? echo $jsArray; 
	//<\script>
	//<? echo"</td>
	//</tr>
	echo"
	<tr>
	<td>KUANT</td><td>:</td><td colspan='2'><input class='form-control' name='kuant' type='text' value='$data[kuant]'></td>
	</tr>
	<tr>
	<td></td><td></td><td align='right'><input type=submit value=Update></td><td>
	<input type=button value=Batal onclick=self.history.back()>
	</td>
	</tr>
	</table>
	</form>";
	break;
	
}


?>