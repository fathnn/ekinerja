<?php 
include "../../config/koneksi.php";
include "../../config/fungsi_indotgl.php";
include "../../config/class_paging.php";
include "../../config/kode_auto.php";
include "../../config/fungsi_thumb.php";

$module=$_GET['module'];
$act=$_GET['act'];

if($module=='skptahunan' AND $act=='hapus' ){ 
	mysql_query("delete from skptahunan where id_skptahunan='$_GET[id_skptahunan]'");
	header('location:../../media.php?module='.$module);
}

if($module=='skptahunan' AND $act=='input' ){
$kual=100;
$waktu=$_POST['kuant']*$_POST['waktu_e'];
	mysql_query("insert into skptahunan set id_skptahunan='$_POST[id_skptahunan]',
										   nip='$_POST[nip]',
										   kd_skp='$_POST[kd_skp]',
										   id_bag='$_POST[id_bag]',
										   kuant='$_POST[kuant]',
										   kual='$kual',
										   waktu='$waktu',
										   t_buat='$_POST[t_buat]',
										   t_edit='$_POST[t_edit]',
										   waktu_e='$_POST[waktu_e]'
										   ");
	header('location:../../media.php?module='.$module);
}

elseif($module=='skptahunan' AND $act=='edit' ){
$kual=100;
$waktu=$_POST['kuant']*$_POST['waktu_e'];
   	mysql_query("update skptahunan set 	   kd_skp='$_POST[kd_skp]',
										   id_bag='$_POST[id_bag]',
										   kuant='$_POST[kuant]',
										   kual='$kual',
										   waktu='$waktu',
										   t_buat='$_POST[t_buat]',
										   t_edit='$_POST[t_edit]',
										   waktu_e='$_POST[waktu_e]'
										   where id_skptahunan='$_POST[id_skptahunan]'
										   ");
	header('location:../../media.php?module='.$module);
}

elseif($module=='skptahunan' AND $act=='hapus' ){
	mysql_query("delete from skptahunan where id_skptahunan = '$_GET[id_skptahunan]'");
	header('location:../../media.php?module='.$module);
}


?>