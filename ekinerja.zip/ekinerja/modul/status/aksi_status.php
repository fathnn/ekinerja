<?php 
include "../../config/koneksi.php";
include "../../config/fungsi_indotgl.php";
include "../../config/class_paging.php";
include "../../config/kode_auto.php";

$module=$_GET['module'];
$act=$_GET['act'];


if($module=='status' AND $act=='input' ){
	mysql_query("insert into rumpun set id_rumpun='$_POST[id_rumpun]', n_rumpun='$_POST[n_rumpun]', nilai='$_POST[nilai]'");
	header('location:../../media.php?module='.$module);
}


elseif($module=='status' AND $act=='editstatus' ){
	mysql_query("update status set n_status='$_POST[n_status]', nilai='$_POST[nilai]' where id_status='$_POST[id_status]'");
	header('location:../../media.php?module='.$module);
}
elseif($module=='status' AND $act=='hapus_s' ){
	mysql_query("delete from status where id_status='$_GET[id_status]'");
	header('location:../../media.php?module='.$module);
}
elseif($module=='status' AND $act=='inputstatus' ){
	mysql_query("insert into status set id_status='$_POST[id_status]', n_status='$_POST[n_status]',id_skpd='$_POST[id_skpd]',id_ukpd='$_POST[id_ukpd]', nilai='$_POST[nilai]'");
	header('location:../../media.php?module='.$module);
}

?>