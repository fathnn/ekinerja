<?php
error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
$aksi="modul/status/aksi_status.php";

switch($_GET[act]){
	default:
	$tampil=mysql_query("select * from status where id_ukpd LIKE '%$_SESSION[id_ukpd]%' order by id_status DESC");
	echo "<h2 class='head'>DATA STATUS</h2>
	<div>
	<input type=button value='Tambah Data' onclick=\"window.location.href='?module=status&act=inputstatus';\">
	</div>
	<table class='table table-bordered table-hover table-striped'>
	<thead>
  <tr>
    <td>No</td>
    <td>Id Status</td>
    <td>Nama Status</td>
	<td>Nilai</td>
	<td>Control</td>
  </tr>
  </thead>";
  $no=1;
  while($dt=mysql_fetch_array($tampil)){
  echo "<tr>
    <td>$no</td>
    <td>$dt[id_status]</td>
    <td>$dt[n_status]</td>
	<td>$dt[nilai]</td>
	<td><span><a href='?module=status&act=editstatus&id_status=$dt[id_status]'>Edit</a></span><span>
	<a href=\"$aksi?module=status&act=hapus_s&id_status=$dt[id_status]\" onClick=\"return confirm('Apakah Anda benar-benar mau menghapusnya?')\">Hapus</a></span></td>
  </tr>";
  $no++;
  }
echo "  
</table>
	";
	
	break;
	
	
	case "inputstatus":
	echo "<h2 class='head'>Entry Data Status</h2>
	<form action='$aksi?module=status&act=inputstatus' method='post'>
	<div class='panel-body'> 
            <div class='table-responsive'> 
	<table>
	<tr>
	<td>ID STATUS</td><td>:</td><td><input class='form-control' name='id_status' type='text' value=".kdauto('status','S')." readonly>
	<input class='form-control' type='hidden' name='id_skpd' value='$_SESSION[id_skpd]' ><input class='form-control' type='hidden' name='id_ukpd' value='$_SESSION[id_ukpd]' ></td>
	</tr>
	<tr>
	<td>NAMA STATUS</td><td>:</td><td><input class='form-control' name='n_status' type='text'></td>
	</tr>
	<tr>
	<td>NILAI PERKALIAN</td><td>:</td><td><input class='form-control' name='nilai' type='text'></td>
	</tr>
	<tr>
	<td></td><td></td><td><input type=submit value=Simpan>
	<input type=button value=Batal onclick=self.history.back()>
	</td>
	</tr>
	</table>
	</form>
	";
	break;
	
	
	case "editstatus":
	$edit=mysql_query("select * from status where id_status='$_GET[id_status]'");
	$data=mysql_fetch_array($edit);
	echo "<h2>Entry Data Status</h2>
	<form action='$aksi?module=status&act=editstatus' method='post'>
	<table>
	<tr>
	<td>ID STATUS</td><td>:</td><td><input class='form-control' name='id_status' type='text' value='$data[id_status]' Readonly>
	<input class='form-control' type='hidden' name='id_skpd' value='$_SESSION[id_skpd]' ><input class='form-control' type='hidden' name='id_ukpd' value='$_SESSION[id_ukpd]' ></td>
	</tr>
	<tr>
	<td>NAMA STATUS</td><td>:</td><td><input class='form-control' name='n_status' type='text' value='$data[n_status]'></td>
	</tr>
	<tr>
	<td>NILAI</td><td>:</td><td><input class='form-control' name='nilai' type='text' value='$data[nilai]'></td>
	</tr>
	<tr>
	<td></td><td></td><td><input type=submit value=Update>
	<input type=button value=Batal onclick=self.history.back()>
	</td>
	</tr>
	</table>
	</form>";
	break;
	
	case "hapus":
	
	break;
}


?>