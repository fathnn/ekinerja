<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<?
	$tgl=mktime(0, 0, 0, date("m")-1, date("d"), date("Y"));
	$date=date("y-m-30", $tgl);
	$per=explode('-',$date);
	$bln=$per[1];
	echo"$bln";
 ?>
</body>
</html>
